"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.OperationInfo = exports.WaitOperationRequest = exports.DeleteOperationRequest = exports.CancelOperationRequest = exports.ListOperationsResponse = exports.ListOperationsRequest = exports.GetOperationRequest = exports.Operation = void 0;
//@ts-nocheck
const duration_1 = require("../protobuf/duration");
const any_1 = require("../protobuf/any");
const status_1 = require("../rpc/status");
const binary_1 = require("../../binary");
function createBaseOperation() {
    return {
        name: "",
        metadata: undefined,
        done: false,
        error: undefined,
        response: undefined
    };
}
exports.Operation = {
    typeUrl: "/google.longrunning.Operation",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.name !== "") {
            writer.uint32(10).string(message.name);
        }
        if (message.metadata !== undefined) {
            any_1.Any.encode(message.metadata, writer.uint32(18).fork()).ldelim();
        }
        if (message.done === true) {
            writer.uint32(24).bool(message.done);
        }
        if (message.error !== undefined) {
            status_1.Status.encode(message.error, writer.uint32(34).fork()).ldelim();
        }
        if (message.response !== undefined) {
            any_1.Any.encode(message.response, writer.uint32(42).fork()).ldelim();
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseOperation();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.name = reader.string();
                    break;
                case 2:
                    message.metadata = any_1.Any.decode(reader, reader.uint32());
                    break;
                case 3:
                    message.done = reader.bool();
                    break;
                case 4:
                    message.error = status_1.Status.decode(reader, reader.uint32());
                    break;
                case 5:
                    message.response = any_1.Any.decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseOperation();
        message.name = object.name ?? "";
        message.metadata = object.metadata !== undefined && object.metadata !== null ? any_1.Any.fromPartial(object.metadata) : undefined;
        message.done = object.done ?? false;
        message.error = object.error !== undefined && object.error !== null ? status_1.Status.fromPartial(object.error) : undefined;
        message.response = object.response !== undefined && object.response !== null ? any_1.Any.fromPartial(object.response) : undefined;
        return message;
    },
    fromAmino(object) {
        const message = createBaseOperation();
        if (object.name !== undefined && object.name !== null) {
            message.name = object.name;
        }
        if (object.metadata !== undefined && object.metadata !== null) {
            message.metadata = any_1.Any.fromAmino(object.metadata);
        }
        if (object.done !== undefined && object.done !== null) {
            message.done = object.done;
        }
        if (object.error !== undefined && object.error !== null) {
            message.error = status_1.Status.fromAmino(object.error);
        }
        if (object.response !== undefined && object.response !== null) {
            message.response = any_1.Any.fromAmino(object.response);
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.name = message.name === "" ? undefined : message.name;
        obj.metadata = message.metadata ? any_1.Any.toAmino(message.metadata) : undefined;
        obj.done = message.done === false ? undefined : message.done;
        obj.error = message.error ? status_1.Status.toAmino(message.error) : undefined;
        obj.response = message.response ? any_1.Any.toAmino(message.response) : undefined;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.Operation.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.Operation.decode(message.value);
    },
    toProto(message) {
        return exports.Operation.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.longrunning.Operation",
            value: exports.Operation.encode(message).finish()
        };
    }
};
function createBaseGetOperationRequest() {
    return {
        name: ""
    };
}
exports.GetOperationRequest = {
    typeUrl: "/google.longrunning.GetOperationRequest",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.name !== "") {
            writer.uint32(10).string(message.name);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseGetOperationRequest();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.name = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseGetOperationRequest();
        message.name = object.name ?? "";
        return message;
    },
    fromAmino(object) {
        const message = createBaseGetOperationRequest();
        if (object.name !== undefined && object.name !== null) {
            message.name = object.name;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.name = message.name === "" ? undefined : message.name;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.GetOperationRequest.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.GetOperationRequest.decode(message.value);
    },
    toProto(message) {
        return exports.GetOperationRequest.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.longrunning.GetOperationRequest",
            value: exports.GetOperationRequest.encode(message).finish()
        };
    }
};
function createBaseListOperationsRequest() {
    return {
        name: "",
        filter: "",
        pageSize: 0,
        pageToken: ""
    };
}
exports.ListOperationsRequest = {
    typeUrl: "/google.longrunning.ListOperationsRequest",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.name !== "") {
            writer.uint32(34).string(message.name);
        }
        if (message.filter !== "") {
            writer.uint32(10).string(message.filter);
        }
        if (message.pageSize !== 0) {
            writer.uint32(16).int32(message.pageSize);
        }
        if (message.pageToken !== "") {
            writer.uint32(26).string(message.pageToken);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseListOperationsRequest();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 4:
                    message.name = reader.string();
                    break;
                case 1:
                    message.filter = reader.string();
                    break;
                case 2:
                    message.pageSize = reader.int32();
                    break;
                case 3:
                    message.pageToken = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseListOperationsRequest();
        message.name = object.name ?? "";
        message.filter = object.filter ?? "";
        message.pageSize = object.pageSize ?? 0;
        message.pageToken = object.pageToken ?? "";
        return message;
    },
    fromAmino(object) {
        const message = createBaseListOperationsRequest();
        if (object.name !== undefined && object.name !== null) {
            message.name = object.name;
        }
        if (object.filter !== undefined && object.filter !== null) {
            message.filter = object.filter;
        }
        if (object.page_size !== undefined && object.page_size !== null) {
            message.pageSize = object.page_size;
        }
        if (object.page_token !== undefined && object.page_token !== null) {
            message.pageToken = object.page_token;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.name = message.name === "" ? undefined : message.name;
        obj.filter = message.filter === "" ? undefined : message.filter;
        obj.page_size = message.pageSize === 0 ? undefined : message.pageSize;
        obj.page_token = message.pageToken === "" ? undefined : message.pageToken;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.ListOperationsRequest.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.ListOperationsRequest.decode(message.value);
    },
    toProto(message) {
        return exports.ListOperationsRequest.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.longrunning.ListOperationsRequest",
            value: exports.ListOperationsRequest.encode(message).finish()
        };
    }
};
function createBaseListOperationsResponse() {
    return {
        operations: [],
        nextPageToken: ""
    };
}
exports.ListOperationsResponse = {
    typeUrl: "/google.longrunning.ListOperationsResponse",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        for (const v of message.operations) {
            exports.Operation.encode(v, writer.uint32(10).fork()).ldelim();
        }
        if (message.nextPageToken !== "") {
            writer.uint32(18).string(message.nextPageToken);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseListOperationsResponse();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.operations.push(exports.Operation.decode(reader, reader.uint32()));
                    break;
                case 2:
                    message.nextPageToken = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseListOperationsResponse();
        message.operations = object.operations?.map(e => exports.Operation.fromPartial(e)) || [];
        message.nextPageToken = object.nextPageToken ?? "";
        return message;
    },
    fromAmino(object) {
        const message = createBaseListOperationsResponse();
        message.operations = object.operations?.map(e => exports.Operation.fromAmino(e)) || [];
        if (object.next_page_token !== undefined && object.next_page_token !== null) {
            message.nextPageToken = object.next_page_token;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        if (message.operations) {
            obj.operations = message.operations.map(e => e ? exports.Operation.toAmino(e) : undefined);
        }
        else {
            obj.operations = message.operations;
        }
        obj.next_page_token = message.nextPageToken === "" ? undefined : message.nextPageToken;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.ListOperationsResponse.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.ListOperationsResponse.decode(message.value);
    },
    toProto(message) {
        return exports.ListOperationsResponse.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.longrunning.ListOperationsResponse",
            value: exports.ListOperationsResponse.encode(message).finish()
        };
    }
};
function createBaseCancelOperationRequest() {
    return {
        name: ""
    };
}
exports.CancelOperationRequest = {
    typeUrl: "/google.longrunning.CancelOperationRequest",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.name !== "") {
            writer.uint32(10).string(message.name);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseCancelOperationRequest();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.name = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseCancelOperationRequest();
        message.name = object.name ?? "";
        return message;
    },
    fromAmino(object) {
        const message = createBaseCancelOperationRequest();
        if (object.name !== undefined && object.name !== null) {
            message.name = object.name;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.name = message.name === "" ? undefined : message.name;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.CancelOperationRequest.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.CancelOperationRequest.decode(message.value);
    },
    toProto(message) {
        return exports.CancelOperationRequest.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.longrunning.CancelOperationRequest",
            value: exports.CancelOperationRequest.encode(message).finish()
        };
    }
};
function createBaseDeleteOperationRequest() {
    return {
        name: ""
    };
}
exports.DeleteOperationRequest = {
    typeUrl: "/google.longrunning.DeleteOperationRequest",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.name !== "") {
            writer.uint32(10).string(message.name);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseDeleteOperationRequest();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.name = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseDeleteOperationRequest();
        message.name = object.name ?? "";
        return message;
    },
    fromAmino(object) {
        const message = createBaseDeleteOperationRequest();
        if (object.name !== undefined && object.name !== null) {
            message.name = object.name;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.name = message.name === "" ? undefined : message.name;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.DeleteOperationRequest.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.DeleteOperationRequest.decode(message.value);
    },
    toProto(message) {
        return exports.DeleteOperationRequest.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.longrunning.DeleteOperationRequest",
            value: exports.DeleteOperationRequest.encode(message).finish()
        };
    }
};
function createBaseWaitOperationRequest() {
    return {
        name: "",
        timeout: undefined
    };
}
exports.WaitOperationRequest = {
    typeUrl: "/google.longrunning.WaitOperationRequest",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.name !== "") {
            writer.uint32(10).string(message.name);
        }
        if (message.timeout !== undefined) {
            duration_1.Duration.encode(message.timeout, writer.uint32(18).fork()).ldelim();
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseWaitOperationRequest();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.name = reader.string();
                    break;
                case 2:
                    message.timeout = duration_1.Duration.decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseWaitOperationRequest();
        message.name = object.name ?? "";
        message.timeout = object.timeout !== undefined && object.timeout !== null ? duration_1.Duration.fromPartial(object.timeout) : undefined;
        return message;
    },
    fromAmino(object) {
        const message = createBaseWaitOperationRequest();
        if (object.name !== undefined && object.name !== null) {
            message.name = object.name;
        }
        if (object.timeout !== undefined && object.timeout !== null) {
            message.timeout = duration_1.Duration.fromAmino(object.timeout);
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.name = message.name === "" ? undefined : message.name;
        obj.timeout = message.timeout ? duration_1.Duration.toAmino(message.timeout) : undefined;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.WaitOperationRequest.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.WaitOperationRequest.decode(message.value);
    },
    toProto(message) {
        return exports.WaitOperationRequest.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.longrunning.WaitOperationRequest",
            value: exports.WaitOperationRequest.encode(message).finish()
        };
    }
};
function createBaseOperationInfo() {
    return {
        responseType: "",
        metadataType: ""
    };
}
exports.OperationInfo = {
    typeUrl: "/google.longrunning.OperationInfo",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.responseType !== "") {
            writer.uint32(10).string(message.responseType);
        }
        if (message.metadataType !== "") {
            writer.uint32(18).string(message.metadataType);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseOperationInfo();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.responseType = reader.string();
                    break;
                case 2:
                    message.metadataType = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseOperationInfo();
        message.responseType = object.responseType ?? "";
        message.metadataType = object.metadataType ?? "";
        return message;
    },
    fromAmino(object) {
        const message = createBaseOperationInfo();
        if (object.response_type !== undefined && object.response_type !== null) {
            message.responseType = object.response_type;
        }
        if (object.metadata_type !== undefined && object.metadata_type !== null) {
            message.metadataType = object.metadata_type;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.response_type = message.responseType === "" ? undefined : message.responseType;
        obj.metadata_type = message.metadataType === "" ? undefined : message.metadataType;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.OperationInfo.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.OperationInfo.decode(message.value);
    },
    toProto(message) {
        return exports.OperationInfo.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.longrunning.OperationInfo",
            value: exports.OperationInfo.encode(message).finish()
        };
    }
};
