"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.LocalizedMessage = exports.Help_Link = exports.Help = exports.ResourceInfo = exports.RequestInfo = exports.BadRequest_FieldViolation = exports.BadRequest = exports.PreconditionFailure_Violation = exports.PreconditionFailure = exports.QuotaFailure_Violation = exports.QuotaFailure_Violation_QuotaDimensionsEntry = exports.QuotaFailure = exports.DebugInfo = exports.RetryInfo = exports.ErrorInfo = exports.ErrorInfo_MetadataEntry = void 0;
//@ts-nocheck
const duration_1 = require("../protobuf/duration");
const binary_1 = require("../../binary");
function createBaseErrorInfo_MetadataEntry() {
    return {
        key: "",
        value: ""
    };
}
exports.ErrorInfo_MetadataEntry = {
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.key !== "") {
            writer.uint32(10).string(message.key);
        }
        if (message.value !== "") {
            writer.uint32(18).string(message.value);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseErrorInfo_MetadataEntry();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.key = reader.string();
                    break;
                case 2:
                    message.value = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseErrorInfo_MetadataEntry();
        message.key = object.key ?? "";
        message.value = object.value ?? "";
        return message;
    },
    fromAmino(object) {
        const message = createBaseErrorInfo_MetadataEntry();
        if (object.key !== undefined && object.key !== null) {
            message.key = object.key;
        }
        if (object.value !== undefined && object.value !== null) {
            message.value = object.value;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.key = message.key === "" ? undefined : message.key;
        obj.value = message.value === "" ? undefined : message.value;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.ErrorInfo_MetadataEntry.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.ErrorInfo_MetadataEntry.decode(message.value);
    },
    toProto(message) {
        return exports.ErrorInfo_MetadataEntry.encode(message).finish();
    }
};
function createBaseErrorInfo() {
    return {
        reason: "",
        domain: "",
        metadata: {}
    };
}
exports.ErrorInfo = {
    typeUrl: "/google.rpc.ErrorInfo",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.reason !== "") {
            writer.uint32(10).string(message.reason);
        }
        if (message.domain !== "") {
            writer.uint32(18).string(message.domain);
        }
        Object.entries(message.metadata).forEach(([key, value]) => {
            exports.ErrorInfo_MetadataEntry.encode({
                key: key,
                value
            }, writer.uint32(26).fork()).ldelim();
        });
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseErrorInfo();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.reason = reader.string();
                    break;
                case 2:
                    message.domain = reader.string();
                    break;
                case 3:
                    const entry3 = exports.ErrorInfo_MetadataEntry.decode(reader, reader.uint32());
                    if (entry3.value !== undefined) {
                        message.metadata[entry3.key] = entry3.value;
                    }
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseErrorInfo();
        message.reason = object.reason ?? "";
        message.domain = object.domain ?? "";
        message.metadata = Object.entries(object.metadata ?? {}).reduce((acc, [key, value]) => {
            if (value !== undefined) {
                acc[key] = String(value);
            }
            return acc;
        }, {});
        return message;
    },
    fromAmino(object) {
        const message = createBaseErrorInfo();
        if (object.reason !== undefined && object.reason !== null) {
            message.reason = object.reason;
        }
        if (object.domain !== undefined && object.domain !== null) {
            message.domain = object.domain;
        }
        message.metadata = Object.entries(object.metadata ?? {}).reduce((acc, [key, value]) => {
            if (value !== undefined) {
                acc[key] = String(value);
            }
            return acc;
        }, {});
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.reason = message.reason === "" ? undefined : message.reason;
        obj.domain = message.domain === "" ? undefined : message.domain;
        obj.metadata = {};
        if (message.metadata) {
            Object.entries(message.metadata).forEach(([k, v]) => {
                obj.metadata[k] = v;
            });
        }
        return obj;
    },
    fromAminoMsg(object) {
        return exports.ErrorInfo.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.ErrorInfo.decode(message.value);
    },
    toProto(message) {
        return exports.ErrorInfo.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.rpc.ErrorInfo",
            value: exports.ErrorInfo.encode(message).finish()
        };
    }
};
function createBaseRetryInfo() {
    return {
        retryDelay: undefined
    };
}
exports.RetryInfo = {
    typeUrl: "/google.rpc.RetryInfo",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.retryDelay !== undefined) {
            duration_1.Duration.encode(message.retryDelay, writer.uint32(10).fork()).ldelim();
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseRetryInfo();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.retryDelay = duration_1.Duration.decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseRetryInfo();
        message.retryDelay = object.retryDelay !== undefined && object.retryDelay !== null ? duration_1.Duration.fromPartial(object.retryDelay) : undefined;
        return message;
    },
    fromAmino(object) {
        const message = createBaseRetryInfo();
        if (object.retry_delay !== undefined && object.retry_delay !== null) {
            message.retryDelay = duration_1.Duration.fromAmino(object.retry_delay);
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.retry_delay = message.retryDelay ? duration_1.Duration.toAmino(message.retryDelay) : undefined;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.RetryInfo.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.RetryInfo.decode(message.value);
    },
    toProto(message) {
        return exports.RetryInfo.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.rpc.RetryInfo",
            value: exports.RetryInfo.encode(message).finish()
        };
    }
};
function createBaseDebugInfo() {
    return {
        stackEntries: [],
        detail: ""
    };
}
exports.DebugInfo = {
    typeUrl: "/google.rpc.DebugInfo",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        for (const v of message.stackEntries) {
            writer.uint32(10).string(v);
        }
        if (message.detail !== "") {
            writer.uint32(18).string(message.detail);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseDebugInfo();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.stackEntries.push(reader.string());
                    break;
                case 2:
                    message.detail = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseDebugInfo();
        message.stackEntries = object.stackEntries?.map(e => e) || [];
        message.detail = object.detail ?? "";
        return message;
    },
    fromAmino(object) {
        const message = createBaseDebugInfo();
        message.stackEntries = object.stack_entries?.map(e => e) || [];
        if (object.detail !== undefined && object.detail !== null) {
            message.detail = object.detail;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        if (message.stackEntries) {
            obj.stack_entries = message.stackEntries.map(e => e);
        }
        else {
            obj.stack_entries = message.stackEntries;
        }
        obj.detail = message.detail === "" ? undefined : message.detail;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.DebugInfo.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.DebugInfo.decode(message.value);
    },
    toProto(message) {
        return exports.DebugInfo.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.rpc.DebugInfo",
            value: exports.DebugInfo.encode(message).finish()
        };
    }
};
function createBaseQuotaFailure() {
    return {
        violations: []
    };
}
exports.QuotaFailure = {
    typeUrl: "/google.rpc.QuotaFailure",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        for (const v of message.violations) {
            exports.QuotaFailure_Violation.encode(v, writer.uint32(10).fork()).ldelim();
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseQuotaFailure();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.violations.push(exports.QuotaFailure_Violation.decode(reader, reader.uint32()));
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseQuotaFailure();
        message.violations = object.violations?.map(e => exports.QuotaFailure_Violation.fromPartial(e)) || [];
        return message;
    },
    fromAmino(object) {
        const message = createBaseQuotaFailure();
        message.violations = object.violations?.map(e => exports.QuotaFailure_Violation.fromAmino(e)) || [];
        return message;
    },
    toAmino(message) {
        const obj = {};
        if (message.violations) {
            obj.violations = message.violations.map(e => e ? exports.QuotaFailure_Violation.toAmino(e) : undefined);
        }
        else {
            obj.violations = message.violations;
        }
        return obj;
    },
    fromAminoMsg(object) {
        return exports.QuotaFailure.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.QuotaFailure.decode(message.value);
    },
    toProto(message) {
        return exports.QuotaFailure.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.rpc.QuotaFailure",
            value: exports.QuotaFailure.encode(message).finish()
        };
    }
};
function createBaseQuotaFailure_Violation_QuotaDimensionsEntry() {
    return {
        key: "",
        value: ""
    };
}
exports.QuotaFailure_Violation_QuotaDimensionsEntry = {
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.key !== "") {
            writer.uint32(10).string(message.key);
        }
        if (message.value !== "") {
            writer.uint32(18).string(message.value);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseQuotaFailure_Violation_QuotaDimensionsEntry();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.key = reader.string();
                    break;
                case 2:
                    message.value = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseQuotaFailure_Violation_QuotaDimensionsEntry();
        message.key = object.key ?? "";
        message.value = object.value ?? "";
        return message;
    },
    fromAmino(object) {
        const message = createBaseQuotaFailure_Violation_QuotaDimensionsEntry();
        if (object.key !== undefined && object.key !== null) {
            message.key = object.key;
        }
        if (object.value !== undefined && object.value !== null) {
            message.value = object.value;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.key = message.key === "" ? undefined : message.key;
        obj.value = message.value === "" ? undefined : message.value;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.QuotaFailure_Violation_QuotaDimensionsEntry.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.QuotaFailure_Violation_QuotaDimensionsEntry.decode(message.value);
    },
    toProto(message) {
        return exports.QuotaFailure_Violation_QuotaDimensionsEntry.encode(message).finish();
    }
};
function createBaseQuotaFailure_Violation() {
    return {
        subject: "",
        description: "",
        apiService: "",
        quotaMetric: "",
        quotaId: "",
        quotaDimensions: {},
        quotaValue: BigInt(0),
        futureQuotaValue: undefined
    };
}
exports.QuotaFailure_Violation = {
    typeUrl: "/google.rpc.Violation",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.subject !== "") {
            writer.uint32(10).string(message.subject);
        }
        if (message.description !== "") {
            writer.uint32(18).string(message.description);
        }
        if (message.apiService !== "") {
            writer.uint32(26).string(message.apiService);
        }
        if (message.quotaMetric !== "") {
            writer.uint32(34).string(message.quotaMetric);
        }
        if (message.quotaId !== "") {
            writer.uint32(42).string(message.quotaId);
        }
        Object.entries(message.quotaDimensions).forEach(([key, value]) => {
            exports.QuotaFailure_Violation_QuotaDimensionsEntry.encode({
                key: key,
                value
            }, writer.uint32(50).fork()).ldelim();
        });
        if (message.quotaValue !== BigInt(0)) {
            writer.uint32(56).int64(message.quotaValue);
        }
        if (message.futureQuotaValue !== undefined) {
            writer.uint32(64).int64(message.futureQuotaValue);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseQuotaFailure_Violation();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.subject = reader.string();
                    break;
                case 2:
                    message.description = reader.string();
                    break;
                case 3:
                    message.apiService = reader.string();
                    break;
                case 4:
                    message.quotaMetric = reader.string();
                    break;
                case 5:
                    message.quotaId = reader.string();
                    break;
                case 6:
                    const entry6 = exports.QuotaFailure_Violation_QuotaDimensionsEntry.decode(reader, reader.uint32());
                    if (entry6.value !== undefined) {
                        message.quotaDimensions[entry6.key] = entry6.value;
                    }
                    break;
                case 7:
                    message.quotaValue = reader.int64();
                    break;
                case 8:
                    message.futureQuotaValue = reader.int64();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseQuotaFailure_Violation();
        message.subject = object.subject ?? "";
        message.description = object.description ?? "";
        message.apiService = object.apiService ?? "";
        message.quotaMetric = object.quotaMetric ?? "";
        message.quotaId = object.quotaId ?? "";
        message.quotaDimensions = Object.entries(object.quotaDimensions ?? {}).reduce((acc, [key, value]) => {
            if (value !== undefined) {
                acc[key] = String(value);
            }
            return acc;
        }, {});
        message.quotaValue = object.quotaValue !== undefined && object.quotaValue !== null ? BigInt(object.quotaValue.toString()) : BigInt(0);
        message.futureQuotaValue = object.futureQuotaValue !== undefined && object.futureQuotaValue !== null ? BigInt(object.futureQuotaValue.toString()) : undefined;
        return message;
    },
    fromAmino(object) {
        const message = createBaseQuotaFailure_Violation();
        if (object.subject !== undefined && object.subject !== null) {
            message.subject = object.subject;
        }
        if (object.description !== undefined && object.description !== null) {
            message.description = object.description;
        }
        if (object.api_service !== undefined && object.api_service !== null) {
            message.apiService = object.api_service;
        }
        if (object.quota_metric !== undefined && object.quota_metric !== null) {
            message.quotaMetric = object.quota_metric;
        }
        if (object.quota_id !== undefined && object.quota_id !== null) {
            message.quotaId = object.quota_id;
        }
        message.quotaDimensions = Object.entries(object.quota_dimensions ?? {}).reduce((acc, [key, value]) => {
            if (value !== undefined) {
                acc[key] = String(value);
            }
            return acc;
        }, {});
        if (object.quota_value !== undefined && object.quota_value !== null) {
            message.quotaValue = BigInt(object.quota_value);
        }
        if (object.future_quota_value !== undefined && object.future_quota_value !== null) {
            message.futureQuotaValue = BigInt(object.future_quota_value);
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.subject = message.subject === "" ? undefined : message.subject;
        obj.description = message.description === "" ? undefined : message.description;
        obj.api_service = message.apiService === "" ? undefined : message.apiService;
        obj.quota_metric = message.quotaMetric === "" ? undefined : message.quotaMetric;
        obj.quota_id = message.quotaId === "" ? undefined : message.quotaId;
        obj.quota_dimensions = {};
        if (message.quotaDimensions) {
            Object.entries(message.quotaDimensions).forEach(([k, v]) => {
                obj.quota_dimensions[k] = v;
            });
        }
        obj.quota_value = message.quotaValue !== BigInt(0) ? message.quotaValue?.toString() : undefined;
        obj.future_quota_value = message.futureQuotaValue !== BigInt(0) ? message.futureQuotaValue?.toString() : undefined;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.QuotaFailure_Violation.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.QuotaFailure_Violation.decode(message.value);
    },
    toProto(message) {
        return exports.QuotaFailure_Violation.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.rpc.Violation",
            value: exports.QuotaFailure_Violation.encode(message).finish()
        };
    }
};
function createBasePreconditionFailure() {
    return {
        violations: []
    };
}
exports.PreconditionFailure = {
    typeUrl: "/google.rpc.PreconditionFailure",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        for (const v of message.violations) {
            exports.PreconditionFailure_Violation.encode(v, writer.uint32(10).fork()).ldelim();
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBasePreconditionFailure();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.violations.push(exports.PreconditionFailure_Violation.decode(reader, reader.uint32()));
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBasePreconditionFailure();
        message.violations = object.violations?.map(e => exports.PreconditionFailure_Violation.fromPartial(e)) || [];
        return message;
    },
    fromAmino(object) {
        const message = createBasePreconditionFailure();
        message.violations = object.violations?.map(e => exports.PreconditionFailure_Violation.fromAmino(e)) || [];
        return message;
    },
    toAmino(message) {
        const obj = {};
        if (message.violations) {
            obj.violations = message.violations.map(e => e ? exports.PreconditionFailure_Violation.toAmino(e) : undefined);
        }
        else {
            obj.violations = message.violations;
        }
        return obj;
    },
    fromAminoMsg(object) {
        return exports.PreconditionFailure.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.PreconditionFailure.decode(message.value);
    },
    toProto(message) {
        return exports.PreconditionFailure.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.rpc.PreconditionFailure",
            value: exports.PreconditionFailure.encode(message).finish()
        };
    }
};
function createBasePreconditionFailure_Violation() {
    return {
        type: "",
        subject: "",
        description: ""
    };
}
exports.PreconditionFailure_Violation = {
    typeUrl: "/google.rpc.Violation",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.type !== "") {
            writer.uint32(10).string(message.type);
        }
        if (message.subject !== "") {
            writer.uint32(18).string(message.subject);
        }
        if (message.description !== "") {
            writer.uint32(26).string(message.description);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBasePreconditionFailure_Violation();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.type = reader.string();
                    break;
                case 2:
                    message.subject = reader.string();
                    break;
                case 3:
                    message.description = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBasePreconditionFailure_Violation();
        message.type = object.type ?? "";
        message.subject = object.subject ?? "";
        message.description = object.description ?? "";
        return message;
    },
    fromAmino(object) {
        const message = createBasePreconditionFailure_Violation();
        if (object.type !== undefined && object.type !== null) {
            message.type = object.type;
        }
        if (object.subject !== undefined && object.subject !== null) {
            message.subject = object.subject;
        }
        if (object.description !== undefined && object.description !== null) {
            message.description = object.description;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.type = message.type === "" ? undefined : message.type;
        obj.subject = message.subject === "" ? undefined : message.subject;
        obj.description = message.description === "" ? undefined : message.description;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.PreconditionFailure_Violation.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.PreconditionFailure_Violation.decode(message.value);
    },
    toProto(message) {
        return exports.PreconditionFailure_Violation.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.rpc.Violation",
            value: exports.PreconditionFailure_Violation.encode(message).finish()
        };
    }
};
function createBaseBadRequest() {
    return {
        fieldViolations: []
    };
}
exports.BadRequest = {
    typeUrl: "/google.rpc.BadRequest",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        for (const v of message.fieldViolations) {
            exports.BadRequest_FieldViolation.encode(v, writer.uint32(10).fork()).ldelim();
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseBadRequest();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.fieldViolations.push(exports.BadRequest_FieldViolation.decode(reader, reader.uint32()));
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseBadRequest();
        message.fieldViolations = object.fieldViolations?.map(e => exports.BadRequest_FieldViolation.fromPartial(e)) || [];
        return message;
    },
    fromAmino(object) {
        const message = createBaseBadRequest();
        message.fieldViolations = object.field_violations?.map(e => exports.BadRequest_FieldViolation.fromAmino(e)) || [];
        return message;
    },
    toAmino(message) {
        const obj = {};
        if (message.fieldViolations) {
            obj.field_violations = message.fieldViolations.map(e => e ? exports.BadRequest_FieldViolation.toAmino(e) : undefined);
        }
        else {
            obj.field_violations = message.fieldViolations;
        }
        return obj;
    },
    fromAminoMsg(object) {
        return exports.BadRequest.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.BadRequest.decode(message.value);
    },
    toProto(message) {
        return exports.BadRequest.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.rpc.BadRequest",
            value: exports.BadRequest.encode(message).finish()
        };
    }
};
function createBaseBadRequest_FieldViolation() {
    return {
        field: "",
        description: "",
        reason: "",
        localizedMessage: undefined
    };
}
exports.BadRequest_FieldViolation = {
    typeUrl: "/google.rpc.FieldViolation",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.field !== "") {
            writer.uint32(10).string(message.field);
        }
        if (message.description !== "") {
            writer.uint32(18).string(message.description);
        }
        if (message.reason !== "") {
            writer.uint32(26).string(message.reason);
        }
        if (message.localizedMessage !== undefined) {
            exports.LocalizedMessage.encode(message.localizedMessage, writer.uint32(34).fork()).ldelim();
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseBadRequest_FieldViolation();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.field = reader.string();
                    break;
                case 2:
                    message.description = reader.string();
                    break;
                case 3:
                    message.reason = reader.string();
                    break;
                case 4:
                    message.localizedMessage = exports.LocalizedMessage.decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseBadRequest_FieldViolation();
        message.field = object.field ?? "";
        message.description = object.description ?? "";
        message.reason = object.reason ?? "";
        message.localizedMessage = object.localizedMessage !== undefined && object.localizedMessage !== null ? exports.LocalizedMessage.fromPartial(object.localizedMessage) : undefined;
        return message;
    },
    fromAmino(object) {
        const message = createBaseBadRequest_FieldViolation();
        if (object.field !== undefined && object.field !== null) {
            message.field = object.field;
        }
        if (object.description !== undefined && object.description !== null) {
            message.description = object.description;
        }
        if (object.reason !== undefined && object.reason !== null) {
            message.reason = object.reason;
        }
        if (object.localized_message !== undefined && object.localized_message !== null) {
            message.localizedMessage = exports.LocalizedMessage.fromAmino(object.localized_message);
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.field = message.field === "" ? undefined : message.field;
        obj.description = message.description === "" ? undefined : message.description;
        obj.reason = message.reason === "" ? undefined : message.reason;
        obj.localized_message = message.localizedMessage ? exports.LocalizedMessage.toAmino(message.localizedMessage) : undefined;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.BadRequest_FieldViolation.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.BadRequest_FieldViolation.decode(message.value);
    },
    toProto(message) {
        return exports.BadRequest_FieldViolation.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.rpc.FieldViolation",
            value: exports.BadRequest_FieldViolation.encode(message).finish()
        };
    }
};
function createBaseRequestInfo() {
    return {
        requestId: "",
        servingData: ""
    };
}
exports.RequestInfo = {
    typeUrl: "/google.rpc.RequestInfo",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.requestId !== "") {
            writer.uint32(10).string(message.requestId);
        }
        if (message.servingData !== "") {
            writer.uint32(18).string(message.servingData);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseRequestInfo();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.requestId = reader.string();
                    break;
                case 2:
                    message.servingData = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseRequestInfo();
        message.requestId = object.requestId ?? "";
        message.servingData = object.servingData ?? "";
        return message;
    },
    fromAmino(object) {
        const message = createBaseRequestInfo();
        if (object.request_id !== undefined && object.request_id !== null) {
            message.requestId = object.request_id;
        }
        if (object.serving_data !== undefined && object.serving_data !== null) {
            message.servingData = object.serving_data;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.request_id = message.requestId === "" ? undefined : message.requestId;
        obj.serving_data = message.servingData === "" ? undefined : message.servingData;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.RequestInfo.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.RequestInfo.decode(message.value);
    },
    toProto(message) {
        return exports.RequestInfo.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.rpc.RequestInfo",
            value: exports.RequestInfo.encode(message).finish()
        };
    }
};
function createBaseResourceInfo() {
    return {
        resourceType: "",
        resourceName: "",
        owner: "",
        description: ""
    };
}
exports.ResourceInfo = {
    typeUrl: "/google.rpc.ResourceInfo",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.resourceType !== "") {
            writer.uint32(10).string(message.resourceType);
        }
        if (message.resourceName !== "") {
            writer.uint32(18).string(message.resourceName);
        }
        if (message.owner !== "") {
            writer.uint32(26).string(message.owner);
        }
        if (message.description !== "") {
            writer.uint32(34).string(message.description);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseResourceInfo();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.resourceType = reader.string();
                    break;
                case 2:
                    message.resourceName = reader.string();
                    break;
                case 3:
                    message.owner = reader.string();
                    break;
                case 4:
                    message.description = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseResourceInfo();
        message.resourceType = object.resourceType ?? "";
        message.resourceName = object.resourceName ?? "";
        message.owner = object.owner ?? "";
        message.description = object.description ?? "";
        return message;
    },
    fromAmino(object) {
        const message = createBaseResourceInfo();
        if (object.resource_type !== undefined && object.resource_type !== null) {
            message.resourceType = object.resource_type;
        }
        if (object.resource_name !== undefined && object.resource_name !== null) {
            message.resourceName = object.resource_name;
        }
        if (object.owner !== undefined && object.owner !== null) {
            message.owner = object.owner;
        }
        if (object.description !== undefined && object.description !== null) {
            message.description = object.description;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.resource_type = message.resourceType === "" ? undefined : message.resourceType;
        obj.resource_name = message.resourceName === "" ? undefined : message.resourceName;
        obj.owner = message.owner === "" ? undefined : message.owner;
        obj.description = message.description === "" ? undefined : message.description;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.ResourceInfo.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.ResourceInfo.decode(message.value);
    },
    toProto(message) {
        return exports.ResourceInfo.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.rpc.ResourceInfo",
            value: exports.ResourceInfo.encode(message).finish()
        };
    }
};
function createBaseHelp() {
    return {
        links: []
    };
}
exports.Help = {
    typeUrl: "/google.rpc.Help",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        for (const v of message.links) {
            exports.Help_Link.encode(v, writer.uint32(10).fork()).ldelim();
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseHelp();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.links.push(exports.Help_Link.decode(reader, reader.uint32()));
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseHelp();
        message.links = object.links?.map(e => exports.Help_Link.fromPartial(e)) || [];
        return message;
    },
    fromAmino(object) {
        const message = createBaseHelp();
        message.links = object.links?.map(e => exports.Help_Link.fromAmino(e)) || [];
        return message;
    },
    toAmino(message) {
        const obj = {};
        if (message.links) {
            obj.links = message.links.map(e => e ? exports.Help_Link.toAmino(e) : undefined);
        }
        else {
            obj.links = message.links;
        }
        return obj;
    },
    fromAminoMsg(object) {
        return exports.Help.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.Help.decode(message.value);
    },
    toProto(message) {
        return exports.Help.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.rpc.Help",
            value: exports.Help.encode(message).finish()
        };
    }
};
function createBaseHelp_Link() {
    return {
        description: "",
        url: ""
    };
}
exports.Help_Link = {
    typeUrl: "/google.rpc.Link",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.description !== "") {
            writer.uint32(10).string(message.description);
        }
        if (message.url !== "") {
            writer.uint32(18).string(message.url);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseHelp_Link();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.description = reader.string();
                    break;
                case 2:
                    message.url = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseHelp_Link();
        message.description = object.description ?? "";
        message.url = object.url ?? "";
        return message;
    },
    fromAmino(object) {
        const message = createBaseHelp_Link();
        if (object.description !== undefined && object.description !== null) {
            message.description = object.description;
        }
        if (object.url !== undefined && object.url !== null) {
            message.url = object.url;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.description = message.description === "" ? undefined : message.description;
        obj.url = message.url === "" ? undefined : message.url;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.Help_Link.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.Help_Link.decode(message.value);
    },
    toProto(message) {
        return exports.Help_Link.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.rpc.Link",
            value: exports.Help_Link.encode(message).finish()
        };
    }
};
function createBaseLocalizedMessage() {
    return {
        locale: "",
        message: ""
    };
}
exports.LocalizedMessage = {
    typeUrl: "/google.rpc.LocalizedMessage",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.locale !== "") {
            writer.uint32(10).string(message.locale);
        }
        if (message.message !== "") {
            writer.uint32(18).string(message.message);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseLocalizedMessage();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.locale = reader.string();
                    break;
                case 2:
                    message.message = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseLocalizedMessage();
        message.locale = object.locale ?? "";
        message.message = object.message ?? "";
        return message;
    },
    fromAmino(object) {
        const message = createBaseLocalizedMessage();
        if (object.locale !== undefined && object.locale !== null) {
            message.locale = object.locale;
        }
        if (object.message !== undefined && object.message !== null) {
            message.message = object.message;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.locale = message.locale === "" ? undefined : message.locale;
        obj.message = message.message === "" ? undefined : message.message;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.LocalizedMessage.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.LocalizedMessage.decode(message.value);
    },
    toProto(message) {
        return exports.LocalizedMessage.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.rpc.LocalizedMessage",
            value: exports.LocalizedMessage.encode(message).finish()
        };
    }
};
