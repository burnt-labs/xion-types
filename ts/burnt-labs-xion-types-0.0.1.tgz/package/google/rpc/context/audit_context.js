"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AuditContext = void 0;
//@ts-nocheck
const struct_1 = require("../../protobuf/struct");
const binary_1 = require("../../../binary");
const helpers_1 = require("../../../helpers");
function createBaseAuditContext() {
    return {
        auditLog: new Uint8Array(),
        scrubbedRequest: undefined,
        scrubbedResponse: undefined,
        scrubbedResponseItemCount: 0,
        targetResource: ""
    };
}
exports.AuditContext = {
    typeUrl: "/google.rpc.context.AuditContext",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.auditLog.length !== 0) {
            writer.uint32(10).bytes(message.auditLog);
        }
        if (message.scrubbedRequest !== undefined) {
            struct_1.Struct.encode(message.scrubbedRequest, writer.uint32(18).fork()).ldelim();
        }
        if (message.scrubbedResponse !== undefined) {
            struct_1.Struct.encode(message.scrubbedResponse, writer.uint32(26).fork()).ldelim();
        }
        if (message.scrubbedResponseItemCount !== 0) {
            writer.uint32(32).int32(message.scrubbedResponseItemCount);
        }
        if (message.targetResource !== "") {
            writer.uint32(42).string(message.targetResource);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseAuditContext();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.auditLog = reader.bytes();
                    break;
                case 2:
                    message.scrubbedRequest = struct_1.Struct.decode(reader, reader.uint32());
                    break;
                case 3:
                    message.scrubbedResponse = struct_1.Struct.decode(reader, reader.uint32());
                    break;
                case 4:
                    message.scrubbedResponseItemCount = reader.int32();
                    break;
                case 5:
                    message.targetResource = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseAuditContext();
        message.auditLog = object.auditLog ?? new Uint8Array();
        message.scrubbedRequest = object.scrubbedRequest !== undefined && object.scrubbedRequest !== null ? struct_1.Struct.fromPartial(object.scrubbedRequest) : undefined;
        message.scrubbedResponse = object.scrubbedResponse !== undefined && object.scrubbedResponse !== null ? struct_1.Struct.fromPartial(object.scrubbedResponse) : undefined;
        message.scrubbedResponseItemCount = object.scrubbedResponseItemCount ?? 0;
        message.targetResource = object.targetResource ?? "";
        return message;
    },
    fromAmino(object) {
        const message = createBaseAuditContext();
        if (object.audit_log !== undefined && object.audit_log !== null) {
            message.auditLog = (0, helpers_1.bytesFromBase64)(object.audit_log);
        }
        if (object.scrubbed_request !== undefined && object.scrubbed_request !== null) {
            message.scrubbedRequest = struct_1.Struct.fromAmino(object.scrubbed_request);
        }
        if (object.scrubbed_response !== undefined && object.scrubbed_response !== null) {
            message.scrubbedResponse = struct_1.Struct.fromAmino(object.scrubbed_response);
        }
        if (object.scrubbed_response_item_count !== undefined && object.scrubbed_response_item_count !== null) {
            message.scrubbedResponseItemCount = object.scrubbed_response_item_count;
        }
        if (object.target_resource !== undefined && object.target_resource !== null) {
            message.targetResource = object.target_resource;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.audit_log = message.auditLog ? (0, helpers_1.base64FromBytes)(message.auditLog) : undefined;
        obj.scrubbed_request = message.scrubbedRequest ? struct_1.Struct.toAmino(message.scrubbedRequest) : undefined;
        obj.scrubbed_response = message.scrubbedResponse ? struct_1.Struct.toAmino(message.scrubbedResponse) : undefined;
        obj.scrubbed_response_item_count = message.scrubbedResponseItemCount === 0 ? undefined : message.scrubbedResponseItemCount;
        obj.target_resource = message.targetResource === "" ? undefined : message.targetResource;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.AuditContext.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.AuditContext.decode(message.value);
    },
    toProto(message) {
        return exports.AuditContext.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.rpc.context.AuditContext",
            value: exports.AuditContext.encode(message).finish()
        };
    }
};
