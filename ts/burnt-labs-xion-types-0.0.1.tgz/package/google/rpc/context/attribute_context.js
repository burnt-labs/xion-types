"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AttributeContext_Resource = exports.AttributeContext_Resource_AnnotationsEntry = exports.AttributeContext_Resource_LabelsEntry = exports.AttributeContext_Response = exports.AttributeContext_Response_HeadersEntry = exports.AttributeContext_Request = exports.AttributeContext_Request_HeadersEntry = exports.AttributeContext_Auth = exports.AttributeContext_Api = exports.AttributeContext_Peer = exports.AttributeContext_Peer_LabelsEntry = exports.AttributeContext = void 0;
//@ts-nocheck
const struct_1 = require("../../protobuf/struct");
const timestamp_1 = require("../../protobuf/timestamp");
const duration_1 = require("../../protobuf/duration");
const any_1 = require("../../protobuf/any");
const binary_1 = require("../../../binary");
const helpers_1 = require("../../../helpers");
function createBaseAttributeContext() {
    return {
        origin: undefined,
        source: undefined,
        destination: undefined,
        request: undefined,
        response: undefined,
        resource: undefined,
        api: undefined,
        extensions: []
    };
}
exports.AttributeContext = {
    typeUrl: "/google.rpc.context.AttributeContext",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.origin !== undefined) {
            exports.AttributeContext_Peer.encode(message.origin, writer.uint32(58).fork()).ldelim();
        }
        if (message.source !== undefined) {
            exports.AttributeContext_Peer.encode(message.source, writer.uint32(10).fork()).ldelim();
        }
        if (message.destination !== undefined) {
            exports.AttributeContext_Peer.encode(message.destination, writer.uint32(18).fork()).ldelim();
        }
        if (message.request !== undefined) {
            exports.AttributeContext_Request.encode(message.request, writer.uint32(26).fork()).ldelim();
        }
        if (message.response !== undefined) {
            exports.AttributeContext_Response.encode(message.response, writer.uint32(34).fork()).ldelim();
        }
        if (message.resource !== undefined) {
            exports.AttributeContext_Resource.encode(message.resource, writer.uint32(42).fork()).ldelim();
        }
        if (message.api !== undefined) {
            exports.AttributeContext_Api.encode(message.api, writer.uint32(50).fork()).ldelim();
        }
        for (const v of message.extensions) {
            any_1.Any.encode(v, writer.uint32(66).fork()).ldelim();
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseAttributeContext();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 7:
                    message.origin = exports.AttributeContext_Peer.decode(reader, reader.uint32());
                    break;
                case 1:
                    message.source = exports.AttributeContext_Peer.decode(reader, reader.uint32());
                    break;
                case 2:
                    message.destination = exports.AttributeContext_Peer.decode(reader, reader.uint32());
                    break;
                case 3:
                    message.request = exports.AttributeContext_Request.decode(reader, reader.uint32());
                    break;
                case 4:
                    message.response = exports.AttributeContext_Response.decode(reader, reader.uint32());
                    break;
                case 5:
                    message.resource = exports.AttributeContext_Resource.decode(reader, reader.uint32());
                    break;
                case 6:
                    message.api = exports.AttributeContext_Api.decode(reader, reader.uint32());
                    break;
                case 8:
                    message.extensions.push(any_1.Any.decode(reader, reader.uint32()));
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseAttributeContext();
        message.origin = object.origin !== undefined && object.origin !== null ? exports.AttributeContext_Peer.fromPartial(object.origin) : undefined;
        message.source = object.source !== undefined && object.source !== null ? exports.AttributeContext_Peer.fromPartial(object.source) : undefined;
        message.destination = object.destination !== undefined && object.destination !== null ? exports.AttributeContext_Peer.fromPartial(object.destination) : undefined;
        message.request = object.request !== undefined && object.request !== null ? exports.AttributeContext_Request.fromPartial(object.request) : undefined;
        message.response = object.response !== undefined && object.response !== null ? exports.AttributeContext_Response.fromPartial(object.response) : undefined;
        message.resource = object.resource !== undefined && object.resource !== null ? exports.AttributeContext_Resource.fromPartial(object.resource) : undefined;
        message.api = object.api !== undefined && object.api !== null ? exports.AttributeContext_Api.fromPartial(object.api) : undefined;
        message.extensions = object.extensions?.map(e => any_1.Any.fromPartial(e)) || [];
        return message;
    },
    fromAmino(object) {
        const message = createBaseAttributeContext();
        if (object.origin !== undefined && object.origin !== null) {
            message.origin = exports.AttributeContext_Peer.fromAmino(object.origin);
        }
        if (object.source !== undefined && object.source !== null) {
            message.source = exports.AttributeContext_Peer.fromAmino(object.source);
        }
        if (object.destination !== undefined && object.destination !== null) {
            message.destination = exports.AttributeContext_Peer.fromAmino(object.destination);
        }
        if (object.request !== undefined && object.request !== null) {
            message.request = exports.AttributeContext_Request.fromAmino(object.request);
        }
        if (object.response !== undefined && object.response !== null) {
            message.response = exports.AttributeContext_Response.fromAmino(object.response);
        }
        if (object.resource !== undefined && object.resource !== null) {
            message.resource = exports.AttributeContext_Resource.fromAmino(object.resource);
        }
        if (object.api !== undefined && object.api !== null) {
            message.api = exports.AttributeContext_Api.fromAmino(object.api);
        }
        message.extensions = object.extensions?.map(e => any_1.Any.fromAmino(e)) || [];
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.origin = message.origin ? exports.AttributeContext_Peer.toAmino(message.origin) : undefined;
        obj.source = message.source ? exports.AttributeContext_Peer.toAmino(message.source) : undefined;
        obj.destination = message.destination ? exports.AttributeContext_Peer.toAmino(message.destination) : undefined;
        obj.request = message.request ? exports.AttributeContext_Request.toAmino(message.request) : undefined;
        obj.response = message.response ? exports.AttributeContext_Response.toAmino(message.response) : undefined;
        obj.resource = message.resource ? exports.AttributeContext_Resource.toAmino(message.resource) : undefined;
        obj.api = message.api ? exports.AttributeContext_Api.toAmino(message.api) : undefined;
        if (message.extensions) {
            obj.extensions = message.extensions.map(e => e ? any_1.Any.toAmino(e) : undefined);
        }
        else {
            obj.extensions = message.extensions;
        }
        return obj;
    },
    fromAminoMsg(object) {
        return exports.AttributeContext.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.AttributeContext.decode(message.value);
    },
    toProto(message) {
        return exports.AttributeContext.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.rpc.context.AttributeContext",
            value: exports.AttributeContext.encode(message).finish()
        };
    }
};
function createBaseAttributeContext_Peer_LabelsEntry() {
    return {
        key: "",
        value: ""
    };
}
exports.AttributeContext_Peer_LabelsEntry = {
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.key !== "") {
            writer.uint32(10).string(message.key);
        }
        if (message.value !== "") {
            writer.uint32(18).string(message.value);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseAttributeContext_Peer_LabelsEntry();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.key = reader.string();
                    break;
                case 2:
                    message.value = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseAttributeContext_Peer_LabelsEntry();
        message.key = object.key ?? "";
        message.value = object.value ?? "";
        return message;
    },
    fromAmino(object) {
        const message = createBaseAttributeContext_Peer_LabelsEntry();
        if (object.key !== undefined && object.key !== null) {
            message.key = object.key;
        }
        if (object.value !== undefined && object.value !== null) {
            message.value = object.value;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.key = message.key === "" ? undefined : message.key;
        obj.value = message.value === "" ? undefined : message.value;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.AttributeContext_Peer_LabelsEntry.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.AttributeContext_Peer_LabelsEntry.decode(message.value);
    },
    toProto(message) {
        return exports.AttributeContext_Peer_LabelsEntry.encode(message).finish();
    }
};
function createBaseAttributeContext_Peer() {
    return {
        ip: "",
        port: BigInt(0),
        labels: {},
        principal: "",
        regionCode: ""
    };
}
exports.AttributeContext_Peer = {
    typeUrl: "/google.rpc.context.Peer",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.ip !== "") {
            writer.uint32(10).string(message.ip);
        }
        if (message.port !== BigInt(0)) {
            writer.uint32(16).int64(message.port);
        }
        Object.entries(message.labels).forEach(([key, value]) => {
            exports.AttributeContext_Peer_LabelsEntry.encode({
                key: key,
                value
            }, writer.uint32(50).fork()).ldelim();
        });
        if (message.principal !== "") {
            writer.uint32(58).string(message.principal);
        }
        if (message.regionCode !== "") {
            writer.uint32(66).string(message.regionCode);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseAttributeContext_Peer();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.ip = reader.string();
                    break;
                case 2:
                    message.port = reader.int64();
                    break;
                case 6:
                    const entry6 = exports.AttributeContext_Peer_LabelsEntry.decode(reader, reader.uint32());
                    if (entry6.value !== undefined) {
                        message.labels[entry6.key] = entry6.value;
                    }
                    break;
                case 7:
                    message.principal = reader.string();
                    break;
                case 8:
                    message.regionCode = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseAttributeContext_Peer();
        message.ip = object.ip ?? "";
        message.port = object.port !== undefined && object.port !== null ? BigInt(object.port.toString()) : BigInt(0);
        message.labels = Object.entries(object.labels ?? {}).reduce((acc, [key, value]) => {
            if (value !== undefined) {
                acc[key] = String(value);
            }
            return acc;
        }, {});
        message.principal = object.principal ?? "";
        message.regionCode = object.regionCode ?? "";
        return message;
    },
    fromAmino(object) {
        const message = createBaseAttributeContext_Peer();
        if (object.ip !== undefined && object.ip !== null) {
            message.ip = object.ip;
        }
        if (object.port !== undefined && object.port !== null) {
            message.port = BigInt(object.port);
        }
        message.labels = Object.entries(object.labels ?? {}).reduce((acc, [key, value]) => {
            if (value !== undefined) {
                acc[key] = String(value);
            }
            return acc;
        }, {});
        if (object.principal !== undefined && object.principal !== null) {
            message.principal = object.principal;
        }
        if (object.region_code !== undefined && object.region_code !== null) {
            message.regionCode = object.region_code;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.ip = message.ip === "" ? undefined : message.ip;
        obj.port = message.port !== BigInt(0) ? message.port?.toString() : undefined;
        obj.labels = {};
        if (message.labels) {
            Object.entries(message.labels).forEach(([k, v]) => {
                obj.labels[k] = v;
            });
        }
        obj.principal = message.principal === "" ? undefined : message.principal;
        obj.region_code = message.regionCode === "" ? undefined : message.regionCode;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.AttributeContext_Peer.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.AttributeContext_Peer.decode(message.value);
    },
    toProto(message) {
        return exports.AttributeContext_Peer.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.rpc.context.Peer",
            value: exports.AttributeContext_Peer.encode(message).finish()
        };
    }
};
function createBaseAttributeContext_Api() {
    return {
        service: "",
        operation: "",
        protocol: "",
        version: ""
    };
}
exports.AttributeContext_Api = {
    typeUrl: "/google.rpc.context.Api",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.service !== "") {
            writer.uint32(10).string(message.service);
        }
        if (message.operation !== "") {
            writer.uint32(18).string(message.operation);
        }
        if (message.protocol !== "") {
            writer.uint32(26).string(message.protocol);
        }
        if (message.version !== "") {
            writer.uint32(34).string(message.version);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseAttributeContext_Api();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.service = reader.string();
                    break;
                case 2:
                    message.operation = reader.string();
                    break;
                case 3:
                    message.protocol = reader.string();
                    break;
                case 4:
                    message.version = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseAttributeContext_Api();
        message.service = object.service ?? "";
        message.operation = object.operation ?? "";
        message.protocol = object.protocol ?? "";
        message.version = object.version ?? "";
        return message;
    },
    fromAmino(object) {
        const message = createBaseAttributeContext_Api();
        if (object.service !== undefined && object.service !== null) {
            message.service = object.service;
        }
        if (object.operation !== undefined && object.operation !== null) {
            message.operation = object.operation;
        }
        if (object.protocol !== undefined && object.protocol !== null) {
            message.protocol = object.protocol;
        }
        if (object.version !== undefined && object.version !== null) {
            message.version = object.version;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.service = message.service === "" ? undefined : message.service;
        obj.operation = message.operation === "" ? undefined : message.operation;
        obj.protocol = message.protocol === "" ? undefined : message.protocol;
        obj.version = message.version === "" ? undefined : message.version;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.AttributeContext_Api.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.AttributeContext_Api.decode(message.value);
    },
    toProto(message) {
        return exports.AttributeContext_Api.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.rpc.context.Api",
            value: exports.AttributeContext_Api.encode(message).finish()
        };
    }
};
function createBaseAttributeContext_Auth() {
    return {
        principal: "",
        audiences: [],
        presenter: "",
        claims: undefined,
        accessLevels: []
    };
}
exports.AttributeContext_Auth = {
    typeUrl: "/google.rpc.context.Auth",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.principal !== "") {
            writer.uint32(10).string(message.principal);
        }
        for (const v of message.audiences) {
            writer.uint32(18).string(v);
        }
        if (message.presenter !== "") {
            writer.uint32(26).string(message.presenter);
        }
        if (message.claims !== undefined) {
            struct_1.Struct.encode(message.claims, writer.uint32(34).fork()).ldelim();
        }
        for (const v of message.accessLevels) {
            writer.uint32(42).string(v);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseAttributeContext_Auth();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.principal = reader.string();
                    break;
                case 2:
                    message.audiences.push(reader.string());
                    break;
                case 3:
                    message.presenter = reader.string();
                    break;
                case 4:
                    message.claims = struct_1.Struct.decode(reader, reader.uint32());
                    break;
                case 5:
                    message.accessLevels.push(reader.string());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseAttributeContext_Auth();
        message.principal = object.principal ?? "";
        message.audiences = object.audiences?.map(e => e) || [];
        message.presenter = object.presenter ?? "";
        message.claims = object.claims !== undefined && object.claims !== null ? struct_1.Struct.fromPartial(object.claims) : undefined;
        message.accessLevels = object.accessLevels?.map(e => e) || [];
        return message;
    },
    fromAmino(object) {
        const message = createBaseAttributeContext_Auth();
        if (object.principal !== undefined && object.principal !== null) {
            message.principal = object.principal;
        }
        message.audiences = object.audiences?.map(e => e) || [];
        if (object.presenter !== undefined && object.presenter !== null) {
            message.presenter = object.presenter;
        }
        if (object.claims !== undefined && object.claims !== null) {
            message.claims = struct_1.Struct.fromAmino(object.claims);
        }
        message.accessLevels = object.access_levels?.map(e => e) || [];
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.principal = message.principal === "" ? undefined : message.principal;
        if (message.audiences) {
            obj.audiences = message.audiences.map(e => e);
        }
        else {
            obj.audiences = message.audiences;
        }
        obj.presenter = message.presenter === "" ? undefined : message.presenter;
        obj.claims = message.claims ? struct_1.Struct.toAmino(message.claims) : undefined;
        if (message.accessLevels) {
            obj.access_levels = message.accessLevels.map(e => e);
        }
        else {
            obj.access_levels = message.accessLevels;
        }
        return obj;
    },
    fromAminoMsg(object) {
        return exports.AttributeContext_Auth.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.AttributeContext_Auth.decode(message.value);
    },
    toProto(message) {
        return exports.AttributeContext_Auth.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.rpc.context.Auth",
            value: exports.AttributeContext_Auth.encode(message).finish()
        };
    }
};
function createBaseAttributeContext_Request_HeadersEntry() {
    return {
        key: "",
        value: ""
    };
}
exports.AttributeContext_Request_HeadersEntry = {
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.key !== "") {
            writer.uint32(10).string(message.key);
        }
        if (message.value !== "") {
            writer.uint32(18).string(message.value);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseAttributeContext_Request_HeadersEntry();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.key = reader.string();
                    break;
                case 2:
                    message.value = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseAttributeContext_Request_HeadersEntry();
        message.key = object.key ?? "";
        message.value = object.value ?? "";
        return message;
    },
    fromAmino(object) {
        const message = createBaseAttributeContext_Request_HeadersEntry();
        if (object.key !== undefined && object.key !== null) {
            message.key = object.key;
        }
        if (object.value !== undefined && object.value !== null) {
            message.value = object.value;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.key = message.key === "" ? undefined : message.key;
        obj.value = message.value === "" ? undefined : message.value;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.AttributeContext_Request_HeadersEntry.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.AttributeContext_Request_HeadersEntry.decode(message.value);
    },
    toProto(message) {
        return exports.AttributeContext_Request_HeadersEntry.encode(message).finish();
    }
};
function createBaseAttributeContext_Request() {
    return {
        id: "",
        method: "",
        headers: {},
        path: "",
        host: "",
        scheme: "",
        query: "",
        time: undefined,
        size: BigInt(0),
        protocol: "",
        reason: "",
        auth: undefined
    };
}
exports.AttributeContext_Request = {
    typeUrl: "/google.rpc.context.Request",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.id !== "") {
            writer.uint32(10).string(message.id);
        }
        if (message.method !== "") {
            writer.uint32(18).string(message.method);
        }
        Object.entries(message.headers).forEach(([key, value]) => {
            exports.AttributeContext_Request_HeadersEntry.encode({
                key: key,
                value
            }, writer.uint32(26).fork()).ldelim();
        });
        if (message.path !== "") {
            writer.uint32(34).string(message.path);
        }
        if (message.host !== "") {
            writer.uint32(42).string(message.host);
        }
        if (message.scheme !== "") {
            writer.uint32(50).string(message.scheme);
        }
        if (message.query !== "") {
            writer.uint32(58).string(message.query);
        }
        if (message.time !== undefined) {
            timestamp_1.Timestamp.encode((0, helpers_1.toTimestamp)(message.time), writer.uint32(74).fork()).ldelim();
        }
        if (message.size !== BigInt(0)) {
            writer.uint32(80).int64(message.size);
        }
        if (message.protocol !== "") {
            writer.uint32(90).string(message.protocol);
        }
        if (message.reason !== "") {
            writer.uint32(98).string(message.reason);
        }
        if (message.auth !== undefined) {
            exports.AttributeContext_Auth.encode(message.auth, writer.uint32(106).fork()).ldelim();
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseAttributeContext_Request();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.id = reader.string();
                    break;
                case 2:
                    message.method = reader.string();
                    break;
                case 3:
                    const entry3 = exports.AttributeContext_Request_HeadersEntry.decode(reader, reader.uint32());
                    if (entry3.value !== undefined) {
                        message.headers[entry3.key] = entry3.value;
                    }
                    break;
                case 4:
                    message.path = reader.string();
                    break;
                case 5:
                    message.host = reader.string();
                    break;
                case 6:
                    message.scheme = reader.string();
                    break;
                case 7:
                    message.query = reader.string();
                    break;
                case 9:
                    message.time = (0, helpers_1.fromTimestamp)(timestamp_1.Timestamp.decode(reader, reader.uint32()));
                    break;
                case 10:
                    message.size = reader.int64();
                    break;
                case 11:
                    message.protocol = reader.string();
                    break;
                case 12:
                    message.reason = reader.string();
                    break;
                case 13:
                    message.auth = exports.AttributeContext_Auth.decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseAttributeContext_Request();
        message.id = object.id ?? "";
        message.method = object.method ?? "";
        message.headers = Object.entries(object.headers ?? {}).reduce((acc, [key, value]) => {
            if (value !== undefined) {
                acc[key] = String(value);
            }
            return acc;
        }, {});
        message.path = object.path ?? "";
        message.host = object.host ?? "";
        message.scheme = object.scheme ?? "";
        message.query = object.query ?? "";
        message.time = object.time ?? undefined;
        message.size = object.size !== undefined && object.size !== null ? BigInt(object.size.toString()) : BigInt(0);
        message.protocol = object.protocol ?? "";
        message.reason = object.reason ?? "";
        message.auth = object.auth !== undefined && object.auth !== null ? exports.AttributeContext_Auth.fromPartial(object.auth) : undefined;
        return message;
    },
    fromAmino(object) {
        const message = createBaseAttributeContext_Request();
        if (object.id !== undefined && object.id !== null) {
            message.id = object.id;
        }
        if (object.method !== undefined && object.method !== null) {
            message.method = object.method;
        }
        message.headers = Object.entries(object.headers ?? {}).reduce((acc, [key, value]) => {
            if (value !== undefined) {
                acc[key] = String(value);
            }
            return acc;
        }, {});
        if (object.path !== undefined && object.path !== null) {
            message.path = object.path;
        }
        if (object.host !== undefined && object.host !== null) {
            message.host = object.host;
        }
        if (object.scheme !== undefined && object.scheme !== null) {
            message.scheme = object.scheme;
        }
        if (object.query !== undefined && object.query !== null) {
            message.query = object.query;
        }
        if (object.time !== undefined && object.time !== null) {
            message.time = (0, helpers_1.fromTimestamp)(timestamp_1.Timestamp.fromAmino(object.time));
        }
        if (object.size !== undefined && object.size !== null) {
            message.size = BigInt(object.size);
        }
        if (object.protocol !== undefined && object.protocol !== null) {
            message.protocol = object.protocol;
        }
        if (object.reason !== undefined && object.reason !== null) {
            message.reason = object.reason;
        }
        if (object.auth !== undefined && object.auth !== null) {
            message.auth = exports.AttributeContext_Auth.fromAmino(object.auth);
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.id = message.id === "" ? undefined : message.id;
        obj.method = message.method === "" ? undefined : message.method;
        obj.headers = {};
        if (message.headers) {
            Object.entries(message.headers).forEach(([k, v]) => {
                obj.headers[k] = v;
            });
        }
        obj.path = message.path === "" ? undefined : message.path;
        obj.host = message.host === "" ? undefined : message.host;
        obj.scheme = message.scheme === "" ? undefined : message.scheme;
        obj.query = message.query === "" ? undefined : message.query;
        obj.time = message.time ? timestamp_1.Timestamp.toAmino((0, helpers_1.toTimestamp)(message.time)) : undefined;
        obj.size = message.size !== BigInt(0) ? message.size?.toString() : undefined;
        obj.protocol = message.protocol === "" ? undefined : message.protocol;
        obj.reason = message.reason === "" ? undefined : message.reason;
        obj.auth = message.auth ? exports.AttributeContext_Auth.toAmino(message.auth) : undefined;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.AttributeContext_Request.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.AttributeContext_Request.decode(message.value);
    },
    toProto(message) {
        return exports.AttributeContext_Request.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.rpc.context.Request",
            value: exports.AttributeContext_Request.encode(message).finish()
        };
    }
};
function createBaseAttributeContext_Response_HeadersEntry() {
    return {
        key: "",
        value: ""
    };
}
exports.AttributeContext_Response_HeadersEntry = {
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.key !== "") {
            writer.uint32(10).string(message.key);
        }
        if (message.value !== "") {
            writer.uint32(18).string(message.value);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseAttributeContext_Response_HeadersEntry();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.key = reader.string();
                    break;
                case 2:
                    message.value = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseAttributeContext_Response_HeadersEntry();
        message.key = object.key ?? "";
        message.value = object.value ?? "";
        return message;
    },
    fromAmino(object) {
        const message = createBaseAttributeContext_Response_HeadersEntry();
        if (object.key !== undefined && object.key !== null) {
            message.key = object.key;
        }
        if (object.value !== undefined && object.value !== null) {
            message.value = object.value;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.key = message.key === "" ? undefined : message.key;
        obj.value = message.value === "" ? undefined : message.value;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.AttributeContext_Response_HeadersEntry.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.AttributeContext_Response_HeadersEntry.decode(message.value);
    },
    toProto(message) {
        return exports.AttributeContext_Response_HeadersEntry.encode(message).finish();
    }
};
function createBaseAttributeContext_Response() {
    return {
        code: BigInt(0),
        size: BigInt(0),
        headers: {},
        time: undefined,
        backendLatency: undefined
    };
}
exports.AttributeContext_Response = {
    typeUrl: "/google.rpc.context.Response",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.code !== BigInt(0)) {
            writer.uint32(8).int64(message.code);
        }
        if (message.size !== BigInt(0)) {
            writer.uint32(16).int64(message.size);
        }
        Object.entries(message.headers).forEach(([key, value]) => {
            exports.AttributeContext_Response_HeadersEntry.encode({
                key: key,
                value
            }, writer.uint32(26).fork()).ldelim();
        });
        if (message.time !== undefined) {
            timestamp_1.Timestamp.encode((0, helpers_1.toTimestamp)(message.time), writer.uint32(34).fork()).ldelim();
        }
        if (message.backendLatency !== undefined) {
            duration_1.Duration.encode(message.backendLatency, writer.uint32(42).fork()).ldelim();
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseAttributeContext_Response();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.code = reader.int64();
                    break;
                case 2:
                    message.size = reader.int64();
                    break;
                case 3:
                    const entry3 = exports.AttributeContext_Response_HeadersEntry.decode(reader, reader.uint32());
                    if (entry3.value !== undefined) {
                        message.headers[entry3.key] = entry3.value;
                    }
                    break;
                case 4:
                    message.time = (0, helpers_1.fromTimestamp)(timestamp_1.Timestamp.decode(reader, reader.uint32()));
                    break;
                case 5:
                    message.backendLatency = duration_1.Duration.decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseAttributeContext_Response();
        message.code = object.code !== undefined && object.code !== null ? BigInt(object.code.toString()) : BigInt(0);
        message.size = object.size !== undefined && object.size !== null ? BigInt(object.size.toString()) : BigInt(0);
        message.headers = Object.entries(object.headers ?? {}).reduce((acc, [key, value]) => {
            if (value !== undefined) {
                acc[key] = String(value);
            }
            return acc;
        }, {});
        message.time = object.time ?? undefined;
        message.backendLatency = object.backendLatency !== undefined && object.backendLatency !== null ? duration_1.Duration.fromPartial(object.backendLatency) : undefined;
        return message;
    },
    fromAmino(object) {
        const message = createBaseAttributeContext_Response();
        if (object.code !== undefined && object.code !== null) {
            message.code = BigInt(object.code);
        }
        if (object.size !== undefined && object.size !== null) {
            message.size = BigInt(object.size);
        }
        message.headers = Object.entries(object.headers ?? {}).reduce((acc, [key, value]) => {
            if (value !== undefined) {
                acc[key] = String(value);
            }
            return acc;
        }, {});
        if (object.time !== undefined && object.time !== null) {
            message.time = (0, helpers_1.fromTimestamp)(timestamp_1.Timestamp.fromAmino(object.time));
        }
        if (object.backend_latency !== undefined && object.backend_latency !== null) {
            message.backendLatency = duration_1.Duration.fromAmino(object.backend_latency);
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.code = message.code !== BigInt(0) ? message.code?.toString() : undefined;
        obj.size = message.size !== BigInt(0) ? message.size?.toString() : undefined;
        obj.headers = {};
        if (message.headers) {
            Object.entries(message.headers).forEach(([k, v]) => {
                obj.headers[k] = v;
            });
        }
        obj.time = message.time ? timestamp_1.Timestamp.toAmino((0, helpers_1.toTimestamp)(message.time)) : undefined;
        obj.backend_latency = message.backendLatency ? duration_1.Duration.toAmino(message.backendLatency) : undefined;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.AttributeContext_Response.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.AttributeContext_Response.decode(message.value);
    },
    toProto(message) {
        return exports.AttributeContext_Response.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.rpc.context.Response",
            value: exports.AttributeContext_Response.encode(message).finish()
        };
    }
};
function createBaseAttributeContext_Resource_LabelsEntry() {
    return {
        key: "",
        value: ""
    };
}
exports.AttributeContext_Resource_LabelsEntry = {
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.key !== "") {
            writer.uint32(10).string(message.key);
        }
        if (message.value !== "") {
            writer.uint32(18).string(message.value);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseAttributeContext_Resource_LabelsEntry();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.key = reader.string();
                    break;
                case 2:
                    message.value = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseAttributeContext_Resource_LabelsEntry();
        message.key = object.key ?? "";
        message.value = object.value ?? "";
        return message;
    },
    fromAmino(object) {
        const message = createBaseAttributeContext_Resource_LabelsEntry();
        if (object.key !== undefined && object.key !== null) {
            message.key = object.key;
        }
        if (object.value !== undefined && object.value !== null) {
            message.value = object.value;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.key = message.key === "" ? undefined : message.key;
        obj.value = message.value === "" ? undefined : message.value;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.AttributeContext_Resource_LabelsEntry.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.AttributeContext_Resource_LabelsEntry.decode(message.value);
    },
    toProto(message) {
        return exports.AttributeContext_Resource_LabelsEntry.encode(message).finish();
    }
};
function createBaseAttributeContext_Resource_AnnotationsEntry() {
    return {
        key: "",
        value: ""
    };
}
exports.AttributeContext_Resource_AnnotationsEntry = {
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.key !== "") {
            writer.uint32(10).string(message.key);
        }
        if (message.value !== "") {
            writer.uint32(18).string(message.value);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseAttributeContext_Resource_AnnotationsEntry();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.key = reader.string();
                    break;
                case 2:
                    message.value = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseAttributeContext_Resource_AnnotationsEntry();
        message.key = object.key ?? "";
        message.value = object.value ?? "";
        return message;
    },
    fromAmino(object) {
        const message = createBaseAttributeContext_Resource_AnnotationsEntry();
        if (object.key !== undefined && object.key !== null) {
            message.key = object.key;
        }
        if (object.value !== undefined && object.value !== null) {
            message.value = object.value;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.key = message.key === "" ? undefined : message.key;
        obj.value = message.value === "" ? undefined : message.value;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.AttributeContext_Resource_AnnotationsEntry.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.AttributeContext_Resource_AnnotationsEntry.decode(message.value);
    },
    toProto(message) {
        return exports.AttributeContext_Resource_AnnotationsEntry.encode(message).finish();
    }
};
function createBaseAttributeContext_Resource() {
    return {
        service: "",
        name: "",
        type: "",
        labels: {},
        uid: "",
        annotations: {},
        displayName: "",
        createTime: undefined,
        updateTime: undefined,
        deleteTime: undefined,
        etag: "",
        location: ""
    };
}
exports.AttributeContext_Resource = {
    typeUrl: "/google.rpc.context.Resource",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.service !== "") {
            writer.uint32(10).string(message.service);
        }
        if (message.name !== "") {
            writer.uint32(18).string(message.name);
        }
        if (message.type !== "") {
            writer.uint32(26).string(message.type);
        }
        Object.entries(message.labels).forEach(([key, value]) => {
            exports.AttributeContext_Resource_LabelsEntry.encode({
                key: key,
                value
            }, writer.uint32(34).fork()).ldelim();
        });
        if (message.uid !== "") {
            writer.uint32(42).string(message.uid);
        }
        Object.entries(message.annotations).forEach(([key, value]) => {
            exports.AttributeContext_Resource_AnnotationsEntry.encode({
                key: key,
                value
            }, writer.uint32(50).fork()).ldelim();
        });
        if (message.displayName !== "") {
            writer.uint32(58).string(message.displayName);
        }
        if (message.createTime !== undefined) {
            timestamp_1.Timestamp.encode((0, helpers_1.toTimestamp)(message.createTime), writer.uint32(66).fork()).ldelim();
        }
        if (message.updateTime !== undefined) {
            timestamp_1.Timestamp.encode((0, helpers_1.toTimestamp)(message.updateTime), writer.uint32(74).fork()).ldelim();
        }
        if (message.deleteTime !== undefined) {
            timestamp_1.Timestamp.encode((0, helpers_1.toTimestamp)(message.deleteTime), writer.uint32(82).fork()).ldelim();
        }
        if (message.etag !== "") {
            writer.uint32(90).string(message.etag);
        }
        if (message.location !== "") {
            writer.uint32(98).string(message.location);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseAttributeContext_Resource();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.service = reader.string();
                    break;
                case 2:
                    message.name = reader.string();
                    break;
                case 3:
                    message.type = reader.string();
                    break;
                case 4:
                    const entry4 = exports.AttributeContext_Resource_LabelsEntry.decode(reader, reader.uint32());
                    if (entry4.value !== undefined) {
                        message.labels[entry4.key] = entry4.value;
                    }
                    break;
                case 5:
                    message.uid = reader.string();
                    break;
                case 6:
                    const entry6 = exports.AttributeContext_Resource_AnnotationsEntry.decode(reader, reader.uint32());
                    if (entry6.value !== undefined) {
                        message.annotations[entry6.key] = entry6.value;
                    }
                    break;
                case 7:
                    message.displayName = reader.string();
                    break;
                case 8:
                    message.createTime = (0, helpers_1.fromTimestamp)(timestamp_1.Timestamp.decode(reader, reader.uint32()));
                    break;
                case 9:
                    message.updateTime = (0, helpers_1.fromTimestamp)(timestamp_1.Timestamp.decode(reader, reader.uint32()));
                    break;
                case 10:
                    message.deleteTime = (0, helpers_1.fromTimestamp)(timestamp_1.Timestamp.decode(reader, reader.uint32()));
                    break;
                case 11:
                    message.etag = reader.string();
                    break;
                case 12:
                    message.location = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseAttributeContext_Resource();
        message.service = object.service ?? "";
        message.name = object.name ?? "";
        message.type = object.type ?? "";
        message.labels = Object.entries(object.labels ?? {}).reduce((acc, [key, value]) => {
            if (value !== undefined) {
                acc[key] = String(value);
            }
            return acc;
        }, {});
        message.uid = object.uid ?? "";
        message.annotations = Object.entries(object.annotations ?? {}).reduce((acc, [key, value]) => {
            if (value !== undefined) {
                acc[key] = String(value);
            }
            return acc;
        }, {});
        message.displayName = object.displayName ?? "";
        message.createTime = object.createTime ?? undefined;
        message.updateTime = object.updateTime ?? undefined;
        message.deleteTime = object.deleteTime ?? undefined;
        message.etag = object.etag ?? "";
        message.location = object.location ?? "";
        return message;
    },
    fromAmino(object) {
        const message = createBaseAttributeContext_Resource();
        if (object.service !== undefined && object.service !== null) {
            message.service = object.service;
        }
        if (object.name !== undefined && object.name !== null) {
            message.name = object.name;
        }
        if (object.type !== undefined && object.type !== null) {
            message.type = object.type;
        }
        message.labels = Object.entries(object.labels ?? {}).reduce((acc, [key, value]) => {
            if (value !== undefined) {
                acc[key] = String(value);
            }
            return acc;
        }, {});
        if (object.uid !== undefined && object.uid !== null) {
            message.uid = object.uid;
        }
        message.annotations = Object.entries(object.annotations ?? {}).reduce((acc, [key, value]) => {
            if (value !== undefined) {
                acc[key] = String(value);
            }
            return acc;
        }, {});
        if (object.display_name !== undefined && object.display_name !== null) {
            message.displayName = object.display_name;
        }
        if (object.create_time !== undefined && object.create_time !== null) {
            message.createTime = (0, helpers_1.fromTimestamp)(timestamp_1.Timestamp.fromAmino(object.create_time));
        }
        if (object.update_time !== undefined && object.update_time !== null) {
            message.updateTime = (0, helpers_1.fromTimestamp)(timestamp_1.Timestamp.fromAmino(object.update_time));
        }
        if (object.delete_time !== undefined && object.delete_time !== null) {
            message.deleteTime = (0, helpers_1.fromTimestamp)(timestamp_1.Timestamp.fromAmino(object.delete_time));
        }
        if (object.etag !== undefined && object.etag !== null) {
            message.etag = object.etag;
        }
        if (object.location !== undefined && object.location !== null) {
            message.location = object.location;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.service = message.service === "" ? undefined : message.service;
        obj.name = message.name === "" ? undefined : message.name;
        obj.type = message.type === "" ? undefined : message.type;
        obj.labels = {};
        if (message.labels) {
            Object.entries(message.labels).forEach(([k, v]) => {
                obj.labels[k] = v;
            });
        }
        obj.uid = message.uid === "" ? undefined : message.uid;
        obj.annotations = {};
        if (message.annotations) {
            Object.entries(message.annotations).forEach(([k, v]) => {
                obj.annotations[k] = v;
            });
        }
        obj.display_name = message.displayName === "" ? undefined : message.displayName;
        obj.create_time = message.createTime ? timestamp_1.Timestamp.toAmino((0, helpers_1.toTimestamp)(message.createTime)) : undefined;
        obj.update_time = message.updateTime ? timestamp_1.Timestamp.toAmino((0, helpers_1.toTimestamp)(message.updateTime)) : undefined;
        obj.delete_time = message.deleteTime ? timestamp_1.Timestamp.toAmino((0, helpers_1.toTimestamp)(message.deleteTime)) : undefined;
        obj.etag = message.etag === "" ? undefined : message.etag;
        obj.location = message.location === "" ? undefined : message.location;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.AttributeContext_Resource.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.AttributeContext_Resource.decode(message.value);
    },
    toProto(message) {
        return exports.AttributeContext_Resource.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.rpc.context.Resource",
            value: exports.AttributeContext_Resource.encode(message).finish()
        };
    }
};
