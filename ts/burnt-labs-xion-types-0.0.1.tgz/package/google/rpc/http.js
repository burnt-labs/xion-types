"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.HttpHeader = exports.HttpResponse = exports.HttpRequest = void 0;
//@ts-nocheck
const binary_1 = require("../../binary");
const helpers_1 = require("../../helpers");
function createBaseHttpRequest() {
    return {
        method: "",
        uri: "",
        headers: [],
        body: new Uint8Array()
    };
}
exports.HttpRequest = {
    typeUrl: "/google.rpc.HttpRequest",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.method !== "") {
            writer.uint32(10).string(message.method);
        }
        if (message.uri !== "") {
            writer.uint32(18).string(message.uri);
        }
        for (const v of message.headers) {
            exports.HttpHeader.encode(v, writer.uint32(26).fork()).ldelim();
        }
        if (message.body.length !== 0) {
            writer.uint32(34).bytes(message.body);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseHttpRequest();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.method = reader.string();
                    break;
                case 2:
                    message.uri = reader.string();
                    break;
                case 3:
                    message.headers.push(exports.HttpHeader.decode(reader, reader.uint32()));
                    break;
                case 4:
                    message.body = reader.bytes();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseHttpRequest();
        message.method = object.method ?? "";
        message.uri = object.uri ?? "";
        message.headers = object.headers?.map(e => exports.HttpHeader.fromPartial(e)) || [];
        message.body = object.body ?? new Uint8Array();
        return message;
    },
    fromAmino(object) {
        const message = createBaseHttpRequest();
        if (object.method !== undefined && object.method !== null) {
            message.method = object.method;
        }
        if (object.uri !== undefined && object.uri !== null) {
            message.uri = object.uri;
        }
        message.headers = object.headers?.map(e => exports.HttpHeader.fromAmino(e)) || [];
        if (object.body !== undefined && object.body !== null) {
            message.body = (0, helpers_1.bytesFromBase64)(object.body);
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.method = message.method === "" ? undefined : message.method;
        obj.uri = message.uri === "" ? undefined : message.uri;
        if (message.headers) {
            obj.headers = message.headers.map(e => e ? exports.HttpHeader.toAmino(e) : undefined);
        }
        else {
            obj.headers = message.headers;
        }
        obj.body = message.body ? (0, helpers_1.base64FromBytes)(message.body) : undefined;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.HttpRequest.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.HttpRequest.decode(message.value);
    },
    toProto(message) {
        return exports.HttpRequest.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.rpc.HttpRequest",
            value: exports.HttpRequest.encode(message).finish()
        };
    }
};
function createBaseHttpResponse() {
    return {
        status: 0,
        reason: "",
        headers: [],
        body: new Uint8Array()
    };
}
exports.HttpResponse = {
    typeUrl: "/google.rpc.HttpResponse",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.status !== 0) {
            writer.uint32(8).int32(message.status);
        }
        if (message.reason !== "") {
            writer.uint32(18).string(message.reason);
        }
        for (const v of message.headers) {
            exports.HttpHeader.encode(v, writer.uint32(26).fork()).ldelim();
        }
        if (message.body.length !== 0) {
            writer.uint32(34).bytes(message.body);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseHttpResponse();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.status = reader.int32();
                    break;
                case 2:
                    message.reason = reader.string();
                    break;
                case 3:
                    message.headers.push(exports.HttpHeader.decode(reader, reader.uint32()));
                    break;
                case 4:
                    message.body = reader.bytes();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseHttpResponse();
        message.status = object.status ?? 0;
        message.reason = object.reason ?? "";
        message.headers = object.headers?.map(e => exports.HttpHeader.fromPartial(e)) || [];
        message.body = object.body ?? new Uint8Array();
        return message;
    },
    fromAmino(object) {
        const message = createBaseHttpResponse();
        if (object.status !== undefined && object.status !== null) {
            message.status = object.status;
        }
        if (object.reason !== undefined && object.reason !== null) {
            message.reason = object.reason;
        }
        message.headers = object.headers?.map(e => exports.HttpHeader.fromAmino(e)) || [];
        if (object.body !== undefined && object.body !== null) {
            message.body = (0, helpers_1.bytesFromBase64)(object.body);
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.status = message.status === 0 ? undefined : message.status;
        obj.reason = message.reason === "" ? undefined : message.reason;
        if (message.headers) {
            obj.headers = message.headers.map(e => e ? exports.HttpHeader.toAmino(e) : undefined);
        }
        else {
            obj.headers = message.headers;
        }
        obj.body = message.body ? (0, helpers_1.base64FromBytes)(message.body) : undefined;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.HttpResponse.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.HttpResponse.decode(message.value);
    },
    toProto(message) {
        return exports.HttpResponse.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.rpc.HttpResponse",
            value: exports.HttpResponse.encode(message).finish()
        };
    }
};
function createBaseHttpHeader() {
    return {
        key: "",
        value: ""
    };
}
exports.HttpHeader = {
    typeUrl: "/google.rpc.HttpHeader",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.key !== "") {
            writer.uint32(10).string(message.key);
        }
        if (message.value !== "") {
            writer.uint32(18).string(message.value);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseHttpHeader();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.key = reader.string();
                    break;
                case 2:
                    message.value = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseHttpHeader();
        message.key = object.key ?? "";
        message.value = object.value ?? "";
        return message;
    },
    fromAmino(object) {
        const message = createBaseHttpHeader();
        if (object.key !== undefined && object.key !== null) {
            message.key = object.key;
        }
        if (object.value !== undefined && object.value !== null) {
            message.value = object.value;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.key = message.key === "" ? undefined : message.key;
        obj.value = message.value === "" ? undefined : message.value;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.HttpHeader.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.HttpHeader.decode(message.value);
    },
    toProto(message) {
        return exports.HttpHeader.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.rpc.HttpHeader",
            value: exports.HttpHeader.encode(message).finish()
        };
    }
};
