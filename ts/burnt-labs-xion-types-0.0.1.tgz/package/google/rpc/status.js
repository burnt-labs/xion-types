"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Status = void 0;
//@ts-nocheck
const any_1 = require("../protobuf/any");
const binary_1 = require("../../binary");
function createBaseStatus() {
    return {
        code: 0,
        message: "",
        details: []
    };
}
exports.Status = {
    typeUrl: "/google.rpc.Status",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.code !== 0) {
            writer.uint32(8).int32(message.code);
        }
        if (message.message !== "") {
            writer.uint32(18).string(message.message);
        }
        for (const v of message.details) {
            any_1.Any.encode(v, writer.uint32(26).fork()).ldelim();
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseStatus();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.code = reader.int32();
                    break;
                case 2:
                    message.message = reader.string();
                    break;
                case 3:
                    message.details.push(any_1.Any.decode(reader, reader.uint32()));
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseStatus();
        message.code = object.code ?? 0;
        message.message = object.message ?? "";
        message.details = object.details?.map(e => any_1.Any.fromPartial(e)) || [];
        return message;
    },
    fromAmino(object) {
        const message = createBaseStatus();
        if (object.code !== undefined && object.code !== null) {
            message.code = object.code;
        }
        if (object.message !== undefined && object.message !== null) {
            message.message = object.message;
        }
        message.details = object.details?.map(e => any_1.Any.fromAmino(e)) || [];
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.code = message.code === 0 ? undefined : message.code;
        obj.message = message.message === "" ? undefined : message.message;
        if (message.details) {
            obj.details = message.details.map(e => e ? any_1.Any.toAmino(e) : undefined);
        }
        else {
            obj.details = message.details;
        }
        return obj;
    },
    fromAminoMsg(object) {
        return exports.Status.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.Status.decode(message.value);
    },
    toProto(message) {
        return exports.Status.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.rpc.Status",
            value: exports.Status.encode(message).finish()
        };
    }
};
