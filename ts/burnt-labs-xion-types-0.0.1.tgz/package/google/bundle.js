"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.google = void 0;
//@ts-nocheck
const _156 = __importStar(require("./api/annotations"));
const _157 = __importStar(require("./api/auth"));
const _158 = __importStar(require("./api/backend"));
const _159 = __importStar(require("./api/billing"));
const _160 = __importStar(require("./api/client"));
const _161 = __importStar(require("./api/config_change"));
const _162 = __importStar(require("./api/consumer"));
const _163 = __importStar(require("./api/context"));
const _164 = __importStar(require("./api/control"));
const _165 = __importStar(require("./api/distribution"));
const _166 = __importStar(require("./api/documentation"));
const _167 = __importStar(require("./api/endpoint"));
const _168 = __importStar(require("./api/error_reason"));
const _169 = __importStar(require("./api/field_behavior"));
const _170 = __importStar(require("./api/field_info"));
const _171 = __importStar(require("./api/http"));
const _172 = __importStar(require("./api/httpbody"));
const _173 = __importStar(require("./api/label"));
const _174 = __importStar(require("./api/launch_stage"));
const _175 = __importStar(require("./api/log"));
const _176 = __importStar(require("./api/logging"));
const _177 = __importStar(require("./api/metric"));
const _178 = __importStar(require("./api/monitored_resource"));
const _179 = __importStar(require("./api/monitoring"));
const _180 = __importStar(require("./api/policy"));
const _181 = __importStar(require("./api/quota"));
const _182 = __importStar(require("./api/resource"));
const _183 = __importStar(require("./api/routing"));
const _184 = __importStar(require("./api/service"));
const _185 = __importStar(require("./api/source_info"));
const _186 = __importStar(require("./api/system_parameter"));
const _187 = __importStar(require("./api/usage"));
const _188 = __importStar(require("./api/visibility"));
const _189 = __importStar(require("./logging/type/log_severity"));
const _190 = __importStar(require("./longrunning/operations"));
const _191 = __importStar(require("./protobuf/any"));
const _192 = __importStar(require("./protobuf/api"));
const _193 = __importStar(require("./protobuf/descriptor"));
const _194 = __importStar(require("./protobuf/duration"));
const _195 = __importStar(require("./protobuf/empty"));
const _196 = __importStar(require("./protobuf/field_mask"));
const _197 = __importStar(require("./protobuf/source_context"));
const _198 = __importStar(require("./protobuf/struct"));
const _199 = __importStar(require("./protobuf/timestamp"));
const _200 = __importStar(require("./protobuf/type"));
const _201 = __importStar(require("./protobuf/wrappers"));
const _202 = __importStar(require("./rpc/code"));
const _203 = __importStar(require("./rpc/error_details"));
const _204 = __importStar(require("./rpc/http"));
const _205 = __importStar(require("./rpc/status"));
var google;
(function (google) {
    google.api = {
        ..._156,
        ..._157,
        ..._158,
        ..._159,
        ..._160,
        ..._161,
        ..._162,
        ..._163,
        ..._164,
        ..._165,
        ..._166,
        ..._167,
        ..._168,
        ..._169,
        ..._170,
        ..._171,
        ..._172,
        ..._173,
        ..._174,
        ..._175,
        ..._176,
        ..._177,
        ..._178,
        ..._179,
        ..._180,
        ..._181,
        ..._182,
        ..._183,
        ..._184,
        ..._185,
        ..._186,
        ..._187,
        ..._188
    };
    let logging;
    (function (logging) {
        logging.type = {
            ..._189
        };
    })(logging = google.logging || (google.logging = {}));
    google.longrunning = {
        ..._190
    };
    google.protobuf = {
        ..._191,
        ..._192,
        ..._193,
        ..._194,
        ..._195,
        ..._196,
        ..._197,
        ..._198,
        ..._199,
        ..._200,
        ..._201
    };
    google.rpc = {
        ..._202,
        ..._203,
        ..._204,
        ..._205
    };
})(google || (exports.google = google = {}));
