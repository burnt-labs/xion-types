"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ListValue = exports.Value = exports.Struct = exports.Struct_FieldsEntry = exports.NullValueAmino = exports.NullValueSDKType = exports.NullValue = void 0;
exports.nullValueFromJSON = nullValueFromJSON;
exports.nullValueToJSON = nullValueToJSON;
//@ts-nocheck
const binary_1 = require("../../binary");
/**
 * `NullValue` is a singleton enumeration to represent the null value for the
 * `Value` type union.
 *
 * The JSON representation for `NullValue` is JSON `null`.
 */
var NullValue;
(function (NullValue) {
    /** NULL_VALUE - Null value. */
    NullValue[NullValue["NULL_VALUE"] = 0] = "NULL_VALUE";
    NullValue[NullValue["UNRECOGNIZED"] = -1] = "UNRECOGNIZED";
})(NullValue || (exports.NullValue = NullValue = {}));
exports.NullValueSDKType = NullValue;
exports.NullValueAmino = NullValue;
function nullValueFromJSON(object) {
    switch (object) {
        case 0:
        case "NULL_VALUE":
            return NullValue.NULL_VALUE;
        case -1:
        case "UNRECOGNIZED":
        default:
            return NullValue.UNRECOGNIZED;
    }
}
function nullValueToJSON(object) {
    switch (object) {
        case NullValue.NULL_VALUE:
            return "NULL_VALUE";
        case NullValue.UNRECOGNIZED:
        default:
            return "UNRECOGNIZED";
    }
}
function createBaseStruct_FieldsEntry() {
    return {
        key: "",
        value: undefined
    };
}
exports.Struct_FieldsEntry = {
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.key !== "") {
            writer.uint32(10).string(message.key);
        }
        if (message.value !== undefined) {
            exports.Value.encode(message.value, writer.uint32(18).fork()).ldelim();
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseStruct_FieldsEntry();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.key = reader.string();
                    break;
                case 2:
                    message.value = exports.Value.decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseStruct_FieldsEntry();
        message.key = object.key ?? "";
        message.value = object.value !== undefined && object.value !== null ? exports.Value.fromPartial(object.value) : undefined;
        return message;
    },
    fromAmino(object) {
        const message = createBaseStruct_FieldsEntry();
        if (object.key !== undefined && object.key !== null) {
            message.key = object.key;
        }
        if (object.value !== undefined && object.value !== null) {
            message.value = exports.Value.fromAmino(object.value);
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.key = message.key === "" ? undefined : message.key;
        obj.value = message.value ? exports.Value.toAmino(message.value) : undefined;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.Struct_FieldsEntry.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.Struct_FieldsEntry.decode(message.value);
    },
    toProto(message) {
        return exports.Struct_FieldsEntry.encode(message).finish();
    }
};
function createBaseStruct() {
    return {
        fields: {}
    };
}
exports.Struct = {
    typeUrl: "/google.protobuf.Struct",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        Object.entries(message.fields).forEach(([key, value]) => {
            exports.Struct_FieldsEntry.encode({
                key: key,
                value
            }, writer.uint32(10).fork()).ldelim();
        });
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseStruct();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    const entry1 = exports.Struct_FieldsEntry.decode(reader, reader.uint32());
                    if (entry1.value !== undefined) {
                        message.fields[entry1.key] = entry1.value;
                    }
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseStruct();
        message.fields = Object.entries(object.fields ?? {}).reduce((acc, [key, value]) => {
            if (value !== undefined) {
                acc[key] = exports.Value.fromPartial(value);
            }
            return acc;
        }, {});
        return message;
    },
    fromAmino(object) {
        const message = createBaseStruct();
        message.fields = Object.entries(object.fields ?? {}).reduce((acc, [key, value]) => {
            if (value !== undefined) {
                acc[key] = exports.Value.fromAmino(value);
            }
            return acc;
        }, {});
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.fields = {};
        if (message.fields) {
            Object.entries(message.fields).forEach(([k, v]) => {
                obj.fields[k] = exports.Value.toAmino(v);
            });
        }
        return obj;
    },
    fromAminoMsg(object) {
        return exports.Struct.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.Struct.decode(message.value);
    },
    toProto(message) {
        return exports.Struct.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.protobuf.Struct",
            value: exports.Struct.encode(message).finish()
        };
    }
};
function createBaseValue() {
    return {
        nullValue: undefined,
        numberValue: undefined,
        stringValue: undefined,
        boolValue: undefined,
        structValue: undefined,
        listValue: undefined
    };
}
exports.Value = {
    typeUrl: "/google.protobuf.Value",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.nullValue !== undefined) {
            writer.uint32(8).int32(message.nullValue);
        }
        if (message.numberValue !== undefined) {
            writer.uint32(17).double(message.numberValue);
        }
        if (message.stringValue !== undefined) {
            writer.uint32(26).string(message.stringValue);
        }
        if (message.boolValue !== undefined) {
            writer.uint32(32).bool(message.boolValue);
        }
        if (message.structValue !== undefined) {
            exports.Struct.encode(message.structValue, writer.uint32(42).fork()).ldelim();
        }
        if (message.listValue !== undefined) {
            exports.ListValue.encode(message.listValue, writer.uint32(50).fork()).ldelim();
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseValue();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.nullValue = reader.int32();
                    break;
                case 2:
                    message.numberValue = reader.double();
                    break;
                case 3:
                    message.stringValue = reader.string();
                    break;
                case 4:
                    message.boolValue = reader.bool();
                    break;
                case 5:
                    message.structValue = exports.Struct.decode(reader, reader.uint32());
                    break;
                case 6:
                    message.listValue = exports.ListValue.decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseValue();
        message.nullValue = object.nullValue ?? undefined;
        message.numberValue = object.numberValue ?? undefined;
        message.stringValue = object.stringValue ?? undefined;
        message.boolValue = object.boolValue ?? undefined;
        message.structValue = object.structValue !== undefined && object.structValue !== null ? exports.Struct.fromPartial(object.structValue) : undefined;
        message.listValue = object.listValue !== undefined && object.listValue !== null ? exports.ListValue.fromPartial(object.listValue) : undefined;
        return message;
    },
    fromAmino(object) {
        const message = createBaseValue();
        if (object.null_value !== undefined && object.null_value !== null) {
            message.nullValue = object.null_value;
        }
        if (object.number_value !== undefined && object.number_value !== null) {
            message.numberValue = object.number_value;
        }
        if (object.string_value !== undefined && object.string_value !== null) {
            message.stringValue = object.string_value;
        }
        if (object.bool_value !== undefined && object.bool_value !== null) {
            message.boolValue = object.bool_value;
        }
        if (object.struct_value !== undefined && object.struct_value !== null) {
            message.structValue = exports.Struct.fromAmino(object.struct_value);
        }
        if (object.list_value !== undefined && object.list_value !== null) {
            message.listValue = exports.ListValue.fromAmino(object.list_value);
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.null_value = message.nullValue === null ? undefined : message.nullValue;
        obj.number_value = message.numberValue === null ? undefined : message.numberValue;
        obj.string_value = message.stringValue === null ? undefined : message.stringValue;
        obj.bool_value = message.boolValue === null ? undefined : message.boolValue;
        obj.struct_value = message.structValue ? exports.Struct.toAmino(message.structValue) : undefined;
        obj.list_value = message.listValue ? exports.ListValue.toAmino(message.listValue) : undefined;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.Value.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.Value.decode(message.value);
    },
    toProto(message) {
        return exports.Value.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.protobuf.Value",
            value: exports.Value.encode(message).finish()
        };
    }
};
function createBaseListValue() {
    return {
        values: []
    };
}
exports.ListValue = {
    typeUrl: "/google.protobuf.ListValue",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        for (const v of message.values) {
            exports.Value.encode(v, writer.uint32(10).fork()).ldelim();
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseListValue();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.values.push(exports.Value.decode(reader, reader.uint32()));
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseListValue();
        message.values = object.values?.map(e => exports.Value.fromPartial(e)) || [];
        return message;
    },
    fromAmino(object) {
        const message = createBaseListValue();
        message.values = object.values?.map(e => exports.Value.fromAmino(e)) || [];
        return message;
    },
    toAmino(message) {
        const obj = {};
        if (message.values) {
            obj.values = message.values.map(e => e ? exports.Value.toAmino(e) : undefined);
        }
        else {
            obj.values = message.values;
        }
        return obj;
    },
    fromAminoMsg(object) {
        return exports.ListValue.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.ListValue.decode(message.value);
    },
    toProto(message) {
        return exports.ListValue.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.protobuf.ListValue",
            value: exports.ListValue.encode(message).finish()
        };
    }
};
