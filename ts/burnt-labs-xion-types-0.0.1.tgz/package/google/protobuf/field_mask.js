"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.FieldMask = void 0;
//@ts-nocheck
const binary_1 = require("../../binary");
function createBaseFieldMask() {
    return {
        paths: []
    };
}
exports.FieldMask = {
    typeUrl: "/google.protobuf.FieldMask",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        for (const v of message.paths) {
            writer.uint32(10).string(v);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseFieldMask();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.paths.push(reader.string());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseFieldMask();
        message.paths = object.paths?.map(e => e) || [];
        return message;
    },
    fromAmino(object) {
        const message = createBaseFieldMask();
        message.paths = object.paths?.map(e => e) || [];
        return message;
    },
    toAmino(message) {
        const obj = {};
        if (message.paths) {
            obj.paths = message.paths.map(e => e);
        }
        else {
            obj.paths = message.paths;
        }
        return obj;
    },
    fromAminoMsg(object) {
        return exports.FieldMask.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.FieldMask.decode(message.value);
    },
    toProto(message) {
        return exports.FieldMask.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.protobuf.FieldMask",
            value: exports.FieldMask.encode(message).finish()
        };
    }
};
