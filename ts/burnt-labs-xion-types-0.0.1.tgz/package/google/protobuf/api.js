"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Mixin = exports.Method = exports.Api = void 0;
//@ts-nocheck
const type_1 = require("./type");
const source_context_1 = require("./source_context");
const binary_1 = require("../../binary");
function createBaseApi() {
    return {
        name: "",
        methods: [],
        options: [],
        version: "",
        sourceContext: undefined,
        mixins: [],
        syntax: 0,
        edition: ""
    };
}
exports.Api = {
    typeUrl: "/google.protobuf.Api",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.name !== "") {
            writer.uint32(10).string(message.name);
        }
        for (const v of message.methods) {
            exports.Method.encode(v, writer.uint32(18).fork()).ldelim();
        }
        for (const v of message.options) {
            type_1.Option.encode(v, writer.uint32(26).fork()).ldelim();
        }
        if (message.version !== "") {
            writer.uint32(34).string(message.version);
        }
        if (message.sourceContext !== undefined) {
            source_context_1.SourceContext.encode(message.sourceContext, writer.uint32(42).fork()).ldelim();
        }
        for (const v of message.mixins) {
            exports.Mixin.encode(v, writer.uint32(50).fork()).ldelim();
        }
        if (message.syntax !== 0) {
            writer.uint32(56).int32(message.syntax);
        }
        if (message.edition !== "") {
            writer.uint32(66).string(message.edition);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseApi();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.name = reader.string();
                    break;
                case 2:
                    message.methods.push(exports.Method.decode(reader, reader.uint32()));
                    break;
                case 3:
                    message.options.push(type_1.Option.decode(reader, reader.uint32()));
                    break;
                case 4:
                    message.version = reader.string();
                    break;
                case 5:
                    message.sourceContext = source_context_1.SourceContext.decode(reader, reader.uint32());
                    break;
                case 6:
                    message.mixins.push(exports.Mixin.decode(reader, reader.uint32()));
                    break;
                case 7:
                    message.syntax = reader.int32();
                    break;
                case 8:
                    message.edition = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseApi();
        message.name = object.name ?? "";
        message.methods = object.methods?.map(e => exports.Method.fromPartial(e)) || [];
        message.options = object.options?.map(e => type_1.Option.fromPartial(e)) || [];
        message.version = object.version ?? "";
        message.sourceContext = object.sourceContext !== undefined && object.sourceContext !== null ? source_context_1.SourceContext.fromPartial(object.sourceContext) : undefined;
        message.mixins = object.mixins?.map(e => exports.Mixin.fromPartial(e)) || [];
        message.syntax = object.syntax ?? 0;
        message.edition = object.edition ?? "";
        return message;
    },
    fromAmino(object) {
        const message = createBaseApi();
        if (object.name !== undefined && object.name !== null) {
            message.name = object.name;
        }
        message.methods = object.methods?.map(e => exports.Method.fromAmino(e)) || [];
        message.options = object.options?.map(e => type_1.Option.fromAmino(e)) || [];
        if (object.version !== undefined && object.version !== null) {
            message.version = object.version;
        }
        if (object.source_context !== undefined && object.source_context !== null) {
            message.sourceContext = source_context_1.SourceContext.fromAmino(object.source_context);
        }
        message.mixins = object.mixins?.map(e => exports.Mixin.fromAmino(e)) || [];
        if (object.syntax !== undefined && object.syntax !== null) {
            message.syntax = object.syntax;
        }
        if (object.edition !== undefined && object.edition !== null) {
            message.edition = object.edition;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.name = message.name === "" ? undefined : message.name;
        if (message.methods) {
            obj.methods = message.methods.map(e => e ? exports.Method.toAmino(e) : undefined);
        }
        else {
            obj.methods = message.methods;
        }
        if (message.options) {
            obj.options = message.options.map(e => e ? type_1.Option.toAmino(e) : undefined);
        }
        else {
            obj.options = message.options;
        }
        obj.version = message.version === "" ? undefined : message.version;
        obj.source_context = message.sourceContext ? source_context_1.SourceContext.toAmino(message.sourceContext) : undefined;
        if (message.mixins) {
            obj.mixins = message.mixins.map(e => e ? exports.Mixin.toAmino(e) : undefined);
        }
        else {
            obj.mixins = message.mixins;
        }
        obj.syntax = message.syntax === 0 ? undefined : message.syntax;
        obj.edition = message.edition === "" ? undefined : message.edition;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.Api.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.Api.decode(message.value);
    },
    toProto(message) {
        return exports.Api.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.protobuf.Api",
            value: exports.Api.encode(message).finish()
        };
    }
};
function createBaseMethod() {
    return {
        name: "",
        requestTypeUrl: "",
        requestStreaming: false,
        responseTypeUrl: "",
        responseStreaming: false,
        options: [],
        syntax: 0,
        edition: ""
    };
}
exports.Method = {
    typeUrl: "/google.protobuf.Method",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.name !== "") {
            writer.uint32(10).string(message.name);
        }
        if (message.requestTypeUrl !== "") {
            writer.uint32(18).string(message.requestTypeUrl);
        }
        if (message.requestStreaming === true) {
            writer.uint32(24).bool(message.requestStreaming);
        }
        if (message.responseTypeUrl !== "") {
            writer.uint32(34).string(message.responseTypeUrl);
        }
        if (message.responseStreaming === true) {
            writer.uint32(40).bool(message.responseStreaming);
        }
        for (const v of message.options) {
            type_1.Option.encode(v, writer.uint32(50).fork()).ldelim();
        }
        if (message.syntax !== 0) {
            writer.uint32(56).int32(message.syntax);
        }
        if (message.edition !== "") {
            writer.uint32(66).string(message.edition);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseMethod();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.name = reader.string();
                    break;
                case 2:
                    message.requestTypeUrl = reader.string();
                    break;
                case 3:
                    message.requestStreaming = reader.bool();
                    break;
                case 4:
                    message.responseTypeUrl = reader.string();
                    break;
                case 5:
                    message.responseStreaming = reader.bool();
                    break;
                case 6:
                    message.options.push(type_1.Option.decode(reader, reader.uint32()));
                    break;
                case 7:
                    message.syntax = reader.int32();
                    break;
                case 8:
                    message.edition = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseMethod();
        message.name = object.name ?? "";
        message.requestTypeUrl = object.requestTypeUrl ?? "";
        message.requestStreaming = object.requestStreaming ?? false;
        message.responseTypeUrl = object.responseTypeUrl ?? "";
        message.responseStreaming = object.responseStreaming ?? false;
        message.options = object.options?.map(e => type_1.Option.fromPartial(e)) || [];
        message.syntax = object.syntax ?? 0;
        message.edition = object.edition ?? "";
        return message;
    },
    fromAmino(object) {
        const message = createBaseMethod();
        if (object.name !== undefined && object.name !== null) {
            message.name = object.name;
        }
        if (object.request_type_url !== undefined && object.request_type_url !== null) {
            message.requestTypeUrl = object.request_type_url;
        }
        if (object.request_streaming !== undefined && object.request_streaming !== null) {
            message.requestStreaming = object.request_streaming;
        }
        if (object.response_type_url !== undefined && object.response_type_url !== null) {
            message.responseTypeUrl = object.response_type_url;
        }
        if (object.response_streaming !== undefined && object.response_streaming !== null) {
            message.responseStreaming = object.response_streaming;
        }
        message.options = object.options?.map(e => type_1.Option.fromAmino(e)) || [];
        if (object.syntax !== undefined && object.syntax !== null) {
            message.syntax = object.syntax;
        }
        if (object.edition !== undefined && object.edition !== null) {
            message.edition = object.edition;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.name = message.name === "" ? undefined : message.name;
        obj.request_type_url = message.requestTypeUrl === "" ? undefined : message.requestTypeUrl;
        obj.request_streaming = message.requestStreaming === false ? undefined : message.requestStreaming;
        obj.response_type_url = message.responseTypeUrl === "" ? undefined : message.responseTypeUrl;
        obj.response_streaming = message.responseStreaming === false ? undefined : message.responseStreaming;
        if (message.options) {
            obj.options = message.options.map(e => e ? type_1.Option.toAmino(e) : undefined);
        }
        else {
            obj.options = message.options;
        }
        obj.syntax = message.syntax === 0 ? undefined : message.syntax;
        obj.edition = message.edition === "" ? undefined : message.edition;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.Method.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.Method.decode(message.value);
    },
    toProto(message) {
        return exports.Method.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.protobuf.Method",
            value: exports.Method.encode(message).finish()
        };
    }
};
function createBaseMixin() {
    return {
        name: "",
        root: ""
    };
}
exports.Mixin = {
    typeUrl: "/google.protobuf.Mixin",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.name !== "") {
            writer.uint32(10).string(message.name);
        }
        if (message.root !== "") {
            writer.uint32(18).string(message.root);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseMixin();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.name = reader.string();
                    break;
                case 2:
                    message.root = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseMixin();
        message.name = object.name ?? "";
        message.root = object.root ?? "";
        return message;
    },
    fromAmino(object) {
        const message = createBaseMixin();
        if (object.name !== undefined && object.name !== null) {
            message.name = object.name;
        }
        if (object.root !== undefined && object.root !== null) {
            message.root = object.root;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.name = message.name === "" ? undefined : message.name;
        obj.root = message.root === "" ? undefined : message.root;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.Mixin.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.Mixin.decode(message.value);
    },
    toProto(message) {
        return exports.Mixin.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.protobuf.Mixin",
            value: exports.Mixin.encode(message).finish()
        };
    }
};
