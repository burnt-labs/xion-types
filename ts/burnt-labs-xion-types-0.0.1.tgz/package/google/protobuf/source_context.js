"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SourceContext = void 0;
//@ts-nocheck
const binary_1 = require("../../binary");
function createBaseSourceContext() {
    return {
        fileName: ""
    };
}
exports.SourceContext = {
    typeUrl: "/google.protobuf.SourceContext",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.fileName !== "") {
            writer.uint32(10).string(message.fileName);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseSourceContext();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.fileName = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseSourceContext();
        message.fileName = object.fileName ?? "";
        return message;
    },
    fromAmino(object) {
        const message = createBaseSourceContext();
        if (object.file_name !== undefined && object.file_name !== null) {
            message.fileName = object.file_name;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.file_name = message.fileName === "" ? undefined : message.fileName;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.SourceContext.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.SourceContext.decode(message.value);
    },
    toProto(message) {
        return exports.SourceContext.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.protobuf.SourceContext",
            value: exports.SourceContext.encode(message).finish()
        };
    }
};
