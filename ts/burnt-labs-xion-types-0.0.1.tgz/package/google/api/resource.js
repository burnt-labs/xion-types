"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ResourceReference = exports.ResourceDescriptor = exports.ResourceDescriptor_StyleAmino = exports.ResourceDescriptor_StyleSDKType = exports.ResourceDescriptor_Style = exports.ResourceDescriptor_HistoryAmino = exports.ResourceDescriptor_HistorySDKType = exports.ResourceDescriptor_History = void 0;
exports.resourceDescriptor_HistoryFromJSON = resourceDescriptor_HistoryFromJSON;
exports.resourceDescriptor_HistoryToJSON = resourceDescriptor_HistoryToJSON;
exports.resourceDescriptor_StyleFromJSON = resourceDescriptor_StyleFromJSON;
exports.resourceDescriptor_StyleToJSON = resourceDescriptor_StyleToJSON;
//@ts-nocheck
const binary_1 = require("../../binary");
/**
 * A description of the historical or future-looking state of the
 * resource pattern.
 */
var ResourceDescriptor_History;
(function (ResourceDescriptor_History) {
    /** HISTORY_UNSPECIFIED - The "unset" value. */
    ResourceDescriptor_History[ResourceDescriptor_History["HISTORY_UNSPECIFIED"] = 0] = "HISTORY_UNSPECIFIED";
    /**
     * ORIGINALLY_SINGLE_PATTERN - The resource originally had one pattern and launched as such, and
     * additional patterns were added later.
     */
    ResourceDescriptor_History[ResourceDescriptor_History["ORIGINALLY_SINGLE_PATTERN"] = 1] = "ORIGINALLY_SINGLE_PATTERN";
    /**
     * FUTURE_MULTI_PATTERN - The resource has one pattern, but the API owner expects to add more
     * later. (This is the inverse of ORIGINALLY_SINGLE_PATTERN, and prevents
     * that from being necessary once there are multiple patterns.)
     */
    ResourceDescriptor_History[ResourceDescriptor_History["FUTURE_MULTI_PATTERN"] = 2] = "FUTURE_MULTI_PATTERN";
    ResourceDescriptor_History[ResourceDescriptor_History["UNRECOGNIZED"] = -1] = "UNRECOGNIZED";
})(ResourceDescriptor_History || (exports.ResourceDescriptor_History = ResourceDescriptor_History = {}));
exports.ResourceDescriptor_HistorySDKType = ResourceDescriptor_History;
exports.ResourceDescriptor_HistoryAmino = ResourceDescriptor_History;
function resourceDescriptor_HistoryFromJSON(object) {
    switch (object) {
        case 0:
        case "HISTORY_UNSPECIFIED":
            return ResourceDescriptor_History.HISTORY_UNSPECIFIED;
        case 1:
        case "ORIGINALLY_SINGLE_PATTERN":
            return ResourceDescriptor_History.ORIGINALLY_SINGLE_PATTERN;
        case 2:
        case "FUTURE_MULTI_PATTERN":
            return ResourceDescriptor_History.FUTURE_MULTI_PATTERN;
        case -1:
        case "UNRECOGNIZED":
        default:
            return ResourceDescriptor_History.UNRECOGNIZED;
    }
}
function resourceDescriptor_HistoryToJSON(object) {
    switch (object) {
        case ResourceDescriptor_History.HISTORY_UNSPECIFIED:
            return "HISTORY_UNSPECIFIED";
        case ResourceDescriptor_History.ORIGINALLY_SINGLE_PATTERN:
            return "ORIGINALLY_SINGLE_PATTERN";
        case ResourceDescriptor_History.FUTURE_MULTI_PATTERN:
            return "FUTURE_MULTI_PATTERN";
        case ResourceDescriptor_History.UNRECOGNIZED:
        default:
            return "UNRECOGNIZED";
    }
}
/** A flag representing a specific style that a resource claims to conform to. */
var ResourceDescriptor_Style;
(function (ResourceDescriptor_Style) {
    /** STYLE_UNSPECIFIED - The unspecified value. Do not use. */
    ResourceDescriptor_Style[ResourceDescriptor_Style["STYLE_UNSPECIFIED"] = 0] = "STYLE_UNSPECIFIED";
    /**
     * DECLARATIVE_FRIENDLY - This resource is intended to be "declarative-friendly".
     *
     * Declarative-friendly resources must be more strictly consistent, and
     * setting this to true communicates to tools that this resource should
     * adhere to declarative-friendly expectations.
     *
     * Note: This is used by the API linter (linter.aip.dev) to enable
     * additional checks.
     */
    ResourceDescriptor_Style[ResourceDescriptor_Style["DECLARATIVE_FRIENDLY"] = 1] = "DECLARATIVE_FRIENDLY";
    ResourceDescriptor_Style[ResourceDescriptor_Style["UNRECOGNIZED"] = -1] = "UNRECOGNIZED";
})(ResourceDescriptor_Style || (exports.ResourceDescriptor_Style = ResourceDescriptor_Style = {}));
exports.ResourceDescriptor_StyleSDKType = ResourceDescriptor_Style;
exports.ResourceDescriptor_StyleAmino = ResourceDescriptor_Style;
function resourceDescriptor_StyleFromJSON(object) {
    switch (object) {
        case 0:
        case "STYLE_UNSPECIFIED":
            return ResourceDescriptor_Style.STYLE_UNSPECIFIED;
        case 1:
        case "DECLARATIVE_FRIENDLY":
            return ResourceDescriptor_Style.DECLARATIVE_FRIENDLY;
        case -1:
        case "UNRECOGNIZED":
        default:
            return ResourceDescriptor_Style.UNRECOGNIZED;
    }
}
function resourceDescriptor_StyleToJSON(object) {
    switch (object) {
        case ResourceDescriptor_Style.STYLE_UNSPECIFIED:
            return "STYLE_UNSPECIFIED";
        case ResourceDescriptor_Style.DECLARATIVE_FRIENDLY:
            return "DECLARATIVE_FRIENDLY";
        case ResourceDescriptor_Style.UNRECOGNIZED:
        default:
            return "UNRECOGNIZED";
    }
}
function createBaseResourceDescriptor() {
    return {
        type: "",
        pattern: [],
        nameField: "",
        history: 0,
        plural: "",
        singular: "",
        style: []
    };
}
exports.ResourceDescriptor = {
    typeUrl: "/google.api.ResourceDescriptor",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.type !== "") {
            writer.uint32(10).string(message.type);
        }
        for (const v of message.pattern) {
            writer.uint32(18).string(v);
        }
        if (message.nameField !== "") {
            writer.uint32(26).string(message.nameField);
        }
        if (message.history !== 0) {
            writer.uint32(32).int32(message.history);
        }
        if (message.plural !== "") {
            writer.uint32(42).string(message.plural);
        }
        if (message.singular !== "") {
            writer.uint32(50).string(message.singular);
        }
        writer.uint32(82).fork();
        for (const v of message.style) {
            writer.int32(v);
        }
        writer.ldelim();
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseResourceDescriptor();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.type = reader.string();
                    break;
                case 2:
                    message.pattern.push(reader.string());
                    break;
                case 3:
                    message.nameField = reader.string();
                    break;
                case 4:
                    message.history = reader.int32();
                    break;
                case 5:
                    message.plural = reader.string();
                    break;
                case 6:
                    message.singular = reader.string();
                    break;
                case 10:
                    if ((tag & 7) === 2) {
                        const end2 = reader.uint32() + reader.pos;
                        while (reader.pos < end2) {
                            message.style.push(reader.int32());
                        }
                    }
                    else {
                        message.style.push(reader.int32());
                    }
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseResourceDescriptor();
        message.type = object.type ?? "";
        message.pattern = object.pattern?.map(e => e) || [];
        message.nameField = object.nameField ?? "";
        message.history = object.history ?? 0;
        message.plural = object.plural ?? "";
        message.singular = object.singular ?? "";
        message.style = object.style?.map(e => e) || [];
        return message;
    },
    fromAmino(object) {
        const message = createBaseResourceDescriptor();
        if (object.type !== undefined && object.type !== null) {
            message.type = object.type;
        }
        message.pattern = object.pattern?.map(e => e) || [];
        if (object.name_field !== undefined && object.name_field !== null) {
            message.nameField = object.name_field;
        }
        if (object.history !== undefined && object.history !== null) {
            message.history = object.history;
        }
        if (object.plural !== undefined && object.plural !== null) {
            message.plural = object.plural;
        }
        if (object.singular !== undefined && object.singular !== null) {
            message.singular = object.singular;
        }
        message.style = object.style?.map(e => e) || [];
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.type = message.type === "" ? undefined : message.type;
        if (message.pattern) {
            obj.pattern = message.pattern.map(e => e);
        }
        else {
            obj.pattern = message.pattern;
        }
        obj.name_field = message.nameField === "" ? undefined : message.nameField;
        obj.history = message.history === 0 ? undefined : message.history;
        obj.plural = message.plural === "" ? undefined : message.plural;
        obj.singular = message.singular === "" ? undefined : message.singular;
        if (message.style) {
            obj.style = message.style.map(e => e);
        }
        else {
            obj.style = message.style;
        }
        return obj;
    },
    fromAminoMsg(object) {
        return exports.ResourceDescriptor.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.ResourceDescriptor.decode(message.value);
    },
    toProto(message) {
        return exports.ResourceDescriptor.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.ResourceDescriptor",
            value: exports.ResourceDescriptor.encode(message).finish()
        };
    }
};
function createBaseResourceReference() {
    return {
        type: "",
        childType: ""
    };
}
exports.ResourceReference = {
    typeUrl: "/google.api.ResourceReference",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.type !== "") {
            writer.uint32(10).string(message.type);
        }
        if (message.childType !== "") {
            writer.uint32(18).string(message.childType);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseResourceReference();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.type = reader.string();
                    break;
                case 2:
                    message.childType = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseResourceReference();
        message.type = object.type ?? "";
        message.childType = object.childType ?? "";
        return message;
    },
    fromAmino(object) {
        const message = createBaseResourceReference();
        if (object.type !== undefined && object.type !== null) {
            message.type = object.type;
        }
        if (object.child_type !== undefined && object.child_type !== null) {
            message.childType = object.child_type;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.type = message.type === "" ? undefined : message.type;
        obj.child_type = message.childType === "" ? undefined : message.childType;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.ResourceReference.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.ResourceReference.decode(message.value);
    },
    toProto(message) {
        return exports.ResourceReference.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.ResourceReference",
            value: exports.ResourceReference.encode(message).finish()
        };
    }
};
