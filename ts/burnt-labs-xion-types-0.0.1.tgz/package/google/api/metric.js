"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Metric = exports.Metric_LabelsEntry = exports.MetricDescriptor_MetricDescriptorMetadata = exports.MetricDescriptor = exports.MetricDescriptor_MetricDescriptorMetadata_TimeSeriesResourceHierarchyLevelAmino = exports.MetricDescriptor_MetricDescriptorMetadata_TimeSeriesResourceHierarchyLevelSDKType = exports.MetricDescriptor_MetricDescriptorMetadata_TimeSeriesResourceHierarchyLevel = exports.MetricDescriptor_ValueTypeAmino = exports.MetricDescriptor_ValueTypeSDKType = exports.MetricDescriptor_ValueType = exports.MetricDescriptor_MetricKindAmino = exports.MetricDescriptor_MetricKindSDKType = exports.MetricDescriptor_MetricKind = void 0;
exports.metricDescriptor_MetricKindFromJSON = metricDescriptor_MetricKindFromJSON;
exports.metricDescriptor_MetricKindToJSON = metricDescriptor_MetricKindToJSON;
exports.metricDescriptor_ValueTypeFromJSON = metricDescriptor_ValueTypeFromJSON;
exports.metricDescriptor_ValueTypeToJSON = metricDescriptor_ValueTypeToJSON;
exports.metricDescriptor_MetricDescriptorMetadata_TimeSeriesResourceHierarchyLevelFromJSON = metricDescriptor_MetricDescriptorMetadata_TimeSeriesResourceHierarchyLevelFromJSON;
exports.metricDescriptor_MetricDescriptorMetadata_TimeSeriesResourceHierarchyLevelToJSON = metricDescriptor_MetricDescriptorMetadata_TimeSeriesResourceHierarchyLevelToJSON;
const duration_1 = require("../protobuf/duration");
const label_1 = require("./label");
const binary_1 = require("../../binary");
/**
 * The kind of measurement. It describes how the data is reported.
 * For information on setting the start time and end time based on
 * the MetricKind, see [TimeInterval][google.monitoring.v3.TimeInterval].
 */
var MetricDescriptor_MetricKind;
(function (MetricDescriptor_MetricKind) {
    /** METRIC_KIND_UNSPECIFIED - Do not use this default value. */
    MetricDescriptor_MetricKind[MetricDescriptor_MetricKind["METRIC_KIND_UNSPECIFIED"] = 0] = "METRIC_KIND_UNSPECIFIED";
    /** GAUGE - An instantaneous measurement of a value. */
    MetricDescriptor_MetricKind[MetricDescriptor_MetricKind["GAUGE"] = 1] = "GAUGE";
    /** DELTA - The change in a value during a time interval. */
    MetricDescriptor_MetricKind[MetricDescriptor_MetricKind["DELTA"] = 2] = "DELTA";
    /**
     * CUMULATIVE - A value accumulated over a time interval.  Cumulative
     * measurements in a time series should have the same start time
     * and increasing end times, until an event resets the cumulative
     * value to zero and sets a new start time for the following
     * points.
     */
    MetricDescriptor_MetricKind[MetricDescriptor_MetricKind["CUMULATIVE"] = 3] = "CUMULATIVE";
    MetricDescriptor_MetricKind[MetricDescriptor_MetricKind["UNRECOGNIZED"] = -1] = "UNRECOGNIZED";
})(MetricDescriptor_MetricKind || (exports.MetricDescriptor_MetricKind = MetricDescriptor_MetricKind = {}));
exports.MetricDescriptor_MetricKindSDKType = MetricDescriptor_MetricKind;
exports.MetricDescriptor_MetricKindAmino = MetricDescriptor_MetricKind;
function metricDescriptor_MetricKindFromJSON(object) {
    switch (object) {
        case 0:
        case "METRIC_KIND_UNSPECIFIED":
            return MetricDescriptor_MetricKind.METRIC_KIND_UNSPECIFIED;
        case 1:
        case "GAUGE":
            return MetricDescriptor_MetricKind.GAUGE;
        case 2:
        case "DELTA":
            return MetricDescriptor_MetricKind.DELTA;
        case 3:
        case "CUMULATIVE":
            return MetricDescriptor_MetricKind.CUMULATIVE;
        case -1:
        case "UNRECOGNIZED":
        default:
            return MetricDescriptor_MetricKind.UNRECOGNIZED;
    }
}
function metricDescriptor_MetricKindToJSON(object) {
    switch (object) {
        case MetricDescriptor_MetricKind.METRIC_KIND_UNSPECIFIED:
            return "METRIC_KIND_UNSPECIFIED";
        case MetricDescriptor_MetricKind.GAUGE:
            return "GAUGE";
        case MetricDescriptor_MetricKind.DELTA:
            return "DELTA";
        case MetricDescriptor_MetricKind.CUMULATIVE:
            return "CUMULATIVE";
        case MetricDescriptor_MetricKind.UNRECOGNIZED:
        default:
            return "UNRECOGNIZED";
    }
}
/** The value type of a metric. */
var MetricDescriptor_ValueType;
(function (MetricDescriptor_ValueType) {
    /** VALUE_TYPE_UNSPECIFIED - Do not use this default value. */
    MetricDescriptor_ValueType[MetricDescriptor_ValueType["VALUE_TYPE_UNSPECIFIED"] = 0] = "VALUE_TYPE_UNSPECIFIED";
    /**
     * BOOL - The value is a boolean.
     * This value type can be used only if the metric kind is `GAUGE`.
     */
    MetricDescriptor_ValueType[MetricDescriptor_ValueType["BOOL"] = 1] = "BOOL";
    /** INT64 - The value is a signed 64-bit integer. */
    MetricDescriptor_ValueType[MetricDescriptor_ValueType["INT64"] = 2] = "INT64";
    /** DOUBLE - The value is a double precision floating point number. */
    MetricDescriptor_ValueType[MetricDescriptor_ValueType["DOUBLE"] = 3] = "DOUBLE";
    /**
     * STRING - The value is a text string.
     * This value type can be used only if the metric kind is `GAUGE`.
     */
    MetricDescriptor_ValueType[MetricDescriptor_ValueType["STRING"] = 4] = "STRING";
    /** DISTRIBUTION - The value is a [`Distribution`][google.api.Distribution]. */
    MetricDescriptor_ValueType[MetricDescriptor_ValueType["DISTRIBUTION"] = 5] = "DISTRIBUTION";
    /** MONEY - The value is money. */
    MetricDescriptor_ValueType[MetricDescriptor_ValueType["MONEY"] = 6] = "MONEY";
    MetricDescriptor_ValueType[MetricDescriptor_ValueType["UNRECOGNIZED"] = -1] = "UNRECOGNIZED";
})(MetricDescriptor_ValueType || (exports.MetricDescriptor_ValueType = MetricDescriptor_ValueType = {}));
exports.MetricDescriptor_ValueTypeSDKType = MetricDescriptor_ValueType;
exports.MetricDescriptor_ValueTypeAmino = MetricDescriptor_ValueType;
function metricDescriptor_ValueTypeFromJSON(object) {
    switch (object) {
        case 0:
        case "VALUE_TYPE_UNSPECIFIED":
            return MetricDescriptor_ValueType.VALUE_TYPE_UNSPECIFIED;
        case 1:
        case "BOOL":
            return MetricDescriptor_ValueType.BOOL;
        case 2:
        case "INT64":
            return MetricDescriptor_ValueType.INT64;
        case 3:
        case "DOUBLE":
            return MetricDescriptor_ValueType.DOUBLE;
        case 4:
        case "STRING":
            return MetricDescriptor_ValueType.STRING;
        case 5:
        case "DISTRIBUTION":
            return MetricDescriptor_ValueType.DISTRIBUTION;
        case 6:
        case "MONEY":
            return MetricDescriptor_ValueType.MONEY;
        case -1:
        case "UNRECOGNIZED":
        default:
            return MetricDescriptor_ValueType.UNRECOGNIZED;
    }
}
function metricDescriptor_ValueTypeToJSON(object) {
    switch (object) {
        case MetricDescriptor_ValueType.VALUE_TYPE_UNSPECIFIED:
            return "VALUE_TYPE_UNSPECIFIED";
        case MetricDescriptor_ValueType.BOOL:
            return "BOOL";
        case MetricDescriptor_ValueType.INT64:
            return "INT64";
        case MetricDescriptor_ValueType.DOUBLE:
            return "DOUBLE";
        case MetricDescriptor_ValueType.STRING:
            return "STRING";
        case MetricDescriptor_ValueType.DISTRIBUTION:
            return "DISTRIBUTION";
        case MetricDescriptor_ValueType.MONEY:
            return "MONEY";
        case MetricDescriptor_ValueType.UNRECOGNIZED:
        default:
            return "UNRECOGNIZED";
    }
}
/** The resource hierarchy level of the timeseries data of a metric. */
var MetricDescriptor_MetricDescriptorMetadata_TimeSeriesResourceHierarchyLevel;
(function (MetricDescriptor_MetricDescriptorMetadata_TimeSeriesResourceHierarchyLevel) {
    /** TIME_SERIES_RESOURCE_HIERARCHY_LEVEL_UNSPECIFIED - Do not use this default value. */
    MetricDescriptor_MetricDescriptorMetadata_TimeSeriesResourceHierarchyLevel[MetricDescriptor_MetricDescriptorMetadata_TimeSeriesResourceHierarchyLevel["TIME_SERIES_RESOURCE_HIERARCHY_LEVEL_UNSPECIFIED"] = 0] = "TIME_SERIES_RESOURCE_HIERARCHY_LEVEL_UNSPECIFIED";
    /** PROJECT - Scopes a metric to a project. */
    MetricDescriptor_MetricDescriptorMetadata_TimeSeriesResourceHierarchyLevel[MetricDescriptor_MetricDescriptorMetadata_TimeSeriesResourceHierarchyLevel["PROJECT"] = 1] = "PROJECT";
    /** ORGANIZATION - Scopes a metric to an organization. */
    MetricDescriptor_MetricDescriptorMetadata_TimeSeriesResourceHierarchyLevel[MetricDescriptor_MetricDescriptorMetadata_TimeSeriesResourceHierarchyLevel["ORGANIZATION"] = 2] = "ORGANIZATION";
    /** FOLDER - Scopes a metric to a folder. */
    MetricDescriptor_MetricDescriptorMetadata_TimeSeriesResourceHierarchyLevel[MetricDescriptor_MetricDescriptorMetadata_TimeSeriesResourceHierarchyLevel["FOLDER"] = 3] = "FOLDER";
    MetricDescriptor_MetricDescriptorMetadata_TimeSeriesResourceHierarchyLevel[MetricDescriptor_MetricDescriptorMetadata_TimeSeriesResourceHierarchyLevel["UNRECOGNIZED"] = -1] = "UNRECOGNIZED";
})(MetricDescriptor_MetricDescriptorMetadata_TimeSeriesResourceHierarchyLevel || (exports.MetricDescriptor_MetricDescriptorMetadata_TimeSeriesResourceHierarchyLevel = MetricDescriptor_MetricDescriptorMetadata_TimeSeriesResourceHierarchyLevel = {}));
exports.MetricDescriptor_MetricDescriptorMetadata_TimeSeriesResourceHierarchyLevelSDKType = MetricDescriptor_MetricDescriptorMetadata_TimeSeriesResourceHierarchyLevel;
exports.MetricDescriptor_MetricDescriptorMetadata_TimeSeriesResourceHierarchyLevelAmino = MetricDescriptor_MetricDescriptorMetadata_TimeSeriesResourceHierarchyLevel;
function metricDescriptor_MetricDescriptorMetadata_TimeSeriesResourceHierarchyLevelFromJSON(object) {
    switch (object) {
        case 0:
        case "TIME_SERIES_RESOURCE_HIERARCHY_LEVEL_UNSPECIFIED":
            return MetricDescriptor_MetricDescriptorMetadata_TimeSeriesResourceHierarchyLevel.TIME_SERIES_RESOURCE_HIERARCHY_LEVEL_UNSPECIFIED;
        case 1:
        case "PROJECT":
            return MetricDescriptor_MetricDescriptorMetadata_TimeSeriesResourceHierarchyLevel.PROJECT;
        case 2:
        case "ORGANIZATION":
            return MetricDescriptor_MetricDescriptorMetadata_TimeSeriesResourceHierarchyLevel.ORGANIZATION;
        case 3:
        case "FOLDER":
            return MetricDescriptor_MetricDescriptorMetadata_TimeSeriesResourceHierarchyLevel.FOLDER;
        case -1:
        case "UNRECOGNIZED":
        default:
            return MetricDescriptor_MetricDescriptorMetadata_TimeSeriesResourceHierarchyLevel.UNRECOGNIZED;
    }
}
function metricDescriptor_MetricDescriptorMetadata_TimeSeriesResourceHierarchyLevelToJSON(object) {
    switch (object) {
        case MetricDescriptor_MetricDescriptorMetadata_TimeSeriesResourceHierarchyLevel.TIME_SERIES_RESOURCE_HIERARCHY_LEVEL_UNSPECIFIED:
            return "TIME_SERIES_RESOURCE_HIERARCHY_LEVEL_UNSPECIFIED";
        case MetricDescriptor_MetricDescriptorMetadata_TimeSeriesResourceHierarchyLevel.PROJECT:
            return "PROJECT";
        case MetricDescriptor_MetricDescriptorMetadata_TimeSeriesResourceHierarchyLevel.ORGANIZATION:
            return "ORGANIZATION";
        case MetricDescriptor_MetricDescriptorMetadata_TimeSeriesResourceHierarchyLevel.FOLDER:
            return "FOLDER";
        case MetricDescriptor_MetricDescriptorMetadata_TimeSeriesResourceHierarchyLevel.UNRECOGNIZED:
        default:
            return "UNRECOGNIZED";
    }
}
function createBaseMetricDescriptor() {
    return {
        name: "",
        type: "",
        labels: [],
        metricKind: 0,
        valueType: 0,
        unit: "",
        description: "",
        displayName: "",
        metadata: undefined,
        launchStage: 0,
        monitoredResourceTypes: []
    };
}
exports.MetricDescriptor = {
    typeUrl: "/google.api.MetricDescriptor",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.name !== "") {
            writer.uint32(10).string(message.name);
        }
        if (message.type !== "") {
            writer.uint32(66).string(message.type);
        }
        for (const v of message.labels) {
            label_1.LabelDescriptor.encode(v, writer.uint32(18).fork()).ldelim();
        }
        if (message.metricKind !== 0) {
            writer.uint32(24).int32(message.metricKind);
        }
        if (message.valueType !== 0) {
            writer.uint32(32).int32(message.valueType);
        }
        if (message.unit !== "") {
            writer.uint32(42).string(message.unit);
        }
        if (message.description !== "") {
            writer.uint32(50).string(message.description);
        }
        if (message.displayName !== "") {
            writer.uint32(58).string(message.displayName);
        }
        if (message.metadata !== undefined) {
            exports.MetricDescriptor_MetricDescriptorMetadata.encode(message.metadata, writer.uint32(82).fork()).ldelim();
        }
        if (message.launchStage !== 0) {
            writer.uint32(96).int32(message.launchStage);
        }
        for (const v of message.monitoredResourceTypes) {
            writer.uint32(106).string(v);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseMetricDescriptor();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.name = reader.string();
                    break;
                case 8:
                    message.type = reader.string();
                    break;
                case 2:
                    message.labels.push(label_1.LabelDescriptor.decode(reader, reader.uint32()));
                    break;
                case 3:
                    message.metricKind = reader.int32();
                    break;
                case 4:
                    message.valueType = reader.int32();
                    break;
                case 5:
                    message.unit = reader.string();
                    break;
                case 6:
                    message.description = reader.string();
                    break;
                case 7:
                    message.displayName = reader.string();
                    break;
                case 10:
                    message.metadata = exports.MetricDescriptor_MetricDescriptorMetadata.decode(reader, reader.uint32());
                    break;
                case 12:
                    message.launchStage = reader.int32();
                    break;
                case 13:
                    message.monitoredResourceTypes.push(reader.string());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseMetricDescriptor();
        message.name = object.name ?? "";
        message.type = object.type ?? "";
        message.labels = object.labels?.map(e => label_1.LabelDescriptor.fromPartial(e)) || [];
        message.metricKind = object.metricKind ?? 0;
        message.valueType = object.valueType ?? 0;
        message.unit = object.unit ?? "";
        message.description = object.description ?? "";
        message.displayName = object.displayName ?? "";
        message.metadata = object.metadata !== undefined && object.metadata !== null ? exports.MetricDescriptor_MetricDescriptorMetadata.fromPartial(object.metadata) : undefined;
        message.launchStage = object.launchStage ?? 0;
        message.monitoredResourceTypes = object.monitoredResourceTypes?.map(e => e) || [];
        return message;
    },
    fromAmino(object) {
        const message = createBaseMetricDescriptor();
        if (object.name !== undefined && object.name !== null) {
            message.name = object.name;
        }
        if (object.type !== undefined && object.type !== null) {
            message.type = object.type;
        }
        message.labels = object.labels?.map(e => label_1.LabelDescriptor.fromAmino(e)) || [];
        if (object.metric_kind !== undefined && object.metric_kind !== null) {
            message.metricKind = object.metric_kind;
        }
        if (object.value_type !== undefined && object.value_type !== null) {
            message.valueType = object.value_type;
        }
        if (object.unit !== undefined && object.unit !== null) {
            message.unit = object.unit;
        }
        if (object.description !== undefined && object.description !== null) {
            message.description = object.description;
        }
        if (object.display_name !== undefined && object.display_name !== null) {
            message.displayName = object.display_name;
        }
        if (object.metadata !== undefined && object.metadata !== null) {
            message.metadata = exports.MetricDescriptor_MetricDescriptorMetadata.fromAmino(object.metadata);
        }
        if (object.launch_stage !== undefined && object.launch_stage !== null) {
            message.launchStage = object.launch_stage;
        }
        message.monitoredResourceTypes = object.monitored_resource_types?.map(e => e) || [];
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.name = message.name === "" ? undefined : message.name;
        obj.type = message.type === "" ? undefined : message.type;
        if (message.labels) {
            obj.labels = message.labels.map(e => e ? label_1.LabelDescriptor.toAmino(e) : undefined);
        }
        else {
            obj.labels = message.labels;
        }
        obj.metric_kind = message.metricKind === 0 ? undefined : message.metricKind;
        obj.value_type = message.valueType === 0 ? undefined : message.valueType;
        obj.unit = message.unit === "" ? undefined : message.unit;
        obj.description = message.description === "" ? undefined : message.description;
        obj.display_name = message.displayName === "" ? undefined : message.displayName;
        obj.metadata = message.metadata ? exports.MetricDescriptor_MetricDescriptorMetadata.toAmino(message.metadata) : undefined;
        obj.launch_stage = message.launchStage === 0 ? undefined : message.launchStage;
        if (message.monitoredResourceTypes) {
            obj.monitored_resource_types = message.monitoredResourceTypes.map(e => e);
        }
        else {
            obj.monitored_resource_types = message.monitoredResourceTypes;
        }
        return obj;
    },
    fromAminoMsg(object) {
        return exports.MetricDescriptor.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.MetricDescriptor.decode(message.value);
    },
    toProto(message) {
        return exports.MetricDescriptor.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.MetricDescriptor",
            value: exports.MetricDescriptor.encode(message).finish()
        };
    }
};
function createBaseMetricDescriptor_MetricDescriptorMetadata() {
    return {
        launchStage: 0,
        samplePeriod: undefined,
        ingestDelay: undefined,
        timeSeriesResourceHierarchyLevel: []
    };
}
exports.MetricDescriptor_MetricDescriptorMetadata = {
    typeUrl: "/google.api.MetricDescriptorMetadata",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.launchStage !== 0) {
            writer.uint32(8).int32(message.launchStage);
        }
        if (message.samplePeriod !== undefined) {
            duration_1.Duration.encode(message.samplePeriod, writer.uint32(18).fork()).ldelim();
        }
        if (message.ingestDelay !== undefined) {
            duration_1.Duration.encode(message.ingestDelay, writer.uint32(26).fork()).ldelim();
        }
        writer.uint32(34).fork();
        for (const v of message.timeSeriesResourceHierarchyLevel) {
            writer.int32(v);
        }
        writer.ldelim();
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseMetricDescriptor_MetricDescriptorMetadata();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.launchStage = reader.int32();
                    break;
                case 2:
                    message.samplePeriod = duration_1.Duration.decode(reader, reader.uint32());
                    break;
                case 3:
                    message.ingestDelay = duration_1.Duration.decode(reader, reader.uint32());
                    break;
                case 4:
                    if ((tag & 7) === 2) {
                        const end2 = reader.uint32() + reader.pos;
                        while (reader.pos < end2) {
                            message.timeSeriesResourceHierarchyLevel.push(reader.int32());
                        }
                    }
                    else {
                        message.timeSeriesResourceHierarchyLevel.push(reader.int32());
                    }
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseMetricDescriptor_MetricDescriptorMetadata();
        message.launchStage = object.launchStage ?? 0;
        message.samplePeriod = object.samplePeriod !== undefined && object.samplePeriod !== null ? duration_1.Duration.fromPartial(object.samplePeriod) : undefined;
        message.ingestDelay = object.ingestDelay !== undefined && object.ingestDelay !== null ? duration_1.Duration.fromPartial(object.ingestDelay) : undefined;
        message.timeSeriesResourceHierarchyLevel = object.timeSeriesResourceHierarchyLevel?.map(e => e) || [];
        return message;
    },
    fromAmino(object) {
        const message = createBaseMetricDescriptor_MetricDescriptorMetadata();
        if (object.launch_stage !== undefined && object.launch_stage !== null) {
            message.launchStage = object.launch_stage;
        }
        if (object.sample_period !== undefined && object.sample_period !== null) {
            message.samplePeriod = duration_1.Duration.fromAmino(object.sample_period);
        }
        if (object.ingest_delay !== undefined && object.ingest_delay !== null) {
            message.ingestDelay = duration_1.Duration.fromAmino(object.ingest_delay);
        }
        message.timeSeriesResourceHierarchyLevel = object.time_series_resource_hierarchy_level?.map(e => e) || [];
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.launch_stage = message.launchStage === 0 ? undefined : message.launchStage;
        obj.sample_period = message.samplePeriod ? duration_1.Duration.toAmino(message.samplePeriod) : undefined;
        obj.ingest_delay = message.ingestDelay ? duration_1.Duration.toAmino(message.ingestDelay) : undefined;
        if (message.timeSeriesResourceHierarchyLevel) {
            obj.time_series_resource_hierarchy_level = message.timeSeriesResourceHierarchyLevel.map(e => e);
        }
        else {
            obj.time_series_resource_hierarchy_level = message.timeSeriesResourceHierarchyLevel;
        }
        return obj;
    },
    fromAminoMsg(object) {
        return exports.MetricDescriptor_MetricDescriptorMetadata.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.MetricDescriptor_MetricDescriptorMetadata.decode(message.value);
    },
    toProto(message) {
        return exports.MetricDescriptor_MetricDescriptorMetadata.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.MetricDescriptorMetadata",
            value: exports.MetricDescriptor_MetricDescriptorMetadata.encode(message).finish()
        };
    }
};
function createBaseMetric_LabelsEntry() {
    return {
        key: "",
        value: ""
    };
}
exports.Metric_LabelsEntry = {
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.key !== "") {
            writer.uint32(10).string(message.key);
        }
        if (message.value !== "") {
            writer.uint32(18).string(message.value);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseMetric_LabelsEntry();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.key = reader.string();
                    break;
                case 2:
                    message.value = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseMetric_LabelsEntry();
        message.key = object.key ?? "";
        message.value = object.value ?? "";
        return message;
    },
    fromAmino(object) {
        const message = createBaseMetric_LabelsEntry();
        if (object.key !== undefined && object.key !== null) {
            message.key = object.key;
        }
        if (object.value !== undefined && object.value !== null) {
            message.value = object.value;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.key = message.key === "" ? undefined : message.key;
        obj.value = message.value === "" ? undefined : message.value;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.Metric_LabelsEntry.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.Metric_LabelsEntry.decode(message.value);
    },
    toProto(message) {
        return exports.Metric_LabelsEntry.encode(message).finish();
    }
};
function createBaseMetric() {
    return {
        type: "",
        labels: {}
    };
}
exports.Metric = {
    typeUrl: "/google.api.Metric",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.type !== "") {
            writer.uint32(26).string(message.type);
        }
        Object.entries(message.labels).forEach(([key, value]) => {
            exports.Metric_LabelsEntry.encode({
                key: key,
                value
            }, writer.uint32(18).fork()).ldelim();
        });
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseMetric();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 3:
                    message.type = reader.string();
                    break;
                case 2:
                    const entry2 = exports.Metric_LabelsEntry.decode(reader, reader.uint32());
                    if (entry2.value !== undefined) {
                        message.labels[entry2.key] = entry2.value;
                    }
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseMetric();
        message.type = object.type ?? "";
        message.labels = Object.entries(object.labels ?? {}).reduce((acc, [key, value]) => {
            if (value !== undefined) {
                acc[key] = String(value);
            }
            return acc;
        }, {});
        return message;
    },
    fromAmino(object) {
        const message = createBaseMetric();
        if (object.type !== undefined && object.type !== null) {
            message.type = object.type;
        }
        message.labels = Object.entries(object.labels ?? {}).reduce((acc, [key, value]) => {
            if (value !== undefined) {
                acc[key] = String(value);
            }
            return acc;
        }, {});
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.type = message.type === "" ? undefined : message.type;
        obj.labels = {};
        if (message.labels) {
            Object.entries(message.labels).forEach(([k, v]) => {
                obj.labels[k] = v;
            });
        }
        return obj;
    },
    fromAminoMsg(object) {
        return exports.Metric.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.Metric.decode(message.value);
    },
    toProto(message) {
        return exports.Metric.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.Metric",
            value: exports.Metric.encode(message).finish()
        };
    }
};
