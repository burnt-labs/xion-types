"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.LogDescriptor = void 0;
//@ts-nocheck
const label_1 = require("./label");
const binary_1 = require("../../binary");
function createBaseLogDescriptor() {
    return {
        name: "",
        labels: [],
        description: "",
        displayName: ""
    };
}
exports.LogDescriptor = {
    typeUrl: "/google.api.LogDescriptor",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.name !== "") {
            writer.uint32(10).string(message.name);
        }
        for (const v of message.labels) {
            label_1.LabelDescriptor.encode(v, writer.uint32(18).fork()).ldelim();
        }
        if (message.description !== "") {
            writer.uint32(26).string(message.description);
        }
        if (message.displayName !== "") {
            writer.uint32(34).string(message.displayName);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseLogDescriptor();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.name = reader.string();
                    break;
                case 2:
                    message.labels.push(label_1.LabelDescriptor.decode(reader, reader.uint32()));
                    break;
                case 3:
                    message.description = reader.string();
                    break;
                case 4:
                    message.displayName = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseLogDescriptor();
        message.name = object.name ?? "";
        message.labels = object.labels?.map(e => label_1.LabelDescriptor.fromPartial(e)) || [];
        message.description = object.description ?? "";
        message.displayName = object.displayName ?? "";
        return message;
    },
    fromAmino(object) {
        const message = createBaseLogDescriptor();
        if (object.name !== undefined && object.name !== null) {
            message.name = object.name;
        }
        message.labels = object.labels?.map(e => label_1.LabelDescriptor.fromAmino(e)) || [];
        if (object.description !== undefined && object.description !== null) {
            message.description = object.description;
        }
        if (object.display_name !== undefined && object.display_name !== null) {
            message.displayName = object.display_name;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.name = message.name === "" ? undefined : message.name;
        if (message.labels) {
            obj.labels = message.labels.map(e => e ? label_1.LabelDescriptor.toAmino(e) : undefined);
        }
        else {
            obj.labels = message.labels;
        }
        obj.description = message.description === "" ? undefined : message.description;
        obj.display_name = message.displayName === "" ? undefined : message.displayName;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.LogDescriptor.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.LogDescriptor.decode(message.value);
    },
    toProto(message) {
        return exports.LogDescriptor.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.LogDescriptor",
            value: exports.LogDescriptor.encode(message).finish()
        };
    }
};
