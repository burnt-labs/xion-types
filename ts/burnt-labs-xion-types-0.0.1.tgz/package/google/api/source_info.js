"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SourceInfo = void 0;
//@ts-nocheck
const any_1 = require("../protobuf/any");
const binary_1 = require("../../binary");
function createBaseSourceInfo() {
    return {
        sourceFiles: []
    };
}
exports.SourceInfo = {
    typeUrl: "/google.api.SourceInfo",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        for (const v of message.sourceFiles) {
            any_1.Any.encode(v, writer.uint32(10).fork()).ldelim();
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseSourceInfo();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.sourceFiles.push(any_1.Any.decode(reader, reader.uint32()));
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseSourceInfo();
        message.sourceFiles = object.sourceFiles?.map(e => any_1.Any.fromPartial(e)) || [];
        return message;
    },
    fromAmino(object) {
        const message = createBaseSourceInfo();
        message.sourceFiles = object.source_files?.map(e => any_1.Any.fromAmino(e)) || [];
        return message;
    },
    toAmino(message) {
        const obj = {};
        if (message.sourceFiles) {
            obj.source_files = message.sourceFiles.map(e => e ? any_1.Any.toAmino(e) : undefined);
        }
        else {
            obj.source_files = message.sourceFiles;
        }
        return obj;
    },
    fromAminoMsg(object) {
        return exports.SourceInfo.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.SourceInfo.decode(message.value);
    },
    toProto(message) {
        return exports.SourceInfo.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.SourceInfo",
            value: exports.SourceInfo.encode(message).finish()
        };
    }
};
