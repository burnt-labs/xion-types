"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.MonitoredResourceMetadata = exports.MonitoredResourceMetadata_UserLabelsEntry = exports.MonitoredResource = exports.MonitoredResource_LabelsEntry = exports.MonitoredResourceDescriptor = void 0;
//@ts-nocheck
const label_1 = require("./label");
const struct_1 = require("../protobuf/struct");
const binary_1 = require("../../binary");
function createBaseMonitoredResourceDescriptor() {
    return {
        name: "",
        type: "",
        displayName: "",
        description: "",
        labels: [],
        launchStage: 0
    };
}
exports.MonitoredResourceDescriptor = {
    typeUrl: "/google.api.MonitoredResourceDescriptor",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.name !== "") {
            writer.uint32(42).string(message.name);
        }
        if (message.type !== "") {
            writer.uint32(10).string(message.type);
        }
        if (message.displayName !== "") {
            writer.uint32(18).string(message.displayName);
        }
        if (message.description !== "") {
            writer.uint32(26).string(message.description);
        }
        for (const v of message.labels) {
            label_1.LabelDescriptor.encode(v, writer.uint32(34).fork()).ldelim();
        }
        if (message.launchStage !== 0) {
            writer.uint32(56).int32(message.launchStage);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseMonitoredResourceDescriptor();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 5:
                    message.name = reader.string();
                    break;
                case 1:
                    message.type = reader.string();
                    break;
                case 2:
                    message.displayName = reader.string();
                    break;
                case 3:
                    message.description = reader.string();
                    break;
                case 4:
                    message.labels.push(label_1.LabelDescriptor.decode(reader, reader.uint32()));
                    break;
                case 7:
                    message.launchStage = reader.int32();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseMonitoredResourceDescriptor();
        message.name = object.name ?? "";
        message.type = object.type ?? "";
        message.displayName = object.displayName ?? "";
        message.description = object.description ?? "";
        message.labels = object.labels?.map(e => label_1.LabelDescriptor.fromPartial(e)) || [];
        message.launchStage = object.launchStage ?? 0;
        return message;
    },
    fromAmino(object) {
        const message = createBaseMonitoredResourceDescriptor();
        if (object.name !== undefined && object.name !== null) {
            message.name = object.name;
        }
        if (object.type !== undefined && object.type !== null) {
            message.type = object.type;
        }
        if (object.display_name !== undefined && object.display_name !== null) {
            message.displayName = object.display_name;
        }
        if (object.description !== undefined && object.description !== null) {
            message.description = object.description;
        }
        message.labels = object.labels?.map(e => label_1.LabelDescriptor.fromAmino(e)) || [];
        if (object.launch_stage !== undefined && object.launch_stage !== null) {
            message.launchStage = object.launch_stage;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.name = message.name === "" ? undefined : message.name;
        obj.type = message.type === "" ? undefined : message.type;
        obj.display_name = message.displayName === "" ? undefined : message.displayName;
        obj.description = message.description === "" ? undefined : message.description;
        if (message.labels) {
            obj.labels = message.labels.map(e => e ? label_1.LabelDescriptor.toAmino(e) : undefined);
        }
        else {
            obj.labels = message.labels;
        }
        obj.launch_stage = message.launchStage === 0 ? undefined : message.launchStage;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.MonitoredResourceDescriptor.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.MonitoredResourceDescriptor.decode(message.value);
    },
    toProto(message) {
        return exports.MonitoredResourceDescriptor.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.MonitoredResourceDescriptor",
            value: exports.MonitoredResourceDescriptor.encode(message).finish()
        };
    }
};
function createBaseMonitoredResource_LabelsEntry() {
    return {
        key: "",
        value: ""
    };
}
exports.MonitoredResource_LabelsEntry = {
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.key !== "") {
            writer.uint32(10).string(message.key);
        }
        if (message.value !== "") {
            writer.uint32(18).string(message.value);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseMonitoredResource_LabelsEntry();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.key = reader.string();
                    break;
                case 2:
                    message.value = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseMonitoredResource_LabelsEntry();
        message.key = object.key ?? "";
        message.value = object.value ?? "";
        return message;
    },
    fromAmino(object) {
        const message = createBaseMonitoredResource_LabelsEntry();
        if (object.key !== undefined && object.key !== null) {
            message.key = object.key;
        }
        if (object.value !== undefined && object.value !== null) {
            message.value = object.value;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.key = message.key === "" ? undefined : message.key;
        obj.value = message.value === "" ? undefined : message.value;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.MonitoredResource_LabelsEntry.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.MonitoredResource_LabelsEntry.decode(message.value);
    },
    toProto(message) {
        return exports.MonitoredResource_LabelsEntry.encode(message).finish();
    }
};
function createBaseMonitoredResource() {
    return {
        type: "",
        labels: {}
    };
}
exports.MonitoredResource = {
    typeUrl: "/google.api.MonitoredResource",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.type !== "") {
            writer.uint32(10).string(message.type);
        }
        Object.entries(message.labels).forEach(([key, value]) => {
            exports.MonitoredResource_LabelsEntry.encode({
                key: key,
                value
            }, writer.uint32(18).fork()).ldelim();
        });
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseMonitoredResource();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.type = reader.string();
                    break;
                case 2:
                    const entry2 = exports.MonitoredResource_LabelsEntry.decode(reader, reader.uint32());
                    if (entry2.value !== undefined) {
                        message.labels[entry2.key] = entry2.value;
                    }
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseMonitoredResource();
        message.type = object.type ?? "";
        message.labels = Object.entries(object.labels ?? {}).reduce((acc, [key, value]) => {
            if (value !== undefined) {
                acc[key] = String(value);
            }
            return acc;
        }, {});
        return message;
    },
    fromAmino(object) {
        const message = createBaseMonitoredResource();
        if (object.type !== undefined && object.type !== null) {
            message.type = object.type;
        }
        message.labels = Object.entries(object.labels ?? {}).reduce((acc, [key, value]) => {
            if (value !== undefined) {
                acc[key] = String(value);
            }
            return acc;
        }, {});
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.type = message.type === "" ? undefined : message.type;
        obj.labels = {};
        if (message.labels) {
            Object.entries(message.labels).forEach(([k, v]) => {
                obj.labels[k] = v;
            });
        }
        return obj;
    },
    fromAminoMsg(object) {
        return exports.MonitoredResource.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.MonitoredResource.decode(message.value);
    },
    toProto(message) {
        return exports.MonitoredResource.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.MonitoredResource",
            value: exports.MonitoredResource.encode(message).finish()
        };
    }
};
function createBaseMonitoredResourceMetadata_UserLabelsEntry() {
    return {
        key: "",
        value: ""
    };
}
exports.MonitoredResourceMetadata_UserLabelsEntry = {
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.key !== "") {
            writer.uint32(10).string(message.key);
        }
        if (message.value !== "") {
            writer.uint32(18).string(message.value);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseMonitoredResourceMetadata_UserLabelsEntry();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.key = reader.string();
                    break;
                case 2:
                    message.value = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseMonitoredResourceMetadata_UserLabelsEntry();
        message.key = object.key ?? "";
        message.value = object.value ?? "";
        return message;
    },
    fromAmino(object) {
        const message = createBaseMonitoredResourceMetadata_UserLabelsEntry();
        if (object.key !== undefined && object.key !== null) {
            message.key = object.key;
        }
        if (object.value !== undefined && object.value !== null) {
            message.value = object.value;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.key = message.key === "" ? undefined : message.key;
        obj.value = message.value === "" ? undefined : message.value;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.MonitoredResourceMetadata_UserLabelsEntry.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.MonitoredResourceMetadata_UserLabelsEntry.decode(message.value);
    },
    toProto(message) {
        return exports.MonitoredResourceMetadata_UserLabelsEntry.encode(message).finish();
    }
};
function createBaseMonitoredResourceMetadata() {
    return {
        systemLabels: undefined,
        userLabels: {}
    };
}
exports.MonitoredResourceMetadata = {
    typeUrl: "/google.api.MonitoredResourceMetadata",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.systemLabels !== undefined) {
            struct_1.Struct.encode(message.systemLabels, writer.uint32(10).fork()).ldelim();
        }
        Object.entries(message.userLabels).forEach(([key, value]) => {
            exports.MonitoredResourceMetadata_UserLabelsEntry.encode({
                key: key,
                value
            }, writer.uint32(18).fork()).ldelim();
        });
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseMonitoredResourceMetadata();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.systemLabels = struct_1.Struct.decode(reader, reader.uint32());
                    break;
                case 2:
                    const entry2 = exports.MonitoredResourceMetadata_UserLabelsEntry.decode(reader, reader.uint32());
                    if (entry2.value !== undefined) {
                        message.userLabels[entry2.key] = entry2.value;
                    }
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseMonitoredResourceMetadata();
        message.systemLabels = object.systemLabels !== undefined && object.systemLabels !== null ? struct_1.Struct.fromPartial(object.systemLabels) : undefined;
        message.userLabels = Object.entries(object.userLabels ?? {}).reduce((acc, [key, value]) => {
            if (value !== undefined) {
                acc[key] = String(value);
            }
            return acc;
        }, {});
        return message;
    },
    fromAmino(object) {
        const message = createBaseMonitoredResourceMetadata();
        if (object.system_labels !== undefined && object.system_labels !== null) {
            message.systemLabels = struct_1.Struct.fromAmino(object.system_labels);
        }
        message.userLabels = Object.entries(object.user_labels ?? {}).reduce((acc, [key, value]) => {
            if (value !== undefined) {
                acc[key] = String(value);
            }
            return acc;
        }, {});
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.system_labels = message.systemLabels ? struct_1.Struct.toAmino(message.systemLabels) : undefined;
        obj.user_labels = {};
        if (message.userLabels) {
            Object.entries(message.userLabels).forEach(([k, v]) => {
                obj.user_labels[k] = v;
            });
        }
        return obj;
    },
    fromAminoMsg(object) {
        return exports.MonitoredResourceMetadata.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.MonitoredResourceMetadata.decode(message.value);
    },
    toProto(message) {
        return exports.MonitoredResourceMetadata.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.MonitoredResourceMetadata",
            value: exports.MonitoredResourceMetadata.encode(message).finish()
        };
    }
};
