"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.IssueDetails = exports.SourcePosition = exports.EvalResponse = exports.EvalRequest = exports.EvalRequest_BindingsEntry = exports.CheckResponse = exports.CheckRequest = exports.ParseResponse = exports.ParseRequest = exports.IssueDetails_SeverityAmino = exports.IssueDetails_SeveritySDKType = exports.IssueDetails_Severity = void 0;
exports.issueDetails_SeverityFromJSON = issueDetails_SeverityFromJSON;
exports.issueDetails_SeverityToJSON = issueDetails_SeverityToJSON;
//@ts-nocheck
const syntax_1 = require("../../v1alpha1/syntax");
const checked_1 = require("../../v1alpha1/checked");
const eval_1 = require("../../v1alpha1/eval");
const status_1 = require("../../../../rpc/status");
const binary_1 = require("../../../../../binary");
/** Severities of issues. */
var IssueDetails_Severity;
(function (IssueDetails_Severity) {
    /** SEVERITY_UNSPECIFIED - An unspecified severity. */
    IssueDetails_Severity[IssueDetails_Severity["SEVERITY_UNSPECIFIED"] = 0] = "SEVERITY_UNSPECIFIED";
    /**
     * DEPRECATION - Deprecation issue for statements and method that may no longer be
     * supported or maintained.
     */
    IssueDetails_Severity[IssueDetails_Severity["DEPRECATION"] = 1] = "DEPRECATION";
    /** WARNING - Warnings such as: unused variables. */
    IssueDetails_Severity[IssueDetails_Severity["WARNING"] = 2] = "WARNING";
    /** ERROR - Errors such as: unmatched curly braces or variable redefinition. */
    IssueDetails_Severity[IssueDetails_Severity["ERROR"] = 3] = "ERROR";
    IssueDetails_Severity[IssueDetails_Severity["UNRECOGNIZED"] = -1] = "UNRECOGNIZED";
})(IssueDetails_Severity || (exports.IssueDetails_Severity = IssueDetails_Severity = {}));
exports.IssueDetails_SeveritySDKType = IssueDetails_Severity;
exports.IssueDetails_SeverityAmino = IssueDetails_Severity;
function issueDetails_SeverityFromJSON(object) {
    switch (object) {
        case 0:
        case "SEVERITY_UNSPECIFIED":
            return IssueDetails_Severity.SEVERITY_UNSPECIFIED;
        case 1:
        case "DEPRECATION":
            return IssueDetails_Severity.DEPRECATION;
        case 2:
        case "WARNING":
            return IssueDetails_Severity.WARNING;
        case 3:
        case "ERROR":
            return IssueDetails_Severity.ERROR;
        case -1:
        case "UNRECOGNIZED":
        default:
            return IssueDetails_Severity.UNRECOGNIZED;
    }
}
function issueDetails_SeverityToJSON(object) {
    switch (object) {
        case IssueDetails_Severity.SEVERITY_UNSPECIFIED:
            return "SEVERITY_UNSPECIFIED";
        case IssueDetails_Severity.DEPRECATION:
            return "DEPRECATION";
        case IssueDetails_Severity.WARNING:
            return "WARNING";
        case IssueDetails_Severity.ERROR:
            return "ERROR";
        case IssueDetails_Severity.UNRECOGNIZED:
        default:
            return "UNRECOGNIZED";
    }
}
function createBaseParseRequest() {
    return {
        celSource: "",
        syntaxVersion: "",
        sourceLocation: "",
        disableMacros: false
    };
}
exports.ParseRequest = {
    typeUrl: "/google.api.expr.conformance.v1alpha1.ParseRequest",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.celSource !== "") {
            writer.uint32(10).string(message.celSource);
        }
        if (message.syntaxVersion !== "") {
            writer.uint32(18).string(message.syntaxVersion);
        }
        if (message.sourceLocation !== "") {
            writer.uint32(26).string(message.sourceLocation);
        }
        if (message.disableMacros === true) {
            writer.uint32(32).bool(message.disableMacros);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseParseRequest();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.celSource = reader.string();
                    break;
                case 2:
                    message.syntaxVersion = reader.string();
                    break;
                case 3:
                    message.sourceLocation = reader.string();
                    break;
                case 4:
                    message.disableMacros = reader.bool();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseParseRequest();
        message.celSource = object.celSource ?? "";
        message.syntaxVersion = object.syntaxVersion ?? "";
        message.sourceLocation = object.sourceLocation ?? "";
        message.disableMacros = object.disableMacros ?? false;
        return message;
    },
    fromAmino(object) {
        const message = createBaseParseRequest();
        if (object.cel_source !== undefined && object.cel_source !== null) {
            message.celSource = object.cel_source;
        }
        if (object.syntax_version !== undefined && object.syntax_version !== null) {
            message.syntaxVersion = object.syntax_version;
        }
        if (object.source_location !== undefined && object.source_location !== null) {
            message.sourceLocation = object.source_location;
        }
        if (object.disable_macros !== undefined && object.disable_macros !== null) {
            message.disableMacros = object.disable_macros;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.cel_source = message.celSource === "" ? undefined : message.celSource;
        obj.syntax_version = message.syntaxVersion === "" ? undefined : message.syntaxVersion;
        obj.source_location = message.sourceLocation === "" ? undefined : message.sourceLocation;
        obj.disable_macros = message.disableMacros === false ? undefined : message.disableMacros;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.ParseRequest.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.ParseRequest.decode(message.value);
    },
    toProto(message) {
        return exports.ParseRequest.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.expr.conformance.v1alpha1.ParseRequest",
            value: exports.ParseRequest.encode(message).finish()
        };
    }
};
function createBaseParseResponse() {
    return {
        parsedExpr: undefined,
        issues: []
    };
}
exports.ParseResponse = {
    typeUrl: "/google.api.expr.conformance.v1alpha1.ParseResponse",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.parsedExpr !== undefined) {
            syntax_1.ParsedExpr.encode(message.parsedExpr, writer.uint32(10).fork()).ldelim();
        }
        for (const v of message.issues) {
            status_1.Status.encode(v, writer.uint32(18).fork()).ldelim();
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseParseResponse();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.parsedExpr = syntax_1.ParsedExpr.decode(reader, reader.uint32());
                    break;
                case 2:
                    message.issues.push(status_1.Status.decode(reader, reader.uint32()));
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseParseResponse();
        message.parsedExpr = object.parsedExpr !== undefined && object.parsedExpr !== null ? syntax_1.ParsedExpr.fromPartial(object.parsedExpr) : undefined;
        message.issues = object.issues?.map(e => status_1.Status.fromPartial(e)) || [];
        return message;
    },
    fromAmino(object) {
        const message = createBaseParseResponse();
        if (object.parsed_expr !== undefined && object.parsed_expr !== null) {
            message.parsedExpr = syntax_1.ParsedExpr.fromAmino(object.parsed_expr);
        }
        message.issues = object.issues?.map(e => status_1.Status.fromAmino(e)) || [];
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.parsed_expr = message.parsedExpr ? syntax_1.ParsedExpr.toAmino(message.parsedExpr) : undefined;
        if (message.issues) {
            obj.issues = message.issues.map(e => e ? status_1.Status.toAmino(e) : undefined);
        }
        else {
            obj.issues = message.issues;
        }
        return obj;
    },
    fromAminoMsg(object) {
        return exports.ParseResponse.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.ParseResponse.decode(message.value);
    },
    toProto(message) {
        return exports.ParseResponse.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.expr.conformance.v1alpha1.ParseResponse",
            value: exports.ParseResponse.encode(message).finish()
        };
    }
};
function createBaseCheckRequest() {
    return {
        parsedExpr: undefined,
        typeEnv: [],
        container: "",
        noStdEnv: false
    };
}
exports.CheckRequest = {
    typeUrl: "/google.api.expr.conformance.v1alpha1.CheckRequest",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.parsedExpr !== undefined) {
            syntax_1.ParsedExpr.encode(message.parsedExpr, writer.uint32(10).fork()).ldelim();
        }
        for (const v of message.typeEnv) {
            checked_1.Decl.encode(v, writer.uint32(18).fork()).ldelim();
        }
        if (message.container !== "") {
            writer.uint32(26).string(message.container);
        }
        if (message.noStdEnv === true) {
            writer.uint32(32).bool(message.noStdEnv);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseCheckRequest();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.parsedExpr = syntax_1.ParsedExpr.decode(reader, reader.uint32());
                    break;
                case 2:
                    message.typeEnv.push(checked_1.Decl.decode(reader, reader.uint32()));
                    break;
                case 3:
                    message.container = reader.string();
                    break;
                case 4:
                    message.noStdEnv = reader.bool();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseCheckRequest();
        message.parsedExpr = object.parsedExpr !== undefined && object.parsedExpr !== null ? syntax_1.ParsedExpr.fromPartial(object.parsedExpr) : undefined;
        message.typeEnv = object.typeEnv?.map(e => checked_1.Decl.fromPartial(e)) || [];
        message.container = object.container ?? "";
        message.noStdEnv = object.noStdEnv ?? false;
        return message;
    },
    fromAmino(object) {
        const message = createBaseCheckRequest();
        if (object.parsed_expr !== undefined && object.parsed_expr !== null) {
            message.parsedExpr = syntax_1.ParsedExpr.fromAmino(object.parsed_expr);
        }
        message.typeEnv = object.type_env?.map(e => checked_1.Decl.fromAmino(e)) || [];
        if (object.container !== undefined && object.container !== null) {
            message.container = object.container;
        }
        if (object.no_std_env !== undefined && object.no_std_env !== null) {
            message.noStdEnv = object.no_std_env;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.parsed_expr = message.parsedExpr ? syntax_1.ParsedExpr.toAmino(message.parsedExpr) : undefined;
        if (message.typeEnv) {
            obj.type_env = message.typeEnv.map(e => e ? checked_1.Decl.toAmino(e) : undefined);
        }
        else {
            obj.type_env = message.typeEnv;
        }
        obj.container = message.container === "" ? undefined : message.container;
        obj.no_std_env = message.noStdEnv === false ? undefined : message.noStdEnv;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.CheckRequest.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.CheckRequest.decode(message.value);
    },
    toProto(message) {
        return exports.CheckRequest.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.expr.conformance.v1alpha1.CheckRequest",
            value: exports.CheckRequest.encode(message).finish()
        };
    }
};
function createBaseCheckResponse() {
    return {
        checkedExpr: undefined,
        issues: []
    };
}
exports.CheckResponse = {
    typeUrl: "/google.api.expr.conformance.v1alpha1.CheckResponse",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.checkedExpr !== undefined) {
            checked_1.CheckedExpr.encode(message.checkedExpr, writer.uint32(10).fork()).ldelim();
        }
        for (const v of message.issues) {
            status_1.Status.encode(v, writer.uint32(18).fork()).ldelim();
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseCheckResponse();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.checkedExpr = checked_1.CheckedExpr.decode(reader, reader.uint32());
                    break;
                case 2:
                    message.issues.push(status_1.Status.decode(reader, reader.uint32()));
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseCheckResponse();
        message.checkedExpr = object.checkedExpr !== undefined && object.checkedExpr !== null ? checked_1.CheckedExpr.fromPartial(object.checkedExpr) : undefined;
        message.issues = object.issues?.map(e => status_1.Status.fromPartial(e)) || [];
        return message;
    },
    fromAmino(object) {
        const message = createBaseCheckResponse();
        if (object.checked_expr !== undefined && object.checked_expr !== null) {
            message.checkedExpr = checked_1.CheckedExpr.fromAmino(object.checked_expr);
        }
        message.issues = object.issues?.map(e => status_1.Status.fromAmino(e)) || [];
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.checked_expr = message.checkedExpr ? checked_1.CheckedExpr.toAmino(message.checkedExpr) : undefined;
        if (message.issues) {
            obj.issues = message.issues.map(e => e ? status_1.Status.toAmino(e) : undefined);
        }
        else {
            obj.issues = message.issues;
        }
        return obj;
    },
    fromAminoMsg(object) {
        return exports.CheckResponse.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.CheckResponse.decode(message.value);
    },
    toProto(message) {
        return exports.CheckResponse.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.expr.conformance.v1alpha1.CheckResponse",
            value: exports.CheckResponse.encode(message).finish()
        };
    }
};
function createBaseEvalRequest_BindingsEntry() {
    return {
        key: "",
        value: undefined
    };
}
exports.EvalRequest_BindingsEntry = {
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.key !== "") {
            writer.uint32(10).string(message.key);
        }
        if (message.value !== undefined) {
            eval_1.ExprValue.encode(message.value, writer.uint32(18).fork()).ldelim();
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseEvalRequest_BindingsEntry();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.key = reader.string();
                    break;
                case 2:
                    message.value = eval_1.ExprValue.decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseEvalRequest_BindingsEntry();
        message.key = object.key ?? "";
        message.value = object.value !== undefined && object.value !== null ? eval_1.ExprValue.fromPartial(object.value) : undefined;
        return message;
    },
    fromAmino(object) {
        const message = createBaseEvalRequest_BindingsEntry();
        if (object.key !== undefined && object.key !== null) {
            message.key = object.key;
        }
        if (object.value !== undefined && object.value !== null) {
            message.value = eval_1.ExprValue.fromAmino(object.value);
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.key = message.key === "" ? undefined : message.key;
        obj.value = message.value ? eval_1.ExprValue.toAmino(message.value) : undefined;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.EvalRequest_BindingsEntry.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.EvalRequest_BindingsEntry.decode(message.value);
    },
    toProto(message) {
        return exports.EvalRequest_BindingsEntry.encode(message).finish();
    }
};
function createBaseEvalRequest() {
    return {
        parsedExpr: undefined,
        checkedExpr: undefined,
        bindings: {},
        container: ""
    };
}
exports.EvalRequest = {
    typeUrl: "/google.api.expr.conformance.v1alpha1.EvalRequest",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.parsedExpr !== undefined) {
            syntax_1.ParsedExpr.encode(message.parsedExpr, writer.uint32(10).fork()).ldelim();
        }
        if (message.checkedExpr !== undefined) {
            checked_1.CheckedExpr.encode(message.checkedExpr, writer.uint32(18).fork()).ldelim();
        }
        Object.entries(message.bindings).forEach(([key, value]) => {
            exports.EvalRequest_BindingsEntry.encode({
                key: key,
                value
            }, writer.uint32(26).fork()).ldelim();
        });
        if (message.container !== "") {
            writer.uint32(34).string(message.container);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseEvalRequest();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.parsedExpr = syntax_1.ParsedExpr.decode(reader, reader.uint32());
                    break;
                case 2:
                    message.checkedExpr = checked_1.CheckedExpr.decode(reader, reader.uint32());
                    break;
                case 3:
                    const entry3 = exports.EvalRequest_BindingsEntry.decode(reader, reader.uint32());
                    if (entry3.value !== undefined) {
                        message.bindings[entry3.key] = entry3.value;
                    }
                    break;
                case 4:
                    message.container = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseEvalRequest();
        message.parsedExpr = object.parsedExpr !== undefined && object.parsedExpr !== null ? syntax_1.ParsedExpr.fromPartial(object.parsedExpr) : undefined;
        message.checkedExpr = object.checkedExpr !== undefined && object.checkedExpr !== null ? checked_1.CheckedExpr.fromPartial(object.checkedExpr) : undefined;
        message.bindings = Object.entries(object.bindings ?? {}).reduce((acc, [key, value]) => {
            if (value !== undefined) {
                acc[key] = eval_1.ExprValue.fromPartial(value);
            }
            return acc;
        }, {});
        message.container = object.container ?? "";
        return message;
    },
    fromAmino(object) {
        const message = createBaseEvalRequest();
        if (object.parsed_expr !== undefined && object.parsed_expr !== null) {
            message.parsedExpr = syntax_1.ParsedExpr.fromAmino(object.parsed_expr);
        }
        if (object.checked_expr !== undefined && object.checked_expr !== null) {
            message.checkedExpr = checked_1.CheckedExpr.fromAmino(object.checked_expr);
        }
        message.bindings = Object.entries(object.bindings ?? {}).reduce((acc, [key, value]) => {
            if (value !== undefined) {
                acc[key] = eval_1.ExprValue.fromAmino(value);
            }
            return acc;
        }, {});
        if (object.container !== undefined && object.container !== null) {
            message.container = object.container;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.parsed_expr = message.parsedExpr ? syntax_1.ParsedExpr.toAmino(message.parsedExpr) : undefined;
        obj.checked_expr = message.checkedExpr ? checked_1.CheckedExpr.toAmino(message.checkedExpr) : undefined;
        obj.bindings = {};
        if (message.bindings) {
            Object.entries(message.bindings).forEach(([k, v]) => {
                obj.bindings[k] = eval_1.ExprValue.toAmino(v);
            });
        }
        obj.container = message.container === "" ? undefined : message.container;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.EvalRequest.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.EvalRequest.decode(message.value);
    },
    toProto(message) {
        return exports.EvalRequest.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.expr.conformance.v1alpha1.EvalRequest",
            value: exports.EvalRequest.encode(message).finish()
        };
    }
};
function createBaseEvalResponse() {
    return {
        result: undefined,
        issues: []
    };
}
exports.EvalResponse = {
    typeUrl: "/google.api.expr.conformance.v1alpha1.EvalResponse",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.result !== undefined) {
            eval_1.ExprValue.encode(message.result, writer.uint32(10).fork()).ldelim();
        }
        for (const v of message.issues) {
            status_1.Status.encode(v, writer.uint32(18).fork()).ldelim();
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseEvalResponse();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.result = eval_1.ExprValue.decode(reader, reader.uint32());
                    break;
                case 2:
                    message.issues.push(status_1.Status.decode(reader, reader.uint32()));
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseEvalResponse();
        message.result = object.result !== undefined && object.result !== null ? eval_1.ExprValue.fromPartial(object.result) : undefined;
        message.issues = object.issues?.map(e => status_1.Status.fromPartial(e)) || [];
        return message;
    },
    fromAmino(object) {
        const message = createBaseEvalResponse();
        if (object.result !== undefined && object.result !== null) {
            message.result = eval_1.ExprValue.fromAmino(object.result);
        }
        message.issues = object.issues?.map(e => status_1.Status.fromAmino(e)) || [];
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.result = message.result ? eval_1.ExprValue.toAmino(message.result) : undefined;
        if (message.issues) {
            obj.issues = message.issues.map(e => e ? status_1.Status.toAmino(e) : undefined);
        }
        else {
            obj.issues = message.issues;
        }
        return obj;
    },
    fromAminoMsg(object) {
        return exports.EvalResponse.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.EvalResponse.decode(message.value);
    },
    toProto(message) {
        return exports.EvalResponse.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.expr.conformance.v1alpha1.EvalResponse",
            value: exports.EvalResponse.encode(message).finish()
        };
    }
};
function createBaseSourcePosition() {
    return {
        location: "",
        offset: 0,
        line: 0,
        column: 0
    };
}
exports.SourcePosition = {
    typeUrl: "/google.api.expr.conformance.v1alpha1.SourcePosition",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.location !== "") {
            writer.uint32(10).string(message.location);
        }
        if (message.offset !== 0) {
            writer.uint32(16).int32(message.offset);
        }
        if (message.line !== 0) {
            writer.uint32(24).int32(message.line);
        }
        if (message.column !== 0) {
            writer.uint32(32).int32(message.column);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseSourcePosition();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.location = reader.string();
                    break;
                case 2:
                    message.offset = reader.int32();
                    break;
                case 3:
                    message.line = reader.int32();
                    break;
                case 4:
                    message.column = reader.int32();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseSourcePosition();
        message.location = object.location ?? "";
        message.offset = object.offset ?? 0;
        message.line = object.line ?? 0;
        message.column = object.column ?? 0;
        return message;
    },
    fromAmino(object) {
        const message = createBaseSourcePosition();
        if (object.location !== undefined && object.location !== null) {
            message.location = object.location;
        }
        if (object.offset !== undefined && object.offset !== null) {
            message.offset = object.offset;
        }
        if (object.line !== undefined && object.line !== null) {
            message.line = object.line;
        }
        if (object.column !== undefined && object.column !== null) {
            message.column = object.column;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.location = message.location === "" ? undefined : message.location;
        obj.offset = message.offset === 0 ? undefined : message.offset;
        obj.line = message.line === 0 ? undefined : message.line;
        obj.column = message.column === 0 ? undefined : message.column;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.SourcePosition.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.SourcePosition.decode(message.value);
    },
    toProto(message) {
        return exports.SourcePosition.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.expr.conformance.v1alpha1.SourcePosition",
            value: exports.SourcePosition.encode(message).finish()
        };
    }
};
function createBaseIssueDetails() {
    return {
        severity: 0,
        position: undefined,
        id: BigInt(0)
    };
}
exports.IssueDetails = {
    typeUrl: "/google.api.expr.conformance.v1alpha1.IssueDetails",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.severity !== 0) {
            writer.uint32(8).int32(message.severity);
        }
        if (message.position !== undefined) {
            exports.SourcePosition.encode(message.position, writer.uint32(18).fork()).ldelim();
        }
        if (message.id !== BigInt(0)) {
            writer.uint32(24).int64(message.id);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseIssueDetails();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.severity = reader.int32();
                    break;
                case 2:
                    message.position = exports.SourcePosition.decode(reader, reader.uint32());
                    break;
                case 3:
                    message.id = reader.int64();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseIssueDetails();
        message.severity = object.severity ?? 0;
        message.position = object.position !== undefined && object.position !== null ? exports.SourcePosition.fromPartial(object.position) : undefined;
        message.id = object.id !== undefined && object.id !== null ? BigInt(object.id.toString()) : BigInt(0);
        return message;
    },
    fromAmino(object) {
        const message = createBaseIssueDetails();
        if (object.severity !== undefined && object.severity !== null) {
            message.severity = object.severity;
        }
        if (object.position !== undefined && object.position !== null) {
            message.position = exports.SourcePosition.fromAmino(object.position);
        }
        if (object.id !== undefined && object.id !== null) {
            message.id = BigInt(object.id);
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.severity = message.severity === 0 ? undefined : message.severity;
        obj.position = message.position ? exports.SourcePosition.toAmino(message.position) : undefined;
        obj.id = message.id !== BigInt(0) ? message.id?.toString() : undefined;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.IssueDetails.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.IssueDetails.decode(message.value);
    },
    toProto(message) {
        return exports.IssueDetails.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.expr.conformance.v1alpha1.IssueDetails",
            value: exports.IssueDetails.encode(message).finish()
        };
    }
};
