"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Literal = exports.Expr_Comprehension = exports.Expr_CreateStruct_Entry = exports.Expr_CreateStruct = exports.Expr_CreateList = exports.Expr_Call = exports.Expr_Select = exports.Expr_Ident = exports.Expr = exports.ParsedExpr = void 0;
//@ts-nocheck
const source_1 = require("./source");
const binary_1 = require("../../../../binary");
const helpers_1 = require("../../../../helpers");
function createBaseParsedExpr() {
    return {
        expr: undefined,
        sourceInfo: undefined,
        syntaxVersion: ""
    };
}
exports.ParsedExpr = {
    typeUrl: "/google.api.expr.v1beta1.ParsedExpr",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.expr !== undefined) {
            exports.Expr.encode(message.expr, writer.uint32(18).fork()).ldelim();
        }
        if (message.sourceInfo !== undefined) {
            source_1.SourceInfo.encode(message.sourceInfo, writer.uint32(26).fork()).ldelim();
        }
        if (message.syntaxVersion !== "") {
            writer.uint32(34).string(message.syntaxVersion);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseParsedExpr();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 2:
                    message.expr = exports.Expr.decode(reader, reader.uint32());
                    break;
                case 3:
                    message.sourceInfo = source_1.SourceInfo.decode(reader, reader.uint32());
                    break;
                case 4:
                    message.syntaxVersion = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseParsedExpr();
        message.expr = object.expr !== undefined && object.expr !== null ? exports.Expr.fromPartial(object.expr) : undefined;
        message.sourceInfo = object.sourceInfo !== undefined && object.sourceInfo !== null ? source_1.SourceInfo.fromPartial(object.sourceInfo) : undefined;
        message.syntaxVersion = object.syntaxVersion ?? "";
        return message;
    },
    fromAmino(object) {
        const message = createBaseParsedExpr();
        if (object.expr !== undefined && object.expr !== null) {
            message.expr = exports.Expr.fromAmino(object.expr);
        }
        if (object.source_info !== undefined && object.source_info !== null) {
            message.sourceInfo = source_1.SourceInfo.fromAmino(object.source_info);
        }
        if (object.syntax_version !== undefined && object.syntax_version !== null) {
            message.syntaxVersion = object.syntax_version;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.expr = message.expr ? exports.Expr.toAmino(message.expr) : undefined;
        obj.source_info = message.sourceInfo ? source_1.SourceInfo.toAmino(message.sourceInfo) : undefined;
        obj.syntax_version = message.syntaxVersion === "" ? undefined : message.syntaxVersion;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.ParsedExpr.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.ParsedExpr.decode(message.value);
    },
    toProto(message) {
        return exports.ParsedExpr.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.expr.v1beta1.ParsedExpr",
            value: exports.ParsedExpr.encode(message).finish()
        };
    }
};
function createBaseExpr() {
    return {
        id: 0,
        literalExpr: undefined,
        identExpr: undefined,
        selectExpr: undefined,
        callExpr: undefined,
        listExpr: undefined,
        structExpr: undefined,
        comprehensionExpr: undefined
    };
}
exports.Expr = {
    typeUrl: "/google.api.expr.v1beta1.Expr",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.id !== 0) {
            writer.uint32(16).int32(message.id);
        }
        if (message.literalExpr !== undefined) {
            exports.Literal.encode(message.literalExpr, writer.uint32(26).fork()).ldelim();
        }
        if (message.identExpr !== undefined) {
            exports.Expr_Ident.encode(message.identExpr, writer.uint32(34).fork()).ldelim();
        }
        if (message.selectExpr !== undefined) {
            exports.Expr_Select.encode(message.selectExpr, writer.uint32(42).fork()).ldelim();
        }
        if (message.callExpr !== undefined) {
            exports.Expr_Call.encode(message.callExpr, writer.uint32(50).fork()).ldelim();
        }
        if (message.listExpr !== undefined) {
            exports.Expr_CreateList.encode(message.listExpr, writer.uint32(58).fork()).ldelim();
        }
        if (message.structExpr !== undefined) {
            exports.Expr_CreateStruct.encode(message.structExpr, writer.uint32(66).fork()).ldelim();
        }
        if (message.comprehensionExpr !== undefined) {
            exports.Expr_Comprehension.encode(message.comprehensionExpr, writer.uint32(74).fork()).ldelim();
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseExpr();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 2:
                    message.id = reader.int32();
                    break;
                case 3:
                    message.literalExpr = exports.Literal.decode(reader, reader.uint32());
                    break;
                case 4:
                    message.identExpr = exports.Expr_Ident.decode(reader, reader.uint32());
                    break;
                case 5:
                    message.selectExpr = exports.Expr_Select.decode(reader, reader.uint32());
                    break;
                case 6:
                    message.callExpr = exports.Expr_Call.decode(reader, reader.uint32());
                    break;
                case 7:
                    message.listExpr = exports.Expr_CreateList.decode(reader, reader.uint32());
                    break;
                case 8:
                    message.structExpr = exports.Expr_CreateStruct.decode(reader, reader.uint32());
                    break;
                case 9:
                    message.comprehensionExpr = exports.Expr_Comprehension.decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseExpr();
        message.id = object.id ?? 0;
        message.literalExpr = object.literalExpr !== undefined && object.literalExpr !== null ? exports.Literal.fromPartial(object.literalExpr) : undefined;
        message.identExpr = object.identExpr !== undefined && object.identExpr !== null ? exports.Expr_Ident.fromPartial(object.identExpr) : undefined;
        message.selectExpr = object.selectExpr !== undefined && object.selectExpr !== null ? exports.Expr_Select.fromPartial(object.selectExpr) : undefined;
        message.callExpr = object.callExpr !== undefined && object.callExpr !== null ? exports.Expr_Call.fromPartial(object.callExpr) : undefined;
        message.listExpr = object.listExpr !== undefined && object.listExpr !== null ? exports.Expr_CreateList.fromPartial(object.listExpr) : undefined;
        message.structExpr = object.structExpr !== undefined && object.structExpr !== null ? exports.Expr_CreateStruct.fromPartial(object.structExpr) : undefined;
        message.comprehensionExpr = object.comprehensionExpr !== undefined && object.comprehensionExpr !== null ? exports.Expr_Comprehension.fromPartial(object.comprehensionExpr) : undefined;
        return message;
    },
    fromAmino(object) {
        const message = createBaseExpr();
        if (object.id !== undefined && object.id !== null) {
            message.id = object.id;
        }
        if (object.literal_expr !== undefined && object.literal_expr !== null) {
            message.literalExpr = exports.Literal.fromAmino(object.literal_expr);
        }
        if (object.ident_expr !== undefined && object.ident_expr !== null) {
            message.identExpr = exports.Expr_Ident.fromAmino(object.ident_expr);
        }
        if (object.select_expr !== undefined && object.select_expr !== null) {
            message.selectExpr = exports.Expr_Select.fromAmino(object.select_expr);
        }
        if (object.call_expr !== undefined && object.call_expr !== null) {
            message.callExpr = exports.Expr_Call.fromAmino(object.call_expr);
        }
        if (object.list_expr !== undefined && object.list_expr !== null) {
            message.listExpr = exports.Expr_CreateList.fromAmino(object.list_expr);
        }
        if (object.struct_expr !== undefined && object.struct_expr !== null) {
            message.structExpr = exports.Expr_CreateStruct.fromAmino(object.struct_expr);
        }
        if (object.comprehension_expr !== undefined && object.comprehension_expr !== null) {
            message.comprehensionExpr = exports.Expr_Comprehension.fromAmino(object.comprehension_expr);
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.id = message.id === 0 ? undefined : message.id;
        obj.literal_expr = message.literalExpr ? exports.Literal.toAmino(message.literalExpr) : undefined;
        obj.ident_expr = message.identExpr ? exports.Expr_Ident.toAmino(message.identExpr) : undefined;
        obj.select_expr = message.selectExpr ? exports.Expr_Select.toAmino(message.selectExpr) : undefined;
        obj.call_expr = message.callExpr ? exports.Expr_Call.toAmino(message.callExpr) : undefined;
        obj.list_expr = message.listExpr ? exports.Expr_CreateList.toAmino(message.listExpr) : undefined;
        obj.struct_expr = message.structExpr ? exports.Expr_CreateStruct.toAmino(message.structExpr) : undefined;
        obj.comprehension_expr = message.comprehensionExpr ? exports.Expr_Comprehension.toAmino(message.comprehensionExpr) : undefined;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.Expr.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.Expr.decode(message.value);
    },
    toProto(message) {
        return exports.Expr.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.expr.v1beta1.Expr",
            value: exports.Expr.encode(message).finish()
        };
    }
};
function createBaseExpr_Ident() {
    return {
        name: ""
    };
}
exports.Expr_Ident = {
    typeUrl: "/google.api.expr.v1beta1.Ident",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.name !== "") {
            writer.uint32(10).string(message.name);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseExpr_Ident();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.name = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseExpr_Ident();
        message.name = object.name ?? "";
        return message;
    },
    fromAmino(object) {
        const message = createBaseExpr_Ident();
        if (object.name !== undefined && object.name !== null) {
            message.name = object.name;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.name = message.name === "" ? undefined : message.name;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.Expr_Ident.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.Expr_Ident.decode(message.value);
    },
    toProto(message) {
        return exports.Expr_Ident.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.expr.v1beta1.Ident",
            value: exports.Expr_Ident.encode(message).finish()
        };
    }
};
function createBaseExpr_Select() {
    return {
        operand: undefined,
        field: "",
        testOnly: false
    };
}
exports.Expr_Select = {
    typeUrl: "/google.api.expr.v1beta1.Select",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.operand !== undefined) {
            exports.Expr.encode(message.operand, writer.uint32(10).fork()).ldelim();
        }
        if (message.field !== "") {
            writer.uint32(18).string(message.field);
        }
        if (message.testOnly === true) {
            writer.uint32(24).bool(message.testOnly);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseExpr_Select();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.operand = exports.Expr.decode(reader, reader.uint32());
                    break;
                case 2:
                    message.field = reader.string();
                    break;
                case 3:
                    message.testOnly = reader.bool();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseExpr_Select();
        message.operand = object.operand !== undefined && object.operand !== null ? exports.Expr.fromPartial(object.operand) : undefined;
        message.field = object.field ?? "";
        message.testOnly = object.testOnly ?? false;
        return message;
    },
    fromAmino(object) {
        const message = createBaseExpr_Select();
        if (object.operand !== undefined && object.operand !== null) {
            message.operand = exports.Expr.fromAmino(object.operand);
        }
        if (object.field !== undefined && object.field !== null) {
            message.field = object.field;
        }
        if (object.test_only !== undefined && object.test_only !== null) {
            message.testOnly = object.test_only;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.operand = message.operand ? exports.Expr.toAmino(message.operand) : undefined;
        obj.field = message.field === "" ? undefined : message.field;
        obj.test_only = message.testOnly === false ? undefined : message.testOnly;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.Expr_Select.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.Expr_Select.decode(message.value);
    },
    toProto(message) {
        return exports.Expr_Select.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.expr.v1beta1.Select",
            value: exports.Expr_Select.encode(message).finish()
        };
    }
};
function createBaseExpr_Call() {
    return {
        target: undefined,
        function: "",
        args: []
    };
}
exports.Expr_Call = {
    typeUrl: "/google.api.expr.v1beta1.Call",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.target !== undefined) {
            exports.Expr.encode(message.target, writer.uint32(10).fork()).ldelim();
        }
        if (message.function !== "") {
            writer.uint32(18).string(message.function);
        }
        for (const v of message.args) {
            exports.Expr.encode(v, writer.uint32(26).fork()).ldelim();
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseExpr_Call();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.target = exports.Expr.decode(reader, reader.uint32());
                    break;
                case 2:
                    message.function = reader.string();
                    break;
                case 3:
                    message.args.push(exports.Expr.decode(reader, reader.uint32()));
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseExpr_Call();
        message.target = object.target !== undefined && object.target !== null ? exports.Expr.fromPartial(object.target) : undefined;
        message.function = object.function ?? "";
        message.args = object.args?.map(e => exports.Expr.fromPartial(e)) || [];
        return message;
    },
    fromAmino(object) {
        const message = createBaseExpr_Call();
        if (object.target !== undefined && object.target !== null) {
            message.target = exports.Expr.fromAmino(object.target);
        }
        if (object.function !== undefined && object.function !== null) {
            message.function = object.function;
        }
        message.args = object.args?.map(e => exports.Expr.fromAmino(e)) || [];
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.target = message.target ? exports.Expr.toAmino(message.target) : undefined;
        obj.function = message.function === "" ? undefined : message.function;
        if (message.args) {
            obj.args = message.args.map(e => e ? exports.Expr.toAmino(e) : undefined);
        }
        else {
            obj.args = message.args;
        }
        return obj;
    },
    fromAminoMsg(object) {
        return exports.Expr_Call.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.Expr_Call.decode(message.value);
    },
    toProto(message) {
        return exports.Expr_Call.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.expr.v1beta1.Call",
            value: exports.Expr_Call.encode(message).finish()
        };
    }
};
function createBaseExpr_CreateList() {
    return {
        elements: []
    };
}
exports.Expr_CreateList = {
    typeUrl: "/google.api.expr.v1beta1.CreateList",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        for (const v of message.elements) {
            exports.Expr.encode(v, writer.uint32(10).fork()).ldelim();
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseExpr_CreateList();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.elements.push(exports.Expr.decode(reader, reader.uint32()));
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseExpr_CreateList();
        message.elements = object.elements?.map(e => exports.Expr.fromPartial(e)) || [];
        return message;
    },
    fromAmino(object) {
        const message = createBaseExpr_CreateList();
        message.elements = object.elements?.map(e => exports.Expr.fromAmino(e)) || [];
        return message;
    },
    toAmino(message) {
        const obj = {};
        if (message.elements) {
            obj.elements = message.elements.map(e => e ? exports.Expr.toAmino(e) : undefined);
        }
        else {
            obj.elements = message.elements;
        }
        return obj;
    },
    fromAminoMsg(object) {
        return exports.Expr_CreateList.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.Expr_CreateList.decode(message.value);
    },
    toProto(message) {
        return exports.Expr_CreateList.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.expr.v1beta1.CreateList",
            value: exports.Expr_CreateList.encode(message).finish()
        };
    }
};
function createBaseExpr_CreateStruct() {
    return {
        type: "",
        entries: []
    };
}
exports.Expr_CreateStruct = {
    typeUrl: "/google.api.expr.v1beta1.CreateStruct",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.type !== "") {
            writer.uint32(10).string(message.type);
        }
        for (const v of message.entries) {
            exports.Expr_CreateStruct_Entry.encode(v, writer.uint32(18).fork()).ldelim();
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseExpr_CreateStruct();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.type = reader.string();
                    break;
                case 2:
                    message.entries.push(exports.Expr_CreateStruct_Entry.decode(reader, reader.uint32()));
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseExpr_CreateStruct();
        message.type = object.type ?? "";
        message.entries = object.entries?.map(e => exports.Expr_CreateStruct_Entry.fromPartial(e)) || [];
        return message;
    },
    fromAmino(object) {
        const message = createBaseExpr_CreateStruct();
        if (object.type !== undefined && object.type !== null) {
            message.type = object.type;
        }
        message.entries = object.entries?.map(e => exports.Expr_CreateStruct_Entry.fromAmino(e)) || [];
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.type = message.type === "" ? undefined : message.type;
        if (message.entries) {
            obj.entries = message.entries.map(e => e ? exports.Expr_CreateStruct_Entry.toAmino(e) : undefined);
        }
        else {
            obj.entries = message.entries;
        }
        return obj;
    },
    fromAminoMsg(object) {
        return exports.Expr_CreateStruct.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.Expr_CreateStruct.decode(message.value);
    },
    toProto(message) {
        return exports.Expr_CreateStruct.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.expr.v1beta1.CreateStruct",
            value: exports.Expr_CreateStruct.encode(message).finish()
        };
    }
};
function createBaseExpr_CreateStruct_Entry() {
    return {
        id: 0,
        fieldKey: undefined,
        mapKey: undefined,
        value: undefined
    };
}
exports.Expr_CreateStruct_Entry = {
    typeUrl: "/google.api.expr.v1beta1.Entry",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.id !== 0) {
            writer.uint32(8).int32(message.id);
        }
        if (message.fieldKey !== undefined) {
            writer.uint32(18).string(message.fieldKey);
        }
        if (message.mapKey !== undefined) {
            exports.Expr.encode(message.mapKey, writer.uint32(26).fork()).ldelim();
        }
        if (message.value !== undefined) {
            exports.Expr.encode(message.value, writer.uint32(34).fork()).ldelim();
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseExpr_CreateStruct_Entry();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.id = reader.int32();
                    break;
                case 2:
                    message.fieldKey = reader.string();
                    break;
                case 3:
                    message.mapKey = exports.Expr.decode(reader, reader.uint32());
                    break;
                case 4:
                    message.value = exports.Expr.decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseExpr_CreateStruct_Entry();
        message.id = object.id ?? 0;
        message.fieldKey = object.fieldKey ?? undefined;
        message.mapKey = object.mapKey !== undefined && object.mapKey !== null ? exports.Expr.fromPartial(object.mapKey) : undefined;
        message.value = object.value !== undefined && object.value !== null ? exports.Expr.fromPartial(object.value) : undefined;
        return message;
    },
    fromAmino(object) {
        const message = createBaseExpr_CreateStruct_Entry();
        if (object.id !== undefined && object.id !== null) {
            message.id = object.id;
        }
        if (object.field_key !== undefined && object.field_key !== null) {
            message.fieldKey = object.field_key;
        }
        if (object.map_key !== undefined && object.map_key !== null) {
            message.mapKey = exports.Expr.fromAmino(object.map_key);
        }
        if (object.value !== undefined && object.value !== null) {
            message.value = exports.Expr.fromAmino(object.value);
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.id = message.id === 0 ? undefined : message.id;
        obj.field_key = message.fieldKey === null ? undefined : message.fieldKey;
        obj.map_key = message.mapKey ? exports.Expr.toAmino(message.mapKey) : undefined;
        obj.value = message.value ? exports.Expr.toAmino(message.value) : undefined;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.Expr_CreateStruct_Entry.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.Expr_CreateStruct_Entry.decode(message.value);
    },
    toProto(message) {
        return exports.Expr_CreateStruct_Entry.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.expr.v1beta1.Entry",
            value: exports.Expr_CreateStruct_Entry.encode(message).finish()
        };
    }
};
function createBaseExpr_Comprehension() {
    return {
        iterVar: "",
        iterRange: undefined,
        accuVar: "",
        accuInit: undefined,
        loopCondition: undefined,
        loopStep: undefined,
        result: undefined
    };
}
exports.Expr_Comprehension = {
    typeUrl: "/google.api.expr.v1beta1.Comprehension",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.iterVar !== "") {
            writer.uint32(10).string(message.iterVar);
        }
        if (message.iterRange !== undefined) {
            exports.Expr.encode(message.iterRange, writer.uint32(18).fork()).ldelim();
        }
        if (message.accuVar !== "") {
            writer.uint32(26).string(message.accuVar);
        }
        if (message.accuInit !== undefined) {
            exports.Expr.encode(message.accuInit, writer.uint32(34).fork()).ldelim();
        }
        if (message.loopCondition !== undefined) {
            exports.Expr.encode(message.loopCondition, writer.uint32(42).fork()).ldelim();
        }
        if (message.loopStep !== undefined) {
            exports.Expr.encode(message.loopStep, writer.uint32(50).fork()).ldelim();
        }
        if (message.result !== undefined) {
            exports.Expr.encode(message.result, writer.uint32(58).fork()).ldelim();
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseExpr_Comprehension();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.iterVar = reader.string();
                    break;
                case 2:
                    message.iterRange = exports.Expr.decode(reader, reader.uint32());
                    break;
                case 3:
                    message.accuVar = reader.string();
                    break;
                case 4:
                    message.accuInit = exports.Expr.decode(reader, reader.uint32());
                    break;
                case 5:
                    message.loopCondition = exports.Expr.decode(reader, reader.uint32());
                    break;
                case 6:
                    message.loopStep = exports.Expr.decode(reader, reader.uint32());
                    break;
                case 7:
                    message.result = exports.Expr.decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseExpr_Comprehension();
        message.iterVar = object.iterVar ?? "";
        message.iterRange = object.iterRange !== undefined && object.iterRange !== null ? exports.Expr.fromPartial(object.iterRange) : undefined;
        message.accuVar = object.accuVar ?? "";
        message.accuInit = object.accuInit !== undefined && object.accuInit !== null ? exports.Expr.fromPartial(object.accuInit) : undefined;
        message.loopCondition = object.loopCondition !== undefined && object.loopCondition !== null ? exports.Expr.fromPartial(object.loopCondition) : undefined;
        message.loopStep = object.loopStep !== undefined && object.loopStep !== null ? exports.Expr.fromPartial(object.loopStep) : undefined;
        message.result = object.result !== undefined && object.result !== null ? exports.Expr.fromPartial(object.result) : undefined;
        return message;
    },
    fromAmino(object) {
        const message = createBaseExpr_Comprehension();
        if (object.iter_var !== undefined && object.iter_var !== null) {
            message.iterVar = object.iter_var;
        }
        if (object.iter_range !== undefined && object.iter_range !== null) {
            message.iterRange = exports.Expr.fromAmino(object.iter_range);
        }
        if (object.accu_var !== undefined && object.accu_var !== null) {
            message.accuVar = object.accu_var;
        }
        if (object.accu_init !== undefined && object.accu_init !== null) {
            message.accuInit = exports.Expr.fromAmino(object.accu_init);
        }
        if (object.loop_condition !== undefined && object.loop_condition !== null) {
            message.loopCondition = exports.Expr.fromAmino(object.loop_condition);
        }
        if (object.loop_step !== undefined && object.loop_step !== null) {
            message.loopStep = exports.Expr.fromAmino(object.loop_step);
        }
        if (object.result !== undefined && object.result !== null) {
            message.result = exports.Expr.fromAmino(object.result);
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.iter_var = message.iterVar === "" ? undefined : message.iterVar;
        obj.iter_range = message.iterRange ? exports.Expr.toAmino(message.iterRange) : undefined;
        obj.accu_var = message.accuVar === "" ? undefined : message.accuVar;
        obj.accu_init = message.accuInit ? exports.Expr.toAmino(message.accuInit) : undefined;
        obj.loop_condition = message.loopCondition ? exports.Expr.toAmino(message.loopCondition) : undefined;
        obj.loop_step = message.loopStep ? exports.Expr.toAmino(message.loopStep) : undefined;
        obj.result = message.result ? exports.Expr.toAmino(message.result) : undefined;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.Expr_Comprehension.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.Expr_Comprehension.decode(message.value);
    },
    toProto(message) {
        return exports.Expr_Comprehension.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.expr.v1beta1.Comprehension",
            value: exports.Expr_Comprehension.encode(message).finish()
        };
    }
};
function createBaseLiteral() {
    return {
        nullValue: undefined,
        boolValue: undefined,
        int64Value: undefined,
        uint64Value: undefined,
        doubleValue: undefined,
        stringValue: undefined,
        bytesValue: undefined
    };
}
exports.Literal = {
    typeUrl: "/google.api.expr.v1beta1.Literal",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.nullValue !== undefined) {
            writer.uint32(8).int32(message.nullValue);
        }
        if (message.boolValue !== undefined) {
            writer.uint32(16).bool(message.boolValue);
        }
        if (message.int64Value !== undefined) {
            writer.uint32(24).int64(message.int64Value);
        }
        if (message.uint64Value !== undefined) {
            writer.uint32(32).uint64(message.uint64Value);
        }
        if (message.doubleValue !== undefined) {
            writer.uint32(41).double(message.doubleValue);
        }
        if (message.stringValue !== undefined) {
            writer.uint32(50).string(message.stringValue);
        }
        if (message.bytesValue !== undefined) {
            writer.uint32(58).bytes(message.bytesValue);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseLiteral();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.nullValue = reader.int32();
                    break;
                case 2:
                    message.boolValue = reader.bool();
                    break;
                case 3:
                    message.int64Value = reader.int64();
                    break;
                case 4:
                    message.uint64Value = reader.uint64();
                    break;
                case 5:
                    message.doubleValue = reader.double();
                    break;
                case 6:
                    message.stringValue = reader.string();
                    break;
                case 7:
                    message.bytesValue = reader.bytes();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseLiteral();
        message.nullValue = object.nullValue ?? undefined;
        message.boolValue = object.boolValue ?? undefined;
        message.int64Value = object.int64Value !== undefined && object.int64Value !== null ? BigInt(object.int64Value.toString()) : undefined;
        message.uint64Value = object.uint64Value !== undefined && object.uint64Value !== null ? BigInt(object.uint64Value.toString()) : undefined;
        message.doubleValue = object.doubleValue ?? undefined;
        message.stringValue = object.stringValue ?? undefined;
        message.bytesValue = object.bytesValue ?? undefined;
        return message;
    },
    fromAmino(object) {
        const message = createBaseLiteral();
        if (object.null_value !== undefined && object.null_value !== null) {
            message.nullValue = object.null_value;
        }
        if (object.bool_value !== undefined && object.bool_value !== null) {
            message.boolValue = object.bool_value;
        }
        if (object.int64_value !== undefined && object.int64_value !== null) {
            message.int64Value = BigInt(object.int64_value);
        }
        if (object.uint64_value !== undefined && object.uint64_value !== null) {
            message.uint64Value = BigInt(object.uint64_value);
        }
        if (object.double_value !== undefined && object.double_value !== null) {
            message.doubleValue = object.double_value;
        }
        if (object.string_value !== undefined && object.string_value !== null) {
            message.stringValue = object.string_value;
        }
        if (object.bytes_value !== undefined && object.bytes_value !== null) {
            message.bytesValue = (0, helpers_1.bytesFromBase64)(object.bytes_value);
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.null_value = message.nullValue === null ? undefined : message.nullValue;
        obj.bool_value = message.boolValue === null ? undefined : message.boolValue;
        obj.int64_value = message.int64Value !== BigInt(0) ? message.int64Value?.toString() : undefined;
        obj.uint64_value = message.uint64Value !== BigInt(0) ? message.uint64Value?.toString() : undefined;
        obj.double_value = message.doubleValue === null ? undefined : message.doubleValue;
        obj.string_value = message.stringValue === null ? undefined : message.stringValue;
        obj.bytes_value = message.bytesValue ? (0, helpers_1.base64FromBytes)(message.bytesValue) : undefined;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.Literal.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.Literal.decode(message.value);
    },
    toProto(message) {
        return exports.Literal.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.expr.v1beta1.Literal",
            value: exports.Literal.encode(message).finish()
        };
    }
};
