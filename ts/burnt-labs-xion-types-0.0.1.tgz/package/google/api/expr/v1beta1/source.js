"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SourcePosition = exports.SourceInfo = exports.SourceInfo_PositionsEntry = void 0;
//@ts-nocheck
const binary_1 = require("../../../../binary");
function createBaseSourceInfo_PositionsEntry() {
    return {
        key: 0,
        value: 0
    };
}
exports.SourceInfo_PositionsEntry = {
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.key !== 0) {
            writer.uint32(8).int32(message.key);
        }
        if (message.value !== 0) {
            writer.uint32(16).int32(message.value);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseSourceInfo_PositionsEntry();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.key = reader.int32();
                    break;
                case 2:
                    message.value = reader.int32();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseSourceInfo_PositionsEntry();
        message.key = object.key ?? 0;
        message.value = object.value ?? 0;
        return message;
    },
    fromAmino(object) {
        const message = createBaseSourceInfo_PositionsEntry();
        if (object.key !== undefined && object.key !== null) {
            message.key = object.key;
        }
        if (object.value !== undefined && object.value !== null) {
            message.value = object.value;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.key = message.key === 0 ? undefined : message.key;
        obj.value = message.value === 0 ? undefined : message.value;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.SourceInfo_PositionsEntry.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.SourceInfo_PositionsEntry.decode(message.value);
    },
    toProto(message) {
        return exports.SourceInfo_PositionsEntry.encode(message).finish();
    }
};
function createBaseSourceInfo() {
    return {
        location: "",
        lineOffsets: [],
        positions: {}
    };
}
exports.SourceInfo = {
    typeUrl: "/google.api.expr.v1beta1.SourceInfo",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.location !== "") {
            writer.uint32(18).string(message.location);
        }
        writer.uint32(26).fork();
        for (const v of message.lineOffsets) {
            writer.int32(v);
        }
        writer.ldelim();
        Object.entries(message.positions).forEach(([key, value]) => {
            exports.SourceInfo_PositionsEntry.encode({
                key: key,
                value
            }, writer.uint32(32).fork()).ldelim();
        });
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseSourceInfo();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 2:
                    message.location = reader.string();
                    break;
                case 3:
                    if ((tag & 7) === 2) {
                        const end2 = reader.uint32() + reader.pos;
                        while (reader.pos < end2) {
                            message.lineOffsets.push(reader.int32());
                        }
                    }
                    else {
                        message.lineOffsets.push(reader.int32());
                    }
                    break;
                case 4:
                    const entry4 = exports.SourceInfo_PositionsEntry.decode(reader, reader.uint32());
                    if (entry4.value !== undefined) {
                        message.positions[entry4.key] = entry4.value;
                    }
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseSourceInfo();
        message.location = object.location ?? "";
        message.lineOffsets = object.lineOffsets?.map(e => e) || [];
        message.positions = Object.entries(object.positions ?? {}).reduce((acc, [key, value]) => {
            if (value !== undefined) {
                acc[Number(key)] = Number(value);
            }
            return acc;
        }, {});
        return message;
    },
    fromAmino(object) {
        const message = createBaseSourceInfo();
        if (object.location !== undefined && object.location !== null) {
            message.location = object.location;
        }
        message.lineOffsets = object.line_offsets?.map(e => e) || [];
        message.positions = Object.entries(object.positions ?? {}).reduce((acc, [key, value]) => {
            if (value !== undefined) {
                acc[Number(key)] = Number(value);
            }
            return acc;
        }, {});
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.location = message.location === "" ? undefined : message.location;
        if (message.lineOffsets) {
            obj.line_offsets = message.lineOffsets.map(e => e);
        }
        else {
            obj.line_offsets = message.lineOffsets;
        }
        obj.positions = {};
        if (message.positions) {
            Object.entries(message.positions).forEach(([k, v]) => {
                obj.positions[k] = Math.round(v);
            });
        }
        return obj;
    },
    fromAminoMsg(object) {
        return exports.SourceInfo.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.SourceInfo.decode(message.value);
    },
    toProto(message) {
        return exports.SourceInfo.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.expr.v1beta1.SourceInfo",
            value: exports.SourceInfo.encode(message).finish()
        };
    }
};
function createBaseSourcePosition() {
    return {
        location: "",
        offset: 0,
        line: 0,
        column: 0
    };
}
exports.SourcePosition = {
    typeUrl: "/google.api.expr.v1beta1.SourcePosition",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.location !== "") {
            writer.uint32(10).string(message.location);
        }
        if (message.offset !== 0) {
            writer.uint32(16).int32(message.offset);
        }
        if (message.line !== 0) {
            writer.uint32(24).int32(message.line);
        }
        if (message.column !== 0) {
            writer.uint32(32).int32(message.column);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseSourcePosition();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.location = reader.string();
                    break;
                case 2:
                    message.offset = reader.int32();
                    break;
                case 3:
                    message.line = reader.int32();
                    break;
                case 4:
                    message.column = reader.int32();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseSourcePosition();
        message.location = object.location ?? "";
        message.offset = object.offset ?? 0;
        message.line = object.line ?? 0;
        message.column = object.column ?? 0;
        return message;
    },
    fromAmino(object) {
        const message = createBaseSourcePosition();
        if (object.location !== undefined && object.location !== null) {
            message.location = object.location;
        }
        if (object.offset !== undefined && object.offset !== null) {
            message.offset = object.offset;
        }
        if (object.line !== undefined && object.line !== null) {
            message.line = object.line;
        }
        if (object.column !== undefined && object.column !== null) {
            message.column = object.column;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.location = message.location === "" ? undefined : message.location;
        obj.offset = message.offset === 0 ? undefined : message.offset;
        obj.line = message.line === 0 ? undefined : message.line;
        obj.column = message.column === 0 ? undefined : message.column;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.SourcePosition.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.SourcePosition.decode(message.value);
    },
    toProto(message) {
        return exports.SourcePosition.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.expr.v1beta1.SourcePosition",
            value: exports.SourcePosition.encode(message).finish()
        };
    }
};
