"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.FunctionDecl = exports.IdentDecl = exports.DeclType = exports.Decl = void 0;
//@ts-nocheck
const expr_1 = require("./expr");
const binary_1 = require("../../../../binary");
function createBaseDecl() {
    return {
        id: 0,
        name: "",
        doc: "",
        ident: undefined,
        function: undefined
    };
}
exports.Decl = {
    typeUrl: "/google.api.expr.v1beta1.Decl",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.id !== 0) {
            writer.uint32(8).int32(message.id);
        }
        if (message.name !== "") {
            writer.uint32(18).string(message.name);
        }
        if (message.doc !== "") {
            writer.uint32(26).string(message.doc);
        }
        if (message.ident !== undefined) {
            exports.IdentDecl.encode(message.ident, writer.uint32(34).fork()).ldelim();
        }
        if (message.function !== undefined) {
            exports.FunctionDecl.encode(message.function, writer.uint32(42).fork()).ldelim();
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseDecl();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.id = reader.int32();
                    break;
                case 2:
                    message.name = reader.string();
                    break;
                case 3:
                    message.doc = reader.string();
                    break;
                case 4:
                    message.ident = exports.IdentDecl.decode(reader, reader.uint32());
                    break;
                case 5:
                    message.function = exports.FunctionDecl.decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseDecl();
        message.id = object.id ?? 0;
        message.name = object.name ?? "";
        message.doc = object.doc ?? "";
        message.ident = object.ident !== undefined && object.ident !== null ? exports.IdentDecl.fromPartial(object.ident) : undefined;
        message.function = object.function !== undefined && object.function !== null ? exports.FunctionDecl.fromPartial(object.function) : undefined;
        return message;
    },
    fromAmino(object) {
        const message = createBaseDecl();
        if (object.id !== undefined && object.id !== null) {
            message.id = object.id;
        }
        if (object.name !== undefined && object.name !== null) {
            message.name = object.name;
        }
        if (object.doc !== undefined && object.doc !== null) {
            message.doc = object.doc;
        }
        if (object.ident !== undefined && object.ident !== null) {
            message.ident = exports.IdentDecl.fromAmino(object.ident);
        }
        if (object.function !== undefined && object.function !== null) {
            message.function = exports.FunctionDecl.fromAmino(object.function);
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.id = message.id === 0 ? undefined : message.id;
        obj.name = message.name === "" ? undefined : message.name;
        obj.doc = message.doc === "" ? undefined : message.doc;
        obj.ident = message.ident ? exports.IdentDecl.toAmino(message.ident) : undefined;
        obj.function = message.function ? exports.FunctionDecl.toAmino(message.function) : undefined;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.Decl.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.Decl.decode(message.value);
    },
    toProto(message) {
        return exports.Decl.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.expr.v1beta1.Decl",
            value: exports.Decl.encode(message).finish()
        };
    }
};
function createBaseDeclType() {
    return {
        id: 0,
        type: "",
        typeParams: []
    };
}
exports.DeclType = {
    typeUrl: "/google.api.expr.v1beta1.DeclType",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.id !== 0) {
            writer.uint32(8).int32(message.id);
        }
        if (message.type !== "") {
            writer.uint32(18).string(message.type);
        }
        for (const v of message.typeParams) {
            exports.DeclType.encode(v, writer.uint32(34).fork()).ldelim();
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseDeclType();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.id = reader.int32();
                    break;
                case 2:
                    message.type = reader.string();
                    break;
                case 4:
                    message.typeParams.push(exports.DeclType.decode(reader, reader.uint32()));
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseDeclType();
        message.id = object.id ?? 0;
        message.type = object.type ?? "";
        message.typeParams = object.typeParams?.map(e => exports.DeclType.fromPartial(e)) || [];
        return message;
    },
    fromAmino(object) {
        const message = createBaseDeclType();
        if (object.id !== undefined && object.id !== null) {
            message.id = object.id;
        }
        if (object.type !== undefined && object.type !== null) {
            message.type = object.type;
        }
        message.typeParams = object.type_params?.map(e => exports.DeclType.fromAmino(e)) || [];
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.id = message.id === 0 ? undefined : message.id;
        obj.type = message.type === "" ? undefined : message.type;
        if (message.typeParams) {
            obj.type_params = message.typeParams.map(e => e ? exports.DeclType.toAmino(e) : undefined);
        }
        else {
            obj.type_params = message.typeParams;
        }
        return obj;
    },
    fromAminoMsg(object) {
        return exports.DeclType.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.DeclType.decode(message.value);
    },
    toProto(message) {
        return exports.DeclType.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.expr.v1beta1.DeclType",
            value: exports.DeclType.encode(message).finish()
        };
    }
};
function createBaseIdentDecl() {
    return {
        type: undefined,
        value: undefined
    };
}
exports.IdentDecl = {
    typeUrl: "/google.api.expr.v1beta1.IdentDecl",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.type !== undefined) {
            exports.DeclType.encode(message.type, writer.uint32(26).fork()).ldelim();
        }
        if (message.value !== undefined) {
            expr_1.Expr.encode(message.value, writer.uint32(34).fork()).ldelim();
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseIdentDecl();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 3:
                    message.type = exports.DeclType.decode(reader, reader.uint32());
                    break;
                case 4:
                    message.value = expr_1.Expr.decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseIdentDecl();
        message.type = object.type !== undefined && object.type !== null ? exports.DeclType.fromPartial(object.type) : undefined;
        message.value = object.value !== undefined && object.value !== null ? expr_1.Expr.fromPartial(object.value) : undefined;
        return message;
    },
    fromAmino(object) {
        const message = createBaseIdentDecl();
        if (object.type !== undefined && object.type !== null) {
            message.type = exports.DeclType.fromAmino(object.type);
        }
        if (object.value !== undefined && object.value !== null) {
            message.value = expr_1.Expr.fromAmino(object.value);
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.type = message.type ? exports.DeclType.toAmino(message.type) : undefined;
        obj.value = message.value ? expr_1.Expr.toAmino(message.value) : undefined;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.IdentDecl.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.IdentDecl.decode(message.value);
    },
    toProto(message) {
        return exports.IdentDecl.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.expr.v1beta1.IdentDecl",
            value: exports.IdentDecl.encode(message).finish()
        };
    }
};
function createBaseFunctionDecl() {
    return {
        args: [],
        returnType: undefined,
        receiverFunction: false
    };
}
exports.FunctionDecl = {
    typeUrl: "/google.api.expr.v1beta1.FunctionDecl",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        for (const v of message.args) {
            exports.IdentDecl.encode(v, writer.uint32(10).fork()).ldelim();
        }
        if (message.returnType !== undefined) {
            exports.DeclType.encode(message.returnType, writer.uint32(18).fork()).ldelim();
        }
        if (message.receiverFunction === true) {
            writer.uint32(24).bool(message.receiverFunction);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseFunctionDecl();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.args.push(exports.IdentDecl.decode(reader, reader.uint32()));
                    break;
                case 2:
                    message.returnType = exports.DeclType.decode(reader, reader.uint32());
                    break;
                case 3:
                    message.receiverFunction = reader.bool();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseFunctionDecl();
        message.args = object.args?.map(e => exports.IdentDecl.fromPartial(e)) || [];
        message.returnType = object.returnType !== undefined && object.returnType !== null ? exports.DeclType.fromPartial(object.returnType) : undefined;
        message.receiverFunction = object.receiverFunction ?? false;
        return message;
    },
    fromAmino(object) {
        const message = createBaseFunctionDecl();
        message.args = object.args?.map(e => exports.IdentDecl.fromAmino(e)) || [];
        if (object.return_type !== undefined && object.return_type !== null) {
            message.returnType = exports.DeclType.fromAmino(object.return_type);
        }
        if (object.receiver_function !== undefined && object.receiver_function !== null) {
            message.receiverFunction = object.receiver_function;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        if (message.args) {
            obj.args = message.args.map(e => e ? exports.IdentDecl.toAmino(e) : undefined);
        }
        else {
            obj.args = message.args;
        }
        obj.return_type = message.returnType ? exports.DeclType.toAmino(message.returnType) : undefined;
        obj.receiver_function = message.receiverFunction === false ? undefined : message.receiverFunction;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.FunctionDecl.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.FunctionDecl.decode(message.value);
    },
    toProto(message) {
        return exports.FunctionDecl.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.expr.v1beta1.FunctionDecl",
            value: exports.FunctionDecl.encode(message).finish()
        };
    }
};
