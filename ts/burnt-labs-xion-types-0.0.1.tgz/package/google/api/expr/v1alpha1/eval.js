"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.UnknownSet = exports.ErrorSet = exports.ExprValue = exports.EvalState_Result = exports.EvalState = void 0;
//@ts-nocheck
const value_1 = require("./value");
const status_1 = require("../../../rpc/status");
const binary_1 = require("../../../../binary");
function createBaseEvalState() {
    return {
        values: [],
        results: []
    };
}
exports.EvalState = {
    typeUrl: "/google.api.expr.v1alpha1.EvalState",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        for (const v of message.values) {
            exports.ExprValue.encode(v, writer.uint32(10).fork()).ldelim();
        }
        for (const v of message.results) {
            exports.EvalState_Result.encode(v, writer.uint32(26).fork()).ldelim();
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseEvalState();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.values.push(exports.ExprValue.decode(reader, reader.uint32()));
                    break;
                case 3:
                    message.results.push(exports.EvalState_Result.decode(reader, reader.uint32()));
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseEvalState();
        message.values = object.values?.map(e => exports.ExprValue.fromPartial(e)) || [];
        message.results = object.results?.map(e => exports.EvalState_Result.fromPartial(e)) || [];
        return message;
    },
    fromAmino(object) {
        const message = createBaseEvalState();
        message.values = object.values?.map(e => exports.ExprValue.fromAmino(e)) || [];
        message.results = object.results?.map(e => exports.EvalState_Result.fromAmino(e)) || [];
        return message;
    },
    toAmino(message) {
        const obj = {};
        if (message.values) {
            obj.values = message.values.map(e => e ? exports.ExprValue.toAmino(e) : undefined);
        }
        else {
            obj.values = message.values;
        }
        if (message.results) {
            obj.results = message.results.map(e => e ? exports.EvalState_Result.toAmino(e) : undefined);
        }
        else {
            obj.results = message.results;
        }
        return obj;
    },
    fromAminoMsg(object) {
        return exports.EvalState.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.EvalState.decode(message.value);
    },
    toProto(message) {
        return exports.EvalState.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.expr.v1alpha1.EvalState",
            value: exports.EvalState.encode(message).finish()
        };
    }
};
function createBaseEvalState_Result() {
    return {
        expr: BigInt(0),
        value: BigInt(0)
    };
}
exports.EvalState_Result = {
    typeUrl: "/google.api.expr.v1alpha1.Result",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.expr !== BigInt(0)) {
            writer.uint32(8).int64(message.expr);
        }
        if (message.value !== BigInt(0)) {
            writer.uint32(16).int64(message.value);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseEvalState_Result();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.expr = reader.int64();
                    break;
                case 2:
                    message.value = reader.int64();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseEvalState_Result();
        message.expr = object.expr !== undefined && object.expr !== null ? BigInt(object.expr.toString()) : BigInt(0);
        message.value = object.value !== undefined && object.value !== null ? BigInt(object.value.toString()) : BigInt(0);
        return message;
    },
    fromAmino(object) {
        const message = createBaseEvalState_Result();
        if (object.expr !== undefined && object.expr !== null) {
            message.expr = BigInt(object.expr);
        }
        if (object.value !== undefined && object.value !== null) {
            message.value = BigInt(object.value);
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.expr = message.expr !== BigInt(0) ? message.expr?.toString() : undefined;
        obj.value = message.value !== BigInt(0) ? message.value?.toString() : undefined;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.EvalState_Result.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.EvalState_Result.decode(message.value);
    },
    toProto(message) {
        return exports.EvalState_Result.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.expr.v1alpha1.Result",
            value: exports.EvalState_Result.encode(message).finish()
        };
    }
};
function createBaseExprValue() {
    return {
        value: undefined,
        error: undefined,
        unknown: undefined
    };
}
exports.ExprValue = {
    typeUrl: "/google.api.expr.v1alpha1.ExprValue",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.value !== undefined) {
            value_1.Value.encode(message.value, writer.uint32(10).fork()).ldelim();
        }
        if (message.error !== undefined) {
            exports.ErrorSet.encode(message.error, writer.uint32(18).fork()).ldelim();
        }
        if (message.unknown !== undefined) {
            exports.UnknownSet.encode(message.unknown, writer.uint32(26).fork()).ldelim();
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseExprValue();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.value = value_1.Value.decode(reader, reader.uint32());
                    break;
                case 2:
                    message.error = exports.ErrorSet.decode(reader, reader.uint32());
                    break;
                case 3:
                    message.unknown = exports.UnknownSet.decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseExprValue();
        message.value = object.value !== undefined && object.value !== null ? value_1.Value.fromPartial(object.value) : undefined;
        message.error = object.error !== undefined && object.error !== null ? exports.ErrorSet.fromPartial(object.error) : undefined;
        message.unknown = object.unknown !== undefined && object.unknown !== null ? exports.UnknownSet.fromPartial(object.unknown) : undefined;
        return message;
    },
    fromAmino(object) {
        const message = createBaseExprValue();
        if (object.value !== undefined && object.value !== null) {
            message.value = value_1.Value.fromAmino(object.value);
        }
        if (object.error !== undefined && object.error !== null) {
            message.error = exports.ErrorSet.fromAmino(object.error);
        }
        if (object.unknown !== undefined && object.unknown !== null) {
            message.unknown = exports.UnknownSet.fromAmino(object.unknown);
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.value = message.value ? value_1.Value.toAmino(message.value) : undefined;
        obj.error = message.error ? exports.ErrorSet.toAmino(message.error) : undefined;
        obj.unknown = message.unknown ? exports.UnknownSet.toAmino(message.unknown) : undefined;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.ExprValue.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.ExprValue.decode(message.value);
    },
    toProto(message) {
        return exports.ExprValue.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.expr.v1alpha1.ExprValue",
            value: exports.ExprValue.encode(message).finish()
        };
    }
};
function createBaseErrorSet() {
    return {
        errors: []
    };
}
exports.ErrorSet = {
    typeUrl: "/google.api.expr.v1alpha1.ErrorSet",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        for (const v of message.errors) {
            status_1.Status.encode(v, writer.uint32(10).fork()).ldelim();
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseErrorSet();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.errors.push(status_1.Status.decode(reader, reader.uint32()));
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseErrorSet();
        message.errors = object.errors?.map(e => status_1.Status.fromPartial(e)) || [];
        return message;
    },
    fromAmino(object) {
        const message = createBaseErrorSet();
        message.errors = object.errors?.map(e => status_1.Status.fromAmino(e)) || [];
        return message;
    },
    toAmino(message) {
        const obj = {};
        if (message.errors) {
            obj.errors = message.errors.map(e => e ? status_1.Status.toAmino(e) : undefined);
        }
        else {
            obj.errors = message.errors;
        }
        return obj;
    },
    fromAminoMsg(object) {
        return exports.ErrorSet.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.ErrorSet.decode(message.value);
    },
    toProto(message) {
        return exports.ErrorSet.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.expr.v1alpha1.ErrorSet",
            value: exports.ErrorSet.encode(message).finish()
        };
    }
};
function createBaseUnknownSet() {
    return {
        exprs: []
    };
}
exports.UnknownSet = {
    typeUrl: "/google.api.expr.v1alpha1.UnknownSet",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        writer.uint32(10).fork();
        for (const v of message.exprs) {
            writer.int64(v);
        }
        writer.ldelim();
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseUnknownSet();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    if ((tag & 7) === 2) {
                        const end2 = reader.uint32() + reader.pos;
                        while (reader.pos < end2) {
                            message.exprs.push(reader.int64());
                        }
                    }
                    else {
                        message.exprs.push(reader.int64());
                    }
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseUnknownSet();
        message.exprs = object.exprs?.map(e => BigInt(e.toString())) || [];
        return message;
    },
    fromAmino(object) {
        const message = createBaseUnknownSet();
        message.exprs = object.exprs?.map(e => BigInt(e)) || [];
        return message;
    },
    toAmino(message) {
        const obj = {};
        if (message.exprs) {
            obj.exprs = message.exprs.map(e => e.toString());
        }
        else {
            obj.exprs = message.exprs;
        }
        return obj;
    },
    fromAminoMsg(object) {
        return exports.UnknownSet.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.UnknownSet.decode(message.value);
    },
    toProto(message) {
        return exports.UnknownSet.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.expr.v1alpha1.UnknownSet",
            value: exports.UnknownSet.encode(message).finish()
        };
    }
};
