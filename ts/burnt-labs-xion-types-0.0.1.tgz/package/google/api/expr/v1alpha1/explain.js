"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Explain_ExprStep = exports.Explain = void 0;
//@ts-nocheck
const value_1 = require("./value");
const binary_1 = require("../../../../binary");
function createBaseExplain() {
    return {
        values: [],
        exprSteps: []
    };
}
exports.Explain = {
    typeUrl: "/google.api.expr.v1alpha1.Explain",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        for (const v of message.values) {
            value_1.Value.encode(v, writer.uint32(10).fork()).ldelim();
        }
        for (const v of message.exprSteps) {
            exports.Explain_ExprStep.encode(v, writer.uint32(18).fork()).ldelim();
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseExplain();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.values.push(value_1.Value.decode(reader, reader.uint32()));
                    break;
                case 2:
                    message.exprSteps.push(exports.Explain_ExprStep.decode(reader, reader.uint32()));
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseExplain();
        message.values = object.values?.map(e => value_1.Value.fromPartial(e)) || [];
        message.exprSteps = object.exprSteps?.map(e => exports.Explain_ExprStep.fromPartial(e)) || [];
        return message;
    },
    fromAmino(object) {
        const message = createBaseExplain();
        message.values = object.values?.map(e => value_1.Value.fromAmino(e)) || [];
        message.exprSteps = object.expr_steps?.map(e => exports.Explain_ExprStep.fromAmino(e)) || [];
        return message;
    },
    toAmino(message) {
        const obj = {};
        if (message.values) {
            obj.values = message.values.map(e => e ? value_1.Value.toAmino(e) : undefined);
        }
        else {
            obj.values = message.values;
        }
        if (message.exprSteps) {
            obj.expr_steps = message.exprSteps.map(e => e ? exports.Explain_ExprStep.toAmino(e) : undefined);
        }
        else {
            obj.expr_steps = message.exprSteps;
        }
        return obj;
    },
    fromAminoMsg(object) {
        return exports.Explain.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.Explain.decode(message.value);
    },
    toProto(message) {
        return exports.Explain.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.expr.v1alpha1.Explain",
            value: exports.Explain.encode(message).finish()
        };
    }
};
function createBaseExplain_ExprStep() {
    return {
        id: BigInt(0),
        valueIndex: 0
    };
}
exports.Explain_ExprStep = {
    typeUrl: "/google.api.expr.v1alpha1.ExprStep",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.id !== BigInt(0)) {
            writer.uint32(8).int64(message.id);
        }
        if (message.valueIndex !== 0) {
            writer.uint32(16).int32(message.valueIndex);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseExplain_ExprStep();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.id = reader.int64();
                    break;
                case 2:
                    message.valueIndex = reader.int32();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseExplain_ExprStep();
        message.id = object.id !== undefined && object.id !== null ? BigInt(object.id.toString()) : BigInt(0);
        message.valueIndex = object.valueIndex ?? 0;
        return message;
    },
    fromAmino(object) {
        const message = createBaseExplain_ExprStep();
        if (object.id !== undefined && object.id !== null) {
            message.id = BigInt(object.id);
        }
        if (object.value_index !== undefined && object.value_index !== null) {
            message.valueIndex = object.value_index;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.id = message.id !== BigInt(0) ? message.id?.toString() : undefined;
        obj.value_index = message.valueIndex === 0 ? undefined : message.valueIndex;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.Explain_ExprStep.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.Explain_ExprStep.decode(message.value);
    },
    toProto(message) {
        return exports.Explain_ExprStep.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.expr.v1alpha1.ExprStep",
            value: exports.Explain_ExprStep.encode(message).finish()
        };
    }
};
