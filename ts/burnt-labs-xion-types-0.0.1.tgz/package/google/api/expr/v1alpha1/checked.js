"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Reference = exports.Decl_FunctionDecl_Overload = exports.Decl_FunctionDecl = exports.Decl_IdentDecl = exports.Decl = exports.Type_AbstractType = exports.Type_FunctionType = exports.Type_MapType = exports.Type_ListType = exports.Type = exports.CheckedExpr = exports.CheckedExpr_TypeMapEntry = exports.CheckedExpr_ReferenceMapEntry = exports.Type_WellKnownTypeAmino = exports.Type_WellKnownTypeSDKType = exports.Type_WellKnownType = exports.Type_PrimitiveTypeAmino = exports.Type_PrimitiveTypeSDKType = exports.Type_PrimitiveType = void 0;
exports.type_PrimitiveTypeFromJSON = type_PrimitiveTypeFromJSON;
exports.type_PrimitiveTypeToJSON = type_PrimitiveTypeToJSON;
exports.type_WellKnownTypeFromJSON = type_WellKnownTypeFromJSON;
exports.type_WellKnownTypeToJSON = type_WellKnownTypeToJSON;
//@ts-nocheck
const syntax_1 = require("./syntax");
const empty_1 = require("../../../protobuf/empty");
const binary_1 = require("../../../../binary");
/** CEL primitive types. */
var Type_PrimitiveType;
(function (Type_PrimitiveType) {
    /** PRIMITIVE_TYPE_UNSPECIFIED - Unspecified type. */
    Type_PrimitiveType[Type_PrimitiveType["PRIMITIVE_TYPE_UNSPECIFIED"] = 0] = "PRIMITIVE_TYPE_UNSPECIFIED";
    /** BOOL - Boolean type. */
    Type_PrimitiveType[Type_PrimitiveType["BOOL"] = 1] = "BOOL";
    /**
     * INT64 - Int64 type.
     *
     * Proto-based integer values are widened to int64.
     */
    Type_PrimitiveType[Type_PrimitiveType["INT64"] = 2] = "INT64";
    /**
     * UINT64 - Uint64 type.
     *
     * Proto-based unsigned integer values are widened to uint64.
     */
    Type_PrimitiveType[Type_PrimitiveType["UINT64"] = 3] = "UINT64";
    /**
     * DOUBLE - Double type.
     *
     * Proto-based float values are widened to double values.
     */
    Type_PrimitiveType[Type_PrimitiveType["DOUBLE"] = 4] = "DOUBLE";
    /** STRING - String type. */
    Type_PrimitiveType[Type_PrimitiveType["STRING"] = 5] = "STRING";
    /** BYTES - Bytes type. */
    Type_PrimitiveType[Type_PrimitiveType["BYTES"] = 6] = "BYTES";
    Type_PrimitiveType[Type_PrimitiveType["UNRECOGNIZED"] = -1] = "UNRECOGNIZED";
})(Type_PrimitiveType || (exports.Type_PrimitiveType = Type_PrimitiveType = {}));
exports.Type_PrimitiveTypeSDKType = Type_PrimitiveType;
exports.Type_PrimitiveTypeAmino = Type_PrimitiveType;
function type_PrimitiveTypeFromJSON(object) {
    switch (object) {
        case 0:
        case "PRIMITIVE_TYPE_UNSPECIFIED":
            return Type_PrimitiveType.PRIMITIVE_TYPE_UNSPECIFIED;
        case 1:
        case "BOOL":
            return Type_PrimitiveType.BOOL;
        case 2:
        case "INT64":
            return Type_PrimitiveType.INT64;
        case 3:
        case "UINT64":
            return Type_PrimitiveType.UINT64;
        case 4:
        case "DOUBLE":
            return Type_PrimitiveType.DOUBLE;
        case 5:
        case "STRING":
            return Type_PrimitiveType.STRING;
        case 6:
        case "BYTES":
            return Type_PrimitiveType.BYTES;
        case -1:
        case "UNRECOGNIZED":
        default:
            return Type_PrimitiveType.UNRECOGNIZED;
    }
}
function type_PrimitiveTypeToJSON(object) {
    switch (object) {
        case Type_PrimitiveType.PRIMITIVE_TYPE_UNSPECIFIED:
            return "PRIMITIVE_TYPE_UNSPECIFIED";
        case Type_PrimitiveType.BOOL:
            return "BOOL";
        case Type_PrimitiveType.INT64:
            return "INT64";
        case Type_PrimitiveType.UINT64:
            return "UINT64";
        case Type_PrimitiveType.DOUBLE:
            return "DOUBLE";
        case Type_PrimitiveType.STRING:
            return "STRING";
        case Type_PrimitiveType.BYTES:
            return "BYTES";
        case Type_PrimitiveType.UNRECOGNIZED:
        default:
            return "UNRECOGNIZED";
    }
}
/** Well-known protobuf types treated with first-class support in CEL. */
var Type_WellKnownType;
(function (Type_WellKnownType) {
    /** WELL_KNOWN_TYPE_UNSPECIFIED - Unspecified type. */
    Type_WellKnownType[Type_WellKnownType["WELL_KNOWN_TYPE_UNSPECIFIED"] = 0] = "WELL_KNOWN_TYPE_UNSPECIFIED";
    /**
     * ANY - Well-known protobuf.Any type.
     *
     * Any types are a polymorphic message type. During type-checking they are
     * treated like `DYN` types, but at runtime they are resolved to a specific
     * message type specified at evaluation time.
     */
    Type_WellKnownType[Type_WellKnownType["ANY"] = 1] = "ANY";
    /** TIMESTAMP - Well-known protobuf.Timestamp type, internally referenced as `timestamp`. */
    Type_WellKnownType[Type_WellKnownType["TIMESTAMP"] = 2] = "TIMESTAMP";
    /** DURATION - Well-known protobuf.Duration type, internally referenced as `duration`. */
    Type_WellKnownType[Type_WellKnownType["DURATION"] = 3] = "DURATION";
    Type_WellKnownType[Type_WellKnownType["UNRECOGNIZED"] = -1] = "UNRECOGNIZED";
})(Type_WellKnownType || (exports.Type_WellKnownType = Type_WellKnownType = {}));
exports.Type_WellKnownTypeSDKType = Type_WellKnownType;
exports.Type_WellKnownTypeAmino = Type_WellKnownType;
function type_WellKnownTypeFromJSON(object) {
    switch (object) {
        case 0:
        case "WELL_KNOWN_TYPE_UNSPECIFIED":
            return Type_WellKnownType.WELL_KNOWN_TYPE_UNSPECIFIED;
        case 1:
        case "ANY":
            return Type_WellKnownType.ANY;
        case 2:
        case "TIMESTAMP":
            return Type_WellKnownType.TIMESTAMP;
        case 3:
        case "DURATION":
            return Type_WellKnownType.DURATION;
        case -1:
        case "UNRECOGNIZED":
        default:
            return Type_WellKnownType.UNRECOGNIZED;
    }
}
function type_WellKnownTypeToJSON(object) {
    switch (object) {
        case Type_WellKnownType.WELL_KNOWN_TYPE_UNSPECIFIED:
            return "WELL_KNOWN_TYPE_UNSPECIFIED";
        case Type_WellKnownType.ANY:
            return "ANY";
        case Type_WellKnownType.TIMESTAMP:
            return "TIMESTAMP";
        case Type_WellKnownType.DURATION:
            return "DURATION";
        case Type_WellKnownType.UNRECOGNIZED:
        default:
            return "UNRECOGNIZED";
    }
}
function createBaseCheckedExpr_ReferenceMapEntry() {
    return {
        key: BigInt(0),
        value: undefined
    };
}
exports.CheckedExpr_ReferenceMapEntry = {
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.key !== BigInt(0)) {
            writer.uint32(8).int64(message.key);
        }
        if (message.value !== undefined) {
            exports.Reference.encode(message.value, writer.uint32(18).fork()).ldelim();
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseCheckedExpr_ReferenceMapEntry();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.key = reader.int64();
                    break;
                case 2:
                    message.value = exports.Reference.decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseCheckedExpr_ReferenceMapEntry();
        message.key = object.key !== undefined && object.key !== null ? BigInt(object.key.toString()) : BigInt(0);
        message.value = object.value !== undefined && object.value !== null ? exports.Reference.fromPartial(object.value) : undefined;
        return message;
    },
    fromAmino(object) {
        const message = createBaseCheckedExpr_ReferenceMapEntry();
        if (object.key !== undefined && object.key !== null) {
            message.key = BigInt(object.key);
        }
        if (object.value !== undefined && object.value !== null) {
            message.value = exports.Reference.fromAmino(object.value);
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.key = message.key !== BigInt(0) ? message.key?.toString() : undefined;
        obj.value = message.value ? exports.Reference.toAmino(message.value) : undefined;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.CheckedExpr_ReferenceMapEntry.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.CheckedExpr_ReferenceMapEntry.decode(message.value);
    },
    toProto(message) {
        return exports.CheckedExpr_ReferenceMapEntry.encode(message).finish();
    }
};
function createBaseCheckedExpr_TypeMapEntry() {
    return {
        key: BigInt(0),
        value: undefined
    };
}
exports.CheckedExpr_TypeMapEntry = {
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.key !== BigInt(0)) {
            writer.uint32(8).int64(message.key);
        }
        if (message.value !== undefined) {
            exports.Type.encode(message.value, writer.uint32(18).fork()).ldelim();
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseCheckedExpr_TypeMapEntry();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.key = reader.int64();
                    break;
                case 2:
                    message.value = exports.Type.decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseCheckedExpr_TypeMapEntry();
        message.key = object.key !== undefined && object.key !== null ? BigInt(object.key.toString()) : BigInt(0);
        message.value = object.value !== undefined && object.value !== null ? exports.Type.fromPartial(object.value) : undefined;
        return message;
    },
    fromAmino(object) {
        const message = createBaseCheckedExpr_TypeMapEntry();
        if (object.key !== undefined && object.key !== null) {
            message.key = BigInt(object.key);
        }
        if (object.value !== undefined && object.value !== null) {
            message.value = exports.Type.fromAmino(object.value);
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.key = message.key !== BigInt(0) ? message.key?.toString() : undefined;
        obj.value = message.value ? exports.Type.toAmino(message.value) : undefined;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.CheckedExpr_TypeMapEntry.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.CheckedExpr_TypeMapEntry.decode(message.value);
    },
    toProto(message) {
        return exports.CheckedExpr_TypeMapEntry.encode(message).finish();
    }
};
function createBaseCheckedExpr() {
    return {
        referenceMap: {},
        typeMap: {},
        sourceInfo: undefined,
        exprVersion: "",
        expr: undefined
    };
}
exports.CheckedExpr = {
    typeUrl: "/google.api.expr.v1alpha1.CheckedExpr",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        Object.entries(message.referenceMap).forEach(([key, value]) => {
            exports.CheckedExpr_ReferenceMapEntry.encode({
                key: key,
                value
            }, writer.uint32(18).fork()).ldelim();
        });
        Object.entries(message.typeMap).forEach(([key, value]) => {
            exports.CheckedExpr_TypeMapEntry.encode({
                key: key,
                value
            }, writer.uint32(26).fork()).ldelim();
        });
        if (message.sourceInfo !== undefined) {
            syntax_1.SourceInfo.encode(message.sourceInfo, writer.uint32(42).fork()).ldelim();
        }
        if (message.exprVersion !== "") {
            writer.uint32(50).string(message.exprVersion);
        }
        if (message.expr !== undefined) {
            syntax_1.Expr.encode(message.expr, writer.uint32(34).fork()).ldelim();
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseCheckedExpr();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 2:
                    const entry2 = exports.CheckedExpr_ReferenceMapEntry.decode(reader, reader.uint32());
                    if (entry2.value !== undefined) {
                        message.referenceMap[entry2.key] = entry2.value;
                    }
                    break;
                case 3:
                    const entry3 = exports.CheckedExpr_TypeMapEntry.decode(reader, reader.uint32());
                    if (entry3.value !== undefined) {
                        message.typeMap[entry3.key] = entry3.value;
                    }
                    break;
                case 5:
                    message.sourceInfo = syntax_1.SourceInfo.decode(reader, reader.uint32());
                    break;
                case 6:
                    message.exprVersion = reader.string();
                    break;
                case 4:
                    message.expr = syntax_1.Expr.decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseCheckedExpr();
        message.referenceMap = Object.entries(object.referenceMap ?? {}).reduce((acc, [key, value]) => {
            if (value !== undefined) {
                acc[Number(key)] = exports.Reference.fromPartial(value);
            }
            return acc;
        }, {});
        message.typeMap = Object.entries(object.typeMap ?? {}).reduce((acc, [key, value]) => {
            if (value !== undefined) {
                acc[Number(key)] = exports.Type.fromPartial(value);
            }
            return acc;
        }, {});
        message.sourceInfo = object.sourceInfo !== undefined && object.sourceInfo !== null ? syntax_1.SourceInfo.fromPartial(object.sourceInfo) : undefined;
        message.exprVersion = object.exprVersion ?? "";
        message.expr = object.expr !== undefined && object.expr !== null ? syntax_1.Expr.fromPartial(object.expr) : undefined;
        return message;
    },
    fromAmino(object) {
        const message = createBaseCheckedExpr();
        message.referenceMap = Object.entries(object.reference_map ?? {}).reduce((acc, [key, value]) => {
            if (value !== undefined) {
                acc[Number(key)] = exports.Reference.fromAmino(value);
            }
            return acc;
        }, {});
        message.typeMap = Object.entries(object.type_map ?? {}).reduce((acc, [key, value]) => {
            if (value !== undefined) {
                acc[Number(key)] = exports.Type.fromAmino(value);
            }
            return acc;
        }, {});
        if (object.source_info !== undefined && object.source_info !== null) {
            message.sourceInfo = syntax_1.SourceInfo.fromAmino(object.source_info);
        }
        if (object.expr_version !== undefined && object.expr_version !== null) {
            message.exprVersion = object.expr_version;
        }
        if (object.expr !== undefined && object.expr !== null) {
            message.expr = syntax_1.Expr.fromAmino(object.expr);
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.reference_map = {};
        if (message.referenceMap) {
            Object.entries(message.referenceMap).forEach(([k, v]) => {
                obj.reference_map[k] = exports.Reference.toAmino(v);
            });
        }
        obj.type_map = {};
        if (message.typeMap) {
            Object.entries(message.typeMap).forEach(([k, v]) => {
                obj.type_map[k] = exports.Type.toAmino(v);
            });
        }
        obj.source_info = message.sourceInfo ? syntax_1.SourceInfo.toAmino(message.sourceInfo) : undefined;
        obj.expr_version = message.exprVersion === "" ? undefined : message.exprVersion;
        obj.expr = message.expr ? syntax_1.Expr.toAmino(message.expr) : undefined;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.CheckedExpr.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.CheckedExpr.decode(message.value);
    },
    toProto(message) {
        return exports.CheckedExpr.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.expr.v1alpha1.CheckedExpr",
            value: exports.CheckedExpr.encode(message).finish()
        };
    }
};
function createBaseType() {
    return {
        dyn: undefined,
        null: undefined,
        primitive: undefined,
        wrapper: undefined,
        wellKnown: undefined,
        listType: undefined,
        mapType: undefined,
        function: undefined,
        messageType: undefined,
        typeParam: undefined,
        type: undefined,
        error: undefined,
        abstractType: undefined
    };
}
exports.Type = {
    typeUrl: "/google.api.expr.v1alpha1.Type",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.dyn !== undefined) {
            empty_1.Empty.encode(message.dyn, writer.uint32(10).fork()).ldelim();
        }
        if (message.null !== undefined) {
            writer.uint32(16).int32(message.null);
        }
        if (message.primitive !== undefined) {
            writer.uint32(24).int32(message.primitive);
        }
        if (message.wrapper !== undefined) {
            writer.uint32(32).int32(message.wrapper);
        }
        if (message.wellKnown !== undefined) {
            writer.uint32(40).int32(message.wellKnown);
        }
        if (message.listType !== undefined) {
            exports.Type_ListType.encode(message.listType, writer.uint32(50).fork()).ldelim();
        }
        if (message.mapType !== undefined) {
            exports.Type_MapType.encode(message.mapType, writer.uint32(58).fork()).ldelim();
        }
        if (message.function !== undefined) {
            exports.Type_FunctionType.encode(message.function, writer.uint32(66).fork()).ldelim();
        }
        if (message.messageType !== undefined) {
            writer.uint32(74).string(message.messageType);
        }
        if (message.typeParam !== undefined) {
            writer.uint32(82).string(message.typeParam);
        }
        if (message.type !== undefined) {
            exports.Type.encode(message.type, writer.uint32(90).fork()).ldelim();
        }
        if (message.error !== undefined) {
            empty_1.Empty.encode(message.error, writer.uint32(98).fork()).ldelim();
        }
        if (message.abstractType !== undefined) {
            exports.Type_AbstractType.encode(message.abstractType, writer.uint32(114).fork()).ldelim();
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseType();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.dyn = empty_1.Empty.decode(reader, reader.uint32());
                    break;
                case 2:
                    message.null = reader.int32();
                    break;
                case 3:
                    message.primitive = reader.int32();
                    break;
                case 4:
                    message.wrapper = reader.int32();
                    break;
                case 5:
                    message.wellKnown = reader.int32();
                    break;
                case 6:
                    message.listType = exports.Type_ListType.decode(reader, reader.uint32());
                    break;
                case 7:
                    message.mapType = exports.Type_MapType.decode(reader, reader.uint32());
                    break;
                case 8:
                    message.function = exports.Type_FunctionType.decode(reader, reader.uint32());
                    break;
                case 9:
                    message.messageType = reader.string();
                    break;
                case 10:
                    message.typeParam = reader.string();
                    break;
                case 11:
                    message.type = exports.Type.decode(reader, reader.uint32());
                    break;
                case 12:
                    message.error = empty_1.Empty.decode(reader, reader.uint32());
                    break;
                case 14:
                    message.abstractType = exports.Type_AbstractType.decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseType();
        message.dyn = object.dyn !== undefined && object.dyn !== null ? empty_1.Empty.fromPartial(object.dyn) : undefined;
        message.null = object.null ?? undefined;
        message.primitive = object.primitive ?? undefined;
        message.wrapper = object.wrapper ?? undefined;
        message.wellKnown = object.wellKnown ?? undefined;
        message.listType = object.listType !== undefined && object.listType !== null ? exports.Type_ListType.fromPartial(object.listType) : undefined;
        message.mapType = object.mapType !== undefined && object.mapType !== null ? exports.Type_MapType.fromPartial(object.mapType) : undefined;
        message.function = object.function !== undefined && object.function !== null ? exports.Type_FunctionType.fromPartial(object.function) : undefined;
        message.messageType = object.messageType ?? undefined;
        message.typeParam = object.typeParam ?? undefined;
        message.type = object.type !== undefined && object.type !== null ? exports.Type.fromPartial(object.type) : undefined;
        message.error = object.error !== undefined && object.error !== null ? empty_1.Empty.fromPartial(object.error) : undefined;
        message.abstractType = object.abstractType !== undefined && object.abstractType !== null ? exports.Type_AbstractType.fromPartial(object.abstractType) : undefined;
        return message;
    },
    fromAmino(object) {
        const message = createBaseType();
        if (object.dyn !== undefined && object.dyn !== null) {
            message.dyn = empty_1.Empty.fromAmino(object.dyn);
        }
        if (object.null !== undefined && object.null !== null) {
            message.null = object.null;
        }
        if (object.primitive !== undefined && object.primitive !== null) {
            message.primitive = object.primitive;
        }
        if (object.wrapper !== undefined && object.wrapper !== null) {
            message.wrapper = object.wrapper;
        }
        if (object.well_known !== undefined && object.well_known !== null) {
            message.wellKnown = object.well_known;
        }
        if (object.list_type !== undefined && object.list_type !== null) {
            message.listType = exports.Type_ListType.fromAmino(object.list_type);
        }
        if (object.map_type !== undefined && object.map_type !== null) {
            message.mapType = exports.Type_MapType.fromAmino(object.map_type);
        }
        if (object.function !== undefined && object.function !== null) {
            message.function = exports.Type_FunctionType.fromAmino(object.function);
        }
        if (object.message_type !== undefined && object.message_type !== null) {
            message.messageType = object.message_type;
        }
        if (object.type_param !== undefined && object.type_param !== null) {
            message.typeParam = object.type_param;
        }
        if (object.type !== undefined && object.type !== null) {
            message.type = exports.Type.fromAmino(object.type);
        }
        if (object.error !== undefined && object.error !== null) {
            message.error = empty_1.Empty.fromAmino(object.error);
        }
        if (object.abstract_type !== undefined && object.abstract_type !== null) {
            message.abstractType = exports.Type_AbstractType.fromAmino(object.abstract_type);
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.dyn = message.dyn ? empty_1.Empty.toAmino(message.dyn) : undefined;
        obj.null = message.null === null ? undefined : message.null;
        obj.primitive = message.primitive === null ? undefined : message.primitive;
        obj.wrapper = message.wrapper === null ? undefined : message.wrapper;
        obj.well_known = message.wellKnown === null ? undefined : message.wellKnown;
        obj.list_type = message.listType ? exports.Type_ListType.toAmino(message.listType) : undefined;
        obj.map_type = message.mapType ? exports.Type_MapType.toAmino(message.mapType) : undefined;
        obj.function = message.function ? exports.Type_FunctionType.toAmino(message.function) : undefined;
        obj.message_type = message.messageType === null ? undefined : message.messageType;
        obj.type_param = message.typeParam === null ? undefined : message.typeParam;
        obj.type = message.type ? exports.Type.toAmino(message.type) : undefined;
        obj.error = message.error ? empty_1.Empty.toAmino(message.error) : undefined;
        obj.abstract_type = message.abstractType ? exports.Type_AbstractType.toAmino(message.abstractType) : undefined;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.Type.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.Type.decode(message.value);
    },
    toProto(message) {
        return exports.Type.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.expr.v1alpha1.Type",
            value: exports.Type.encode(message).finish()
        };
    }
};
function createBaseType_ListType() {
    return {
        elemType: undefined
    };
}
exports.Type_ListType = {
    typeUrl: "/google.api.expr.v1alpha1.ListType",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.elemType !== undefined) {
            exports.Type.encode(message.elemType, writer.uint32(10).fork()).ldelim();
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseType_ListType();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.elemType = exports.Type.decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseType_ListType();
        message.elemType = object.elemType !== undefined && object.elemType !== null ? exports.Type.fromPartial(object.elemType) : undefined;
        return message;
    },
    fromAmino(object) {
        const message = createBaseType_ListType();
        if (object.elem_type !== undefined && object.elem_type !== null) {
            message.elemType = exports.Type.fromAmino(object.elem_type);
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.elem_type = message.elemType ? exports.Type.toAmino(message.elemType) : undefined;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.Type_ListType.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.Type_ListType.decode(message.value);
    },
    toProto(message) {
        return exports.Type_ListType.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.expr.v1alpha1.ListType",
            value: exports.Type_ListType.encode(message).finish()
        };
    }
};
function createBaseType_MapType() {
    return {
        keyType: undefined,
        valueType: undefined
    };
}
exports.Type_MapType = {
    typeUrl: "/google.api.expr.v1alpha1.MapType",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.keyType !== undefined) {
            exports.Type.encode(message.keyType, writer.uint32(10).fork()).ldelim();
        }
        if (message.valueType !== undefined) {
            exports.Type.encode(message.valueType, writer.uint32(18).fork()).ldelim();
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseType_MapType();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.keyType = exports.Type.decode(reader, reader.uint32());
                    break;
                case 2:
                    message.valueType = exports.Type.decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseType_MapType();
        message.keyType = object.keyType !== undefined && object.keyType !== null ? exports.Type.fromPartial(object.keyType) : undefined;
        message.valueType = object.valueType !== undefined && object.valueType !== null ? exports.Type.fromPartial(object.valueType) : undefined;
        return message;
    },
    fromAmino(object) {
        const message = createBaseType_MapType();
        if (object.key_type !== undefined && object.key_type !== null) {
            message.keyType = exports.Type.fromAmino(object.key_type);
        }
        if (object.value_type !== undefined && object.value_type !== null) {
            message.valueType = exports.Type.fromAmino(object.value_type);
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.key_type = message.keyType ? exports.Type.toAmino(message.keyType) : undefined;
        obj.value_type = message.valueType ? exports.Type.toAmino(message.valueType) : undefined;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.Type_MapType.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.Type_MapType.decode(message.value);
    },
    toProto(message) {
        return exports.Type_MapType.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.expr.v1alpha1.MapType",
            value: exports.Type_MapType.encode(message).finish()
        };
    }
};
function createBaseType_FunctionType() {
    return {
        resultType: undefined,
        argTypes: []
    };
}
exports.Type_FunctionType = {
    typeUrl: "/google.api.expr.v1alpha1.FunctionType",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.resultType !== undefined) {
            exports.Type.encode(message.resultType, writer.uint32(10).fork()).ldelim();
        }
        for (const v of message.argTypes) {
            exports.Type.encode(v, writer.uint32(18).fork()).ldelim();
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseType_FunctionType();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.resultType = exports.Type.decode(reader, reader.uint32());
                    break;
                case 2:
                    message.argTypes.push(exports.Type.decode(reader, reader.uint32()));
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseType_FunctionType();
        message.resultType = object.resultType !== undefined && object.resultType !== null ? exports.Type.fromPartial(object.resultType) : undefined;
        message.argTypes = object.argTypes?.map(e => exports.Type.fromPartial(e)) || [];
        return message;
    },
    fromAmino(object) {
        const message = createBaseType_FunctionType();
        if (object.result_type !== undefined && object.result_type !== null) {
            message.resultType = exports.Type.fromAmino(object.result_type);
        }
        message.argTypes = object.arg_types?.map(e => exports.Type.fromAmino(e)) || [];
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.result_type = message.resultType ? exports.Type.toAmino(message.resultType) : undefined;
        if (message.argTypes) {
            obj.arg_types = message.argTypes.map(e => e ? exports.Type.toAmino(e) : undefined);
        }
        else {
            obj.arg_types = message.argTypes;
        }
        return obj;
    },
    fromAminoMsg(object) {
        return exports.Type_FunctionType.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.Type_FunctionType.decode(message.value);
    },
    toProto(message) {
        return exports.Type_FunctionType.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.expr.v1alpha1.FunctionType",
            value: exports.Type_FunctionType.encode(message).finish()
        };
    }
};
function createBaseType_AbstractType() {
    return {
        name: "",
        parameterTypes: []
    };
}
exports.Type_AbstractType = {
    typeUrl: "/google.api.expr.v1alpha1.AbstractType",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.name !== "") {
            writer.uint32(10).string(message.name);
        }
        for (const v of message.parameterTypes) {
            exports.Type.encode(v, writer.uint32(18).fork()).ldelim();
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseType_AbstractType();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.name = reader.string();
                    break;
                case 2:
                    message.parameterTypes.push(exports.Type.decode(reader, reader.uint32()));
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseType_AbstractType();
        message.name = object.name ?? "";
        message.parameterTypes = object.parameterTypes?.map(e => exports.Type.fromPartial(e)) || [];
        return message;
    },
    fromAmino(object) {
        const message = createBaseType_AbstractType();
        if (object.name !== undefined && object.name !== null) {
            message.name = object.name;
        }
        message.parameterTypes = object.parameter_types?.map(e => exports.Type.fromAmino(e)) || [];
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.name = message.name === "" ? undefined : message.name;
        if (message.parameterTypes) {
            obj.parameter_types = message.parameterTypes.map(e => e ? exports.Type.toAmino(e) : undefined);
        }
        else {
            obj.parameter_types = message.parameterTypes;
        }
        return obj;
    },
    fromAminoMsg(object) {
        return exports.Type_AbstractType.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.Type_AbstractType.decode(message.value);
    },
    toProto(message) {
        return exports.Type_AbstractType.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.expr.v1alpha1.AbstractType",
            value: exports.Type_AbstractType.encode(message).finish()
        };
    }
};
function createBaseDecl() {
    return {
        name: "",
        ident: undefined,
        function: undefined
    };
}
exports.Decl = {
    typeUrl: "/google.api.expr.v1alpha1.Decl",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.name !== "") {
            writer.uint32(10).string(message.name);
        }
        if (message.ident !== undefined) {
            exports.Decl_IdentDecl.encode(message.ident, writer.uint32(18).fork()).ldelim();
        }
        if (message.function !== undefined) {
            exports.Decl_FunctionDecl.encode(message.function, writer.uint32(26).fork()).ldelim();
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseDecl();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.name = reader.string();
                    break;
                case 2:
                    message.ident = exports.Decl_IdentDecl.decode(reader, reader.uint32());
                    break;
                case 3:
                    message.function = exports.Decl_FunctionDecl.decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseDecl();
        message.name = object.name ?? "";
        message.ident = object.ident !== undefined && object.ident !== null ? exports.Decl_IdentDecl.fromPartial(object.ident) : undefined;
        message.function = object.function !== undefined && object.function !== null ? exports.Decl_FunctionDecl.fromPartial(object.function) : undefined;
        return message;
    },
    fromAmino(object) {
        const message = createBaseDecl();
        if (object.name !== undefined && object.name !== null) {
            message.name = object.name;
        }
        if (object.ident !== undefined && object.ident !== null) {
            message.ident = exports.Decl_IdentDecl.fromAmino(object.ident);
        }
        if (object.function !== undefined && object.function !== null) {
            message.function = exports.Decl_FunctionDecl.fromAmino(object.function);
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.name = message.name === "" ? undefined : message.name;
        obj.ident = message.ident ? exports.Decl_IdentDecl.toAmino(message.ident) : undefined;
        obj.function = message.function ? exports.Decl_FunctionDecl.toAmino(message.function) : undefined;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.Decl.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.Decl.decode(message.value);
    },
    toProto(message) {
        return exports.Decl.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.expr.v1alpha1.Decl",
            value: exports.Decl.encode(message).finish()
        };
    }
};
function createBaseDecl_IdentDecl() {
    return {
        type: undefined,
        value: undefined,
        doc: ""
    };
}
exports.Decl_IdentDecl = {
    typeUrl: "/google.api.expr.v1alpha1.IdentDecl",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.type !== undefined) {
            exports.Type.encode(message.type, writer.uint32(10).fork()).ldelim();
        }
        if (message.value !== undefined) {
            syntax_1.Constant.encode(message.value, writer.uint32(18).fork()).ldelim();
        }
        if (message.doc !== "") {
            writer.uint32(26).string(message.doc);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseDecl_IdentDecl();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.type = exports.Type.decode(reader, reader.uint32());
                    break;
                case 2:
                    message.value = syntax_1.Constant.decode(reader, reader.uint32());
                    break;
                case 3:
                    message.doc = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseDecl_IdentDecl();
        message.type = object.type !== undefined && object.type !== null ? exports.Type.fromPartial(object.type) : undefined;
        message.value = object.value !== undefined && object.value !== null ? syntax_1.Constant.fromPartial(object.value) : undefined;
        message.doc = object.doc ?? "";
        return message;
    },
    fromAmino(object) {
        const message = createBaseDecl_IdentDecl();
        if (object.type !== undefined && object.type !== null) {
            message.type = exports.Type.fromAmino(object.type);
        }
        if (object.value !== undefined && object.value !== null) {
            message.value = syntax_1.Constant.fromAmino(object.value);
        }
        if (object.doc !== undefined && object.doc !== null) {
            message.doc = object.doc;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.type = message.type ? exports.Type.toAmino(message.type) : undefined;
        obj.value = message.value ? syntax_1.Constant.toAmino(message.value) : undefined;
        obj.doc = message.doc === "" ? undefined : message.doc;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.Decl_IdentDecl.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.Decl_IdentDecl.decode(message.value);
    },
    toProto(message) {
        return exports.Decl_IdentDecl.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.expr.v1alpha1.IdentDecl",
            value: exports.Decl_IdentDecl.encode(message).finish()
        };
    }
};
function createBaseDecl_FunctionDecl() {
    return {
        overloads: []
    };
}
exports.Decl_FunctionDecl = {
    typeUrl: "/google.api.expr.v1alpha1.FunctionDecl",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        for (const v of message.overloads) {
            exports.Decl_FunctionDecl_Overload.encode(v, writer.uint32(10).fork()).ldelim();
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseDecl_FunctionDecl();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.overloads.push(exports.Decl_FunctionDecl_Overload.decode(reader, reader.uint32()));
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseDecl_FunctionDecl();
        message.overloads = object.overloads?.map(e => exports.Decl_FunctionDecl_Overload.fromPartial(e)) || [];
        return message;
    },
    fromAmino(object) {
        const message = createBaseDecl_FunctionDecl();
        message.overloads = object.overloads?.map(e => exports.Decl_FunctionDecl_Overload.fromAmino(e)) || [];
        return message;
    },
    toAmino(message) {
        const obj = {};
        if (message.overloads) {
            obj.overloads = message.overloads.map(e => e ? exports.Decl_FunctionDecl_Overload.toAmino(e) : undefined);
        }
        else {
            obj.overloads = message.overloads;
        }
        return obj;
    },
    fromAminoMsg(object) {
        return exports.Decl_FunctionDecl.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.Decl_FunctionDecl.decode(message.value);
    },
    toProto(message) {
        return exports.Decl_FunctionDecl.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.expr.v1alpha1.FunctionDecl",
            value: exports.Decl_FunctionDecl.encode(message).finish()
        };
    }
};
function createBaseDecl_FunctionDecl_Overload() {
    return {
        overloadId: "",
        params: [],
        typeParams: [],
        resultType: undefined,
        isInstanceFunction: false,
        doc: ""
    };
}
exports.Decl_FunctionDecl_Overload = {
    typeUrl: "/google.api.expr.v1alpha1.Overload",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.overloadId !== "") {
            writer.uint32(10).string(message.overloadId);
        }
        for (const v of message.params) {
            exports.Type.encode(v, writer.uint32(18).fork()).ldelim();
        }
        for (const v of message.typeParams) {
            writer.uint32(26).string(v);
        }
        if (message.resultType !== undefined) {
            exports.Type.encode(message.resultType, writer.uint32(34).fork()).ldelim();
        }
        if (message.isInstanceFunction === true) {
            writer.uint32(40).bool(message.isInstanceFunction);
        }
        if (message.doc !== "") {
            writer.uint32(50).string(message.doc);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseDecl_FunctionDecl_Overload();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.overloadId = reader.string();
                    break;
                case 2:
                    message.params.push(exports.Type.decode(reader, reader.uint32()));
                    break;
                case 3:
                    message.typeParams.push(reader.string());
                    break;
                case 4:
                    message.resultType = exports.Type.decode(reader, reader.uint32());
                    break;
                case 5:
                    message.isInstanceFunction = reader.bool();
                    break;
                case 6:
                    message.doc = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseDecl_FunctionDecl_Overload();
        message.overloadId = object.overloadId ?? "";
        message.params = object.params?.map(e => exports.Type.fromPartial(e)) || [];
        message.typeParams = object.typeParams?.map(e => e) || [];
        message.resultType = object.resultType !== undefined && object.resultType !== null ? exports.Type.fromPartial(object.resultType) : undefined;
        message.isInstanceFunction = object.isInstanceFunction ?? false;
        message.doc = object.doc ?? "";
        return message;
    },
    fromAmino(object) {
        const message = createBaseDecl_FunctionDecl_Overload();
        if (object.overload_id !== undefined && object.overload_id !== null) {
            message.overloadId = object.overload_id;
        }
        message.params = object.params?.map(e => exports.Type.fromAmino(e)) || [];
        message.typeParams = object.type_params?.map(e => e) || [];
        if (object.result_type !== undefined && object.result_type !== null) {
            message.resultType = exports.Type.fromAmino(object.result_type);
        }
        if (object.is_instance_function !== undefined && object.is_instance_function !== null) {
            message.isInstanceFunction = object.is_instance_function;
        }
        if (object.doc !== undefined && object.doc !== null) {
            message.doc = object.doc;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.overload_id = message.overloadId === "" ? undefined : message.overloadId;
        if (message.params) {
            obj.params = message.params.map(e => e ? exports.Type.toAmino(e) : undefined);
        }
        else {
            obj.params = message.params;
        }
        if (message.typeParams) {
            obj.type_params = message.typeParams.map(e => e);
        }
        else {
            obj.type_params = message.typeParams;
        }
        obj.result_type = message.resultType ? exports.Type.toAmino(message.resultType) : undefined;
        obj.is_instance_function = message.isInstanceFunction === false ? undefined : message.isInstanceFunction;
        obj.doc = message.doc === "" ? undefined : message.doc;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.Decl_FunctionDecl_Overload.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.Decl_FunctionDecl_Overload.decode(message.value);
    },
    toProto(message) {
        return exports.Decl_FunctionDecl_Overload.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.expr.v1alpha1.Overload",
            value: exports.Decl_FunctionDecl_Overload.encode(message).finish()
        };
    }
};
function createBaseReference() {
    return {
        name: "",
        overloadId: [],
        value: undefined
    };
}
exports.Reference = {
    typeUrl: "/google.api.expr.v1alpha1.Reference",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.name !== "") {
            writer.uint32(10).string(message.name);
        }
        for (const v of message.overloadId) {
            writer.uint32(26).string(v);
        }
        if (message.value !== undefined) {
            syntax_1.Constant.encode(message.value, writer.uint32(34).fork()).ldelim();
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseReference();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.name = reader.string();
                    break;
                case 3:
                    message.overloadId.push(reader.string());
                    break;
                case 4:
                    message.value = syntax_1.Constant.decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseReference();
        message.name = object.name ?? "";
        message.overloadId = object.overloadId?.map(e => e) || [];
        message.value = object.value !== undefined && object.value !== null ? syntax_1.Constant.fromPartial(object.value) : undefined;
        return message;
    },
    fromAmino(object) {
        const message = createBaseReference();
        if (object.name !== undefined && object.name !== null) {
            message.name = object.name;
        }
        message.overloadId = object.overload_id?.map(e => e) || [];
        if (object.value !== undefined && object.value !== null) {
            message.value = syntax_1.Constant.fromAmino(object.value);
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.name = message.name === "" ? undefined : message.name;
        if (message.overloadId) {
            obj.overload_id = message.overloadId.map(e => e);
        }
        else {
            obj.overload_id = message.overloadId;
        }
        obj.value = message.value ? syntax_1.Constant.toAmino(message.value) : undefined;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.Reference.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.Reference.decode(message.value);
    },
    toProto(message) {
        return exports.Reference.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.expr.v1alpha1.Reference",
            value: exports.Reference.encode(message).finish()
        };
    }
};
