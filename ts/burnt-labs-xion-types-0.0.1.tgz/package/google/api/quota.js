"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.QuotaLimit = exports.QuotaLimit_ValuesEntry = exports.MetricRule = exports.MetricRule_MetricCostsEntry = exports.Quota = void 0;
//@ts-nocheck
const binary_1 = require("../../binary");
function createBaseQuota() {
    return {
        limits: [],
        metricRules: []
    };
}
exports.Quota = {
    typeUrl: "/google.api.Quota",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        for (const v of message.limits) {
            exports.QuotaLimit.encode(v, writer.uint32(26).fork()).ldelim();
        }
        for (const v of message.metricRules) {
            exports.MetricRule.encode(v, writer.uint32(34).fork()).ldelim();
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseQuota();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 3:
                    message.limits.push(exports.QuotaLimit.decode(reader, reader.uint32()));
                    break;
                case 4:
                    message.metricRules.push(exports.MetricRule.decode(reader, reader.uint32()));
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseQuota();
        message.limits = object.limits?.map(e => exports.QuotaLimit.fromPartial(e)) || [];
        message.metricRules = object.metricRules?.map(e => exports.MetricRule.fromPartial(e)) || [];
        return message;
    },
    fromAmino(object) {
        const message = createBaseQuota();
        message.limits = object.limits?.map(e => exports.QuotaLimit.fromAmino(e)) || [];
        message.metricRules = object.metric_rules?.map(e => exports.MetricRule.fromAmino(e)) || [];
        return message;
    },
    toAmino(message) {
        const obj = {};
        if (message.limits) {
            obj.limits = message.limits.map(e => e ? exports.QuotaLimit.toAmino(e) : undefined);
        }
        else {
            obj.limits = message.limits;
        }
        if (message.metricRules) {
            obj.metric_rules = message.metricRules.map(e => e ? exports.MetricRule.toAmino(e) : undefined);
        }
        else {
            obj.metric_rules = message.metricRules;
        }
        return obj;
    },
    fromAminoMsg(object) {
        return exports.Quota.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.Quota.decode(message.value);
    },
    toProto(message) {
        return exports.Quota.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.Quota",
            value: exports.Quota.encode(message).finish()
        };
    }
};
function createBaseMetricRule_MetricCostsEntry() {
    return {
        key: "",
        value: BigInt(0)
    };
}
exports.MetricRule_MetricCostsEntry = {
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.key !== "") {
            writer.uint32(10).string(message.key);
        }
        if (message.value !== BigInt(0)) {
            writer.uint32(16).int64(message.value);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseMetricRule_MetricCostsEntry();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.key = reader.string();
                    break;
                case 2:
                    message.value = reader.int64();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseMetricRule_MetricCostsEntry();
        message.key = object.key ?? "";
        message.value = object.value !== undefined && object.value !== null ? BigInt(object.value.toString()) : BigInt(0);
        return message;
    },
    fromAmino(object) {
        const message = createBaseMetricRule_MetricCostsEntry();
        if (object.key !== undefined && object.key !== null) {
            message.key = object.key;
        }
        if (object.value !== undefined && object.value !== null) {
            message.value = BigInt(object.value);
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.key = message.key === "" ? undefined : message.key;
        obj.value = message.value !== BigInt(0) ? message.value?.toString() : undefined;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.MetricRule_MetricCostsEntry.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.MetricRule_MetricCostsEntry.decode(message.value);
    },
    toProto(message) {
        return exports.MetricRule_MetricCostsEntry.encode(message).finish();
    }
};
function createBaseMetricRule() {
    return {
        selector: "",
        metricCosts: {}
    };
}
exports.MetricRule = {
    typeUrl: "/google.api.MetricRule",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.selector !== "") {
            writer.uint32(10).string(message.selector);
        }
        Object.entries(message.metricCosts).forEach(([key, value]) => {
            exports.MetricRule_MetricCostsEntry.encode({
                key: key,
                value
            }, writer.uint32(16).fork()).ldelim();
        });
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseMetricRule();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.selector = reader.string();
                    break;
                case 2:
                    const entry2 = exports.MetricRule_MetricCostsEntry.decode(reader, reader.uint32());
                    if (entry2.value !== undefined) {
                        message.metricCosts[entry2.key] = entry2.value;
                    }
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseMetricRule();
        message.selector = object.selector ?? "";
        message.metricCosts = Object.entries(object.metricCosts ?? {}).reduce((acc, [key, value]) => {
            if (value !== undefined) {
                acc[key] = BigInt(value.toString());
            }
            return acc;
        }, {});
        return message;
    },
    fromAmino(object) {
        const message = createBaseMetricRule();
        if (object.selector !== undefined && object.selector !== null) {
            message.selector = object.selector;
        }
        message.metricCosts = Object.entries(object.metric_costs ?? {}).reduce((acc, [key, value]) => {
            if (value !== undefined) {
                acc[key] = BigInt(value.toString());
            }
            return acc;
        }, {});
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.selector = message.selector === "" ? undefined : message.selector;
        obj.metric_costs = {};
        if (message.metricCosts) {
            Object.entries(message.metricCosts).forEach(([k, v]) => {
                obj.metric_costs[k] = v.toString();
            });
        }
        return obj;
    },
    fromAminoMsg(object) {
        return exports.MetricRule.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.MetricRule.decode(message.value);
    },
    toProto(message) {
        return exports.MetricRule.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.MetricRule",
            value: exports.MetricRule.encode(message).finish()
        };
    }
};
function createBaseQuotaLimit_ValuesEntry() {
    return {
        key: "",
        value: BigInt(0)
    };
}
exports.QuotaLimit_ValuesEntry = {
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.key !== "") {
            writer.uint32(10).string(message.key);
        }
        if (message.value !== BigInt(0)) {
            writer.uint32(16).int64(message.value);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseQuotaLimit_ValuesEntry();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.key = reader.string();
                    break;
                case 2:
                    message.value = reader.int64();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseQuotaLimit_ValuesEntry();
        message.key = object.key ?? "";
        message.value = object.value !== undefined && object.value !== null ? BigInt(object.value.toString()) : BigInt(0);
        return message;
    },
    fromAmino(object) {
        const message = createBaseQuotaLimit_ValuesEntry();
        if (object.key !== undefined && object.key !== null) {
            message.key = object.key;
        }
        if (object.value !== undefined && object.value !== null) {
            message.value = BigInt(object.value);
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.key = message.key === "" ? undefined : message.key;
        obj.value = message.value !== BigInt(0) ? message.value?.toString() : undefined;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.QuotaLimit_ValuesEntry.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.QuotaLimit_ValuesEntry.decode(message.value);
    },
    toProto(message) {
        return exports.QuotaLimit_ValuesEntry.encode(message).finish();
    }
};
function createBaseQuotaLimit() {
    return {
        name: "",
        description: "",
        defaultLimit: BigInt(0),
        maxLimit: BigInt(0),
        freeTier: BigInt(0),
        duration: "",
        metric: "",
        unit: "",
        values: {},
        displayName: ""
    };
}
exports.QuotaLimit = {
    typeUrl: "/google.api.QuotaLimit",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.name !== "") {
            writer.uint32(50).string(message.name);
        }
        if (message.description !== "") {
            writer.uint32(18).string(message.description);
        }
        if (message.defaultLimit !== BigInt(0)) {
            writer.uint32(24).int64(message.defaultLimit);
        }
        if (message.maxLimit !== BigInt(0)) {
            writer.uint32(32).int64(message.maxLimit);
        }
        if (message.freeTier !== BigInt(0)) {
            writer.uint32(56).int64(message.freeTier);
        }
        if (message.duration !== "") {
            writer.uint32(42).string(message.duration);
        }
        if (message.metric !== "") {
            writer.uint32(66).string(message.metric);
        }
        if (message.unit !== "") {
            writer.uint32(74).string(message.unit);
        }
        Object.entries(message.values).forEach(([key, value]) => {
            exports.QuotaLimit_ValuesEntry.encode({
                key: key,
                value
            }, writer.uint32(80).fork()).ldelim();
        });
        if (message.displayName !== "") {
            writer.uint32(98).string(message.displayName);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseQuotaLimit();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 6:
                    message.name = reader.string();
                    break;
                case 2:
                    message.description = reader.string();
                    break;
                case 3:
                    message.defaultLimit = reader.int64();
                    break;
                case 4:
                    message.maxLimit = reader.int64();
                    break;
                case 7:
                    message.freeTier = reader.int64();
                    break;
                case 5:
                    message.duration = reader.string();
                    break;
                case 8:
                    message.metric = reader.string();
                    break;
                case 9:
                    message.unit = reader.string();
                    break;
                case 10:
                    const entry10 = exports.QuotaLimit_ValuesEntry.decode(reader, reader.uint32());
                    if (entry10.value !== undefined) {
                        message.values[entry10.key] = entry10.value;
                    }
                    break;
                case 12:
                    message.displayName = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseQuotaLimit();
        message.name = object.name ?? "";
        message.description = object.description ?? "";
        message.defaultLimit = object.defaultLimit !== undefined && object.defaultLimit !== null ? BigInt(object.defaultLimit.toString()) : BigInt(0);
        message.maxLimit = object.maxLimit !== undefined && object.maxLimit !== null ? BigInt(object.maxLimit.toString()) : BigInt(0);
        message.freeTier = object.freeTier !== undefined && object.freeTier !== null ? BigInt(object.freeTier.toString()) : BigInt(0);
        message.duration = object.duration ?? "";
        message.metric = object.metric ?? "";
        message.unit = object.unit ?? "";
        message.values = Object.entries(object.values ?? {}).reduce((acc, [key, value]) => {
            if (value !== undefined) {
                acc[key] = BigInt(value.toString());
            }
            return acc;
        }, {});
        message.displayName = object.displayName ?? "";
        return message;
    },
    fromAmino(object) {
        const message = createBaseQuotaLimit();
        if (object.name !== undefined && object.name !== null) {
            message.name = object.name;
        }
        if (object.description !== undefined && object.description !== null) {
            message.description = object.description;
        }
        if (object.default_limit !== undefined && object.default_limit !== null) {
            message.defaultLimit = BigInt(object.default_limit);
        }
        if (object.max_limit !== undefined && object.max_limit !== null) {
            message.maxLimit = BigInt(object.max_limit);
        }
        if (object.free_tier !== undefined && object.free_tier !== null) {
            message.freeTier = BigInt(object.free_tier);
        }
        if (object.duration !== undefined && object.duration !== null) {
            message.duration = object.duration;
        }
        if (object.metric !== undefined && object.metric !== null) {
            message.metric = object.metric;
        }
        if (object.unit !== undefined && object.unit !== null) {
            message.unit = object.unit;
        }
        message.values = Object.entries(object.values ?? {}).reduce((acc, [key, value]) => {
            if (value !== undefined) {
                acc[key] = BigInt(value.toString());
            }
            return acc;
        }, {});
        if (object.display_name !== undefined && object.display_name !== null) {
            message.displayName = object.display_name;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.name = message.name === "" ? undefined : message.name;
        obj.description = message.description === "" ? undefined : message.description;
        obj.default_limit = message.defaultLimit !== BigInt(0) ? message.defaultLimit?.toString() : undefined;
        obj.max_limit = message.maxLimit !== BigInt(0) ? message.maxLimit?.toString() : undefined;
        obj.free_tier = message.freeTier !== BigInt(0) ? message.freeTier?.toString() : undefined;
        obj.duration = message.duration === "" ? undefined : message.duration;
        obj.metric = message.metric === "" ? undefined : message.metric;
        obj.unit = message.unit === "" ? undefined : message.unit;
        obj.values = {};
        if (message.values) {
            Object.entries(message.values).forEach(([k, v]) => {
                obj.values[k] = v.toString();
            });
        }
        obj.display_name = message.displayName === "" ? undefined : message.displayName;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.QuotaLimit.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.QuotaLimit.decode(message.value);
    },
    toProto(message) {
        return exports.QuotaLimit.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.QuotaLimit",
            value: exports.QuotaLimit.encode(message).finish()
        };
    }
};
