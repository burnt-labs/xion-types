"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ContextRule = exports.Context = void 0;
//@ts-nocheck
const binary_1 = require("../../binary");
function createBaseContext() {
    return {
        rules: []
    };
}
exports.Context = {
    typeUrl: "/google.api.Context",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        for (const v of message.rules) {
            exports.ContextRule.encode(v, writer.uint32(10).fork()).ldelim();
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseContext();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.rules.push(exports.ContextRule.decode(reader, reader.uint32()));
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseContext();
        message.rules = object.rules?.map(e => exports.ContextRule.fromPartial(e)) || [];
        return message;
    },
    fromAmino(object) {
        const message = createBaseContext();
        message.rules = object.rules?.map(e => exports.ContextRule.fromAmino(e)) || [];
        return message;
    },
    toAmino(message) {
        const obj = {};
        if (message.rules) {
            obj.rules = message.rules.map(e => e ? exports.ContextRule.toAmino(e) : undefined);
        }
        else {
            obj.rules = message.rules;
        }
        return obj;
    },
    fromAminoMsg(object) {
        return exports.Context.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.Context.decode(message.value);
    },
    toProto(message) {
        return exports.Context.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.Context",
            value: exports.Context.encode(message).finish()
        };
    }
};
function createBaseContextRule() {
    return {
        selector: "",
        requested: [],
        provided: [],
        allowedRequestExtensions: [],
        allowedResponseExtensions: []
    };
}
exports.ContextRule = {
    typeUrl: "/google.api.ContextRule",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.selector !== "") {
            writer.uint32(10).string(message.selector);
        }
        for (const v of message.requested) {
            writer.uint32(18).string(v);
        }
        for (const v of message.provided) {
            writer.uint32(26).string(v);
        }
        for (const v of message.allowedRequestExtensions) {
            writer.uint32(34).string(v);
        }
        for (const v of message.allowedResponseExtensions) {
            writer.uint32(42).string(v);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseContextRule();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.selector = reader.string();
                    break;
                case 2:
                    message.requested.push(reader.string());
                    break;
                case 3:
                    message.provided.push(reader.string());
                    break;
                case 4:
                    message.allowedRequestExtensions.push(reader.string());
                    break;
                case 5:
                    message.allowedResponseExtensions.push(reader.string());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseContextRule();
        message.selector = object.selector ?? "";
        message.requested = object.requested?.map(e => e) || [];
        message.provided = object.provided?.map(e => e) || [];
        message.allowedRequestExtensions = object.allowedRequestExtensions?.map(e => e) || [];
        message.allowedResponseExtensions = object.allowedResponseExtensions?.map(e => e) || [];
        return message;
    },
    fromAmino(object) {
        const message = createBaseContextRule();
        if (object.selector !== undefined && object.selector !== null) {
            message.selector = object.selector;
        }
        message.requested = object.requested?.map(e => e) || [];
        message.provided = object.provided?.map(e => e) || [];
        message.allowedRequestExtensions = object.allowed_request_extensions?.map(e => e) || [];
        message.allowedResponseExtensions = object.allowed_response_extensions?.map(e => e) || [];
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.selector = message.selector === "" ? undefined : message.selector;
        if (message.requested) {
            obj.requested = message.requested.map(e => e);
        }
        else {
            obj.requested = message.requested;
        }
        if (message.provided) {
            obj.provided = message.provided.map(e => e);
        }
        else {
            obj.provided = message.provided;
        }
        if (message.allowedRequestExtensions) {
            obj.allowed_request_extensions = message.allowedRequestExtensions.map(e => e);
        }
        else {
            obj.allowed_request_extensions = message.allowedRequestExtensions;
        }
        if (message.allowedResponseExtensions) {
            obj.allowed_response_extensions = message.allowedResponseExtensions.map(e => e);
        }
        else {
            obj.allowed_response_extensions = message.allowedResponseExtensions;
        }
        return obj;
    },
    fromAminoMsg(object) {
        return exports.ContextRule.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.ContextRule.decode(message.value);
    },
    toProto(message) {
        return exports.ContextRule.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.ContextRule",
            value: exports.ContextRule.encode(message).finish()
        };
    }
};
