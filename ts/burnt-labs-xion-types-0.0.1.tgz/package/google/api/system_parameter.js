"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SystemParameter = exports.SystemParameterRule = exports.SystemParameters = void 0;
//@ts-nocheck
const binary_1 = require("../../binary");
function createBaseSystemParameters() {
    return {
        rules: []
    };
}
exports.SystemParameters = {
    typeUrl: "/google.api.SystemParameters",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        for (const v of message.rules) {
            exports.SystemParameterRule.encode(v, writer.uint32(10).fork()).ldelim();
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseSystemParameters();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.rules.push(exports.SystemParameterRule.decode(reader, reader.uint32()));
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseSystemParameters();
        message.rules = object.rules?.map(e => exports.SystemParameterRule.fromPartial(e)) || [];
        return message;
    },
    fromAmino(object) {
        const message = createBaseSystemParameters();
        message.rules = object.rules?.map(e => exports.SystemParameterRule.fromAmino(e)) || [];
        return message;
    },
    toAmino(message) {
        const obj = {};
        if (message.rules) {
            obj.rules = message.rules.map(e => e ? exports.SystemParameterRule.toAmino(e) : undefined);
        }
        else {
            obj.rules = message.rules;
        }
        return obj;
    },
    fromAminoMsg(object) {
        return exports.SystemParameters.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.SystemParameters.decode(message.value);
    },
    toProto(message) {
        return exports.SystemParameters.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.SystemParameters",
            value: exports.SystemParameters.encode(message).finish()
        };
    }
};
function createBaseSystemParameterRule() {
    return {
        selector: "",
        parameters: []
    };
}
exports.SystemParameterRule = {
    typeUrl: "/google.api.SystemParameterRule",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.selector !== "") {
            writer.uint32(10).string(message.selector);
        }
        for (const v of message.parameters) {
            exports.SystemParameter.encode(v, writer.uint32(18).fork()).ldelim();
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseSystemParameterRule();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.selector = reader.string();
                    break;
                case 2:
                    message.parameters.push(exports.SystemParameter.decode(reader, reader.uint32()));
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseSystemParameterRule();
        message.selector = object.selector ?? "";
        message.parameters = object.parameters?.map(e => exports.SystemParameter.fromPartial(e)) || [];
        return message;
    },
    fromAmino(object) {
        const message = createBaseSystemParameterRule();
        if (object.selector !== undefined && object.selector !== null) {
            message.selector = object.selector;
        }
        message.parameters = object.parameters?.map(e => exports.SystemParameter.fromAmino(e)) || [];
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.selector = message.selector === "" ? undefined : message.selector;
        if (message.parameters) {
            obj.parameters = message.parameters.map(e => e ? exports.SystemParameter.toAmino(e) : undefined);
        }
        else {
            obj.parameters = message.parameters;
        }
        return obj;
    },
    fromAminoMsg(object) {
        return exports.SystemParameterRule.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.SystemParameterRule.decode(message.value);
    },
    toProto(message) {
        return exports.SystemParameterRule.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.SystemParameterRule",
            value: exports.SystemParameterRule.encode(message).finish()
        };
    }
};
function createBaseSystemParameter() {
    return {
        name: "",
        httpHeader: "",
        urlQueryParameter: ""
    };
}
exports.SystemParameter = {
    typeUrl: "/google.api.SystemParameter",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.name !== "") {
            writer.uint32(10).string(message.name);
        }
        if (message.httpHeader !== "") {
            writer.uint32(18).string(message.httpHeader);
        }
        if (message.urlQueryParameter !== "") {
            writer.uint32(26).string(message.urlQueryParameter);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseSystemParameter();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.name = reader.string();
                    break;
                case 2:
                    message.httpHeader = reader.string();
                    break;
                case 3:
                    message.urlQueryParameter = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseSystemParameter();
        message.name = object.name ?? "";
        message.httpHeader = object.httpHeader ?? "";
        message.urlQueryParameter = object.urlQueryParameter ?? "";
        return message;
    },
    fromAmino(object) {
        const message = createBaseSystemParameter();
        if (object.name !== undefined && object.name !== null) {
            message.name = object.name;
        }
        if (object.http_header !== undefined && object.http_header !== null) {
            message.httpHeader = object.http_header;
        }
        if (object.url_query_parameter !== undefined && object.url_query_parameter !== null) {
            message.urlQueryParameter = object.url_query_parameter;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.name = message.name === "" ? undefined : message.name;
        obj.http_header = message.httpHeader === "" ? undefined : message.httpHeader;
        obj.url_query_parameter = message.urlQueryParameter === "" ? undefined : message.urlQueryParameter;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.SystemParameter.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.SystemParameter.decode(message.value);
    },
    toProto(message) {
        return exports.SystemParameter.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.SystemParameter",
            value: exports.SystemParameter.encode(message).finish()
        };
    }
};
