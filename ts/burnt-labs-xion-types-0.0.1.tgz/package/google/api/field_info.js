"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.TypeReference = exports.FieldInfo = exports.FieldInfo_FormatAmino = exports.FieldInfo_FormatSDKType = exports.FieldInfo_Format = void 0;
exports.fieldInfo_FormatFromJSON = fieldInfo_FormatFromJSON;
exports.fieldInfo_FormatToJSON = fieldInfo_FormatToJSON;
//@ts-nocheck
const binary_1 = require("../../binary");
/**
 * The standard format of a field value. The supported formats are all backed
 * by either an RFC defined by the IETF or a Google-defined AIP.
 */
var FieldInfo_Format;
(function (FieldInfo_Format) {
    /** FORMAT_UNSPECIFIED - Default, unspecified value. */
    FieldInfo_Format[FieldInfo_Format["FORMAT_UNSPECIFIED"] = 0] = "FORMAT_UNSPECIFIED";
    /**
     * UUID4 - Universally Unique Identifier, version 4, value as defined by
     * https://datatracker.ietf.org/doc/html/rfc4122. The value may be
     * normalized to entirely lowercase letters. For example, the value
     * `F47AC10B-58CC-0372-8567-0E02B2C3D479` would be normalized to
     * `f47ac10b-58cc-0372-8567-0e02b2c3d479`.
     */
    FieldInfo_Format[FieldInfo_Format["UUID4"] = 1] = "UUID4";
    /**
     * IPV4 - Internet Protocol v4 value as defined by [RFC
     * 791](https://datatracker.ietf.org/doc/html/rfc791). The value may be
     * condensed, with leading zeros in each octet stripped. For example,
     * `001.022.233.040` would be condensed to `1.22.233.40`.
     */
    FieldInfo_Format[FieldInfo_Format["IPV4"] = 2] = "IPV4";
    /**
     * IPV6 - Internet Protocol v6 value as defined by [RFC
     * 2460](https://datatracker.ietf.org/doc/html/rfc2460). The value may be
     * normalized to entirely lowercase letters with zeros compressed, following
     * [RFC 5952](https://datatracker.ietf.org/doc/html/rfc5952). For example,
     * the value `2001:0DB8:0::0` would be normalized to `2001:db8::`.
     */
    FieldInfo_Format[FieldInfo_Format["IPV6"] = 3] = "IPV6";
    /**
     * IPV4_OR_IPV6 - An IP address in either v4 or v6 format as described by the individual
     * values defined herein. See the comments on the IPV4 and IPV6 types for
     * allowed normalizations of each.
     */
    FieldInfo_Format[FieldInfo_Format["IPV4_OR_IPV6"] = 4] = "IPV4_OR_IPV6";
    FieldInfo_Format[FieldInfo_Format["UNRECOGNIZED"] = -1] = "UNRECOGNIZED";
})(FieldInfo_Format || (exports.FieldInfo_Format = FieldInfo_Format = {}));
exports.FieldInfo_FormatSDKType = FieldInfo_Format;
exports.FieldInfo_FormatAmino = FieldInfo_Format;
function fieldInfo_FormatFromJSON(object) {
    switch (object) {
        case 0:
        case "FORMAT_UNSPECIFIED":
            return FieldInfo_Format.FORMAT_UNSPECIFIED;
        case 1:
        case "UUID4":
            return FieldInfo_Format.UUID4;
        case 2:
        case "IPV4":
            return FieldInfo_Format.IPV4;
        case 3:
        case "IPV6":
            return FieldInfo_Format.IPV6;
        case 4:
        case "IPV4_OR_IPV6":
            return FieldInfo_Format.IPV4_OR_IPV6;
        case -1:
        case "UNRECOGNIZED":
        default:
            return FieldInfo_Format.UNRECOGNIZED;
    }
}
function fieldInfo_FormatToJSON(object) {
    switch (object) {
        case FieldInfo_Format.FORMAT_UNSPECIFIED:
            return "FORMAT_UNSPECIFIED";
        case FieldInfo_Format.UUID4:
            return "UUID4";
        case FieldInfo_Format.IPV4:
            return "IPV4";
        case FieldInfo_Format.IPV6:
            return "IPV6";
        case FieldInfo_Format.IPV4_OR_IPV6:
            return "IPV4_OR_IPV6";
        case FieldInfo_Format.UNRECOGNIZED:
        default:
            return "UNRECOGNIZED";
    }
}
function createBaseFieldInfo() {
    return {
        format: 0,
        referencedTypes: []
    };
}
exports.FieldInfo = {
    typeUrl: "/google.api.FieldInfo",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.format !== 0) {
            writer.uint32(8).int32(message.format);
        }
        for (const v of message.referencedTypes) {
            exports.TypeReference.encode(v, writer.uint32(18).fork()).ldelim();
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseFieldInfo();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.format = reader.int32();
                    break;
                case 2:
                    message.referencedTypes.push(exports.TypeReference.decode(reader, reader.uint32()));
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseFieldInfo();
        message.format = object.format ?? 0;
        message.referencedTypes = object.referencedTypes?.map(e => exports.TypeReference.fromPartial(e)) || [];
        return message;
    },
    fromAmino(object) {
        const message = createBaseFieldInfo();
        if (object.format !== undefined && object.format !== null) {
            message.format = object.format;
        }
        message.referencedTypes = object.referenced_types?.map(e => exports.TypeReference.fromAmino(e)) || [];
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.format = message.format === 0 ? undefined : message.format;
        if (message.referencedTypes) {
            obj.referenced_types = message.referencedTypes.map(e => e ? exports.TypeReference.toAmino(e) : undefined);
        }
        else {
            obj.referenced_types = message.referencedTypes;
        }
        return obj;
    },
    fromAminoMsg(object) {
        return exports.FieldInfo.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.FieldInfo.decode(message.value);
    },
    toProto(message) {
        return exports.FieldInfo.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.FieldInfo",
            value: exports.FieldInfo.encode(message).finish()
        };
    }
};
function createBaseTypeReference() {
    return {
        typeName: ""
    };
}
exports.TypeReference = {
    typeUrl: "/google.api.TypeReference",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.typeName !== "") {
            writer.uint32(10).string(message.typeName);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseTypeReference();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.typeName = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseTypeReference();
        message.typeName = object.typeName ?? "";
        return message;
    },
    fromAmino(object) {
        const message = createBaseTypeReference();
        if (object.type_name !== undefined && object.type_name !== null) {
            message.typeName = object.type_name;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.type_name = message.typeName === "" ? undefined : message.typeName;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.TypeReference.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.TypeReference.decode(message.value);
    },
    toProto(message) {
        return exports.TypeReference.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.TypeReference",
            value: exports.TypeReference.encode(message).finish()
        };
    }
};
