"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GetServiceIdentityMetadata = exports.GetServiceIdentityResponse = exports.GenerateServiceIdentityRequest = exports.DeleteAdminQuotaPolicyMetadata = exports.UpdateAdminQuotaPolicyMetadata = exports.CreateAdminQuotaPolicyMetadata = exports.ImportAdminQuotaPoliciesMetadata = exports.ImportAdminQuotaPoliciesResponse = exports.ImportConsumerOverridesMetadata = exports.ImportConsumerOverridesResponse = exports.ImportConsumerOverridesRequest = exports.BatchCreateConsumerOverridesResponse = exports.ListConsumerOverridesResponse = exports.ListConsumerOverridesRequest = exports.DeleteConsumerOverrideRequest = exports.UpdateConsumerOverrideRequest = exports.CreateConsumerOverrideRequest = exports.ImportAdminOverridesMetadata = exports.ImportAdminOverridesResponse = exports.ImportAdminOverridesRequest = exports.BatchCreateAdminOverridesResponse = exports.ListAdminOverridesResponse = exports.ListAdminOverridesRequest = exports.DeleteAdminOverrideRequest = exports.UpdateAdminOverrideRequest = exports.CreateAdminOverrideRequest = exports.GetConsumerQuotaLimitRequest = exports.GetConsumerQuotaMetricRequest = exports.ListConsumerQuotaMetricsResponse = exports.ListConsumerQuotaMetricsRequest = exports.BatchEnableServicesRequest = exports.ListServicesResponse = exports.ListServicesRequest = exports.GetServiceRequest = exports.DisableServiceRequest = exports.EnableServiceRequest = exports.GetServiceIdentityResponse_IdentityStateAmino = exports.GetServiceIdentityResponse_IdentityStateSDKType = exports.GetServiceIdentityResponse_IdentityState = void 0;
exports.getServiceIdentityResponse_IdentityStateFromJSON = getServiceIdentityResponse_IdentityStateFromJSON;
exports.getServiceIdentityResponse_IdentityStateToJSON = getServiceIdentityResponse_IdentityStateToJSON;
//@ts-nocheck
const resources_1 = require("./resources");
const field_mask_1 = require("../../../protobuf/field_mask");
const binary_1 = require("../../../../binary");
/** Enum for service identity state. */
var GetServiceIdentityResponse_IdentityState;
(function (GetServiceIdentityResponse_IdentityState) {
    /**
     * IDENTITY_STATE_UNSPECIFIED - Default service identity state. This value is used if the state is
     * omitted.
     */
    GetServiceIdentityResponse_IdentityState[GetServiceIdentityResponse_IdentityState["IDENTITY_STATE_UNSPECIFIED"] = 0] = "IDENTITY_STATE_UNSPECIFIED";
    /** ACTIVE - Service identity has been created and can be used. */
    GetServiceIdentityResponse_IdentityState[GetServiceIdentityResponse_IdentityState["ACTIVE"] = 1] = "ACTIVE";
    GetServiceIdentityResponse_IdentityState[GetServiceIdentityResponse_IdentityState["UNRECOGNIZED"] = -1] = "UNRECOGNIZED";
})(GetServiceIdentityResponse_IdentityState || (exports.GetServiceIdentityResponse_IdentityState = GetServiceIdentityResponse_IdentityState = {}));
exports.GetServiceIdentityResponse_IdentityStateSDKType = GetServiceIdentityResponse_IdentityState;
exports.GetServiceIdentityResponse_IdentityStateAmino = GetServiceIdentityResponse_IdentityState;
function getServiceIdentityResponse_IdentityStateFromJSON(object) {
    switch (object) {
        case 0:
        case "IDENTITY_STATE_UNSPECIFIED":
            return GetServiceIdentityResponse_IdentityState.IDENTITY_STATE_UNSPECIFIED;
        case 1:
        case "ACTIVE":
            return GetServiceIdentityResponse_IdentityState.ACTIVE;
        case -1:
        case "UNRECOGNIZED":
        default:
            return GetServiceIdentityResponse_IdentityState.UNRECOGNIZED;
    }
}
function getServiceIdentityResponse_IdentityStateToJSON(object) {
    switch (object) {
        case GetServiceIdentityResponse_IdentityState.IDENTITY_STATE_UNSPECIFIED:
            return "IDENTITY_STATE_UNSPECIFIED";
        case GetServiceIdentityResponse_IdentityState.ACTIVE:
            return "ACTIVE";
        case GetServiceIdentityResponse_IdentityState.UNRECOGNIZED:
        default:
            return "UNRECOGNIZED";
    }
}
function createBaseEnableServiceRequest() {
    return {
        name: ""
    };
}
exports.EnableServiceRequest = {
    typeUrl: "/google.api.serviceusage.v1beta1.EnableServiceRequest",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.name !== "") {
            writer.uint32(10).string(message.name);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseEnableServiceRequest();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.name = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseEnableServiceRequest();
        message.name = object.name ?? "";
        return message;
    },
    fromAmino(object) {
        const message = createBaseEnableServiceRequest();
        if (object.name !== undefined && object.name !== null) {
            message.name = object.name;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.name = message.name === "" ? undefined : message.name;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.EnableServiceRequest.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.EnableServiceRequest.decode(message.value);
    },
    toProto(message) {
        return exports.EnableServiceRequest.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.serviceusage.v1beta1.EnableServiceRequest",
            value: exports.EnableServiceRequest.encode(message).finish()
        };
    }
};
function createBaseDisableServiceRequest() {
    return {
        name: ""
    };
}
exports.DisableServiceRequest = {
    typeUrl: "/google.api.serviceusage.v1beta1.DisableServiceRequest",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.name !== "") {
            writer.uint32(10).string(message.name);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseDisableServiceRequest();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.name = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseDisableServiceRequest();
        message.name = object.name ?? "";
        return message;
    },
    fromAmino(object) {
        const message = createBaseDisableServiceRequest();
        if (object.name !== undefined && object.name !== null) {
            message.name = object.name;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.name = message.name === "" ? undefined : message.name;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.DisableServiceRequest.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.DisableServiceRequest.decode(message.value);
    },
    toProto(message) {
        return exports.DisableServiceRequest.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.serviceusage.v1beta1.DisableServiceRequest",
            value: exports.DisableServiceRequest.encode(message).finish()
        };
    }
};
function createBaseGetServiceRequest() {
    return {
        name: ""
    };
}
exports.GetServiceRequest = {
    typeUrl: "/google.api.serviceusage.v1beta1.GetServiceRequest",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.name !== "") {
            writer.uint32(10).string(message.name);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseGetServiceRequest();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.name = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseGetServiceRequest();
        message.name = object.name ?? "";
        return message;
    },
    fromAmino(object) {
        const message = createBaseGetServiceRequest();
        if (object.name !== undefined && object.name !== null) {
            message.name = object.name;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.name = message.name === "" ? undefined : message.name;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.GetServiceRequest.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.GetServiceRequest.decode(message.value);
    },
    toProto(message) {
        return exports.GetServiceRequest.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.serviceusage.v1beta1.GetServiceRequest",
            value: exports.GetServiceRequest.encode(message).finish()
        };
    }
};
function createBaseListServicesRequest() {
    return {
        parent: "",
        pageSize: 0,
        pageToken: "",
        filter: ""
    };
}
exports.ListServicesRequest = {
    typeUrl: "/google.api.serviceusage.v1beta1.ListServicesRequest",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.parent !== "") {
            writer.uint32(10).string(message.parent);
        }
        if (message.pageSize !== 0) {
            writer.uint32(16).int32(message.pageSize);
        }
        if (message.pageToken !== "") {
            writer.uint32(26).string(message.pageToken);
        }
        if (message.filter !== "") {
            writer.uint32(34).string(message.filter);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseListServicesRequest();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.parent = reader.string();
                    break;
                case 2:
                    message.pageSize = reader.int32();
                    break;
                case 3:
                    message.pageToken = reader.string();
                    break;
                case 4:
                    message.filter = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseListServicesRequest();
        message.parent = object.parent ?? "";
        message.pageSize = object.pageSize ?? 0;
        message.pageToken = object.pageToken ?? "";
        message.filter = object.filter ?? "";
        return message;
    },
    fromAmino(object) {
        const message = createBaseListServicesRequest();
        if (object.parent !== undefined && object.parent !== null) {
            message.parent = object.parent;
        }
        if (object.page_size !== undefined && object.page_size !== null) {
            message.pageSize = object.page_size;
        }
        if (object.page_token !== undefined && object.page_token !== null) {
            message.pageToken = object.page_token;
        }
        if (object.filter !== undefined && object.filter !== null) {
            message.filter = object.filter;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.parent = message.parent === "" ? undefined : message.parent;
        obj.page_size = message.pageSize === 0 ? undefined : message.pageSize;
        obj.page_token = message.pageToken === "" ? undefined : message.pageToken;
        obj.filter = message.filter === "" ? undefined : message.filter;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.ListServicesRequest.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.ListServicesRequest.decode(message.value);
    },
    toProto(message) {
        return exports.ListServicesRequest.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.serviceusage.v1beta1.ListServicesRequest",
            value: exports.ListServicesRequest.encode(message).finish()
        };
    }
};
function createBaseListServicesResponse() {
    return {
        services: [],
        nextPageToken: ""
    };
}
exports.ListServicesResponse = {
    typeUrl: "/google.api.serviceusage.v1beta1.ListServicesResponse",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        for (const v of message.services) {
            resources_1.Service.encode(v, writer.uint32(10).fork()).ldelim();
        }
        if (message.nextPageToken !== "") {
            writer.uint32(18).string(message.nextPageToken);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseListServicesResponse();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.services.push(resources_1.Service.decode(reader, reader.uint32()));
                    break;
                case 2:
                    message.nextPageToken = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseListServicesResponse();
        message.services = object.services?.map(e => resources_1.Service.fromPartial(e)) || [];
        message.nextPageToken = object.nextPageToken ?? "";
        return message;
    },
    fromAmino(object) {
        const message = createBaseListServicesResponse();
        message.services = object.services?.map(e => resources_1.Service.fromAmino(e)) || [];
        if (object.next_page_token !== undefined && object.next_page_token !== null) {
            message.nextPageToken = object.next_page_token;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        if (message.services) {
            obj.services = message.services.map(e => e ? resources_1.Service.toAmino(e) : undefined);
        }
        else {
            obj.services = message.services;
        }
        obj.next_page_token = message.nextPageToken === "" ? undefined : message.nextPageToken;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.ListServicesResponse.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.ListServicesResponse.decode(message.value);
    },
    toProto(message) {
        return exports.ListServicesResponse.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.serviceusage.v1beta1.ListServicesResponse",
            value: exports.ListServicesResponse.encode(message).finish()
        };
    }
};
function createBaseBatchEnableServicesRequest() {
    return {
        parent: "",
        serviceIds: []
    };
}
exports.BatchEnableServicesRequest = {
    typeUrl: "/google.api.serviceusage.v1beta1.BatchEnableServicesRequest",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.parent !== "") {
            writer.uint32(10).string(message.parent);
        }
        for (const v of message.serviceIds) {
            writer.uint32(18).string(v);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseBatchEnableServicesRequest();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.parent = reader.string();
                    break;
                case 2:
                    message.serviceIds.push(reader.string());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseBatchEnableServicesRequest();
        message.parent = object.parent ?? "";
        message.serviceIds = object.serviceIds?.map(e => e) || [];
        return message;
    },
    fromAmino(object) {
        const message = createBaseBatchEnableServicesRequest();
        if (object.parent !== undefined && object.parent !== null) {
            message.parent = object.parent;
        }
        message.serviceIds = object.service_ids?.map(e => e) || [];
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.parent = message.parent === "" ? undefined : message.parent;
        if (message.serviceIds) {
            obj.service_ids = message.serviceIds.map(e => e);
        }
        else {
            obj.service_ids = message.serviceIds;
        }
        return obj;
    },
    fromAminoMsg(object) {
        return exports.BatchEnableServicesRequest.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.BatchEnableServicesRequest.decode(message.value);
    },
    toProto(message) {
        return exports.BatchEnableServicesRequest.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.serviceusage.v1beta1.BatchEnableServicesRequest",
            value: exports.BatchEnableServicesRequest.encode(message).finish()
        };
    }
};
function createBaseListConsumerQuotaMetricsRequest() {
    return {
        parent: "",
        pageSize: 0,
        pageToken: "",
        view: 0
    };
}
exports.ListConsumerQuotaMetricsRequest = {
    typeUrl: "/google.api.serviceusage.v1beta1.ListConsumerQuotaMetricsRequest",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.parent !== "") {
            writer.uint32(10).string(message.parent);
        }
        if (message.pageSize !== 0) {
            writer.uint32(16).int32(message.pageSize);
        }
        if (message.pageToken !== "") {
            writer.uint32(26).string(message.pageToken);
        }
        if (message.view !== 0) {
            writer.uint32(32).int32(message.view);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseListConsumerQuotaMetricsRequest();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.parent = reader.string();
                    break;
                case 2:
                    message.pageSize = reader.int32();
                    break;
                case 3:
                    message.pageToken = reader.string();
                    break;
                case 4:
                    message.view = reader.int32();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseListConsumerQuotaMetricsRequest();
        message.parent = object.parent ?? "";
        message.pageSize = object.pageSize ?? 0;
        message.pageToken = object.pageToken ?? "";
        message.view = object.view ?? 0;
        return message;
    },
    fromAmino(object) {
        const message = createBaseListConsumerQuotaMetricsRequest();
        if (object.parent !== undefined && object.parent !== null) {
            message.parent = object.parent;
        }
        if (object.page_size !== undefined && object.page_size !== null) {
            message.pageSize = object.page_size;
        }
        if (object.page_token !== undefined && object.page_token !== null) {
            message.pageToken = object.page_token;
        }
        if (object.view !== undefined && object.view !== null) {
            message.view = object.view;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.parent = message.parent === "" ? undefined : message.parent;
        obj.page_size = message.pageSize === 0 ? undefined : message.pageSize;
        obj.page_token = message.pageToken === "" ? undefined : message.pageToken;
        obj.view = message.view === 0 ? undefined : message.view;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.ListConsumerQuotaMetricsRequest.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.ListConsumerQuotaMetricsRequest.decode(message.value);
    },
    toProto(message) {
        return exports.ListConsumerQuotaMetricsRequest.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.serviceusage.v1beta1.ListConsumerQuotaMetricsRequest",
            value: exports.ListConsumerQuotaMetricsRequest.encode(message).finish()
        };
    }
};
function createBaseListConsumerQuotaMetricsResponse() {
    return {
        metrics: [],
        nextPageToken: ""
    };
}
exports.ListConsumerQuotaMetricsResponse = {
    typeUrl: "/google.api.serviceusage.v1beta1.ListConsumerQuotaMetricsResponse",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        for (const v of message.metrics) {
            resources_1.ConsumerQuotaMetric.encode(v, writer.uint32(10).fork()).ldelim();
        }
        if (message.nextPageToken !== "") {
            writer.uint32(18).string(message.nextPageToken);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseListConsumerQuotaMetricsResponse();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.metrics.push(resources_1.ConsumerQuotaMetric.decode(reader, reader.uint32()));
                    break;
                case 2:
                    message.nextPageToken = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseListConsumerQuotaMetricsResponse();
        message.metrics = object.metrics?.map(e => resources_1.ConsumerQuotaMetric.fromPartial(e)) || [];
        message.nextPageToken = object.nextPageToken ?? "";
        return message;
    },
    fromAmino(object) {
        const message = createBaseListConsumerQuotaMetricsResponse();
        message.metrics = object.metrics?.map(e => resources_1.ConsumerQuotaMetric.fromAmino(e)) || [];
        if (object.next_page_token !== undefined && object.next_page_token !== null) {
            message.nextPageToken = object.next_page_token;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        if (message.metrics) {
            obj.metrics = message.metrics.map(e => e ? resources_1.ConsumerQuotaMetric.toAmino(e) : undefined);
        }
        else {
            obj.metrics = message.metrics;
        }
        obj.next_page_token = message.nextPageToken === "" ? undefined : message.nextPageToken;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.ListConsumerQuotaMetricsResponse.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.ListConsumerQuotaMetricsResponse.decode(message.value);
    },
    toProto(message) {
        return exports.ListConsumerQuotaMetricsResponse.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.serviceusage.v1beta1.ListConsumerQuotaMetricsResponse",
            value: exports.ListConsumerQuotaMetricsResponse.encode(message).finish()
        };
    }
};
function createBaseGetConsumerQuotaMetricRequest() {
    return {
        name: "",
        view: 0
    };
}
exports.GetConsumerQuotaMetricRequest = {
    typeUrl: "/google.api.serviceusage.v1beta1.GetConsumerQuotaMetricRequest",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.name !== "") {
            writer.uint32(10).string(message.name);
        }
        if (message.view !== 0) {
            writer.uint32(16).int32(message.view);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseGetConsumerQuotaMetricRequest();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.name = reader.string();
                    break;
                case 2:
                    message.view = reader.int32();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseGetConsumerQuotaMetricRequest();
        message.name = object.name ?? "";
        message.view = object.view ?? 0;
        return message;
    },
    fromAmino(object) {
        const message = createBaseGetConsumerQuotaMetricRequest();
        if (object.name !== undefined && object.name !== null) {
            message.name = object.name;
        }
        if (object.view !== undefined && object.view !== null) {
            message.view = object.view;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.name = message.name === "" ? undefined : message.name;
        obj.view = message.view === 0 ? undefined : message.view;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.GetConsumerQuotaMetricRequest.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.GetConsumerQuotaMetricRequest.decode(message.value);
    },
    toProto(message) {
        return exports.GetConsumerQuotaMetricRequest.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.serviceusage.v1beta1.GetConsumerQuotaMetricRequest",
            value: exports.GetConsumerQuotaMetricRequest.encode(message).finish()
        };
    }
};
function createBaseGetConsumerQuotaLimitRequest() {
    return {
        name: "",
        view: 0
    };
}
exports.GetConsumerQuotaLimitRequest = {
    typeUrl: "/google.api.serviceusage.v1beta1.GetConsumerQuotaLimitRequest",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.name !== "") {
            writer.uint32(10).string(message.name);
        }
        if (message.view !== 0) {
            writer.uint32(16).int32(message.view);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseGetConsumerQuotaLimitRequest();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.name = reader.string();
                    break;
                case 2:
                    message.view = reader.int32();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseGetConsumerQuotaLimitRequest();
        message.name = object.name ?? "";
        message.view = object.view ?? 0;
        return message;
    },
    fromAmino(object) {
        const message = createBaseGetConsumerQuotaLimitRequest();
        if (object.name !== undefined && object.name !== null) {
            message.name = object.name;
        }
        if (object.view !== undefined && object.view !== null) {
            message.view = object.view;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.name = message.name === "" ? undefined : message.name;
        obj.view = message.view === 0 ? undefined : message.view;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.GetConsumerQuotaLimitRequest.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.GetConsumerQuotaLimitRequest.decode(message.value);
    },
    toProto(message) {
        return exports.GetConsumerQuotaLimitRequest.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.serviceusage.v1beta1.GetConsumerQuotaLimitRequest",
            value: exports.GetConsumerQuotaLimitRequest.encode(message).finish()
        };
    }
};
function createBaseCreateAdminOverrideRequest() {
    return {
        parent: "",
        override: undefined,
        force: false,
        forceOnly: []
    };
}
exports.CreateAdminOverrideRequest = {
    typeUrl: "/google.api.serviceusage.v1beta1.CreateAdminOverrideRequest",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.parent !== "") {
            writer.uint32(10).string(message.parent);
        }
        if (message.override !== undefined) {
            resources_1.QuotaOverride.encode(message.override, writer.uint32(18).fork()).ldelim();
        }
        if (message.force === true) {
            writer.uint32(24).bool(message.force);
        }
        writer.uint32(34).fork();
        for (const v of message.forceOnly) {
            writer.int32(v);
        }
        writer.ldelim();
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseCreateAdminOverrideRequest();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.parent = reader.string();
                    break;
                case 2:
                    message.override = resources_1.QuotaOverride.decode(reader, reader.uint32());
                    break;
                case 3:
                    message.force = reader.bool();
                    break;
                case 4:
                    if ((tag & 7) === 2) {
                        const end2 = reader.uint32() + reader.pos;
                        while (reader.pos < end2) {
                            message.forceOnly.push(reader.int32());
                        }
                    }
                    else {
                        message.forceOnly.push(reader.int32());
                    }
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseCreateAdminOverrideRequest();
        message.parent = object.parent ?? "";
        message.override = object.override !== undefined && object.override !== null ? resources_1.QuotaOverride.fromPartial(object.override) : undefined;
        message.force = object.force ?? false;
        message.forceOnly = object.forceOnly?.map(e => e) || [];
        return message;
    },
    fromAmino(object) {
        const message = createBaseCreateAdminOverrideRequest();
        if (object.parent !== undefined && object.parent !== null) {
            message.parent = object.parent;
        }
        if (object.override !== undefined && object.override !== null) {
            message.override = resources_1.QuotaOverride.fromAmino(object.override);
        }
        if (object.force !== undefined && object.force !== null) {
            message.force = object.force;
        }
        message.forceOnly = object.force_only?.map(e => e) || [];
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.parent = message.parent === "" ? undefined : message.parent;
        obj.override = message.override ? resources_1.QuotaOverride.toAmino(message.override) : undefined;
        obj.force = message.force === false ? undefined : message.force;
        if (message.forceOnly) {
            obj.force_only = message.forceOnly.map(e => e);
        }
        else {
            obj.force_only = message.forceOnly;
        }
        return obj;
    },
    fromAminoMsg(object) {
        return exports.CreateAdminOverrideRequest.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.CreateAdminOverrideRequest.decode(message.value);
    },
    toProto(message) {
        return exports.CreateAdminOverrideRequest.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.serviceusage.v1beta1.CreateAdminOverrideRequest",
            value: exports.CreateAdminOverrideRequest.encode(message).finish()
        };
    }
};
function createBaseUpdateAdminOverrideRequest() {
    return {
        name: "",
        override: undefined,
        force: false,
        updateMask: undefined,
        forceOnly: []
    };
}
exports.UpdateAdminOverrideRequest = {
    typeUrl: "/google.api.serviceusage.v1beta1.UpdateAdminOverrideRequest",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.name !== "") {
            writer.uint32(10).string(message.name);
        }
        if (message.override !== undefined) {
            resources_1.QuotaOverride.encode(message.override, writer.uint32(18).fork()).ldelim();
        }
        if (message.force === true) {
            writer.uint32(24).bool(message.force);
        }
        if (message.updateMask !== undefined) {
            field_mask_1.FieldMask.encode(message.updateMask, writer.uint32(34).fork()).ldelim();
        }
        writer.uint32(42).fork();
        for (const v of message.forceOnly) {
            writer.int32(v);
        }
        writer.ldelim();
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseUpdateAdminOverrideRequest();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.name = reader.string();
                    break;
                case 2:
                    message.override = resources_1.QuotaOverride.decode(reader, reader.uint32());
                    break;
                case 3:
                    message.force = reader.bool();
                    break;
                case 4:
                    message.updateMask = field_mask_1.FieldMask.decode(reader, reader.uint32());
                    break;
                case 5:
                    if ((tag & 7) === 2) {
                        const end2 = reader.uint32() + reader.pos;
                        while (reader.pos < end2) {
                            message.forceOnly.push(reader.int32());
                        }
                    }
                    else {
                        message.forceOnly.push(reader.int32());
                    }
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseUpdateAdminOverrideRequest();
        message.name = object.name ?? "";
        message.override = object.override !== undefined && object.override !== null ? resources_1.QuotaOverride.fromPartial(object.override) : undefined;
        message.force = object.force ?? false;
        message.updateMask = object.updateMask !== undefined && object.updateMask !== null ? field_mask_1.FieldMask.fromPartial(object.updateMask) : undefined;
        message.forceOnly = object.forceOnly?.map(e => e) || [];
        return message;
    },
    fromAmino(object) {
        const message = createBaseUpdateAdminOverrideRequest();
        if (object.name !== undefined && object.name !== null) {
            message.name = object.name;
        }
        if (object.override !== undefined && object.override !== null) {
            message.override = resources_1.QuotaOverride.fromAmino(object.override);
        }
        if (object.force !== undefined && object.force !== null) {
            message.force = object.force;
        }
        if (object.update_mask !== undefined && object.update_mask !== null) {
            message.updateMask = field_mask_1.FieldMask.fromAmino(object.update_mask);
        }
        message.forceOnly = object.force_only?.map(e => e) || [];
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.name = message.name === "" ? undefined : message.name;
        obj.override = message.override ? resources_1.QuotaOverride.toAmino(message.override) : undefined;
        obj.force = message.force === false ? undefined : message.force;
        obj.update_mask = message.updateMask ? field_mask_1.FieldMask.toAmino(message.updateMask) : undefined;
        if (message.forceOnly) {
            obj.force_only = message.forceOnly.map(e => e);
        }
        else {
            obj.force_only = message.forceOnly;
        }
        return obj;
    },
    fromAminoMsg(object) {
        return exports.UpdateAdminOverrideRequest.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.UpdateAdminOverrideRequest.decode(message.value);
    },
    toProto(message) {
        return exports.UpdateAdminOverrideRequest.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.serviceusage.v1beta1.UpdateAdminOverrideRequest",
            value: exports.UpdateAdminOverrideRequest.encode(message).finish()
        };
    }
};
function createBaseDeleteAdminOverrideRequest() {
    return {
        name: "",
        force: false,
        forceOnly: []
    };
}
exports.DeleteAdminOverrideRequest = {
    typeUrl: "/google.api.serviceusage.v1beta1.DeleteAdminOverrideRequest",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.name !== "") {
            writer.uint32(10).string(message.name);
        }
        if (message.force === true) {
            writer.uint32(16).bool(message.force);
        }
        writer.uint32(26).fork();
        for (const v of message.forceOnly) {
            writer.int32(v);
        }
        writer.ldelim();
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseDeleteAdminOverrideRequest();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.name = reader.string();
                    break;
                case 2:
                    message.force = reader.bool();
                    break;
                case 3:
                    if ((tag & 7) === 2) {
                        const end2 = reader.uint32() + reader.pos;
                        while (reader.pos < end2) {
                            message.forceOnly.push(reader.int32());
                        }
                    }
                    else {
                        message.forceOnly.push(reader.int32());
                    }
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseDeleteAdminOverrideRequest();
        message.name = object.name ?? "";
        message.force = object.force ?? false;
        message.forceOnly = object.forceOnly?.map(e => e) || [];
        return message;
    },
    fromAmino(object) {
        const message = createBaseDeleteAdminOverrideRequest();
        if (object.name !== undefined && object.name !== null) {
            message.name = object.name;
        }
        if (object.force !== undefined && object.force !== null) {
            message.force = object.force;
        }
        message.forceOnly = object.force_only?.map(e => e) || [];
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.name = message.name === "" ? undefined : message.name;
        obj.force = message.force === false ? undefined : message.force;
        if (message.forceOnly) {
            obj.force_only = message.forceOnly.map(e => e);
        }
        else {
            obj.force_only = message.forceOnly;
        }
        return obj;
    },
    fromAminoMsg(object) {
        return exports.DeleteAdminOverrideRequest.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.DeleteAdminOverrideRequest.decode(message.value);
    },
    toProto(message) {
        return exports.DeleteAdminOverrideRequest.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.serviceusage.v1beta1.DeleteAdminOverrideRequest",
            value: exports.DeleteAdminOverrideRequest.encode(message).finish()
        };
    }
};
function createBaseListAdminOverridesRequest() {
    return {
        parent: "",
        pageSize: 0,
        pageToken: ""
    };
}
exports.ListAdminOverridesRequest = {
    typeUrl: "/google.api.serviceusage.v1beta1.ListAdminOverridesRequest",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.parent !== "") {
            writer.uint32(10).string(message.parent);
        }
        if (message.pageSize !== 0) {
            writer.uint32(16).int32(message.pageSize);
        }
        if (message.pageToken !== "") {
            writer.uint32(26).string(message.pageToken);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseListAdminOverridesRequest();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.parent = reader.string();
                    break;
                case 2:
                    message.pageSize = reader.int32();
                    break;
                case 3:
                    message.pageToken = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseListAdminOverridesRequest();
        message.parent = object.parent ?? "";
        message.pageSize = object.pageSize ?? 0;
        message.pageToken = object.pageToken ?? "";
        return message;
    },
    fromAmino(object) {
        const message = createBaseListAdminOverridesRequest();
        if (object.parent !== undefined && object.parent !== null) {
            message.parent = object.parent;
        }
        if (object.page_size !== undefined && object.page_size !== null) {
            message.pageSize = object.page_size;
        }
        if (object.page_token !== undefined && object.page_token !== null) {
            message.pageToken = object.page_token;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.parent = message.parent === "" ? undefined : message.parent;
        obj.page_size = message.pageSize === 0 ? undefined : message.pageSize;
        obj.page_token = message.pageToken === "" ? undefined : message.pageToken;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.ListAdminOverridesRequest.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.ListAdminOverridesRequest.decode(message.value);
    },
    toProto(message) {
        return exports.ListAdminOverridesRequest.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.serviceusage.v1beta1.ListAdminOverridesRequest",
            value: exports.ListAdminOverridesRequest.encode(message).finish()
        };
    }
};
function createBaseListAdminOverridesResponse() {
    return {
        overrides: [],
        nextPageToken: ""
    };
}
exports.ListAdminOverridesResponse = {
    typeUrl: "/google.api.serviceusage.v1beta1.ListAdminOverridesResponse",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        for (const v of message.overrides) {
            resources_1.QuotaOverride.encode(v, writer.uint32(10).fork()).ldelim();
        }
        if (message.nextPageToken !== "") {
            writer.uint32(18).string(message.nextPageToken);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseListAdminOverridesResponse();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.overrides.push(resources_1.QuotaOverride.decode(reader, reader.uint32()));
                    break;
                case 2:
                    message.nextPageToken = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseListAdminOverridesResponse();
        message.overrides = object.overrides?.map(e => resources_1.QuotaOverride.fromPartial(e)) || [];
        message.nextPageToken = object.nextPageToken ?? "";
        return message;
    },
    fromAmino(object) {
        const message = createBaseListAdminOverridesResponse();
        message.overrides = object.overrides?.map(e => resources_1.QuotaOverride.fromAmino(e)) || [];
        if (object.next_page_token !== undefined && object.next_page_token !== null) {
            message.nextPageToken = object.next_page_token;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        if (message.overrides) {
            obj.overrides = message.overrides.map(e => e ? resources_1.QuotaOverride.toAmino(e) : undefined);
        }
        else {
            obj.overrides = message.overrides;
        }
        obj.next_page_token = message.nextPageToken === "" ? undefined : message.nextPageToken;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.ListAdminOverridesResponse.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.ListAdminOverridesResponse.decode(message.value);
    },
    toProto(message) {
        return exports.ListAdminOverridesResponse.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.serviceusage.v1beta1.ListAdminOverridesResponse",
            value: exports.ListAdminOverridesResponse.encode(message).finish()
        };
    }
};
function createBaseBatchCreateAdminOverridesResponse() {
    return {
        overrides: []
    };
}
exports.BatchCreateAdminOverridesResponse = {
    typeUrl: "/google.api.serviceusage.v1beta1.BatchCreateAdminOverridesResponse",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        for (const v of message.overrides) {
            resources_1.QuotaOverride.encode(v, writer.uint32(10).fork()).ldelim();
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseBatchCreateAdminOverridesResponse();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.overrides.push(resources_1.QuotaOverride.decode(reader, reader.uint32()));
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseBatchCreateAdminOverridesResponse();
        message.overrides = object.overrides?.map(e => resources_1.QuotaOverride.fromPartial(e)) || [];
        return message;
    },
    fromAmino(object) {
        const message = createBaseBatchCreateAdminOverridesResponse();
        message.overrides = object.overrides?.map(e => resources_1.QuotaOverride.fromAmino(e)) || [];
        return message;
    },
    toAmino(message) {
        const obj = {};
        if (message.overrides) {
            obj.overrides = message.overrides.map(e => e ? resources_1.QuotaOverride.toAmino(e) : undefined);
        }
        else {
            obj.overrides = message.overrides;
        }
        return obj;
    },
    fromAminoMsg(object) {
        return exports.BatchCreateAdminOverridesResponse.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.BatchCreateAdminOverridesResponse.decode(message.value);
    },
    toProto(message) {
        return exports.BatchCreateAdminOverridesResponse.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.serviceusage.v1beta1.BatchCreateAdminOverridesResponse",
            value: exports.BatchCreateAdminOverridesResponse.encode(message).finish()
        };
    }
};
function createBaseImportAdminOverridesRequest() {
    return {
        parent: "",
        inlineSource: undefined,
        force: false,
        forceOnly: []
    };
}
exports.ImportAdminOverridesRequest = {
    typeUrl: "/google.api.serviceusage.v1beta1.ImportAdminOverridesRequest",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.parent !== "") {
            writer.uint32(10).string(message.parent);
        }
        if (message.inlineSource !== undefined) {
            resources_1.OverrideInlineSource.encode(message.inlineSource, writer.uint32(18).fork()).ldelim();
        }
        if (message.force === true) {
            writer.uint32(24).bool(message.force);
        }
        writer.uint32(34).fork();
        for (const v of message.forceOnly) {
            writer.int32(v);
        }
        writer.ldelim();
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseImportAdminOverridesRequest();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.parent = reader.string();
                    break;
                case 2:
                    message.inlineSource = resources_1.OverrideInlineSource.decode(reader, reader.uint32());
                    break;
                case 3:
                    message.force = reader.bool();
                    break;
                case 4:
                    if ((tag & 7) === 2) {
                        const end2 = reader.uint32() + reader.pos;
                        while (reader.pos < end2) {
                            message.forceOnly.push(reader.int32());
                        }
                    }
                    else {
                        message.forceOnly.push(reader.int32());
                    }
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseImportAdminOverridesRequest();
        message.parent = object.parent ?? "";
        message.inlineSource = object.inlineSource !== undefined && object.inlineSource !== null ? resources_1.OverrideInlineSource.fromPartial(object.inlineSource) : undefined;
        message.force = object.force ?? false;
        message.forceOnly = object.forceOnly?.map(e => e) || [];
        return message;
    },
    fromAmino(object) {
        const message = createBaseImportAdminOverridesRequest();
        if (object.parent !== undefined && object.parent !== null) {
            message.parent = object.parent;
        }
        if (object.inline_source !== undefined && object.inline_source !== null) {
            message.inlineSource = resources_1.OverrideInlineSource.fromAmino(object.inline_source);
        }
        if (object.force !== undefined && object.force !== null) {
            message.force = object.force;
        }
        message.forceOnly = object.force_only?.map(e => e) || [];
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.parent = message.parent === "" ? undefined : message.parent;
        obj.inline_source = message.inlineSource ? resources_1.OverrideInlineSource.toAmino(message.inlineSource) : undefined;
        obj.force = message.force === false ? undefined : message.force;
        if (message.forceOnly) {
            obj.force_only = message.forceOnly.map(e => e);
        }
        else {
            obj.force_only = message.forceOnly;
        }
        return obj;
    },
    fromAminoMsg(object) {
        return exports.ImportAdminOverridesRequest.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.ImportAdminOverridesRequest.decode(message.value);
    },
    toProto(message) {
        return exports.ImportAdminOverridesRequest.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.serviceusage.v1beta1.ImportAdminOverridesRequest",
            value: exports.ImportAdminOverridesRequest.encode(message).finish()
        };
    }
};
function createBaseImportAdminOverridesResponse() {
    return {
        overrides: []
    };
}
exports.ImportAdminOverridesResponse = {
    typeUrl: "/google.api.serviceusage.v1beta1.ImportAdminOverridesResponse",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        for (const v of message.overrides) {
            resources_1.QuotaOverride.encode(v, writer.uint32(10).fork()).ldelim();
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseImportAdminOverridesResponse();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.overrides.push(resources_1.QuotaOverride.decode(reader, reader.uint32()));
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseImportAdminOverridesResponse();
        message.overrides = object.overrides?.map(e => resources_1.QuotaOverride.fromPartial(e)) || [];
        return message;
    },
    fromAmino(object) {
        const message = createBaseImportAdminOverridesResponse();
        message.overrides = object.overrides?.map(e => resources_1.QuotaOverride.fromAmino(e)) || [];
        return message;
    },
    toAmino(message) {
        const obj = {};
        if (message.overrides) {
            obj.overrides = message.overrides.map(e => e ? resources_1.QuotaOverride.toAmino(e) : undefined);
        }
        else {
            obj.overrides = message.overrides;
        }
        return obj;
    },
    fromAminoMsg(object) {
        return exports.ImportAdminOverridesResponse.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.ImportAdminOverridesResponse.decode(message.value);
    },
    toProto(message) {
        return exports.ImportAdminOverridesResponse.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.serviceusage.v1beta1.ImportAdminOverridesResponse",
            value: exports.ImportAdminOverridesResponse.encode(message).finish()
        };
    }
};
function createBaseImportAdminOverridesMetadata() {
    return {};
}
exports.ImportAdminOverridesMetadata = {
    typeUrl: "/google.api.serviceusage.v1beta1.ImportAdminOverridesMetadata",
    encode(_, writer = binary_1.BinaryWriter.create()) {
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseImportAdminOverridesMetadata();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(_) {
        const message = createBaseImportAdminOverridesMetadata();
        return message;
    },
    fromAmino(_) {
        const message = createBaseImportAdminOverridesMetadata();
        return message;
    },
    toAmino(_) {
        const obj = {};
        return obj;
    },
    fromAminoMsg(object) {
        return exports.ImportAdminOverridesMetadata.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.ImportAdminOverridesMetadata.decode(message.value);
    },
    toProto(message) {
        return exports.ImportAdminOverridesMetadata.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.serviceusage.v1beta1.ImportAdminOverridesMetadata",
            value: exports.ImportAdminOverridesMetadata.encode(message).finish()
        };
    }
};
function createBaseCreateConsumerOverrideRequest() {
    return {
        parent: "",
        override: undefined,
        force: false,
        forceOnly: []
    };
}
exports.CreateConsumerOverrideRequest = {
    typeUrl: "/google.api.serviceusage.v1beta1.CreateConsumerOverrideRequest",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.parent !== "") {
            writer.uint32(10).string(message.parent);
        }
        if (message.override !== undefined) {
            resources_1.QuotaOverride.encode(message.override, writer.uint32(18).fork()).ldelim();
        }
        if (message.force === true) {
            writer.uint32(24).bool(message.force);
        }
        writer.uint32(34).fork();
        for (const v of message.forceOnly) {
            writer.int32(v);
        }
        writer.ldelim();
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseCreateConsumerOverrideRequest();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.parent = reader.string();
                    break;
                case 2:
                    message.override = resources_1.QuotaOverride.decode(reader, reader.uint32());
                    break;
                case 3:
                    message.force = reader.bool();
                    break;
                case 4:
                    if ((tag & 7) === 2) {
                        const end2 = reader.uint32() + reader.pos;
                        while (reader.pos < end2) {
                            message.forceOnly.push(reader.int32());
                        }
                    }
                    else {
                        message.forceOnly.push(reader.int32());
                    }
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseCreateConsumerOverrideRequest();
        message.parent = object.parent ?? "";
        message.override = object.override !== undefined && object.override !== null ? resources_1.QuotaOverride.fromPartial(object.override) : undefined;
        message.force = object.force ?? false;
        message.forceOnly = object.forceOnly?.map(e => e) || [];
        return message;
    },
    fromAmino(object) {
        const message = createBaseCreateConsumerOverrideRequest();
        if (object.parent !== undefined && object.parent !== null) {
            message.parent = object.parent;
        }
        if (object.override !== undefined && object.override !== null) {
            message.override = resources_1.QuotaOverride.fromAmino(object.override);
        }
        if (object.force !== undefined && object.force !== null) {
            message.force = object.force;
        }
        message.forceOnly = object.force_only?.map(e => e) || [];
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.parent = message.parent === "" ? undefined : message.parent;
        obj.override = message.override ? resources_1.QuotaOverride.toAmino(message.override) : undefined;
        obj.force = message.force === false ? undefined : message.force;
        if (message.forceOnly) {
            obj.force_only = message.forceOnly.map(e => e);
        }
        else {
            obj.force_only = message.forceOnly;
        }
        return obj;
    },
    fromAminoMsg(object) {
        return exports.CreateConsumerOverrideRequest.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.CreateConsumerOverrideRequest.decode(message.value);
    },
    toProto(message) {
        return exports.CreateConsumerOverrideRequest.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.serviceusage.v1beta1.CreateConsumerOverrideRequest",
            value: exports.CreateConsumerOverrideRequest.encode(message).finish()
        };
    }
};
function createBaseUpdateConsumerOverrideRequest() {
    return {
        name: "",
        override: undefined,
        force: false,
        updateMask: undefined,
        forceOnly: []
    };
}
exports.UpdateConsumerOverrideRequest = {
    typeUrl: "/google.api.serviceusage.v1beta1.UpdateConsumerOverrideRequest",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.name !== "") {
            writer.uint32(10).string(message.name);
        }
        if (message.override !== undefined) {
            resources_1.QuotaOverride.encode(message.override, writer.uint32(18).fork()).ldelim();
        }
        if (message.force === true) {
            writer.uint32(24).bool(message.force);
        }
        if (message.updateMask !== undefined) {
            field_mask_1.FieldMask.encode(message.updateMask, writer.uint32(34).fork()).ldelim();
        }
        writer.uint32(42).fork();
        for (const v of message.forceOnly) {
            writer.int32(v);
        }
        writer.ldelim();
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseUpdateConsumerOverrideRequest();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.name = reader.string();
                    break;
                case 2:
                    message.override = resources_1.QuotaOverride.decode(reader, reader.uint32());
                    break;
                case 3:
                    message.force = reader.bool();
                    break;
                case 4:
                    message.updateMask = field_mask_1.FieldMask.decode(reader, reader.uint32());
                    break;
                case 5:
                    if ((tag & 7) === 2) {
                        const end2 = reader.uint32() + reader.pos;
                        while (reader.pos < end2) {
                            message.forceOnly.push(reader.int32());
                        }
                    }
                    else {
                        message.forceOnly.push(reader.int32());
                    }
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseUpdateConsumerOverrideRequest();
        message.name = object.name ?? "";
        message.override = object.override !== undefined && object.override !== null ? resources_1.QuotaOverride.fromPartial(object.override) : undefined;
        message.force = object.force ?? false;
        message.updateMask = object.updateMask !== undefined && object.updateMask !== null ? field_mask_1.FieldMask.fromPartial(object.updateMask) : undefined;
        message.forceOnly = object.forceOnly?.map(e => e) || [];
        return message;
    },
    fromAmino(object) {
        const message = createBaseUpdateConsumerOverrideRequest();
        if (object.name !== undefined && object.name !== null) {
            message.name = object.name;
        }
        if (object.override !== undefined && object.override !== null) {
            message.override = resources_1.QuotaOverride.fromAmino(object.override);
        }
        if (object.force !== undefined && object.force !== null) {
            message.force = object.force;
        }
        if (object.update_mask !== undefined && object.update_mask !== null) {
            message.updateMask = field_mask_1.FieldMask.fromAmino(object.update_mask);
        }
        message.forceOnly = object.force_only?.map(e => e) || [];
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.name = message.name === "" ? undefined : message.name;
        obj.override = message.override ? resources_1.QuotaOverride.toAmino(message.override) : undefined;
        obj.force = message.force === false ? undefined : message.force;
        obj.update_mask = message.updateMask ? field_mask_1.FieldMask.toAmino(message.updateMask) : undefined;
        if (message.forceOnly) {
            obj.force_only = message.forceOnly.map(e => e);
        }
        else {
            obj.force_only = message.forceOnly;
        }
        return obj;
    },
    fromAminoMsg(object) {
        return exports.UpdateConsumerOverrideRequest.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.UpdateConsumerOverrideRequest.decode(message.value);
    },
    toProto(message) {
        return exports.UpdateConsumerOverrideRequest.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.serviceusage.v1beta1.UpdateConsumerOverrideRequest",
            value: exports.UpdateConsumerOverrideRequest.encode(message).finish()
        };
    }
};
function createBaseDeleteConsumerOverrideRequest() {
    return {
        name: "",
        force: false,
        forceOnly: []
    };
}
exports.DeleteConsumerOverrideRequest = {
    typeUrl: "/google.api.serviceusage.v1beta1.DeleteConsumerOverrideRequest",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.name !== "") {
            writer.uint32(10).string(message.name);
        }
        if (message.force === true) {
            writer.uint32(16).bool(message.force);
        }
        writer.uint32(26).fork();
        for (const v of message.forceOnly) {
            writer.int32(v);
        }
        writer.ldelim();
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseDeleteConsumerOverrideRequest();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.name = reader.string();
                    break;
                case 2:
                    message.force = reader.bool();
                    break;
                case 3:
                    if ((tag & 7) === 2) {
                        const end2 = reader.uint32() + reader.pos;
                        while (reader.pos < end2) {
                            message.forceOnly.push(reader.int32());
                        }
                    }
                    else {
                        message.forceOnly.push(reader.int32());
                    }
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseDeleteConsumerOverrideRequest();
        message.name = object.name ?? "";
        message.force = object.force ?? false;
        message.forceOnly = object.forceOnly?.map(e => e) || [];
        return message;
    },
    fromAmino(object) {
        const message = createBaseDeleteConsumerOverrideRequest();
        if (object.name !== undefined && object.name !== null) {
            message.name = object.name;
        }
        if (object.force !== undefined && object.force !== null) {
            message.force = object.force;
        }
        message.forceOnly = object.force_only?.map(e => e) || [];
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.name = message.name === "" ? undefined : message.name;
        obj.force = message.force === false ? undefined : message.force;
        if (message.forceOnly) {
            obj.force_only = message.forceOnly.map(e => e);
        }
        else {
            obj.force_only = message.forceOnly;
        }
        return obj;
    },
    fromAminoMsg(object) {
        return exports.DeleteConsumerOverrideRequest.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.DeleteConsumerOverrideRequest.decode(message.value);
    },
    toProto(message) {
        return exports.DeleteConsumerOverrideRequest.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.serviceusage.v1beta1.DeleteConsumerOverrideRequest",
            value: exports.DeleteConsumerOverrideRequest.encode(message).finish()
        };
    }
};
function createBaseListConsumerOverridesRequest() {
    return {
        parent: "",
        pageSize: 0,
        pageToken: ""
    };
}
exports.ListConsumerOverridesRequest = {
    typeUrl: "/google.api.serviceusage.v1beta1.ListConsumerOverridesRequest",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.parent !== "") {
            writer.uint32(10).string(message.parent);
        }
        if (message.pageSize !== 0) {
            writer.uint32(16).int32(message.pageSize);
        }
        if (message.pageToken !== "") {
            writer.uint32(26).string(message.pageToken);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseListConsumerOverridesRequest();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.parent = reader.string();
                    break;
                case 2:
                    message.pageSize = reader.int32();
                    break;
                case 3:
                    message.pageToken = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseListConsumerOverridesRequest();
        message.parent = object.parent ?? "";
        message.pageSize = object.pageSize ?? 0;
        message.pageToken = object.pageToken ?? "";
        return message;
    },
    fromAmino(object) {
        const message = createBaseListConsumerOverridesRequest();
        if (object.parent !== undefined && object.parent !== null) {
            message.parent = object.parent;
        }
        if (object.page_size !== undefined && object.page_size !== null) {
            message.pageSize = object.page_size;
        }
        if (object.page_token !== undefined && object.page_token !== null) {
            message.pageToken = object.page_token;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.parent = message.parent === "" ? undefined : message.parent;
        obj.page_size = message.pageSize === 0 ? undefined : message.pageSize;
        obj.page_token = message.pageToken === "" ? undefined : message.pageToken;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.ListConsumerOverridesRequest.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.ListConsumerOverridesRequest.decode(message.value);
    },
    toProto(message) {
        return exports.ListConsumerOverridesRequest.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.serviceusage.v1beta1.ListConsumerOverridesRequest",
            value: exports.ListConsumerOverridesRequest.encode(message).finish()
        };
    }
};
function createBaseListConsumerOverridesResponse() {
    return {
        overrides: [],
        nextPageToken: ""
    };
}
exports.ListConsumerOverridesResponse = {
    typeUrl: "/google.api.serviceusage.v1beta1.ListConsumerOverridesResponse",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        for (const v of message.overrides) {
            resources_1.QuotaOverride.encode(v, writer.uint32(10).fork()).ldelim();
        }
        if (message.nextPageToken !== "") {
            writer.uint32(18).string(message.nextPageToken);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseListConsumerOverridesResponse();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.overrides.push(resources_1.QuotaOverride.decode(reader, reader.uint32()));
                    break;
                case 2:
                    message.nextPageToken = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseListConsumerOverridesResponse();
        message.overrides = object.overrides?.map(e => resources_1.QuotaOverride.fromPartial(e)) || [];
        message.nextPageToken = object.nextPageToken ?? "";
        return message;
    },
    fromAmino(object) {
        const message = createBaseListConsumerOverridesResponse();
        message.overrides = object.overrides?.map(e => resources_1.QuotaOverride.fromAmino(e)) || [];
        if (object.next_page_token !== undefined && object.next_page_token !== null) {
            message.nextPageToken = object.next_page_token;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        if (message.overrides) {
            obj.overrides = message.overrides.map(e => e ? resources_1.QuotaOverride.toAmino(e) : undefined);
        }
        else {
            obj.overrides = message.overrides;
        }
        obj.next_page_token = message.nextPageToken === "" ? undefined : message.nextPageToken;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.ListConsumerOverridesResponse.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.ListConsumerOverridesResponse.decode(message.value);
    },
    toProto(message) {
        return exports.ListConsumerOverridesResponse.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.serviceusage.v1beta1.ListConsumerOverridesResponse",
            value: exports.ListConsumerOverridesResponse.encode(message).finish()
        };
    }
};
function createBaseBatchCreateConsumerOverridesResponse() {
    return {
        overrides: []
    };
}
exports.BatchCreateConsumerOverridesResponse = {
    typeUrl: "/google.api.serviceusage.v1beta1.BatchCreateConsumerOverridesResponse",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        for (const v of message.overrides) {
            resources_1.QuotaOverride.encode(v, writer.uint32(10).fork()).ldelim();
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseBatchCreateConsumerOverridesResponse();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.overrides.push(resources_1.QuotaOverride.decode(reader, reader.uint32()));
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseBatchCreateConsumerOverridesResponse();
        message.overrides = object.overrides?.map(e => resources_1.QuotaOverride.fromPartial(e)) || [];
        return message;
    },
    fromAmino(object) {
        const message = createBaseBatchCreateConsumerOverridesResponse();
        message.overrides = object.overrides?.map(e => resources_1.QuotaOverride.fromAmino(e)) || [];
        return message;
    },
    toAmino(message) {
        const obj = {};
        if (message.overrides) {
            obj.overrides = message.overrides.map(e => e ? resources_1.QuotaOverride.toAmino(e) : undefined);
        }
        else {
            obj.overrides = message.overrides;
        }
        return obj;
    },
    fromAminoMsg(object) {
        return exports.BatchCreateConsumerOverridesResponse.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.BatchCreateConsumerOverridesResponse.decode(message.value);
    },
    toProto(message) {
        return exports.BatchCreateConsumerOverridesResponse.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.serviceusage.v1beta1.BatchCreateConsumerOverridesResponse",
            value: exports.BatchCreateConsumerOverridesResponse.encode(message).finish()
        };
    }
};
function createBaseImportConsumerOverridesRequest() {
    return {
        parent: "",
        inlineSource: undefined,
        force: false,
        forceOnly: []
    };
}
exports.ImportConsumerOverridesRequest = {
    typeUrl: "/google.api.serviceusage.v1beta1.ImportConsumerOverridesRequest",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.parent !== "") {
            writer.uint32(10).string(message.parent);
        }
        if (message.inlineSource !== undefined) {
            resources_1.OverrideInlineSource.encode(message.inlineSource, writer.uint32(18).fork()).ldelim();
        }
        if (message.force === true) {
            writer.uint32(24).bool(message.force);
        }
        writer.uint32(34).fork();
        for (const v of message.forceOnly) {
            writer.int32(v);
        }
        writer.ldelim();
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseImportConsumerOverridesRequest();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.parent = reader.string();
                    break;
                case 2:
                    message.inlineSource = resources_1.OverrideInlineSource.decode(reader, reader.uint32());
                    break;
                case 3:
                    message.force = reader.bool();
                    break;
                case 4:
                    if ((tag & 7) === 2) {
                        const end2 = reader.uint32() + reader.pos;
                        while (reader.pos < end2) {
                            message.forceOnly.push(reader.int32());
                        }
                    }
                    else {
                        message.forceOnly.push(reader.int32());
                    }
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseImportConsumerOverridesRequest();
        message.parent = object.parent ?? "";
        message.inlineSource = object.inlineSource !== undefined && object.inlineSource !== null ? resources_1.OverrideInlineSource.fromPartial(object.inlineSource) : undefined;
        message.force = object.force ?? false;
        message.forceOnly = object.forceOnly?.map(e => e) || [];
        return message;
    },
    fromAmino(object) {
        const message = createBaseImportConsumerOverridesRequest();
        if (object.parent !== undefined && object.parent !== null) {
            message.parent = object.parent;
        }
        if (object.inline_source !== undefined && object.inline_source !== null) {
            message.inlineSource = resources_1.OverrideInlineSource.fromAmino(object.inline_source);
        }
        if (object.force !== undefined && object.force !== null) {
            message.force = object.force;
        }
        message.forceOnly = object.force_only?.map(e => e) || [];
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.parent = message.parent === "" ? undefined : message.parent;
        obj.inline_source = message.inlineSource ? resources_1.OverrideInlineSource.toAmino(message.inlineSource) : undefined;
        obj.force = message.force === false ? undefined : message.force;
        if (message.forceOnly) {
            obj.force_only = message.forceOnly.map(e => e);
        }
        else {
            obj.force_only = message.forceOnly;
        }
        return obj;
    },
    fromAminoMsg(object) {
        return exports.ImportConsumerOverridesRequest.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.ImportConsumerOverridesRequest.decode(message.value);
    },
    toProto(message) {
        return exports.ImportConsumerOverridesRequest.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.serviceusage.v1beta1.ImportConsumerOverridesRequest",
            value: exports.ImportConsumerOverridesRequest.encode(message).finish()
        };
    }
};
function createBaseImportConsumerOverridesResponse() {
    return {
        overrides: []
    };
}
exports.ImportConsumerOverridesResponse = {
    typeUrl: "/google.api.serviceusage.v1beta1.ImportConsumerOverridesResponse",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        for (const v of message.overrides) {
            resources_1.QuotaOverride.encode(v, writer.uint32(10).fork()).ldelim();
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseImportConsumerOverridesResponse();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.overrides.push(resources_1.QuotaOverride.decode(reader, reader.uint32()));
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseImportConsumerOverridesResponse();
        message.overrides = object.overrides?.map(e => resources_1.QuotaOverride.fromPartial(e)) || [];
        return message;
    },
    fromAmino(object) {
        const message = createBaseImportConsumerOverridesResponse();
        message.overrides = object.overrides?.map(e => resources_1.QuotaOverride.fromAmino(e)) || [];
        return message;
    },
    toAmino(message) {
        const obj = {};
        if (message.overrides) {
            obj.overrides = message.overrides.map(e => e ? resources_1.QuotaOverride.toAmino(e) : undefined);
        }
        else {
            obj.overrides = message.overrides;
        }
        return obj;
    },
    fromAminoMsg(object) {
        return exports.ImportConsumerOverridesResponse.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.ImportConsumerOverridesResponse.decode(message.value);
    },
    toProto(message) {
        return exports.ImportConsumerOverridesResponse.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.serviceusage.v1beta1.ImportConsumerOverridesResponse",
            value: exports.ImportConsumerOverridesResponse.encode(message).finish()
        };
    }
};
function createBaseImportConsumerOverridesMetadata() {
    return {};
}
exports.ImportConsumerOverridesMetadata = {
    typeUrl: "/google.api.serviceusage.v1beta1.ImportConsumerOverridesMetadata",
    encode(_, writer = binary_1.BinaryWriter.create()) {
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseImportConsumerOverridesMetadata();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(_) {
        const message = createBaseImportConsumerOverridesMetadata();
        return message;
    },
    fromAmino(_) {
        const message = createBaseImportConsumerOverridesMetadata();
        return message;
    },
    toAmino(_) {
        const obj = {};
        return obj;
    },
    fromAminoMsg(object) {
        return exports.ImportConsumerOverridesMetadata.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.ImportConsumerOverridesMetadata.decode(message.value);
    },
    toProto(message) {
        return exports.ImportConsumerOverridesMetadata.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.serviceusage.v1beta1.ImportConsumerOverridesMetadata",
            value: exports.ImportConsumerOverridesMetadata.encode(message).finish()
        };
    }
};
function createBaseImportAdminQuotaPoliciesResponse() {
    return {
        policies: []
    };
}
exports.ImportAdminQuotaPoliciesResponse = {
    typeUrl: "/google.api.serviceusage.v1beta1.ImportAdminQuotaPoliciesResponse",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        for (const v of message.policies) {
            resources_1.AdminQuotaPolicy.encode(v, writer.uint32(10).fork()).ldelim();
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseImportAdminQuotaPoliciesResponse();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.policies.push(resources_1.AdminQuotaPolicy.decode(reader, reader.uint32()));
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseImportAdminQuotaPoliciesResponse();
        message.policies = object.policies?.map(e => resources_1.AdminQuotaPolicy.fromPartial(e)) || [];
        return message;
    },
    fromAmino(object) {
        const message = createBaseImportAdminQuotaPoliciesResponse();
        message.policies = object.policies?.map(e => resources_1.AdminQuotaPolicy.fromAmino(e)) || [];
        return message;
    },
    toAmino(message) {
        const obj = {};
        if (message.policies) {
            obj.policies = message.policies.map(e => e ? resources_1.AdminQuotaPolicy.toAmino(e) : undefined);
        }
        else {
            obj.policies = message.policies;
        }
        return obj;
    },
    fromAminoMsg(object) {
        return exports.ImportAdminQuotaPoliciesResponse.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.ImportAdminQuotaPoliciesResponse.decode(message.value);
    },
    toProto(message) {
        return exports.ImportAdminQuotaPoliciesResponse.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.serviceusage.v1beta1.ImportAdminQuotaPoliciesResponse",
            value: exports.ImportAdminQuotaPoliciesResponse.encode(message).finish()
        };
    }
};
function createBaseImportAdminQuotaPoliciesMetadata() {
    return {};
}
exports.ImportAdminQuotaPoliciesMetadata = {
    typeUrl: "/google.api.serviceusage.v1beta1.ImportAdminQuotaPoliciesMetadata",
    encode(_, writer = binary_1.BinaryWriter.create()) {
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseImportAdminQuotaPoliciesMetadata();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(_) {
        const message = createBaseImportAdminQuotaPoliciesMetadata();
        return message;
    },
    fromAmino(_) {
        const message = createBaseImportAdminQuotaPoliciesMetadata();
        return message;
    },
    toAmino(_) {
        const obj = {};
        return obj;
    },
    fromAminoMsg(object) {
        return exports.ImportAdminQuotaPoliciesMetadata.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.ImportAdminQuotaPoliciesMetadata.decode(message.value);
    },
    toProto(message) {
        return exports.ImportAdminQuotaPoliciesMetadata.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.serviceusage.v1beta1.ImportAdminQuotaPoliciesMetadata",
            value: exports.ImportAdminQuotaPoliciesMetadata.encode(message).finish()
        };
    }
};
function createBaseCreateAdminQuotaPolicyMetadata() {
    return {};
}
exports.CreateAdminQuotaPolicyMetadata = {
    typeUrl: "/google.api.serviceusage.v1beta1.CreateAdminQuotaPolicyMetadata",
    encode(_, writer = binary_1.BinaryWriter.create()) {
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseCreateAdminQuotaPolicyMetadata();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(_) {
        const message = createBaseCreateAdminQuotaPolicyMetadata();
        return message;
    },
    fromAmino(_) {
        const message = createBaseCreateAdminQuotaPolicyMetadata();
        return message;
    },
    toAmino(_) {
        const obj = {};
        return obj;
    },
    fromAminoMsg(object) {
        return exports.CreateAdminQuotaPolicyMetadata.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.CreateAdminQuotaPolicyMetadata.decode(message.value);
    },
    toProto(message) {
        return exports.CreateAdminQuotaPolicyMetadata.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.serviceusage.v1beta1.CreateAdminQuotaPolicyMetadata",
            value: exports.CreateAdminQuotaPolicyMetadata.encode(message).finish()
        };
    }
};
function createBaseUpdateAdminQuotaPolicyMetadata() {
    return {};
}
exports.UpdateAdminQuotaPolicyMetadata = {
    typeUrl: "/google.api.serviceusage.v1beta1.UpdateAdminQuotaPolicyMetadata",
    encode(_, writer = binary_1.BinaryWriter.create()) {
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseUpdateAdminQuotaPolicyMetadata();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(_) {
        const message = createBaseUpdateAdminQuotaPolicyMetadata();
        return message;
    },
    fromAmino(_) {
        const message = createBaseUpdateAdminQuotaPolicyMetadata();
        return message;
    },
    toAmino(_) {
        const obj = {};
        return obj;
    },
    fromAminoMsg(object) {
        return exports.UpdateAdminQuotaPolicyMetadata.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.UpdateAdminQuotaPolicyMetadata.decode(message.value);
    },
    toProto(message) {
        return exports.UpdateAdminQuotaPolicyMetadata.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.serviceusage.v1beta1.UpdateAdminQuotaPolicyMetadata",
            value: exports.UpdateAdminQuotaPolicyMetadata.encode(message).finish()
        };
    }
};
function createBaseDeleteAdminQuotaPolicyMetadata() {
    return {};
}
exports.DeleteAdminQuotaPolicyMetadata = {
    typeUrl: "/google.api.serviceusage.v1beta1.DeleteAdminQuotaPolicyMetadata",
    encode(_, writer = binary_1.BinaryWriter.create()) {
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseDeleteAdminQuotaPolicyMetadata();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(_) {
        const message = createBaseDeleteAdminQuotaPolicyMetadata();
        return message;
    },
    fromAmino(_) {
        const message = createBaseDeleteAdminQuotaPolicyMetadata();
        return message;
    },
    toAmino(_) {
        const obj = {};
        return obj;
    },
    fromAminoMsg(object) {
        return exports.DeleteAdminQuotaPolicyMetadata.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.DeleteAdminQuotaPolicyMetadata.decode(message.value);
    },
    toProto(message) {
        return exports.DeleteAdminQuotaPolicyMetadata.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.serviceusage.v1beta1.DeleteAdminQuotaPolicyMetadata",
            value: exports.DeleteAdminQuotaPolicyMetadata.encode(message).finish()
        };
    }
};
function createBaseGenerateServiceIdentityRequest() {
    return {
        parent: ""
    };
}
exports.GenerateServiceIdentityRequest = {
    typeUrl: "/google.api.serviceusage.v1beta1.GenerateServiceIdentityRequest",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.parent !== "") {
            writer.uint32(10).string(message.parent);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseGenerateServiceIdentityRequest();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.parent = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseGenerateServiceIdentityRequest();
        message.parent = object.parent ?? "";
        return message;
    },
    fromAmino(object) {
        const message = createBaseGenerateServiceIdentityRequest();
        if (object.parent !== undefined && object.parent !== null) {
            message.parent = object.parent;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.parent = message.parent === "" ? undefined : message.parent;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.GenerateServiceIdentityRequest.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.GenerateServiceIdentityRequest.decode(message.value);
    },
    toProto(message) {
        return exports.GenerateServiceIdentityRequest.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.serviceusage.v1beta1.GenerateServiceIdentityRequest",
            value: exports.GenerateServiceIdentityRequest.encode(message).finish()
        };
    }
};
function createBaseGetServiceIdentityResponse() {
    return {
        identity: undefined,
        state: 0
    };
}
exports.GetServiceIdentityResponse = {
    typeUrl: "/google.api.serviceusage.v1beta1.GetServiceIdentityResponse",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.identity !== undefined) {
            resources_1.ServiceIdentity.encode(message.identity, writer.uint32(10).fork()).ldelim();
        }
        if (message.state !== 0) {
            writer.uint32(16).int32(message.state);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseGetServiceIdentityResponse();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.identity = resources_1.ServiceIdentity.decode(reader, reader.uint32());
                    break;
                case 2:
                    message.state = reader.int32();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseGetServiceIdentityResponse();
        message.identity = object.identity !== undefined && object.identity !== null ? resources_1.ServiceIdentity.fromPartial(object.identity) : undefined;
        message.state = object.state ?? 0;
        return message;
    },
    fromAmino(object) {
        const message = createBaseGetServiceIdentityResponse();
        if (object.identity !== undefined && object.identity !== null) {
            message.identity = resources_1.ServiceIdentity.fromAmino(object.identity);
        }
        if (object.state !== undefined && object.state !== null) {
            message.state = object.state;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.identity = message.identity ? resources_1.ServiceIdentity.toAmino(message.identity) : undefined;
        obj.state = message.state === 0 ? undefined : message.state;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.GetServiceIdentityResponse.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.GetServiceIdentityResponse.decode(message.value);
    },
    toProto(message) {
        return exports.GetServiceIdentityResponse.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.serviceusage.v1beta1.GetServiceIdentityResponse",
            value: exports.GetServiceIdentityResponse.encode(message).finish()
        };
    }
};
function createBaseGetServiceIdentityMetadata() {
    return {};
}
exports.GetServiceIdentityMetadata = {
    typeUrl: "/google.api.serviceusage.v1beta1.GetServiceIdentityMetadata",
    encode(_, writer = binary_1.BinaryWriter.create()) {
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseGetServiceIdentityMetadata();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(_) {
        const message = createBaseGetServiceIdentityMetadata();
        return message;
    },
    fromAmino(_) {
        const message = createBaseGetServiceIdentityMetadata();
        return message;
    },
    toAmino(_) {
        const obj = {};
        return obj;
    },
    fromAminoMsg(object) {
        return exports.GetServiceIdentityMetadata.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.GetServiceIdentityMetadata.decode(message.value);
    },
    toProto(message) {
        return exports.GetServiceIdentityMetadata.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.serviceusage.v1beta1.GetServiceIdentityMetadata",
            value: exports.GetServiceIdentityMetadata.encode(message).finish()
        };
    }
};
