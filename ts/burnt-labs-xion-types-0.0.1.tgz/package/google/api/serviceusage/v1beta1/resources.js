"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ServiceIdentity = exports.AdminQuotaPolicy = exports.AdminQuotaPolicy_DimensionsEntry = exports.ProducerQuotaPolicy = exports.ProducerQuotaPolicy_DimensionsEntry = exports.OverrideInlineSource = exports.QuotaOverride = exports.QuotaOverride_DimensionsEntry = exports.QuotaBucket = exports.QuotaBucket_DimensionsEntry = exports.ConsumerQuotaLimit = exports.ConsumerQuotaMetric = exports.OperationMetadata = exports.ServiceConfig = exports.Service = exports.QuotaSafetyCheckAmino = exports.QuotaSafetyCheckSDKType = exports.QuotaSafetyCheck = exports.QuotaViewAmino = exports.QuotaViewSDKType = exports.QuotaView = exports.StateAmino = exports.StateSDKType = exports.State = void 0;
exports.stateFromJSON = stateFromJSON;
exports.stateToJSON = stateToJSON;
exports.quotaViewFromJSON = quotaViewFromJSON;
exports.quotaViewToJSON = quotaViewToJSON;
exports.quotaSafetyCheckFromJSON = quotaSafetyCheckFromJSON;
exports.quotaSafetyCheckToJSON = quotaSafetyCheckToJSON;
//@ts-nocheck
const api_1 = require("../../../protobuf/api");
const documentation_1 = require("../../documentation");
const quota_1 = require("../../quota");
const auth_1 = require("../../auth");
const usage_1 = require("../../usage");
const endpoint_1 = require("../../endpoint");
const monitored_resource_1 = require("../../monitored_resource");
const monitoring_1 = require("../../monitoring");
const binary_1 = require("../../../../binary");
/** Whether or not a service has been enabled for use by a consumer. */
var State;
(function (State) {
    /**
     * STATE_UNSPECIFIED - The default value, which indicates that the enabled state of the service
     * is unspecified or not meaningful. Currently, all consumers other than
     * projects (such as folders and organizations) are always in this state.
     */
    State[State["STATE_UNSPECIFIED"] = 0] = "STATE_UNSPECIFIED";
    /**
     * DISABLED - The service cannot be used by this consumer. It has either been explicitly
     * disabled, or has never been enabled.
     */
    State[State["DISABLED"] = 1] = "DISABLED";
    /** ENABLED - The service has been explicitly enabled for use by this consumer. */
    State[State["ENABLED"] = 2] = "ENABLED";
    State[State["UNRECOGNIZED"] = -1] = "UNRECOGNIZED";
})(State || (exports.State = State = {}));
exports.StateSDKType = State;
exports.StateAmino = State;
function stateFromJSON(object) {
    switch (object) {
        case 0:
        case "STATE_UNSPECIFIED":
            return State.STATE_UNSPECIFIED;
        case 1:
        case "DISABLED":
            return State.DISABLED;
        case 2:
        case "ENABLED":
            return State.ENABLED;
        case -1:
        case "UNRECOGNIZED":
        default:
            return State.UNRECOGNIZED;
    }
}
function stateToJSON(object) {
    switch (object) {
        case State.STATE_UNSPECIFIED:
            return "STATE_UNSPECIFIED";
        case State.DISABLED:
            return "DISABLED";
        case State.ENABLED:
            return "ENABLED";
        case State.UNRECOGNIZED:
        default:
            return "UNRECOGNIZED";
    }
}
/**
 * Selected view of quota. Can be used to request more detailed quota
 * information when retrieving quota metrics and limits.
 */
var QuotaView;
(function (QuotaView) {
    /**
     * QUOTA_VIEW_UNSPECIFIED - No quota view specified. Requests that do not specify a quota view will
     * typically default to the BASIC view.
     */
    QuotaView[QuotaView["QUOTA_VIEW_UNSPECIFIED"] = 0] = "QUOTA_VIEW_UNSPECIFIED";
    /** BASIC - Only buckets with overrides are shown in the response. */
    QuotaView[QuotaView["BASIC"] = 1] = "BASIC";
    /**
     * FULL - Include per-location buckets even if they do not have overrides.
     * When the view is FULL, and a limit has regional or zonal quota, the limit
     * will include buckets for all regions or zones that could support
     * overrides, even if none are currently present. In some cases this will
     * cause the response to become very large; callers that do not need this
     * extra information should use the BASIC view instead.
     */
    QuotaView[QuotaView["FULL"] = 2] = "FULL";
    QuotaView[QuotaView["UNRECOGNIZED"] = -1] = "UNRECOGNIZED";
})(QuotaView || (exports.QuotaView = QuotaView = {}));
exports.QuotaViewSDKType = QuotaView;
exports.QuotaViewAmino = QuotaView;
function quotaViewFromJSON(object) {
    switch (object) {
        case 0:
        case "QUOTA_VIEW_UNSPECIFIED":
            return QuotaView.QUOTA_VIEW_UNSPECIFIED;
        case 1:
        case "BASIC":
            return QuotaView.BASIC;
        case 2:
        case "FULL":
            return QuotaView.FULL;
        case -1:
        case "UNRECOGNIZED":
        default:
            return QuotaView.UNRECOGNIZED;
    }
}
function quotaViewToJSON(object) {
    switch (object) {
        case QuotaView.QUOTA_VIEW_UNSPECIFIED:
            return "QUOTA_VIEW_UNSPECIFIED";
        case QuotaView.BASIC:
            return "BASIC";
        case QuotaView.FULL:
            return "FULL";
        case QuotaView.UNRECOGNIZED:
        default:
            return "UNRECOGNIZED";
    }
}
/** Enumerations of quota safety checks. */
var QuotaSafetyCheck;
(function (QuotaSafetyCheck) {
    /** QUOTA_SAFETY_CHECK_UNSPECIFIED - Unspecified quota safety check. */
    QuotaSafetyCheck[QuotaSafetyCheck["QUOTA_SAFETY_CHECK_UNSPECIFIED"] = 0] = "QUOTA_SAFETY_CHECK_UNSPECIFIED";
    /**
     * LIMIT_DECREASE_BELOW_USAGE - Validates that a quota mutation would not cause the consumer's effective
     * limit to be lower than the consumer's quota usage.
     */
    QuotaSafetyCheck[QuotaSafetyCheck["LIMIT_DECREASE_BELOW_USAGE"] = 1] = "LIMIT_DECREASE_BELOW_USAGE";
    /**
     * LIMIT_DECREASE_PERCENTAGE_TOO_HIGH - Validates that a quota mutation would not cause the consumer's effective
     * limit to decrease by more than 10 percent.
     */
    QuotaSafetyCheck[QuotaSafetyCheck["LIMIT_DECREASE_PERCENTAGE_TOO_HIGH"] = 2] = "LIMIT_DECREASE_PERCENTAGE_TOO_HIGH";
    QuotaSafetyCheck[QuotaSafetyCheck["UNRECOGNIZED"] = -1] = "UNRECOGNIZED";
})(QuotaSafetyCheck || (exports.QuotaSafetyCheck = QuotaSafetyCheck = {}));
exports.QuotaSafetyCheckSDKType = QuotaSafetyCheck;
exports.QuotaSafetyCheckAmino = QuotaSafetyCheck;
function quotaSafetyCheckFromJSON(object) {
    switch (object) {
        case 0:
        case "QUOTA_SAFETY_CHECK_UNSPECIFIED":
            return QuotaSafetyCheck.QUOTA_SAFETY_CHECK_UNSPECIFIED;
        case 1:
        case "LIMIT_DECREASE_BELOW_USAGE":
            return QuotaSafetyCheck.LIMIT_DECREASE_BELOW_USAGE;
        case 2:
        case "LIMIT_DECREASE_PERCENTAGE_TOO_HIGH":
            return QuotaSafetyCheck.LIMIT_DECREASE_PERCENTAGE_TOO_HIGH;
        case -1:
        case "UNRECOGNIZED":
        default:
            return QuotaSafetyCheck.UNRECOGNIZED;
    }
}
function quotaSafetyCheckToJSON(object) {
    switch (object) {
        case QuotaSafetyCheck.QUOTA_SAFETY_CHECK_UNSPECIFIED:
            return "QUOTA_SAFETY_CHECK_UNSPECIFIED";
        case QuotaSafetyCheck.LIMIT_DECREASE_BELOW_USAGE:
            return "LIMIT_DECREASE_BELOW_USAGE";
        case QuotaSafetyCheck.LIMIT_DECREASE_PERCENTAGE_TOO_HIGH:
            return "LIMIT_DECREASE_PERCENTAGE_TOO_HIGH";
        case QuotaSafetyCheck.UNRECOGNIZED:
        default:
            return "UNRECOGNIZED";
    }
}
function createBaseService() {
    return {
        name: "",
        parent: "",
        config: undefined,
        state: 0
    };
}
exports.Service = {
    typeUrl: "/google.api.serviceusage.v1beta1.Service",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.name !== "") {
            writer.uint32(10).string(message.name);
        }
        if (message.parent !== "") {
            writer.uint32(42).string(message.parent);
        }
        if (message.config !== undefined) {
            exports.ServiceConfig.encode(message.config, writer.uint32(18).fork()).ldelim();
        }
        if (message.state !== 0) {
            writer.uint32(32).int32(message.state);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseService();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.name = reader.string();
                    break;
                case 5:
                    message.parent = reader.string();
                    break;
                case 2:
                    message.config = exports.ServiceConfig.decode(reader, reader.uint32());
                    break;
                case 4:
                    message.state = reader.int32();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseService();
        message.name = object.name ?? "";
        message.parent = object.parent ?? "";
        message.config = object.config !== undefined && object.config !== null ? exports.ServiceConfig.fromPartial(object.config) : undefined;
        message.state = object.state ?? 0;
        return message;
    },
    fromAmino(object) {
        const message = createBaseService();
        if (object.name !== undefined && object.name !== null) {
            message.name = object.name;
        }
        if (object.parent !== undefined && object.parent !== null) {
            message.parent = object.parent;
        }
        if (object.config !== undefined && object.config !== null) {
            message.config = exports.ServiceConfig.fromAmino(object.config);
        }
        if (object.state !== undefined && object.state !== null) {
            message.state = object.state;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.name = message.name === "" ? undefined : message.name;
        obj.parent = message.parent === "" ? undefined : message.parent;
        obj.config = message.config ? exports.ServiceConfig.toAmino(message.config) : undefined;
        obj.state = message.state === 0 ? undefined : message.state;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.Service.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.Service.decode(message.value);
    },
    toProto(message) {
        return exports.Service.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.serviceusage.v1beta1.Service",
            value: exports.Service.encode(message).finish()
        };
    }
};
function createBaseServiceConfig() {
    return {
        name: "",
        title: "",
        apis: [],
        documentation: undefined,
        quota: undefined,
        authentication: undefined,
        usage: undefined,
        endpoints: [],
        monitoredResources: [],
        monitoring: undefined
    };
}
exports.ServiceConfig = {
    typeUrl: "/google.api.serviceusage.v1beta1.ServiceConfig",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.name !== "") {
            writer.uint32(10).string(message.name);
        }
        if (message.title !== "") {
            writer.uint32(18).string(message.title);
        }
        for (const v of message.apis) {
            api_1.Api.encode(v, writer.uint32(26).fork()).ldelim();
        }
        if (message.documentation !== undefined) {
            documentation_1.Documentation.encode(message.documentation, writer.uint32(50).fork()).ldelim();
        }
        if (message.quota !== undefined) {
            quota_1.Quota.encode(message.quota, writer.uint32(82).fork()).ldelim();
        }
        if (message.authentication !== undefined) {
            auth_1.Authentication.encode(message.authentication, writer.uint32(90).fork()).ldelim();
        }
        if (message.usage !== undefined) {
            usage_1.Usage.encode(message.usage, writer.uint32(122).fork()).ldelim();
        }
        for (const v of message.endpoints) {
            endpoint_1.Endpoint.encode(v, writer.uint32(146).fork()).ldelim();
        }
        for (const v of message.monitoredResources) {
            monitored_resource_1.MonitoredResourceDescriptor.encode(v, writer.uint32(202).fork()).ldelim();
        }
        if (message.monitoring !== undefined) {
            monitoring_1.Monitoring.encode(message.monitoring, writer.uint32(226).fork()).ldelim();
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseServiceConfig();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.name = reader.string();
                    break;
                case 2:
                    message.title = reader.string();
                    break;
                case 3:
                    message.apis.push(api_1.Api.decode(reader, reader.uint32()));
                    break;
                case 6:
                    message.documentation = documentation_1.Documentation.decode(reader, reader.uint32());
                    break;
                case 10:
                    message.quota = quota_1.Quota.decode(reader, reader.uint32());
                    break;
                case 11:
                    message.authentication = auth_1.Authentication.decode(reader, reader.uint32());
                    break;
                case 15:
                    message.usage = usage_1.Usage.decode(reader, reader.uint32());
                    break;
                case 18:
                    message.endpoints.push(endpoint_1.Endpoint.decode(reader, reader.uint32()));
                    break;
                case 25:
                    message.monitoredResources.push(monitored_resource_1.MonitoredResourceDescriptor.decode(reader, reader.uint32()));
                    break;
                case 28:
                    message.monitoring = monitoring_1.Monitoring.decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseServiceConfig();
        message.name = object.name ?? "";
        message.title = object.title ?? "";
        message.apis = object.apis?.map(e => api_1.Api.fromPartial(e)) || [];
        message.documentation = object.documentation !== undefined && object.documentation !== null ? documentation_1.Documentation.fromPartial(object.documentation) : undefined;
        message.quota = object.quota !== undefined && object.quota !== null ? quota_1.Quota.fromPartial(object.quota) : undefined;
        message.authentication = object.authentication !== undefined && object.authentication !== null ? auth_1.Authentication.fromPartial(object.authentication) : undefined;
        message.usage = object.usage !== undefined && object.usage !== null ? usage_1.Usage.fromPartial(object.usage) : undefined;
        message.endpoints = object.endpoints?.map(e => endpoint_1.Endpoint.fromPartial(e)) || [];
        message.monitoredResources = object.monitoredResources?.map(e => monitored_resource_1.MonitoredResourceDescriptor.fromPartial(e)) || [];
        message.monitoring = object.monitoring !== undefined && object.monitoring !== null ? monitoring_1.Monitoring.fromPartial(object.monitoring) : undefined;
        return message;
    },
    fromAmino(object) {
        const message = createBaseServiceConfig();
        if (object.name !== undefined && object.name !== null) {
            message.name = object.name;
        }
        if (object.title !== undefined && object.title !== null) {
            message.title = object.title;
        }
        message.apis = object.apis?.map(e => api_1.Api.fromAmino(e)) || [];
        if (object.documentation !== undefined && object.documentation !== null) {
            message.documentation = documentation_1.Documentation.fromAmino(object.documentation);
        }
        if (object.quota !== undefined && object.quota !== null) {
            message.quota = quota_1.Quota.fromAmino(object.quota);
        }
        if (object.authentication !== undefined && object.authentication !== null) {
            message.authentication = auth_1.Authentication.fromAmino(object.authentication);
        }
        if (object.usage !== undefined && object.usage !== null) {
            message.usage = usage_1.Usage.fromAmino(object.usage);
        }
        message.endpoints = object.endpoints?.map(e => endpoint_1.Endpoint.fromAmino(e)) || [];
        message.monitoredResources = object.monitored_resources?.map(e => monitored_resource_1.MonitoredResourceDescriptor.fromAmino(e)) || [];
        if (object.monitoring !== undefined && object.monitoring !== null) {
            message.monitoring = monitoring_1.Monitoring.fromAmino(object.monitoring);
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.name = message.name === "" ? undefined : message.name;
        obj.title = message.title === "" ? undefined : message.title;
        if (message.apis) {
            obj.apis = message.apis.map(e => e ? api_1.Api.toAmino(e) : undefined);
        }
        else {
            obj.apis = message.apis;
        }
        obj.documentation = message.documentation ? documentation_1.Documentation.toAmino(message.documentation) : undefined;
        obj.quota = message.quota ? quota_1.Quota.toAmino(message.quota) : undefined;
        obj.authentication = message.authentication ? auth_1.Authentication.toAmino(message.authentication) : undefined;
        obj.usage = message.usage ? usage_1.Usage.toAmino(message.usage) : undefined;
        if (message.endpoints) {
            obj.endpoints = message.endpoints.map(e => e ? endpoint_1.Endpoint.toAmino(e) : undefined);
        }
        else {
            obj.endpoints = message.endpoints;
        }
        if (message.monitoredResources) {
            obj.monitored_resources = message.monitoredResources.map(e => e ? monitored_resource_1.MonitoredResourceDescriptor.toAmino(e) : undefined);
        }
        else {
            obj.monitored_resources = message.monitoredResources;
        }
        obj.monitoring = message.monitoring ? monitoring_1.Monitoring.toAmino(message.monitoring) : undefined;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.ServiceConfig.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.ServiceConfig.decode(message.value);
    },
    toProto(message) {
        return exports.ServiceConfig.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.serviceusage.v1beta1.ServiceConfig",
            value: exports.ServiceConfig.encode(message).finish()
        };
    }
};
function createBaseOperationMetadata() {
    return {
        resourceNames: []
    };
}
exports.OperationMetadata = {
    typeUrl: "/google.api.serviceusage.v1beta1.OperationMetadata",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        for (const v of message.resourceNames) {
            writer.uint32(18).string(v);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseOperationMetadata();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 2:
                    message.resourceNames.push(reader.string());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseOperationMetadata();
        message.resourceNames = object.resourceNames?.map(e => e) || [];
        return message;
    },
    fromAmino(object) {
        const message = createBaseOperationMetadata();
        message.resourceNames = object.resource_names?.map(e => e) || [];
        return message;
    },
    toAmino(message) {
        const obj = {};
        if (message.resourceNames) {
            obj.resource_names = message.resourceNames.map(e => e);
        }
        else {
            obj.resource_names = message.resourceNames;
        }
        return obj;
    },
    fromAminoMsg(object) {
        return exports.OperationMetadata.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.OperationMetadata.decode(message.value);
    },
    toProto(message) {
        return exports.OperationMetadata.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.serviceusage.v1beta1.OperationMetadata",
            value: exports.OperationMetadata.encode(message).finish()
        };
    }
};
function createBaseConsumerQuotaMetric() {
    return {
        name: "",
        metric: "",
        displayName: "",
        consumerQuotaLimits: [],
        descendantConsumerQuotaLimits: [],
        unit: ""
    };
}
exports.ConsumerQuotaMetric = {
    typeUrl: "/google.api.serviceusage.v1beta1.ConsumerQuotaMetric",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.name !== "") {
            writer.uint32(10).string(message.name);
        }
        if (message.metric !== "") {
            writer.uint32(34).string(message.metric);
        }
        if (message.displayName !== "") {
            writer.uint32(18).string(message.displayName);
        }
        for (const v of message.consumerQuotaLimits) {
            exports.ConsumerQuotaLimit.encode(v, writer.uint32(26).fork()).ldelim();
        }
        for (const v of message.descendantConsumerQuotaLimits) {
            exports.ConsumerQuotaLimit.encode(v, writer.uint32(50).fork()).ldelim();
        }
        if (message.unit !== "") {
            writer.uint32(42).string(message.unit);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseConsumerQuotaMetric();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.name = reader.string();
                    break;
                case 4:
                    message.metric = reader.string();
                    break;
                case 2:
                    message.displayName = reader.string();
                    break;
                case 3:
                    message.consumerQuotaLimits.push(exports.ConsumerQuotaLimit.decode(reader, reader.uint32()));
                    break;
                case 6:
                    message.descendantConsumerQuotaLimits.push(exports.ConsumerQuotaLimit.decode(reader, reader.uint32()));
                    break;
                case 5:
                    message.unit = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseConsumerQuotaMetric();
        message.name = object.name ?? "";
        message.metric = object.metric ?? "";
        message.displayName = object.displayName ?? "";
        message.consumerQuotaLimits = object.consumerQuotaLimits?.map(e => exports.ConsumerQuotaLimit.fromPartial(e)) || [];
        message.descendantConsumerQuotaLimits = object.descendantConsumerQuotaLimits?.map(e => exports.ConsumerQuotaLimit.fromPartial(e)) || [];
        message.unit = object.unit ?? "";
        return message;
    },
    fromAmino(object) {
        const message = createBaseConsumerQuotaMetric();
        if (object.name !== undefined && object.name !== null) {
            message.name = object.name;
        }
        if (object.metric !== undefined && object.metric !== null) {
            message.metric = object.metric;
        }
        if (object.display_name !== undefined && object.display_name !== null) {
            message.displayName = object.display_name;
        }
        message.consumerQuotaLimits = object.consumer_quota_limits?.map(e => exports.ConsumerQuotaLimit.fromAmino(e)) || [];
        message.descendantConsumerQuotaLimits = object.descendant_consumer_quota_limits?.map(e => exports.ConsumerQuotaLimit.fromAmino(e)) || [];
        if (object.unit !== undefined && object.unit !== null) {
            message.unit = object.unit;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.name = message.name === "" ? undefined : message.name;
        obj.metric = message.metric === "" ? undefined : message.metric;
        obj.display_name = message.displayName === "" ? undefined : message.displayName;
        if (message.consumerQuotaLimits) {
            obj.consumer_quota_limits = message.consumerQuotaLimits.map(e => e ? exports.ConsumerQuotaLimit.toAmino(e) : undefined);
        }
        else {
            obj.consumer_quota_limits = message.consumerQuotaLimits;
        }
        if (message.descendantConsumerQuotaLimits) {
            obj.descendant_consumer_quota_limits = message.descendantConsumerQuotaLimits.map(e => e ? exports.ConsumerQuotaLimit.toAmino(e) : undefined);
        }
        else {
            obj.descendant_consumer_quota_limits = message.descendantConsumerQuotaLimits;
        }
        obj.unit = message.unit === "" ? undefined : message.unit;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.ConsumerQuotaMetric.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.ConsumerQuotaMetric.decode(message.value);
    },
    toProto(message) {
        return exports.ConsumerQuotaMetric.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.serviceusage.v1beta1.ConsumerQuotaMetric",
            value: exports.ConsumerQuotaMetric.encode(message).finish()
        };
    }
};
function createBaseConsumerQuotaLimit() {
    return {
        name: "",
        metric: "",
        unit: "",
        isPrecise: false,
        allowsAdminOverrides: false,
        quotaBuckets: [],
        supportedLocations: []
    };
}
exports.ConsumerQuotaLimit = {
    typeUrl: "/google.api.serviceusage.v1beta1.ConsumerQuotaLimit",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.name !== "") {
            writer.uint32(10).string(message.name);
        }
        if (message.metric !== "") {
            writer.uint32(66).string(message.metric);
        }
        if (message.unit !== "") {
            writer.uint32(18).string(message.unit);
        }
        if (message.isPrecise === true) {
            writer.uint32(24).bool(message.isPrecise);
        }
        if (message.allowsAdminOverrides === true) {
            writer.uint32(56).bool(message.allowsAdminOverrides);
        }
        for (const v of message.quotaBuckets) {
            exports.QuotaBucket.encode(v, writer.uint32(74).fork()).ldelim();
        }
        for (const v of message.supportedLocations) {
            writer.uint32(90).string(v);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseConsumerQuotaLimit();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.name = reader.string();
                    break;
                case 8:
                    message.metric = reader.string();
                    break;
                case 2:
                    message.unit = reader.string();
                    break;
                case 3:
                    message.isPrecise = reader.bool();
                    break;
                case 7:
                    message.allowsAdminOverrides = reader.bool();
                    break;
                case 9:
                    message.quotaBuckets.push(exports.QuotaBucket.decode(reader, reader.uint32()));
                    break;
                case 11:
                    message.supportedLocations.push(reader.string());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseConsumerQuotaLimit();
        message.name = object.name ?? "";
        message.metric = object.metric ?? "";
        message.unit = object.unit ?? "";
        message.isPrecise = object.isPrecise ?? false;
        message.allowsAdminOverrides = object.allowsAdminOverrides ?? false;
        message.quotaBuckets = object.quotaBuckets?.map(e => exports.QuotaBucket.fromPartial(e)) || [];
        message.supportedLocations = object.supportedLocations?.map(e => e) || [];
        return message;
    },
    fromAmino(object) {
        const message = createBaseConsumerQuotaLimit();
        if (object.name !== undefined && object.name !== null) {
            message.name = object.name;
        }
        if (object.metric !== undefined && object.metric !== null) {
            message.metric = object.metric;
        }
        if (object.unit !== undefined && object.unit !== null) {
            message.unit = object.unit;
        }
        if (object.is_precise !== undefined && object.is_precise !== null) {
            message.isPrecise = object.is_precise;
        }
        if (object.allows_admin_overrides !== undefined && object.allows_admin_overrides !== null) {
            message.allowsAdminOverrides = object.allows_admin_overrides;
        }
        message.quotaBuckets = object.quota_buckets?.map(e => exports.QuotaBucket.fromAmino(e)) || [];
        message.supportedLocations = object.supported_locations?.map(e => e) || [];
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.name = message.name === "" ? undefined : message.name;
        obj.metric = message.metric === "" ? undefined : message.metric;
        obj.unit = message.unit === "" ? undefined : message.unit;
        obj.is_precise = message.isPrecise === false ? undefined : message.isPrecise;
        obj.allows_admin_overrides = message.allowsAdminOverrides === false ? undefined : message.allowsAdminOverrides;
        if (message.quotaBuckets) {
            obj.quota_buckets = message.quotaBuckets.map(e => e ? exports.QuotaBucket.toAmino(e) : undefined);
        }
        else {
            obj.quota_buckets = message.quotaBuckets;
        }
        if (message.supportedLocations) {
            obj.supported_locations = message.supportedLocations.map(e => e);
        }
        else {
            obj.supported_locations = message.supportedLocations;
        }
        return obj;
    },
    fromAminoMsg(object) {
        return exports.ConsumerQuotaLimit.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.ConsumerQuotaLimit.decode(message.value);
    },
    toProto(message) {
        return exports.ConsumerQuotaLimit.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.serviceusage.v1beta1.ConsumerQuotaLimit",
            value: exports.ConsumerQuotaLimit.encode(message).finish()
        };
    }
};
function createBaseQuotaBucket_DimensionsEntry() {
    return {
        key: "",
        value: ""
    };
}
exports.QuotaBucket_DimensionsEntry = {
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.key !== "") {
            writer.uint32(10).string(message.key);
        }
        if (message.value !== "") {
            writer.uint32(18).string(message.value);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseQuotaBucket_DimensionsEntry();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.key = reader.string();
                    break;
                case 2:
                    message.value = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseQuotaBucket_DimensionsEntry();
        message.key = object.key ?? "";
        message.value = object.value ?? "";
        return message;
    },
    fromAmino(object) {
        const message = createBaseQuotaBucket_DimensionsEntry();
        if (object.key !== undefined && object.key !== null) {
            message.key = object.key;
        }
        if (object.value !== undefined && object.value !== null) {
            message.value = object.value;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.key = message.key === "" ? undefined : message.key;
        obj.value = message.value === "" ? undefined : message.value;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.QuotaBucket_DimensionsEntry.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.QuotaBucket_DimensionsEntry.decode(message.value);
    },
    toProto(message) {
        return exports.QuotaBucket_DimensionsEntry.encode(message).finish();
    }
};
function createBaseQuotaBucket() {
    return {
        effectiveLimit: BigInt(0),
        defaultLimit: BigInt(0),
        producerOverride: undefined,
        consumerOverride: undefined,
        adminOverride: undefined,
        producerQuotaPolicy: undefined,
        dimensions: {}
    };
}
exports.QuotaBucket = {
    typeUrl: "/google.api.serviceusage.v1beta1.QuotaBucket",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.effectiveLimit !== BigInt(0)) {
            writer.uint32(8).int64(message.effectiveLimit);
        }
        if (message.defaultLimit !== BigInt(0)) {
            writer.uint32(16).int64(message.defaultLimit);
        }
        if (message.producerOverride !== undefined) {
            exports.QuotaOverride.encode(message.producerOverride, writer.uint32(26).fork()).ldelim();
        }
        if (message.consumerOverride !== undefined) {
            exports.QuotaOverride.encode(message.consumerOverride, writer.uint32(34).fork()).ldelim();
        }
        if (message.adminOverride !== undefined) {
            exports.QuotaOverride.encode(message.adminOverride, writer.uint32(42).fork()).ldelim();
        }
        if (message.producerQuotaPolicy !== undefined) {
            exports.ProducerQuotaPolicy.encode(message.producerQuotaPolicy, writer.uint32(58).fork()).ldelim();
        }
        Object.entries(message.dimensions).forEach(([key, value]) => {
            exports.QuotaBucket_DimensionsEntry.encode({
                key: key,
                value
            }, writer.uint32(50).fork()).ldelim();
        });
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseQuotaBucket();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.effectiveLimit = reader.int64();
                    break;
                case 2:
                    message.defaultLimit = reader.int64();
                    break;
                case 3:
                    message.producerOverride = exports.QuotaOverride.decode(reader, reader.uint32());
                    break;
                case 4:
                    message.consumerOverride = exports.QuotaOverride.decode(reader, reader.uint32());
                    break;
                case 5:
                    message.adminOverride = exports.QuotaOverride.decode(reader, reader.uint32());
                    break;
                case 7:
                    message.producerQuotaPolicy = exports.ProducerQuotaPolicy.decode(reader, reader.uint32());
                    break;
                case 6:
                    const entry6 = exports.QuotaBucket_DimensionsEntry.decode(reader, reader.uint32());
                    if (entry6.value !== undefined) {
                        message.dimensions[entry6.key] = entry6.value;
                    }
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseQuotaBucket();
        message.effectiveLimit = object.effectiveLimit !== undefined && object.effectiveLimit !== null ? BigInt(object.effectiveLimit.toString()) : BigInt(0);
        message.defaultLimit = object.defaultLimit !== undefined && object.defaultLimit !== null ? BigInt(object.defaultLimit.toString()) : BigInt(0);
        message.producerOverride = object.producerOverride !== undefined && object.producerOverride !== null ? exports.QuotaOverride.fromPartial(object.producerOverride) : undefined;
        message.consumerOverride = object.consumerOverride !== undefined && object.consumerOverride !== null ? exports.QuotaOverride.fromPartial(object.consumerOverride) : undefined;
        message.adminOverride = object.adminOverride !== undefined && object.adminOverride !== null ? exports.QuotaOverride.fromPartial(object.adminOverride) : undefined;
        message.producerQuotaPolicy = object.producerQuotaPolicy !== undefined && object.producerQuotaPolicy !== null ? exports.ProducerQuotaPolicy.fromPartial(object.producerQuotaPolicy) : undefined;
        message.dimensions = Object.entries(object.dimensions ?? {}).reduce((acc, [key, value]) => {
            if (value !== undefined) {
                acc[key] = String(value);
            }
            return acc;
        }, {});
        return message;
    },
    fromAmino(object) {
        const message = createBaseQuotaBucket();
        if (object.effective_limit !== undefined && object.effective_limit !== null) {
            message.effectiveLimit = BigInt(object.effective_limit);
        }
        if (object.default_limit !== undefined && object.default_limit !== null) {
            message.defaultLimit = BigInt(object.default_limit);
        }
        if (object.producer_override !== undefined && object.producer_override !== null) {
            message.producerOverride = exports.QuotaOverride.fromAmino(object.producer_override);
        }
        if (object.consumer_override !== undefined && object.consumer_override !== null) {
            message.consumerOverride = exports.QuotaOverride.fromAmino(object.consumer_override);
        }
        if (object.admin_override !== undefined && object.admin_override !== null) {
            message.adminOverride = exports.QuotaOverride.fromAmino(object.admin_override);
        }
        if (object.producer_quota_policy !== undefined && object.producer_quota_policy !== null) {
            message.producerQuotaPolicy = exports.ProducerQuotaPolicy.fromAmino(object.producer_quota_policy);
        }
        message.dimensions = Object.entries(object.dimensions ?? {}).reduce((acc, [key, value]) => {
            if (value !== undefined) {
                acc[key] = String(value);
            }
            return acc;
        }, {});
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.effective_limit = message.effectiveLimit !== BigInt(0) ? message.effectiveLimit?.toString() : undefined;
        obj.default_limit = message.defaultLimit !== BigInt(0) ? message.defaultLimit?.toString() : undefined;
        obj.producer_override = message.producerOverride ? exports.QuotaOverride.toAmino(message.producerOverride) : undefined;
        obj.consumer_override = message.consumerOverride ? exports.QuotaOverride.toAmino(message.consumerOverride) : undefined;
        obj.admin_override = message.adminOverride ? exports.QuotaOverride.toAmino(message.adminOverride) : undefined;
        obj.producer_quota_policy = message.producerQuotaPolicy ? exports.ProducerQuotaPolicy.toAmino(message.producerQuotaPolicy) : undefined;
        obj.dimensions = {};
        if (message.dimensions) {
            Object.entries(message.dimensions).forEach(([k, v]) => {
                obj.dimensions[k] = v;
            });
        }
        return obj;
    },
    fromAminoMsg(object) {
        return exports.QuotaBucket.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.QuotaBucket.decode(message.value);
    },
    toProto(message) {
        return exports.QuotaBucket.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.serviceusage.v1beta1.QuotaBucket",
            value: exports.QuotaBucket.encode(message).finish()
        };
    }
};
function createBaseQuotaOverride_DimensionsEntry() {
    return {
        key: "",
        value: ""
    };
}
exports.QuotaOverride_DimensionsEntry = {
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.key !== "") {
            writer.uint32(10).string(message.key);
        }
        if (message.value !== "") {
            writer.uint32(18).string(message.value);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseQuotaOverride_DimensionsEntry();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.key = reader.string();
                    break;
                case 2:
                    message.value = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseQuotaOverride_DimensionsEntry();
        message.key = object.key ?? "";
        message.value = object.value ?? "";
        return message;
    },
    fromAmino(object) {
        const message = createBaseQuotaOverride_DimensionsEntry();
        if (object.key !== undefined && object.key !== null) {
            message.key = object.key;
        }
        if (object.value !== undefined && object.value !== null) {
            message.value = object.value;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.key = message.key === "" ? undefined : message.key;
        obj.value = message.value === "" ? undefined : message.value;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.QuotaOverride_DimensionsEntry.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.QuotaOverride_DimensionsEntry.decode(message.value);
    },
    toProto(message) {
        return exports.QuotaOverride_DimensionsEntry.encode(message).finish();
    }
};
function createBaseQuotaOverride() {
    return {
        name: "",
        overrideValue: BigInt(0),
        dimensions: {},
        metric: "",
        unit: "",
        adminOverrideAncestor: ""
    };
}
exports.QuotaOverride = {
    typeUrl: "/google.api.serviceusage.v1beta1.QuotaOverride",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.name !== "") {
            writer.uint32(10).string(message.name);
        }
        if (message.overrideValue !== BigInt(0)) {
            writer.uint32(16).int64(message.overrideValue);
        }
        Object.entries(message.dimensions).forEach(([key, value]) => {
            exports.QuotaOverride_DimensionsEntry.encode({
                key: key,
                value
            }, writer.uint32(26).fork()).ldelim();
        });
        if (message.metric !== "") {
            writer.uint32(34).string(message.metric);
        }
        if (message.unit !== "") {
            writer.uint32(42).string(message.unit);
        }
        if (message.adminOverrideAncestor !== "") {
            writer.uint32(50).string(message.adminOverrideAncestor);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseQuotaOverride();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.name = reader.string();
                    break;
                case 2:
                    message.overrideValue = reader.int64();
                    break;
                case 3:
                    const entry3 = exports.QuotaOverride_DimensionsEntry.decode(reader, reader.uint32());
                    if (entry3.value !== undefined) {
                        message.dimensions[entry3.key] = entry3.value;
                    }
                    break;
                case 4:
                    message.metric = reader.string();
                    break;
                case 5:
                    message.unit = reader.string();
                    break;
                case 6:
                    message.adminOverrideAncestor = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseQuotaOverride();
        message.name = object.name ?? "";
        message.overrideValue = object.overrideValue !== undefined && object.overrideValue !== null ? BigInt(object.overrideValue.toString()) : BigInt(0);
        message.dimensions = Object.entries(object.dimensions ?? {}).reduce((acc, [key, value]) => {
            if (value !== undefined) {
                acc[key] = String(value);
            }
            return acc;
        }, {});
        message.metric = object.metric ?? "";
        message.unit = object.unit ?? "";
        message.adminOverrideAncestor = object.adminOverrideAncestor ?? "";
        return message;
    },
    fromAmino(object) {
        const message = createBaseQuotaOverride();
        if (object.name !== undefined && object.name !== null) {
            message.name = object.name;
        }
        if (object.override_value !== undefined && object.override_value !== null) {
            message.overrideValue = BigInt(object.override_value);
        }
        message.dimensions = Object.entries(object.dimensions ?? {}).reduce((acc, [key, value]) => {
            if (value !== undefined) {
                acc[key] = String(value);
            }
            return acc;
        }, {});
        if (object.metric !== undefined && object.metric !== null) {
            message.metric = object.metric;
        }
        if (object.unit !== undefined && object.unit !== null) {
            message.unit = object.unit;
        }
        if (object.admin_override_ancestor !== undefined && object.admin_override_ancestor !== null) {
            message.adminOverrideAncestor = object.admin_override_ancestor;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.name = message.name === "" ? undefined : message.name;
        obj.override_value = message.overrideValue !== BigInt(0) ? message.overrideValue?.toString() : undefined;
        obj.dimensions = {};
        if (message.dimensions) {
            Object.entries(message.dimensions).forEach(([k, v]) => {
                obj.dimensions[k] = v;
            });
        }
        obj.metric = message.metric === "" ? undefined : message.metric;
        obj.unit = message.unit === "" ? undefined : message.unit;
        obj.admin_override_ancestor = message.adminOverrideAncestor === "" ? undefined : message.adminOverrideAncestor;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.QuotaOverride.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.QuotaOverride.decode(message.value);
    },
    toProto(message) {
        return exports.QuotaOverride.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.serviceusage.v1beta1.QuotaOverride",
            value: exports.QuotaOverride.encode(message).finish()
        };
    }
};
function createBaseOverrideInlineSource() {
    return {
        overrides: []
    };
}
exports.OverrideInlineSource = {
    typeUrl: "/google.api.serviceusage.v1beta1.OverrideInlineSource",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        for (const v of message.overrides) {
            exports.QuotaOverride.encode(v, writer.uint32(10).fork()).ldelim();
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseOverrideInlineSource();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.overrides.push(exports.QuotaOverride.decode(reader, reader.uint32()));
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseOverrideInlineSource();
        message.overrides = object.overrides?.map(e => exports.QuotaOverride.fromPartial(e)) || [];
        return message;
    },
    fromAmino(object) {
        const message = createBaseOverrideInlineSource();
        message.overrides = object.overrides?.map(e => exports.QuotaOverride.fromAmino(e)) || [];
        return message;
    },
    toAmino(message) {
        const obj = {};
        if (message.overrides) {
            obj.overrides = message.overrides.map(e => e ? exports.QuotaOverride.toAmino(e) : undefined);
        }
        else {
            obj.overrides = message.overrides;
        }
        return obj;
    },
    fromAminoMsg(object) {
        return exports.OverrideInlineSource.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.OverrideInlineSource.decode(message.value);
    },
    toProto(message) {
        return exports.OverrideInlineSource.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.serviceusage.v1beta1.OverrideInlineSource",
            value: exports.OverrideInlineSource.encode(message).finish()
        };
    }
};
function createBaseProducerQuotaPolicy_DimensionsEntry() {
    return {
        key: "",
        value: ""
    };
}
exports.ProducerQuotaPolicy_DimensionsEntry = {
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.key !== "") {
            writer.uint32(10).string(message.key);
        }
        if (message.value !== "") {
            writer.uint32(18).string(message.value);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseProducerQuotaPolicy_DimensionsEntry();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.key = reader.string();
                    break;
                case 2:
                    message.value = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseProducerQuotaPolicy_DimensionsEntry();
        message.key = object.key ?? "";
        message.value = object.value ?? "";
        return message;
    },
    fromAmino(object) {
        const message = createBaseProducerQuotaPolicy_DimensionsEntry();
        if (object.key !== undefined && object.key !== null) {
            message.key = object.key;
        }
        if (object.value !== undefined && object.value !== null) {
            message.value = object.value;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.key = message.key === "" ? undefined : message.key;
        obj.value = message.value === "" ? undefined : message.value;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.ProducerQuotaPolicy_DimensionsEntry.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.ProducerQuotaPolicy_DimensionsEntry.decode(message.value);
    },
    toProto(message) {
        return exports.ProducerQuotaPolicy_DimensionsEntry.encode(message).finish();
    }
};
function createBaseProducerQuotaPolicy() {
    return {
        name: "",
        policyValue: BigInt(0),
        dimensions: {},
        metric: "",
        unit: "",
        container: ""
    };
}
exports.ProducerQuotaPolicy = {
    typeUrl: "/google.api.serviceusage.v1beta1.ProducerQuotaPolicy",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.name !== "") {
            writer.uint32(10).string(message.name);
        }
        if (message.policyValue !== BigInt(0)) {
            writer.uint32(16).int64(message.policyValue);
        }
        Object.entries(message.dimensions).forEach(([key, value]) => {
            exports.ProducerQuotaPolicy_DimensionsEntry.encode({
                key: key,
                value
            }, writer.uint32(26).fork()).ldelim();
        });
        if (message.metric !== "") {
            writer.uint32(34).string(message.metric);
        }
        if (message.unit !== "") {
            writer.uint32(42).string(message.unit);
        }
        if (message.container !== "") {
            writer.uint32(50).string(message.container);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseProducerQuotaPolicy();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.name = reader.string();
                    break;
                case 2:
                    message.policyValue = reader.int64();
                    break;
                case 3:
                    const entry3 = exports.ProducerQuotaPolicy_DimensionsEntry.decode(reader, reader.uint32());
                    if (entry3.value !== undefined) {
                        message.dimensions[entry3.key] = entry3.value;
                    }
                    break;
                case 4:
                    message.metric = reader.string();
                    break;
                case 5:
                    message.unit = reader.string();
                    break;
                case 6:
                    message.container = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseProducerQuotaPolicy();
        message.name = object.name ?? "";
        message.policyValue = object.policyValue !== undefined && object.policyValue !== null ? BigInt(object.policyValue.toString()) : BigInt(0);
        message.dimensions = Object.entries(object.dimensions ?? {}).reduce((acc, [key, value]) => {
            if (value !== undefined) {
                acc[key] = String(value);
            }
            return acc;
        }, {});
        message.metric = object.metric ?? "";
        message.unit = object.unit ?? "";
        message.container = object.container ?? "";
        return message;
    },
    fromAmino(object) {
        const message = createBaseProducerQuotaPolicy();
        if (object.name !== undefined && object.name !== null) {
            message.name = object.name;
        }
        if (object.policy_value !== undefined && object.policy_value !== null) {
            message.policyValue = BigInt(object.policy_value);
        }
        message.dimensions = Object.entries(object.dimensions ?? {}).reduce((acc, [key, value]) => {
            if (value !== undefined) {
                acc[key] = String(value);
            }
            return acc;
        }, {});
        if (object.metric !== undefined && object.metric !== null) {
            message.metric = object.metric;
        }
        if (object.unit !== undefined && object.unit !== null) {
            message.unit = object.unit;
        }
        if (object.container !== undefined && object.container !== null) {
            message.container = object.container;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.name = message.name === "" ? undefined : message.name;
        obj.policy_value = message.policyValue !== BigInt(0) ? message.policyValue?.toString() : undefined;
        obj.dimensions = {};
        if (message.dimensions) {
            Object.entries(message.dimensions).forEach(([k, v]) => {
                obj.dimensions[k] = v;
            });
        }
        obj.metric = message.metric === "" ? undefined : message.metric;
        obj.unit = message.unit === "" ? undefined : message.unit;
        obj.container = message.container === "" ? undefined : message.container;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.ProducerQuotaPolicy.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.ProducerQuotaPolicy.decode(message.value);
    },
    toProto(message) {
        return exports.ProducerQuotaPolicy.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.serviceusage.v1beta1.ProducerQuotaPolicy",
            value: exports.ProducerQuotaPolicy.encode(message).finish()
        };
    }
};
function createBaseAdminQuotaPolicy_DimensionsEntry() {
    return {
        key: "",
        value: ""
    };
}
exports.AdminQuotaPolicy_DimensionsEntry = {
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.key !== "") {
            writer.uint32(10).string(message.key);
        }
        if (message.value !== "") {
            writer.uint32(18).string(message.value);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseAdminQuotaPolicy_DimensionsEntry();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.key = reader.string();
                    break;
                case 2:
                    message.value = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseAdminQuotaPolicy_DimensionsEntry();
        message.key = object.key ?? "";
        message.value = object.value ?? "";
        return message;
    },
    fromAmino(object) {
        const message = createBaseAdminQuotaPolicy_DimensionsEntry();
        if (object.key !== undefined && object.key !== null) {
            message.key = object.key;
        }
        if (object.value !== undefined && object.value !== null) {
            message.value = object.value;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.key = message.key === "" ? undefined : message.key;
        obj.value = message.value === "" ? undefined : message.value;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.AdminQuotaPolicy_DimensionsEntry.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.AdminQuotaPolicy_DimensionsEntry.decode(message.value);
    },
    toProto(message) {
        return exports.AdminQuotaPolicy_DimensionsEntry.encode(message).finish();
    }
};
function createBaseAdminQuotaPolicy() {
    return {
        name: "",
        policyValue: BigInt(0),
        dimensions: {},
        metric: "",
        unit: "",
        container: ""
    };
}
exports.AdminQuotaPolicy = {
    typeUrl: "/google.api.serviceusage.v1beta1.AdminQuotaPolicy",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.name !== "") {
            writer.uint32(10).string(message.name);
        }
        if (message.policyValue !== BigInt(0)) {
            writer.uint32(16).int64(message.policyValue);
        }
        Object.entries(message.dimensions).forEach(([key, value]) => {
            exports.AdminQuotaPolicy_DimensionsEntry.encode({
                key: key,
                value
            }, writer.uint32(26).fork()).ldelim();
        });
        if (message.metric !== "") {
            writer.uint32(34).string(message.metric);
        }
        if (message.unit !== "") {
            writer.uint32(42).string(message.unit);
        }
        if (message.container !== "") {
            writer.uint32(50).string(message.container);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseAdminQuotaPolicy();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.name = reader.string();
                    break;
                case 2:
                    message.policyValue = reader.int64();
                    break;
                case 3:
                    const entry3 = exports.AdminQuotaPolicy_DimensionsEntry.decode(reader, reader.uint32());
                    if (entry3.value !== undefined) {
                        message.dimensions[entry3.key] = entry3.value;
                    }
                    break;
                case 4:
                    message.metric = reader.string();
                    break;
                case 5:
                    message.unit = reader.string();
                    break;
                case 6:
                    message.container = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseAdminQuotaPolicy();
        message.name = object.name ?? "";
        message.policyValue = object.policyValue !== undefined && object.policyValue !== null ? BigInt(object.policyValue.toString()) : BigInt(0);
        message.dimensions = Object.entries(object.dimensions ?? {}).reduce((acc, [key, value]) => {
            if (value !== undefined) {
                acc[key] = String(value);
            }
            return acc;
        }, {});
        message.metric = object.metric ?? "";
        message.unit = object.unit ?? "";
        message.container = object.container ?? "";
        return message;
    },
    fromAmino(object) {
        const message = createBaseAdminQuotaPolicy();
        if (object.name !== undefined && object.name !== null) {
            message.name = object.name;
        }
        if (object.policy_value !== undefined && object.policy_value !== null) {
            message.policyValue = BigInt(object.policy_value);
        }
        message.dimensions = Object.entries(object.dimensions ?? {}).reduce((acc, [key, value]) => {
            if (value !== undefined) {
                acc[key] = String(value);
            }
            return acc;
        }, {});
        if (object.metric !== undefined && object.metric !== null) {
            message.metric = object.metric;
        }
        if (object.unit !== undefined && object.unit !== null) {
            message.unit = object.unit;
        }
        if (object.container !== undefined && object.container !== null) {
            message.container = object.container;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.name = message.name === "" ? undefined : message.name;
        obj.policy_value = message.policyValue !== BigInt(0) ? message.policyValue?.toString() : undefined;
        obj.dimensions = {};
        if (message.dimensions) {
            Object.entries(message.dimensions).forEach(([k, v]) => {
                obj.dimensions[k] = v;
            });
        }
        obj.metric = message.metric === "" ? undefined : message.metric;
        obj.unit = message.unit === "" ? undefined : message.unit;
        obj.container = message.container === "" ? undefined : message.container;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.AdminQuotaPolicy.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.AdminQuotaPolicy.decode(message.value);
    },
    toProto(message) {
        return exports.AdminQuotaPolicy.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.serviceusage.v1beta1.AdminQuotaPolicy",
            value: exports.AdminQuotaPolicy.encode(message).finish()
        };
    }
};
function createBaseServiceIdentity() {
    return {
        email: "",
        uniqueId: ""
    };
}
exports.ServiceIdentity = {
    typeUrl: "/google.api.serviceusage.v1beta1.ServiceIdentity",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.email !== "") {
            writer.uint32(10).string(message.email);
        }
        if (message.uniqueId !== "") {
            writer.uint32(18).string(message.uniqueId);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseServiceIdentity();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.email = reader.string();
                    break;
                case 2:
                    message.uniqueId = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseServiceIdentity();
        message.email = object.email ?? "";
        message.uniqueId = object.uniqueId ?? "";
        return message;
    },
    fromAmino(object) {
        const message = createBaseServiceIdentity();
        if (object.email !== undefined && object.email !== null) {
            message.email = object.email;
        }
        if (object.unique_id !== undefined && object.unique_id !== null) {
            message.uniqueId = object.unique_id;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.email = message.email === "" ? undefined : message.email;
        obj.unique_id = message.uniqueId === "" ? undefined : message.uniqueId;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.ServiceIdentity.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.ServiceIdentity.decode(message.value);
    },
    toProto(message) {
        return exports.ServiceIdentity.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.serviceusage.v1beta1.ServiceIdentity",
            value: exports.ServiceIdentity.encode(message).finish()
        };
    }
};
