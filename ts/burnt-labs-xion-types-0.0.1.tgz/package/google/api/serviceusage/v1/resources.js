"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.OperationMetadata = exports.ServiceConfig = exports.Service = exports.StateAmino = exports.StateSDKType = exports.State = void 0;
exports.stateFromJSON = stateFromJSON;
exports.stateToJSON = stateToJSON;
//@ts-nocheck
const api_1 = require("../../../protobuf/api");
const documentation_1 = require("../../documentation");
const quota_1 = require("../../quota");
const auth_1 = require("../../auth");
const usage_1 = require("../../usage");
const endpoint_1 = require("../../endpoint");
const monitored_resource_1 = require("../../monitored_resource");
const monitoring_1 = require("../../monitoring");
const binary_1 = require("../../../../binary");
/** Whether or not a service has been enabled for use by a consumer. */
var State;
(function (State) {
    /**
     * STATE_UNSPECIFIED - The default value, which indicates that the enabled state of the service
     * is unspecified or not meaningful. Currently, all consumers other than
     * projects (such as folders and organizations) are always in this state.
     */
    State[State["STATE_UNSPECIFIED"] = 0] = "STATE_UNSPECIFIED";
    /**
     * DISABLED - The service cannot be used by this consumer. It has either been explicitly
     * disabled, or has never been enabled.
     */
    State[State["DISABLED"] = 1] = "DISABLED";
    /** ENABLED - The service has been explicitly enabled for use by this consumer. */
    State[State["ENABLED"] = 2] = "ENABLED";
    State[State["UNRECOGNIZED"] = -1] = "UNRECOGNIZED";
})(State || (exports.State = State = {}));
exports.StateSDKType = State;
exports.StateAmino = State;
function stateFromJSON(object) {
    switch (object) {
        case 0:
        case "STATE_UNSPECIFIED":
            return State.STATE_UNSPECIFIED;
        case 1:
        case "DISABLED":
            return State.DISABLED;
        case 2:
        case "ENABLED":
            return State.ENABLED;
        case -1:
        case "UNRECOGNIZED":
        default:
            return State.UNRECOGNIZED;
    }
}
function stateToJSON(object) {
    switch (object) {
        case State.STATE_UNSPECIFIED:
            return "STATE_UNSPECIFIED";
        case State.DISABLED:
            return "DISABLED";
        case State.ENABLED:
            return "ENABLED";
        case State.UNRECOGNIZED:
        default:
            return "UNRECOGNIZED";
    }
}
function createBaseService() {
    return {
        name: "",
        parent: "",
        config: undefined,
        state: 0
    };
}
exports.Service = {
    typeUrl: "/google.api.serviceusage.v1.Service",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.name !== "") {
            writer.uint32(10).string(message.name);
        }
        if (message.parent !== "") {
            writer.uint32(42).string(message.parent);
        }
        if (message.config !== undefined) {
            exports.ServiceConfig.encode(message.config, writer.uint32(18).fork()).ldelim();
        }
        if (message.state !== 0) {
            writer.uint32(32).int32(message.state);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseService();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.name = reader.string();
                    break;
                case 5:
                    message.parent = reader.string();
                    break;
                case 2:
                    message.config = exports.ServiceConfig.decode(reader, reader.uint32());
                    break;
                case 4:
                    message.state = reader.int32();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseService();
        message.name = object.name ?? "";
        message.parent = object.parent ?? "";
        message.config = object.config !== undefined && object.config !== null ? exports.ServiceConfig.fromPartial(object.config) : undefined;
        message.state = object.state ?? 0;
        return message;
    },
    fromAmino(object) {
        const message = createBaseService();
        if (object.name !== undefined && object.name !== null) {
            message.name = object.name;
        }
        if (object.parent !== undefined && object.parent !== null) {
            message.parent = object.parent;
        }
        if (object.config !== undefined && object.config !== null) {
            message.config = exports.ServiceConfig.fromAmino(object.config);
        }
        if (object.state !== undefined && object.state !== null) {
            message.state = object.state;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.name = message.name === "" ? undefined : message.name;
        obj.parent = message.parent === "" ? undefined : message.parent;
        obj.config = message.config ? exports.ServiceConfig.toAmino(message.config) : undefined;
        obj.state = message.state === 0 ? undefined : message.state;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.Service.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.Service.decode(message.value);
    },
    toProto(message) {
        return exports.Service.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.serviceusage.v1.Service",
            value: exports.Service.encode(message).finish()
        };
    }
};
function createBaseServiceConfig() {
    return {
        name: "",
        title: "",
        apis: [],
        documentation: undefined,
        quota: undefined,
        authentication: undefined,
        usage: undefined,
        endpoints: [],
        monitoredResources: [],
        monitoring: undefined
    };
}
exports.ServiceConfig = {
    typeUrl: "/google.api.serviceusage.v1.ServiceConfig",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.name !== "") {
            writer.uint32(10).string(message.name);
        }
        if (message.title !== "") {
            writer.uint32(18).string(message.title);
        }
        for (const v of message.apis) {
            api_1.Api.encode(v, writer.uint32(26).fork()).ldelim();
        }
        if (message.documentation !== undefined) {
            documentation_1.Documentation.encode(message.documentation, writer.uint32(50).fork()).ldelim();
        }
        if (message.quota !== undefined) {
            quota_1.Quota.encode(message.quota, writer.uint32(82).fork()).ldelim();
        }
        if (message.authentication !== undefined) {
            auth_1.Authentication.encode(message.authentication, writer.uint32(90).fork()).ldelim();
        }
        if (message.usage !== undefined) {
            usage_1.Usage.encode(message.usage, writer.uint32(122).fork()).ldelim();
        }
        for (const v of message.endpoints) {
            endpoint_1.Endpoint.encode(v, writer.uint32(146).fork()).ldelim();
        }
        for (const v of message.monitoredResources) {
            monitored_resource_1.MonitoredResourceDescriptor.encode(v, writer.uint32(202).fork()).ldelim();
        }
        if (message.monitoring !== undefined) {
            monitoring_1.Monitoring.encode(message.monitoring, writer.uint32(226).fork()).ldelim();
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseServiceConfig();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.name = reader.string();
                    break;
                case 2:
                    message.title = reader.string();
                    break;
                case 3:
                    message.apis.push(api_1.Api.decode(reader, reader.uint32()));
                    break;
                case 6:
                    message.documentation = documentation_1.Documentation.decode(reader, reader.uint32());
                    break;
                case 10:
                    message.quota = quota_1.Quota.decode(reader, reader.uint32());
                    break;
                case 11:
                    message.authentication = auth_1.Authentication.decode(reader, reader.uint32());
                    break;
                case 15:
                    message.usage = usage_1.Usage.decode(reader, reader.uint32());
                    break;
                case 18:
                    message.endpoints.push(endpoint_1.Endpoint.decode(reader, reader.uint32()));
                    break;
                case 25:
                    message.monitoredResources.push(monitored_resource_1.MonitoredResourceDescriptor.decode(reader, reader.uint32()));
                    break;
                case 28:
                    message.monitoring = monitoring_1.Monitoring.decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseServiceConfig();
        message.name = object.name ?? "";
        message.title = object.title ?? "";
        message.apis = object.apis?.map(e => api_1.Api.fromPartial(e)) || [];
        message.documentation = object.documentation !== undefined && object.documentation !== null ? documentation_1.Documentation.fromPartial(object.documentation) : undefined;
        message.quota = object.quota !== undefined && object.quota !== null ? quota_1.Quota.fromPartial(object.quota) : undefined;
        message.authentication = object.authentication !== undefined && object.authentication !== null ? auth_1.Authentication.fromPartial(object.authentication) : undefined;
        message.usage = object.usage !== undefined && object.usage !== null ? usage_1.Usage.fromPartial(object.usage) : undefined;
        message.endpoints = object.endpoints?.map(e => endpoint_1.Endpoint.fromPartial(e)) || [];
        message.monitoredResources = object.monitoredResources?.map(e => monitored_resource_1.MonitoredResourceDescriptor.fromPartial(e)) || [];
        message.monitoring = object.monitoring !== undefined && object.monitoring !== null ? monitoring_1.Monitoring.fromPartial(object.monitoring) : undefined;
        return message;
    },
    fromAmino(object) {
        const message = createBaseServiceConfig();
        if (object.name !== undefined && object.name !== null) {
            message.name = object.name;
        }
        if (object.title !== undefined && object.title !== null) {
            message.title = object.title;
        }
        message.apis = object.apis?.map(e => api_1.Api.fromAmino(e)) || [];
        if (object.documentation !== undefined && object.documentation !== null) {
            message.documentation = documentation_1.Documentation.fromAmino(object.documentation);
        }
        if (object.quota !== undefined && object.quota !== null) {
            message.quota = quota_1.Quota.fromAmino(object.quota);
        }
        if (object.authentication !== undefined && object.authentication !== null) {
            message.authentication = auth_1.Authentication.fromAmino(object.authentication);
        }
        if (object.usage !== undefined && object.usage !== null) {
            message.usage = usage_1.Usage.fromAmino(object.usage);
        }
        message.endpoints = object.endpoints?.map(e => endpoint_1.Endpoint.fromAmino(e)) || [];
        message.monitoredResources = object.monitored_resources?.map(e => monitored_resource_1.MonitoredResourceDescriptor.fromAmino(e)) || [];
        if (object.monitoring !== undefined && object.monitoring !== null) {
            message.monitoring = monitoring_1.Monitoring.fromAmino(object.monitoring);
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.name = message.name === "" ? undefined : message.name;
        obj.title = message.title === "" ? undefined : message.title;
        if (message.apis) {
            obj.apis = message.apis.map(e => e ? api_1.Api.toAmino(e) : undefined);
        }
        else {
            obj.apis = message.apis;
        }
        obj.documentation = message.documentation ? documentation_1.Documentation.toAmino(message.documentation) : undefined;
        obj.quota = message.quota ? quota_1.Quota.toAmino(message.quota) : undefined;
        obj.authentication = message.authentication ? auth_1.Authentication.toAmino(message.authentication) : undefined;
        obj.usage = message.usage ? usage_1.Usage.toAmino(message.usage) : undefined;
        if (message.endpoints) {
            obj.endpoints = message.endpoints.map(e => e ? endpoint_1.Endpoint.toAmino(e) : undefined);
        }
        else {
            obj.endpoints = message.endpoints;
        }
        if (message.monitoredResources) {
            obj.monitored_resources = message.monitoredResources.map(e => e ? monitored_resource_1.MonitoredResourceDescriptor.toAmino(e) : undefined);
        }
        else {
            obj.monitored_resources = message.monitoredResources;
        }
        obj.monitoring = message.monitoring ? monitoring_1.Monitoring.toAmino(message.monitoring) : undefined;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.ServiceConfig.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.ServiceConfig.decode(message.value);
    },
    toProto(message) {
        return exports.ServiceConfig.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.serviceusage.v1.ServiceConfig",
            value: exports.ServiceConfig.encode(message).finish()
        };
    }
};
function createBaseOperationMetadata() {
    return {
        resourceNames: []
    };
}
exports.OperationMetadata = {
    typeUrl: "/google.api.serviceusage.v1.OperationMetadata",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        for (const v of message.resourceNames) {
            writer.uint32(18).string(v);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseOperationMetadata();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 2:
                    message.resourceNames.push(reader.string());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseOperationMetadata();
        message.resourceNames = object.resourceNames?.map(e => e) || [];
        return message;
    },
    fromAmino(object) {
        const message = createBaseOperationMetadata();
        message.resourceNames = object.resource_names?.map(e => e) || [];
        return message;
    },
    toAmino(message) {
        const obj = {};
        if (message.resourceNames) {
            obj.resource_names = message.resourceNames.map(e => e);
        }
        else {
            obj.resource_names = message.resourceNames;
        }
        return obj;
    },
    fromAminoMsg(object) {
        return exports.OperationMetadata.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.OperationMetadata.decode(message.value);
    },
    toProto(message) {
        return exports.OperationMetadata.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.serviceusage.v1.OperationMetadata",
            value: exports.OperationMetadata.encode(message).finish()
        };
    }
};
