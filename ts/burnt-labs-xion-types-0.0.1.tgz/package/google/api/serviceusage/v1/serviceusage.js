"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.BatchGetServicesResponse = exports.BatchGetServicesRequest = exports.BatchEnableServicesResponse_EnableFailure = exports.BatchEnableServicesResponse = exports.BatchEnableServicesRequest = exports.ListServicesResponse = exports.ListServicesRequest = exports.GetServiceRequest = exports.DisableServiceResponse = exports.DisableServiceRequest = exports.EnableServiceResponse = exports.EnableServiceRequest = exports.DisableServiceRequest_CheckIfServiceHasUsageAmino = exports.DisableServiceRequest_CheckIfServiceHasUsageSDKType = exports.DisableServiceRequest_CheckIfServiceHasUsage = void 0;
exports.disableServiceRequest_CheckIfServiceHasUsageFromJSON = disableServiceRequest_CheckIfServiceHasUsageFromJSON;
exports.disableServiceRequest_CheckIfServiceHasUsageToJSON = disableServiceRequest_CheckIfServiceHasUsageToJSON;
//@ts-nocheck
const resources_1 = require("./resources");
const binary_1 = require("../../../../binary");
/**
 * Enum to determine if service usage should be checked when disabling a
 * service.
 */
var DisableServiceRequest_CheckIfServiceHasUsage;
(function (DisableServiceRequest_CheckIfServiceHasUsage) {
    /** CHECK_IF_SERVICE_HAS_USAGE_UNSPECIFIED - When unset, the default behavior is used, which is SKIP. */
    DisableServiceRequest_CheckIfServiceHasUsage[DisableServiceRequest_CheckIfServiceHasUsage["CHECK_IF_SERVICE_HAS_USAGE_UNSPECIFIED"] = 0] = "CHECK_IF_SERVICE_HAS_USAGE_UNSPECIFIED";
    /** SKIP - If set, skip checking service usage when disabling a service. */
    DisableServiceRequest_CheckIfServiceHasUsage[DisableServiceRequest_CheckIfServiceHasUsage["SKIP"] = 1] = "SKIP";
    /**
     * CHECK - If set, service usage is checked when disabling the service. If a
     * service, or its dependents, has usage in the last 30 days, the request
     * returns a FAILED_PRECONDITION error.
     */
    DisableServiceRequest_CheckIfServiceHasUsage[DisableServiceRequest_CheckIfServiceHasUsage["CHECK"] = 2] = "CHECK";
    DisableServiceRequest_CheckIfServiceHasUsage[DisableServiceRequest_CheckIfServiceHasUsage["UNRECOGNIZED"] = -1] = "UNRECOGNIZED";
})(DisableServiceRequest_CheckIfServiceHasUsage || (exports.DisableServiceRequest_CheckIfServiceHasUsage = DisableServiceRequest_CheckIfServiceHasUsage = {}));
exports.DisableServiceRequest_CheckIfServiceHasUsageSDKType = DisableServiceRequest_CheckIfServiceHasUsage;
exports.DisableServiceRequest_CheckIfServiceHasUsageAmino = DisableServiceRequest_CheckIfServiceHasUsage;
function disableServiceRequest_CheckIfServiceHasUsageFromJSON(object) {
    switch (object) {
        case 0:
        case "CHECK_IF_SERVICE_HAS_USAGE_UNSPECIFIED":
            return DisableServiceRequest_CheckIfServiceHasUsage.CHECK_IF_SERVICE_HAS_USAGE_UNSPECIFIED;
        case 1:
        case "SKIP":
            return DisableServiceRequest_CheckIfServiceHasUsage.SKIP;
        case 2:
        case "CHECK":
            return DisableServiceRequest_CheckIfServiceHasUsage.CHECK;
        case -1:
        case "UNRECOGNIZED":
        default:
            return DisableServiceRequest_CheckIfServiceHasUsage.UNRECOGNIZED;
    }
}
function disableServiceRequest_CheckIfServiceHasUsageToJSON(object) {
    switch (object) {
        case DisableServiceRequest_CheckIfServiceHasUsage.CHECK_IF_SERVICE_HAS_USAGE_UNSPECIFIED:
            return "CHECK_IF_SERVICE_HAS_USAGE_UNSPECIFIED";
        case DisableServiceRequest_CheckIfServiceHasUsage.SKIP:
            return "SKIP";
        case DisableServiceRequest_CheckIfServiceHasUsage.CHECK:
            return "CHECK";
        case DisableServiceRequest_CheckIfServiceHasUsage.UNRECOGNIZED:
        default:
            return "UNRECOGNIZED";
    }
}
function createBaseEnableServiceRequest() {
    return {
        name: ""
    };
}
exports.EnableServiceRequest = {
    typeUrl: "/google.api.serviceusage.v1.EnableServiceRequest",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.name !== "") {
            writer.uint32(10).string(message.name);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseEnableServiceRequest();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.name = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseEnableServiceRequest();
        message.name = object.name ?? "";
        return message;
    },
    fromAmino(object) {
        const message = createBaseEnableServiceRequest();
        if (object.name !== undefined && object.name !== null) {
            message.name = object.name;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.name = message.name === "" ? undefined : message.name;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.EnableServiceRequest.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.EnableServiceRequest.decode(message.value);
    },
    toProto(message) {
        return exports.EnableServiceRequest.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.serviceusage.v1.EnableServiceRequest",
            value: exports.EnableServiceRequest.encode(message).finish()
        };
    }
};
function createBaseEnableServiceResponse() {
    return {
        service: undefined
    };
}
exports.EnableServiceResponse = {
    typeUrl: "/google.api.serviceusage.v1.EnableServiceResponse",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.service !== undefined) {
            resources_1.Service.encode(message.service, writer.uint32(10).fork()).ldelim();
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseEnableServiceResponse();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.service = resources_1.Service.decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseEnableServiceResponse();
        message.service = object.service !== undefined && object.service !== null ? resources_1.Service.fromPartial(object.service) : undefined;
        return message;
    },
    fromAmino(object) {
        const message = createBaseEnableServiceResponse();
        if (object.service !== undefined && object.service !== null) {
            message.service = resources_1.Service.fromAmino(object.service);
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.service = message.service ? resources_1.Service.toAmino(message.service) : undefined;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.EnableServiceResponse.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.EnableServiceResponse.decode(message.value);
    },
    toProto(message) {
        return exports.EnableServiceResponse.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.serviceusage.v1.EnableServiceResponse",
            value: exports.EnableServiceResponse.encode(message).finish()
        };
    }
};
function createBaseDisableServiceRequest() {
    return {
        name: "",
        disableDependentServices: false,
        checkIfServiceHasUsage: 0
    };
}
exports.DisableServiceRequest = {
    typeUrl: "/google.api.serviceusage.v1.DisableServiceRequest",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.name !== "") {
            writer.uint32(10).string(message.name);
        }
        if (message.disableDependentServices === true) {
            writer.uint32(16).bool(message.disableDependentServices);
        }
        if (message.checkIfServiceHasUsage !== 0) {
            writer.uint32(24).int32(message.checkIfServiceHasUsage);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseDisableServiceRequest();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.name = reader.string();
                    break;
                case 2:
                    message.disableDependentServices = reader.bool();
                    break;
                case 3:
                    message.checkIfServiceHasUsage = reader.int32();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseDisableServiceRequest();
        message.name = object.name ?? "";
        message.disableDependentServices = object.disableDependentServices ?? false;
        message.checkIfServiceHasUsage = object.checkIfServiceHasUsage ?? 0;
        return message;
    },
    fromAmino(object) {
        const message = createBaseDisableServiceRequest();
        if (object.name !== undefined && object.name !== null) {
            message.name = object.name;
        }
        if (object.disable_dependent_services !== undefined && object.disable_dependent_services !== null) {
            message.disableDependentServices = object.disable_dependent_services;
        }
        if (object.check_if_service_has_usage !== undefined && object.check_if_service_has_usage !== null) {
            message.checkIfServiceHasUsage = object.check_if_service_has_usage;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.name = message.name === "" ? undefined : message.name;
        obj.disable_dependent_services = message.disableDependentServices === false ? undefined : message.disableDependentServices;
        obj.check_if_service_has_usage = message.checkIfServiceHasUsage === 0 ? undefined : message.checkIfServiceHasUsage;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.DisableServiceRequest.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.DisableServiceRequest.decode(message.value);
    },
    toProto(message) {
        return exports.DisableServiceRequest.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.serviceusage.v1.DisableServiceRequest",
            value: exports.DisableServiceRequest.encode(message).finish()
        };
    }
};
function createBaseDisableServiceResponse() {
    return {
        service: undefined
    };
}
exports.DisableServiceResponse = {
    typeUrl: "/google.api.serviceusage.v1.DisableServiceResponse",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.service !== undefined) {
            resources_1.Service.encode(message.service, writer.uint32(10).fork()).ldelim();
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseDisableServiceResponse();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.service = resources_1.Service.decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseDisableServiceResponse();
        message.service = object.service !== undefined && object.service !== null ? resources_1.Service.fromPartial(object.service) : undefined;
        return message;
    },
    fromAmino(object) {
        const message = createBaseDisableServiceResponse();
        if (object.service !== undefined && object.service !== null) {
            message.service = resources_1.Service.fromAmino(object.service);
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.service = message.service ? resources_1.Service.toAmino(message.service) : undefined;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.DisableServiceResponse.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.DisableServiceResponse.decode(message.value);
    },
    toProto(message) {
        return exports.DisableServiceResponse.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.serviceusage.v1.DisableServiceResponse",
            value: exports.DisableServiceResponse.encode(message).finish()
        };
    }
};
function createBaseGetServiceRequest() {
    return {
        name: ""
    };
}
exports.GetServiceRequest = {
    typeUrl: "/google.api.serviceusage.v1.GetServiceRequest",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.name !== "") {
            writer.uint32(10).string(message.name);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseGetServiceRequest();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.name = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseGetServiceRequest();
        message.name = object.name ?? "";
        return message;
    },
    fromAmino(object) {
        const message = createBaseGetServiceRequest();
        if (object.name !== undefined && object.name !== null) {
            message.name = object.name;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.name = message.name === "" ? undefined : message.name;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.GetServiceRequest.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.GetServiceRequest.decode(message.value);
    },
    toProto(message) {
        return exports.GetServiceRequest.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.serviceusage.v1.GetServiceRequest",
            value: exports.GetServiceRequest.encode(message).finish()
        };
    }
};
function createBaseListServicesRequest() {
    return {
        parent: "",
        pageSize: 0,
        pageToken: "",
        filter: ""
    };
}
exports.ListServicesRequest = {
    typeUrl: "/google.api.serviceusage.v1.ListServicesRequest",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.parent !== "") {
            writer.uint32(10).string(message.parent);
        }
        if (message.pageSize !== 0) {
            writer.uint32(16).int32(message.pageSize);
        }
        if (message.pageToken !== "") {
            writer.uint32(26).string(message.pageToken);
        }
        if (message.filter !== "") {
            writer.uint32(34).string(message.filter);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseListServicesRequest();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.parent = reader.string();
                    break;
                case 2:
                    message.pageSize = reader.int32();
                    break;
                case 3:
                    message.pageToken = reader.string();
                    break;
                case 4:
                    message.filter = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseListServicesRequest();
        message.parent = object.parent ?? "";
        message.pageSize = object.pageSize ?? 0;
        message.pageToken = object.pageToken ?? "";
        message.filter = object.filter ?? "";
        return message;
    },
    fromAmino(object) {
        const message = createBaseListServicesRequest();
        if (object.parent !== undefined && object.parent !== null) {
            message.parent = object.parent;
        }
        if (object.page_size !== undefined && object.page_size !== null) {
            message.pageSize = object.page_size;
        }
        if (object.page_token !== undefined && object.page_token !== null) {
            message.pageToken = object.page_token;
        }
        if (object.filter !== undefined && object.filter !== null) {
            message.filter = object.filter;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.parent = message.parent === "" ? undefined : message.parent;
        obj.page_size = message.pageSize === 0 ? undefined : message.pageSize;
        obj.page_token = message.pageToken === "" ? undefined : message.pageToken;
        obj.filter = message.filter === "" ? undefined : message.filter;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.ListServicesRequest.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.ListServicesRequest.decode(message.value);
    },
    toProto(message) {
        return exports.ListServicesRequest.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.serviceusage.v1.ListServicesRequest",
            value: exports.ListServicesRequest.encode(message).finish()
        };
    }
};
function createBaseListServicesResponse() {
    return {
        services: [],
        nextPageToken: ""
    };
}
exports.ListServicesResponse = {
    typeUrl: "/google.api.serviceusage.v1.ListServicesResponse",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        for (const v of message.services) {
            resources_1.Service.encode(v, writer.uint32(10).fork()).ldelim();
        }
        if (message.nextPageToken !== "") {
            writer.uint32(18).string(message.nextPageToken);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseListServicesResponse();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.services.push(resources_1.Service.decode(reader, reader.uint32()));
                    break;
                case 2:
                    message.nextPageToken = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseListServicesResponse();
        message.services = object.services?.map(e => resources_1.Service.fromPartial(e)) || [];
        message.nextPageToken = object.nextPageToken ?? "";
        return message;
    },
    fromAmino(object) {
        const message = createBaseListServicesResponse();
        message.services = object.services?.map(e => resources_1.Service.fromAmino(e)) || [];
        if (object.next_page_token !== undefined && object.next_page_token !== null) {
            message.nextPageToken = object.next_page_token;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        if (message.services) {
            obj.services = message.services.map(e => e ? resources_1.Service.toAmino(e) : undefined);
        }
        else {
            obj.services = message.services;
        }
        obj.next_page_token = message.nextPageToken === "" ? undefined : message.nextPageToken;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.ListServicesResponse.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.ListServicesResponse.decode(message.value);
    },
    toProto(message) {
        return exports.ListServicesResponse.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.serviceusage.v1.ListServicesResponse",
            value: exports.ListServicesResponse.encode(message).finish()
        };
    }
};
function createBaseBatchEnableServicesRequest() {
    return {
        parent: "",
        serviceIds: []
    };
}
exports.BatchEnableServicesRequest = {
    typeUrl: "/google.api.serviceusage.v1.BatchEnableServicesRequest",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.parent !== "") {
            writer.uint32(10).string(message.parent);
        }
        for (const v of message.serviceIds) {
            writer.uint32(18).string(v);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseBatchEnableServicesRequest();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.parent = reader.string();
                    break;
                case 2:
                    message.serviceIds.push(reader.string());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseBatchEnableServicesRequest();
        message.parent = object.parent ?? "";
        message.serviceIds = object.serviceIds?.map(e => e) || [];
        return message;
    },
    fromAmino(object) {
        const message = createBaseBatchEnableServicesRequest();
        if (object.parent !== undefined && object.parent !== null) {
            message.parent = object.parent;
        }
        message.serviceIds = object.service_ids?.map(e => e) || [];
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.parent = message.parent === "" ? undefined : message.parent;
        if (message.serviceIds) {
            obj.service_ids = message.serviceIds.map(e => e);
        }
        else {
            obj.service_ids = message.serviceIds;
        }
        return obj;
    },
    fromAminoMsg(object) {
        return exports.BatchEnableServicesRequest.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.BatchEnableServicesRequest.decode(message.value);
    },
    toProto(message) {
        return exports.BatchEnableServicesRequest.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.serviceusage.v1.BatchEnableServicesRequest",
            value: exports.BatchEnableServicesRequest.encode(message).finish()
        };
    }
};
function createBaseBatchEnableServicesResponse() {
    return {
        services: [],
        failures: []
    };
}
exports.BatchEnableServicesResponse = {
    typeUrl: "/google.api.serviceusage.v1.BatchEnableServicesResponse",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        for (const v of message.services) {
            resources_1.Service.encode(v, writer.uint32(10).fork()).ldelim();
        }
        for (const v of message.failures) {
            exports.BatchEnableServicesResponse_EnableFailure.encode(v, writer.uint32(18).fork()).ldelim();
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseBatchEnableServicesResponse();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.services.push(resources_1.Service.decode(reader, reader.uint32()));
                    break;
                case 2:
                    message.failures.push(exports.BatchEnableServicesResponse_EnableFailure.decode(reader, reader.uint32()));
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseBatchEnableServicesResponse();
        message.services = object.services?.map(e => resources_1.Service.fromPartial(e)) || [];
        message.failures = object.failures?.map(e => exports.BatchEnableServicesResponse_EnableFailure.fromPartial(e)) || [];
        return message;
    },
    fromAmino(object) {
        const message = createBaseBatchEnableServicesResponse();
        message.services = object.services?.map(e => resources_1.Service.fromAmino(e)) || [];
        message.failures = object.failures?.map(e => exports.BatchEnableServicesResponse_EnableFailure.fromAmino(e)) || [];
        return message;
    },
    toAmino(message) {
        const obj = {};
        if (message.services) {
            obj.services = message.services.map(e => e ? resources_1.Service.toAmino(e) : undefined);
        }
        else {
            obj.services = message.services;
        }
        if (message.failures) {
            obj.failures = message.failures.map(e => e ? exports.BatchEnableServicesResponse_EnableFailure.toAmino(e) : undefined);
        }
        else {
            obj.failures = message.failures;
        }
        return obj;
    },
    fromAminoMsg(object) {
        return exports.BatchEnableServicesResponse.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.BatchEnableServicesResponse.decode(message.value);
    },
    toProto(message) {
        return exports.BatchEnableServicesResponse.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.serviceusage.v1.BatchEnableServicesResponse",
            value: exports.BatchEnableServicesResponse.encode(message).finish()
        };
    }
};
function createBaseBatchEnableServicesResponse_EnableFailure() {
    return {
        serviceId: "",
        errorMessage: ""
    };
}
exports.BatchEnableServicesResponse_EnableFailure = {
    typeUrl: "/google.api.serviceusage.v1.EnableFailure",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.serviceId !== "") {
            writer.uint32(10).string(message.serviceId);
        }
        if (message.errorMessage !== "") {
            writer.uint32(18).string(message.errorMessage);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseBatchEnableServicesResponse_EnableFailure();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.serviceId = reader.string();
                    break;
                case 2:
                    message.errorMessage = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseBatchEnableServicesResponse_EnableFailure();
        message.serviceId = object.serviceId ?? "";
        message.errorMessage = object.errorMessage ?? "";
        return message;
    },
    fromAmino(object) {
        const message = createBaseBatchEnableServicesResponse_EnableFailure();
        if (object.service_id !== undefined && object.service_id !== null) {
            message.serviceId = object.service_id;
        }
        if (object.error_message !== undefined && object.error_message !== null) {
            message.errorMessage = object.error_message;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.service_id = message.serviceId === "" ? undefined : message.serviceId;
        obj.error_message = message.errorMessage === "" ? undefined : message.errorMessage;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.BatchEnableServicesResponse_EnableFailure.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.BatchEnableServicesResponse_EnableFailure.decode(message.value);
    },
    toProto(message) {
        return exports.BatchEnableServicesResponse_EnableFailure.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.serviceusage.v1.EnableFailure",
            value: exports.BatchEnableServicesResponse_EnableFailure.encode(message).finish()
        };
    }
};
function createBaseBatchGetServicesRequest() {
    return {
        parent: "",
        names: []
    };
}
exports.BatchGetServicesRequest = {
    typeUrl: "/google.api.serviceusage.v1.BatchGetServicesRequest",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.parent !== "") {
            writer.uint32(10).string(message.parent);
        }
        for (const v of message.names) {
            writer.uint32(18).string(v);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseBatchGetServicesRequest();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.parent = reader.string();
                    break;
                case 2:
                    message.names.push(reader.string());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseBatchGetServicesRequest();
        message.parent = object.parent ?? "";
        message.names = object.names?.map(e => e) || [];
        return message;
    },
    fromAmino(object) {
        const message = createBaseBatchGetServicesRequest();
        if (object.parent !== undefined && object.parent !== null) {
            message.parent = object.parent;
        }
        message.names = object.names?.map(e => e) || [];
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.parent = message.parent === "" ? undefined : message.parent;
        if (message.names) {
            obj.names = message.names.map(e => e);
        }
        else {
            obj.names = message.names;
        }
        return obj;
    },
    fromAminoMsg(object) {
        return exports.BatchGetServicesRequest.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.BatchGetServicesRequest.decode(message.value);
    },
    toProto(message) {
        return exports.BatchGetServicesRequest.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.serviceusage.v1.BatchGetServicesRequest",
            value: exports.BatchGetServicesRequest.encode(message).finish()
        };
    }
};
function createBaseBatchGetServicesResponse() {
    return {
        services: []
    };
}
exports.BatchGetServicesResponse = {
    typeUrl: "/google.api.serviceusage.v1.BatchGetServicesResponse",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        for (const v of message.services) {
            resources_1.Service.encode(v, writer.uint32(10).fork()).ldelim();
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseBatchGetServicesResponse();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.services.push(resources_1.Service.decode(reader, reader.uint32()));
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseBatchGetServicesResponse();
        message.services = object.services?.map(e => resources_1.Service.fromPartial(e)) || [];
        return message;
    },
    fromAmino(object) {
        const message = createBaseBatchGetServicesResponse();
        message.services = object.services?.map(e => resources_1.Service.fromAmino(e)) || [];
        return message;
    },
    toAmino(message) {
        const obj = {};
        if (message.services) {
            obj.services = message.services.map(e => e ? resources_1.Service.toAmino(e) : undefined);
        }
        else {
            obj.services = message.services;
        }
        return obj;
    },
    fromAminoMsg(object) {
        return exports.BatchGetServicesResponse.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.BatchGetServicesResponse.decode(message.value);
    },
    toProto(message) {
        return exports.BatchGetServicesResponse.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.serviceusage.v1.BatchGetServicesResponse",
            value: exports.BatchGetServicesResponse.encode(message).finish()
        };
    }
};
