"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Distribution_Exemplar = exports.Distribution_BucketOptions_Explicit = exports.Distribution_BucketOptions_Exponential = exports.Distribution_BucketOptions_Linear = exports.Distribution_BucketOptions = exports.Distribution_Range = exports.Distribution = void 0;
//@ts-nocheck
const timestamp_1 = require("../protobuf/timestamp");
const any_1 = require("../protobuf/any");
const binary_1 = require("../../binary");
const helpers_1 = require("../../helpers");
function createBaseDistribution() {
    return {
        count: BigInt(0),
        mean: 0,
        sumOfSquaredDeviation: 0,
        range: undefined,
        bucketOptions: undefined,
        bucketCounts: [],
        exemplars: []
    };
}
exports.Distribution = {
    typeUrl: "/google.api.Distribution",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.count !== BigInt(0)) {
            writer.uint32(8).int64(message.count);
        }
        if (message.mean !== 0) {
            writer.uint32(17).double(message.mean);
        }
        if (message.sumOfSquaredDeviation !== 0) {
            writer.uint32(25).double(message.sumOfSquaredDeviation);
        }
        if (message.range !== undefined) {
            exports.Distribution_Range.encode(message.range, writer.uint32(34).fork()).ldelim();
        }
        if (message.bucketOptions !== undefined) {
            exports.Distribution_BucketOptions.encode(message.bucketOptions, writer.uint32(50).fork()).ldelim();
        }
        writer.uint32(58).fork();
        for (const v of message.bucketCounts) {
            writer.int64(v);
        }
        writer.ldelim();
        for (const v of message.exemplars) {
            exports.Distribution_Exemplar.encode(v, writer.uint32(82).fork()).ldelim();
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseDistribution();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.count = reader.int64();
                    break;
                case 2:
                    message.mean = reader.double();
                    break;
                case 3:
                    message.sumOfSquaredDeviation = reader.double();
                    break;
                case 4:
                    message.range = exports.Distribution_Range.decode(reader, reader.uint32());
                    break;
                case 6:
                    message.bucketOptions = exports.Distribution_BucketOptions.decode(reader, reader.uint32());
                    break;
                case 7:
                    if ((tag & 7) === 2) {
                        const end2 = reader.uint32() + reader.pos;
                        while (reader.pos < end2) {
                            message.bucketCounts.push(reader.int64());
                        }
                    }
                    else {
                        message.bucketCounts.push(reader.int64());
                    }
                    break;
                case 10:
                    message.exemplars.push(exports.Distribution_Exemplar.decode(reader, reader.uint32()));
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseDistribution();
        message.count = object.count !== undefined && object.count !== null ? BigInt(object.count.toString()) : BigInt(0);
        message.mean = object.mean ?? 0;
        message.sumOfSquaredDeviation = object.sumOfSquaredDeviation ?? 0;
        message.range = object.range !== undefined && object.range !== null ? exports.Distribution_Range.fromPartial(object.range) : undefined;
        message.bucketOptions = object.bucketOptions !== undefined && object.bucketOptions !== null ? exports.Distribution_BucketOptions.fromPartial(object.bucketOptions) : undefined;
        message.bucketCounts = object.bucketCounts?.map(e => BigInt(e.toString())) || [];
        message.exemplars = object.exemplars?.map(e => exports.Distribution_Exemplar.fromPartial(e)) || [];
        return message;
    },
    fromAmino(object) {
        const message = createBaseDistribution();
        if (object.count !== undefined && object.count !== null) {
            message.count = BigInt(object.count);
        }
        if (object.mean !== undefined && object.mean !== null) {
            message.mean = object.mean;
        }
        if (object.sum_of_squared_deviation !== undefined && object.sum_of_squared_deviation !== null) {
            message.sumOfSquaredDeviation = object.sum_of_squared_deviation;
        }
        if (object.range !== undefined && object.range !== null) {
            message.range = exports.Distribution_Range.fromAmino(object.range);
        }
        if (object.bucket_options !== undefined && object.bucket_options !== null) {
            message.bucketOptions = exports.Distribution_BucketOptions.fromAmino(object.bucket_options);
        }
        message.bucketCounts = object.bucket_counts?.map(e => BigInt(e)) || [];
        message.exemplars = object.exemplars?.map(e => exports.Distribution_Exemplar.fromAmino(e)) || [];
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.count = message.count !== BigInt(0) ? message.count?.toString() : undefined;
        obj.mean = message.mean === 0 ? undefined : message.mean;
        obj.sum_of_squared_deviation = message.sumOfSquaredDeviation === 0 ? undefined : message.sumOfSquaredDeviation;
        obj.range = message.range ? exports.Distribution_Range.toAmino(message.range) : undefined;
        obj.bucket_options = message.bucketOptions ? exports.Distribution_BucketOptions.toAmino(message.bucketOptions) : undefined;
        if (message.bucketCounts) {
            obj.bucket_counts = message.bucketCounts.map(e => e.toString());
        }
        else {
            obj.bucket_counts = message.bucketCounts;
        }
        if (message.exemplars) {
            obj.exemplars = message.exemplars.map(e => e ? exports.Distribution_Exemplar.toAmino(e) : undefined);
        }
        else {
            obj.exemplars = message.exemplars;
        }
        return obj;
    },
    fromAminoMsg(object) {
        return exports.Distribution.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.Distribution.decode(message.value);
    },
    toProto(message) {
        return exports.Distribution.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.Distribution",
            value: exports.Distribution.encode(message).finish()
        };
    }
};
function createBaseDistribution_Range() {
    return {
        min: 0,
        max: 0
    };
}
exports.Distribution_Range = {
    typeUrl: "/google.api.Range",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.min !== 0) {
            writer.uint32(9).double(message.min);
        }
        if (message.max !== 0) {
            writer.uint32(17).double(message.max);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseDistribution_Range();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.min = reader.double();
                    break;
                case 2:
                    message.max = reader.double();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseDistribution_Range();
        message.min = object.min ?? 0;
        message.max = object.max ?? 0;
        return message;
    },
    fromAmino(object) {
        const message = createBaseDistribution_Range();
        if (object.min !== undefined && object.min !== null) {
            message.min = object.min;
        }
        if (object.max !== undefined && object.max !== null) {
            message.max = object.max;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.min = message.min === 0 ? undefined : message.min;
        obj.max = message.max === 0 ? undefined : message.max;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.Distribution_Range.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.Distribution_Range.decode(message.value);
    },
    toProto(message) {
        return exports.Distribution_Range.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.Range",
            value: exports.Distribution_Range.encode(message).finish()
        };
    }
};
function createBaseDistribution_BucketOptions() {
    return {
        linearBuckets: undefined,
        exponentialBuckets: undefined,
        explicitBuckets: undefined
    };
}
exports.Distribution_BucketOptions = {
    typeUrl: "/google.api.BucketOptions",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.linearBuckets !== undefined) {
            exports.Distribution_BucketOptions_Linear.encode(message.linearBuckets, writer.uint32(10).fork()).ldelim();
        }
        if (message.exponentialBuckets !== undefined) {
            exports.Distribution_BucketOptions_Exponential.encode(message.exponentialBuckets, writer.uint32(18).fork()).ldelim();
        }
        if (message.explicitBuckets !== undefined) {
            exports.Distribution_BucketOptions_Explicit.encode(message.explicitBuckets, writer.uint32(26).fork()).ldelim();
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseDistribution_BucketOptions();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.linearBuckets = exports.Distribution_BucketOptions_Linear.decode(reader, reader.uint32());
                    break;
                case 2:
                    message.exponentialBuckets = exports.Distribution_BucketOptions_Exponential.decode(reader, reader.uint32());
                    break;
                case 3:
                    message.explicitBuckets = exports.Distribution_BucketOptions_Explicit.decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseDistribution_BucketOptions();
        message.linearBuckets = object.linearBuckets !== undefined && object.linearBuckets !== null ? exports.Distribution_BucketOptions_Linear.fromPartial(object.linearBuckets) : undefined;
        message.exponentialBuckets = object.exponentialBuckets !== undefined && object.exponentialBuckets !== null ? exports.Distribution_BucketOptions_Exponential.fromPartial(object.exponentialBuckets) : undefined;
        message.explicitBuckets = object.explicitBuckets !== undefined && object.explicitBuckets !== null ? exports.Distribution_BucketOptions_Explicit.fromPartial(object.explicitBuckets) : undefined;
        return message;
    },
    fromAmino(object) {
        const message = createBaseDistribution_BucketOptions();
        if (object.linear_buckets !== undefined && object.linear_buckets !== null) {
            message.linearBuckets = exports.Distribution_BucketOptions_Linear.fromAmino(object.linear_buckets);
        }
        if (object.exponential_buckets !== undefined && object.exponential_buckets !== null) {
            message.exponentialBuckets = exports.Distribution_BucketOptions_Exponential.fromAmino(object.exponential_buckets);
        }
        if (object.explicit_buckets !== undefined && object.explicit_buckets !== null) {
            message.explicitBuckets = exports.Distribution_BucketOptions_Explicit.fromAmino(object.explicit_buckets);
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.linear_buckets = message.linearBuckets ? exports.Distribution_BucketOptions_Linear.toAmino(message.linearBuckets) : undefined;
        obj.exponential_buckets = message.exponentialBuckets ? exports.Distribution_BucketOptions_Exponential.toAmino(message.exponentialBuckets) : undefined;
        obj.explicit_buckets = message.explicitBuckets ? exports.Distribution_BucketOptions_Explicit.toAmino(message.explicitBuckets) : undefined;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.Distribution_BucketOptions.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.Distribution_BucketOptions.decode(message.value);
    },
    toProto(message) {
        return exports.Distribution_BucketOptions.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.BucketOptions",
            value: exports.Distribution_BucketOptions.encode(message).finish()
        };
    }
};
function createBaseDistribution_BucketOptions_Linear() {
    return {
        numFiniteBuckets: 0,
        width: 0,
        offset: 0
    };
}
exports.Distribution_BucketOptions_Linear = {
    typeUrl: "/google.api.Linear",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.numFiniteBuckets !== 0) {
            writer.uint32(8).int32(message.numFiniteBuckets);
        }
        if (message.width !== 0) {
            writer.uint32(17).double(message.width);
        }
        if (message.offset !== 0) {
            writer.uint32(25).double(message.offset);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseDistribution_BucketOptions_Linear();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.numFiniteBuckets = reader.int32();
                    break;
                case 2:
                    message.width = reader.double();
                    break;
                case 3:
                    message.offset = reader.double();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseDistribution_BucketOptions_Linear();
        message.numFiniteBuckets = object.numFiniteBuckets ?? 0;
        message.width = object.width ?? 0;
        message.offset = object.offset ?? 0;
        return message;
    },
    fromAmino(object) {
        const message = createBaseDistribution_BucketOptions_Linear();
        if (object.num_finite_buckets !== undefined && object.num_finite_buckets !== null) {
            message.numFiniteBuckets = object.num_finite_buckets;
        }
        if (object.width !== undefined && object.width !== null) {
            message.width = object.width;
        }
        if (object.offset !== undefined && object.offset !== null) {
            message.offset = object.offset;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.num_finite_buckets = message.numFiniteBuckets === 0 ? undefined : message.numFiniteBuckets;
        obj.width = message.width === 0 ? undefined : message.width;
        obj.offset = message.offset === 0 ? undefined : message.offset;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.Distribution_BucketOptions_Linear.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.Distribution_BucketOptions_Linear.decode(message.value);
    },
    toProto(message) {
        return exports.Distribution_BucketOptions_Linear.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.Linear",
            value: exports.Distribution_BucketOptions_Linear.encode(message).finish()
        };
    }
};
function createBaseDistribution_BucketOptions_Exponential() {
    return {
        numFiniteBuckets: 0,
        growthFactor: 0,
        scale: 0
    };
}
exports.Distribution_BucketOptions_Exponential = {
    typeUrl: "/google.api.Exponential",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.numFiniteBuckets !== 0) {
            writer.uint32(8).int32(message.numFiniteBuckets);
        }
        if (message.growthFactor !== 0) {
            writer.uint32(17).double(message.growthFactor);
        }
        if (message.scale !== 0) {
            writer.uint32(25).double(message.scale);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseDistribution_BucketOptions_Exponential();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.numFiniteBuckets = reader.int32();
                    break;
                case 2:
                    message.growthFactor = reader.double();
                    break;
                case 3:
                    message.scale = reader.double();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseDistribution_BucketOptions_Exponential();
        message.numFiniteBuckets = object.numFiniteBuckets ?? 0;
        message.growthFactor = object.growthFactor ?? 0;
        message.scale = object.scale ?? 0;
        return message;
    },
    fromAmino(object) {
        const message = createBaseDistribution_BucketOptions_Exponential();
        if (object.num_finite_buckets !== undefined && object.num_finite_buckets !== null) {
            message.numFiniteBuckets = object.num_finite_buckets;
        }
        if (object.growth_factor !== undefined && object.growth_factor !== null) {
            message.growthFactor = object.growth_factor;
        }
        if (object.scale !== undefined && object.scale !== null) {
            message.scale = object.scale;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.num_finite_buckets = message.numFiniteBuckets === 0 ? undefined : message.numFiniteBuckets;
        obj.growth_factor = message.growthFactor === 0 ? undefined : message.growthFactor;
        obj.scale = message.scale === 0 ? undefined : message.scale;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.Distribution_BucketOptions_Exponential.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.Distribution_BucketOptions_Exponential.decode(message.value);
    },
    toProto(message) {
        return exports.Distribution_BucketOptions_Exponential.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.Exponential",
            value: exports.Distribution_BucketOptions_Exponential.encode(message).finish()
        };
    }
};
function createBaseDistribution_BucketOptions_Explicit() {
    return {
        bounds: []
    };
}
exports.Distribution_BucketOptions_Explicit = {
    typeUrl: "/google.api.Explicit",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        writer.uint32(10).fork();
        for (const v of message.bounds) {
            writer.double(v);
        }
        writer.ldelim();
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseDistribution_BucketOptions_Explicit();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    if ((tag & 7) === 2) {
                        const end2 = reader.uint32() + reader.pos;
                        while (reader.pos < end2) {
                            message.bounds.push(reader.double());
                        }
                    }
                    else {
                        message.bounds.push(reader.double());
                    }
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseDistribution_BucketOptions_Explicit();
        message.bounds = object.bounds?.map(e => e) || [];
        return message;
    },
    fromAmino(object) {
        const message = createBaseDistribution_BucketOptions_Explicit();
        message.bounds = object.bounds?.map(e => e) || [];
        return message;
    },
    toAmino(message) {
        const obj = {};
        if (message.bounds) {
            obj.bounds = message.bounds.map(e => e);
        }
        else {
            obj.bounds = message.bounds;
        }
        return obj;
    },
    fromAminoMsg(object) {
        return exports.Distribution_BucketOptions_Explicit.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.Distribution_BucketOptions_Explicit.decode(message.value);
    },
    toProto(message) {
        return exports.Distribution_BucketOptions_Explicit.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.Explicit",
            value: exports.Distribution_BucketOptions_Explicit.encode(message).finish()
        };
    }
};
function createBaseDistribution_Exemplar() {
    return {
        value: 0,
        timestamp: undefined,
        attachments: []
    };
}
exports.Distribution_Exemplar = {
    typeUrl: "/google.api.Exemplar",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.value !== 0) {
            writer.uint32(9).double(message.value);
        }
        if (message.timestamp !== undefined) {
            timestamp_1.Timestamp.encode((0, helpers_1.toTimestamp)(message.timestamp), writer.uint32(18).fork()).ldelim();
        }
        for (const v of message.attachments) {
            any_1.Any.encode(v, writer.uint32(26).fork()).ldelim();
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseDistribution_Exemplar();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.value = reader.double();
                    break;
                case 2:
                    message.timestamp = (0, helpers_1.fromTimestamp)(timestamp_1.Timestamp.decode(reader, reader.uint32()));
                    break;
                case 3:
                    message.attachments.push(any_1.Any.decode(reader, reader.uint32()));
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseDistribution_Exemplar();
        message.value = object.value ?? 0;
        message.timestamp = object.timestamp ?? undefined;
        message.attachments = object.attachments?.map(e => any_1.Any.fromPartial(e)) || [];
        return message;
    },
    fromAmino(object) {
        const message = createBaseDistribution_Exemplar();
        if (object.value !== undefined && object.value !== null) {
            message.value = object.value;
        }
        if (object.timestamp !== undefined && object.timestamp !== null) {
            message.timestamp = (0, helpers_1.fromTimestamp)(timestamp_1.Timestamp.fromAmino(object.timestamp));
        }
        message.attachments = object.attachments?.map(e => any_1.Any.fromAmino(e)) || [];
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.value = message.value === 0 ? undefined : message.value;
        obj.timestamp = message.timestamp ? timestamp_1.Timestamp.toAmino((0, helpers_1.toTimestamp)(message.timestamp)) : undefined;
        if (message.attachments) {
            obj.attachments = message.attachments.map(e => e ? any_1.Any.toAmino(e) : undefined);
        }
        else {
            obj.attachments = message.attachments;
        }
        return obj;
    },
    fromAminoMsg(object) {
        return exports.Distribution_Exemplar.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.Distribution_Exemplar.decode(message.value);
    },
    toProto(message) {
        return exports.Distribution_Exemplar.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.Exemplar",
            value: exports.Distribution_Exemplar.encode(message).finish()
        };
    }
};
