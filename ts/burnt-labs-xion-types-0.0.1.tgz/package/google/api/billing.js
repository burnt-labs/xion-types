"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Billing_BillingDestination = exports.Billing = void 0;
//@ts-nocheck
const binary_1 = require("../../binary");
function createBaseBilling() {
    return {
        consumerDestinations: []
    };
}
exports.Billing = {
    typeUrl: "/google.api.Billing",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        for (const v of message.consumerDestinations) {
            exports.Billing_BillingDestination.encode(v, writer.uint32(66).fork()).ldelim();
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseBilling();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 8:
                    message.consumerDestinations.push(exports.Billing_BillingDestination.decode(reader, reader.uint32()));
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseBilling();
        message.consumerDestinations = object.consumerDestinations?.map(e => exports.Billing_BillingDestination.fromPartial(e)) || [];
        return message;
    },
    fromAmino(object) {
        const message = createBaseBilling();
        message.consumerDestinations = object.consumer_destinations?.map(e => exports.Billing_BillingDestination.fromAmino(e)) || [];
        return message;
    },
    toAmino(message) {
        const obj = {};
        if (message.consumerDestinations) {
            obj.consumer_destinations = message.consumerDestinations.map(e => e ? exports.Billing_BillingDestination.toAmino(e) : undefined);
        }
        else {
            obj.consumer_destinations = message.consumerDestinations;
        }
        return obj;
    },
    fromAminoMsg(object) {
        return exports.Billing.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.Billing.decode(message.value);
    },
    toProto(message) {
        return exports.Billing.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.Billing",
            value: exports.Billing.encode(message).finish()
        };
    }
};
function createBaseBilling_BillingDestination() {
    return {
        monitoredResource: "",
        metrics: []
    };
}
exports.Billing_BillingDestination = {
    typeUrl: "/google.api.BillingDestination",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.monitoredResource !== "") {
            writer.uint32(10).string(message.monitoredResource);
        }
        for (const v of message.metrics) {
            writer.uint32(18).string(v);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseBilling_BillingDestination();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.monitoredResource = reader.string();
                    break;
                case 2:
                    message.metrics.push(reader.string());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseBilling_BillingDestination();
        message.monitoredResource = object.monitoredResource ?? "";
        message.metrics = object.metrics?.map(e => e) || [];
        return message;
    },
    fromAmino(object) {
        const message = createBaseBilling_BillingDestination();
        if (object.monitored_resource !== undefined && object.monitored_resource !== null) {
            message.monitoredResource = object.monitored_resource;
        }
        message.metrics = object.metrics?.map(e => e) || [];
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.monitored_resource = message.monitoredResource === "" ? undefined : message.monitoredResource;
        if (message.metrics) {
            obj.metrics = message.metrics.map(e => e);
        }
        else {
            obj.metrics = message.metrics;
        }
        return obj;
    },
    fromAminoMsg(object) {
        return exports.Billing_BillingDestination.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.Billing_BillingDestination.decode(message.value);
    },
    toProto(message) {
        return exports.Billing_BillingDestination.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.BillingDestination",
            value: exports.Billing_BillingDestination.encode(message).finish()
        };
    }
};
