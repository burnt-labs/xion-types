"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.RoutingParameter = exports.RoutingRule = void 0;
//@ts-nocheck
const binary_1 = require("../../binary");
function createBaseRoutingRule() {
    return {
        routingParameters: []
    };
}
exports.RoutingRule = {
    typeUrl: "/google.api.RoutingRule",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        for (const v of message.routingParameters) {
            exports.RoutingParameter.encode(v, writer.uint32(18).fork()).ldelim();
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseRoutingRule();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 2:
                    message.routingParameters.push(exports.RoutingParameter.decode(reader, reader.uint32()));
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseRoutingRule();
        message.routingParameters = object.routingParameters?.map(e => exports.RoutingParameter.fromPartial(e)) || [];
        return message;
    },
    fromAmino(object) {
        const message = createBaseRoutingRule();
        message.routingParameters = object.routing_parameters?.map(e => exports.RoutingParameter.fromAmino(e)) || [];
        return message;
    },
    toAmino(message) {
        const obj = {};
        if (message.routingParameters) {
            obj.routing_parameters = message.routingParameters.map(e => e ? exports.RoutingParameter.toAmino(e) : undefined);
        }
        else {
            obj.routing_parameters = message.routingParameters;
        }
        return obj;
    },
    fromAminoMsg(object) {
        return exports.RoutingRule.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.RoutingRule.decode(message.value);
    },
    toProto(message) {
        return exports.RoutingRule.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.RoutingRule",
            value: exports.RoutingRule.encode(message).finish()
        };
    }
};
function createBaseRoutingParameter() {
    return {
        field: "",
        pathTemplate: ""
    };
}
exports.RoutingParameter = {
    typeUrl: "/google.api.RoutingParameter",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.field !== "") {
            writer.uint32(10).string(message.field);
        }
        if (message.pathTemplate !== "") {
            writer.uint32(18).string(message.pathTemplate);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseRoutingParameter();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.field = reader.string();
                    break;
                case 2:
                    message.pathTemplate = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseRoutingParameter();
        message.field = object.field ?? "";
        message.pathTemplate = object.pathTemplate ?? "";
        return message;
    },
    fromAmino(object) {
        const message = createBaseRoutingParameter();
        if (object.field !== undefined && object.field !== null) {
            message.field = object.field;
        }
        if (object.path_template !== undefined && object.path_template !== null) {
            message.pathTemplate = object.path_template;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.field = message.field === "" ? undefined : message.field;
        obj.path_template = message.pathTemplate === "" ? undefined : message.pathTemplate;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.RoutingParameter.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.RoutingParameter.decode(message.value);
    },
    toProto(message) {
        return exports.RoutingParameter.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.RoutingParameter",
            value: exports.RoutingParameter.encode(message).finish()
        };
    }
};
