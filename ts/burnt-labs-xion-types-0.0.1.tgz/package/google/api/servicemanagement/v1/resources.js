"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Rollout_DeleteServiceStrategy = exports.Rollout_TrafficPercentStrategy = exports.Rollout_TrafficPercentStrategy_PercentagesEntry = exports.Rollout = exports.ChangeReport = exports.ConfigRef = exports.ConfigFile = exports.ConfigSource = exports.Diagnostic = exports.OperationMetadata_Step = exports.OperationMetadata = exports.ManagedService = exports.Rollout_RolloutStatusAmino = exports.Rollout_RolloutStatusSDKType = exports.Rollout_RolloutStatus = exports.ConfigFile_FileTypeAmino = exports.ConfigFile_FileTypeSDKType = exports.ConfigFile_FileType = exports.Diagnostic_KindAmino = exports.Diagnostic_KindSDKType = exports.Diagnostic_Kind = exports.OperationMetadata_StatusAmino = exports.OperationMetadata_StatusSDKType = exports.OperationMetadata_Status = void 0;
exports.operationMetadata_StatusFromJSON = operationMetadata_StatusFromJSON;
exports.operationMetadata_StatusToJSON = operationMetadata_StatusToJSON;
exports.diagnostic_KindFromJSON = diagnostic_KindFromJSON;
exports.diagnostic_KindToJSON = diagnostic_KindToJSON;
exports.configFile_FileTypeFromJSON = configFile_FileTypeFromJSON;
exports.configFile_FileTypeToJSON = configFile_FileTypeToJSON;
exports.rollout_RolloutStatusFromJSON = rollout_RolloutStatusFromJSON;
exports.rollout_RolloutStatusToJSON = rollout_RolloutStatusToJSON;
//@ts-nocheck
const timestamp_1 = require("../../../protobuf/timestamp");
const config_change_1 = require("../../config_change");
const binary_1 = require("../../../../binary");
const helpers_1 = require("../../../../helpers");
/** Code describes the status of the operation (or one of its steps). */
var OperationMetadata_Status;
(function (OperationMetadata_Status) {
    /** STATUS_UNSPECIFIED - Unspecifed code. */
    OperationMetadata_Status[OperationMetadata_Status["STATUS_UNSPECIFIED"] = 0] = "STATUS_UNSPECIFIED";
    /** DONE - The operation or step has completed without errors. */
    OperationMetadata_Status[OperationMetadata_Status["DONE"] = 1] = "DONE";
    /** NOT_STARTED - The operation or step has not started yet. */
    OperationMetadata_Status[OperationMetadata_Status["NOT_STARTED"] = 2] = "NOT_STARTED";
    /** IN_PROGRESS - The operation or step is in progress. */
    OperationMetadata_Status[OperationMetadata_Status["IN_PROGRESS"] = 3] = "IN_PROGRESS";
    /**
     * FAILED - The operation or step has completed with errors. If the operation is
     * rollbackable, the rollback completed with errors too.
     */
    OperationMetadata_Status[OperationMetadata_Status["FAILED"] = 4] = "FAILED";
    /** CANCELLED - The operation or step has completed with cancellation. */
    OperationMetadata_Status[OperationMetadata_Status["CANCELLED"] = 5] = "CANCELLED";
    OperationMetadata_Status[OperationMetadata_Status["UNRECOGNIZED"] = -1] = "UNRECOGNIZED";
})(OperationMetadata_Status || (exports.OperationMetadata_Status = OperationMetadata_Status = {}));
exports.OperationMetadata_StatusSDKType = OperationMetadata_Status;
exports.OperationMetadata_StatusAmino = OperationMetadata_Status;
function operationMetadata_StatusFromJSON(object) {
    switch (object) {
        case 0:
        case "STATUS_UNSPECIFIED":
            return OperationMetadata_Status.STATUS_UNSPECIFIED;
        case 1:
        case "DONE":
            return OperationMetadata_Status.DONE;
        case 2:
        case "NOT_STARTED":
            return OperationMetadata_Status.NOT_STARTED;
        case 3:
        case "IN_PROGRESS":
            return OperationMetadata_Status.IN_PROGRESS;
        case 4:
        case "FAILED":
            return OperationMetadata_Status.FAILED;
        case 5:
        case "CANCELLED":
            return OperationMetadata_Status.CANCELLED;
        case -1:
        case "UNRECOGNIZED":
        default:
            return OperationMetadata_Status.UNRECOGNIZED;
    }
}
function operationMetadata_StatusToJSON(object) {
    switch (object) {
        case OperationMetadata_Status.STATUS_UNSPECIFIED:
            return "STATUS_UNSPECIFIED";
        case OperationMetadata_Status.DONE:
            return "DONE";
        case OperationMetadata_Status.NOT_STARTED:
            return "NOT_STARTED";
        case OperationMetadata_Status.IN_PROGRESS:
            return "IN_PROGRESS";
        case OperationMetadata_Status.FAILED:
            return "FAILED";
        case OperationMetadata_Status.CANCELLED:
            return "CANCELLED";
        case OperationMetadata_Status.UNRECOGNIZED:
        default:
            return "UNRECOGNIZED";
    }
}
/** The kind of diagnostic information possible. */
var Diagnostic_Kind;
(function (Diagnostic_Kind) {
    /** WARNING - Warnings and errors */
    Diagnostic_Kind[Diagnostic_Kind["WARNING"] = 0] = "WARNING";
    /** ERROR - Only errors */
    Diagnostic_Kind[Diagnostic_Kind["ERROR"] = 1] = "ERROR";
    Diagnostic_Kind[Diagnostic_Kind["UNRECOGNIZED"] = -1] = "UNRECOGNIZED";
})(Diagnostic_Kind || (exports.Diagnostic_Kind = Diagnostic_Kind = {}));
exports.Diagnostic_KindSDKType = Diagnostic_Kind;
exports.Diagnostic_KindAmino = Diagnostic_Kind;
function diagnostic_KindFromJSON(object) {
    switch (object) {
        case 0:
        case "WARNING":
            return Diagnostic_Kind.WARNING;
        case 1:
        case "ERROR":
            return Diagnostic_Kind.ERROR;
        case -1:
        case "UNRECOGNIZED":
        default:
            return Diagnostic_Kind.UNRECOGNIZED;
    }
}
function diagnostic_KindToJSON(object) {
    switch (object) {
        case Diagnostic_Kind.WARNING:
            return "WARNING";
        case Diagnostic_Kind.ERROR:
            return "ERROR";
        case Diagnostic_Kind.UNRECOGNIZED:
        default:
            return "UNRECOGNIZED";
    }
}
var ConfigFile_FileType;
(function (ConfigFile_FileType) {
    /** FILE_TYPE_UNSPECIFIED - Unknown file type. */
    ConfigFile_FileType[ConfigFile_FileType["FILE_TYPE_UNSPECIFIED"] = 0] = "FILE_TYPE_UNSPECIFIED";
    /** SERVICE_CONFIG_YAML - YAML-specification of service. */
    ConfigFile_FileType[ConfigFile_FileType["SERVICE_CONFIG_YAML"] = 1] = "SERVICE_CONFIG_YAML";
    /** OPEN_API_JSON - OpenAPI specification, serialized in JSON. */
    ConfigFile_FileType[ConfigFile_FileType["OPEN_API_JSON"] = 2] = "OPEN_API_JSON";
    /** OPEN_API_YAML - OpenAPI specification, serialized in YAML. */
    ConfigFile_FileType[ConfigFile_FileType["OPEN_API_YAML"] = 3] = "OPEN_API_YAML";
    /**
     * FILE_DESCRIPTOR_SET_PROTO - FileDescriptorSet, generated by protoc.
     *
     * To generate, use protoc with imports and source info included.
     * For an example test.proto file, the following command would put the value
     * in a new file named out.pb.
     *
     * $protoc --include_imports --include_source_info test.proto -o out.pb
     */
    ConfigFile_FileType[ConfigFile_FileType["FILE_DESCRIPTOR_SET_PROTO"] = 4] = "FILE_DESCRIPTOR_SET_PROTO";
    /**
     * PROTO_FILE - Uncompiled Proto file. Used for storage and display purposes only,
     * currently server-side compilation is not supported. Should match the
     * inputs to 'protoc' command used to generated FILE_DESCRIPTOR_SET_PROTO. A
     * file of this type can only be included if at least one file of type
     * FILE_DESCRIPTOR_SET_PROTO is included.
     */
    ConfigFile_FileType[ConfigFile_FileType["PROTO_FILE"] = 6] = "PROTO_FILE";
    ConfigFile_FileType[ConfigFile_FileType["UNRECOGNIZED"] = -1] = "UNRECOGNIZED";
})(ConfigFile_FileType || (exports.ConfigFile_FileType = ConfigFile_FileType = {}));
exports.ConfigFile_FileTypeSDKType = ConfigFile_FileType;
exports.ConfigFile_FileTypeAmino = ConfigFile_FileType;
function configFile_FileTypeFromJSON(object) {
    switch (object) {
        case 0:
        case "FILE_TYPE_UNSPECIFIED":
            return ConfigFile_FileType.FILE_TYPE_UNSPECIFIED;
        case 1:
        case "SERVICE_CONFIG_YAML":
            return ConfigFile_FileType.SERVICE_CONFIG_YAML;
        case 2:
        case "OPEN_API_JSON":
            return ConfigFile_FileType.OPEN_API_JSON;
        case 3:
        case "OPEN_API_YAML":
            return ConfigFile_FileType.OPEN_API_YAML;
        case 4:
        case "FILE_DESCRIPTOR_SET_PROTO":
            return ConfigFile_FileType.FILE_DESCRIPTOR_SET_PROTO;
        case 6:
        case "PROTO_FILE":
            return ConfigFile_FileType.PROTO_FILE;
        case -1:
        case "UNRECOGNIZED":
        default:
            return ConfigFile_FileType.UNRECOGNIZED;
    }
}
function configFile_FileTypeToJSON(object) {
    switch (object) {
        case ConfigFile_FileType.FILE_TYPE_UNSPECIFIED:
            return "FILE_TYPE_UNSPECIFIED";
        case ConfigFile_FileType.SERVICE_CONFIG_YAML:
            return "SERVICE_CONFIG_YAML";
        case ConfigFile_FileType.OPEN_API_JSON:
            return "OPEN_API_JSON";
        case ConfigFile_FileType.OPEN_API_YAML:
            return "OPEN_API_YAML";
        case ConfigFile_FileType.FILE_DESCRIPTOR_SET_PROTO:
            return "FILE_DESCRIPTOR_SET_PROTO";
        case ConfigFile_FileType.PROTO_FILE:
            return "PROTO_FILE";
        case ConfigFile_FileType.UNRECOGNIZED:
        default:
            return "UNRECOGNIZED";
    }
}
/** Status of a Rollout. */
var Rollout_RolloutStatus;
(function (Rollout_RolloutStatus) {
    /** ROLLOUT_STATUS_UNSPECIFIED - No status specified. */
    Rollout_RolloutStatus[Rollout_RolloutStatus["ROLLOUT_STATUS_UNSPECIFIED"] = 0] = "ROLLOUT_STATUS_UNSPECIFIED";
    /** IN_PROGRESS - The Rollout is in progress. */
    Rollout_RolloutStatus[Rollout_RolloutStatus["IN_PROGRESS"] = 1] = "IN_PROGRESS";
    /** SUCCESS - The Rollout has completed successfully. */
    Rollout_RolloutStatus[Rollout_RolloutStatus["SUCCESS"] = 2] = "SUCCESS";
    /**
     * CANCELLED - The Rollout has been cancelled. This can happen if you have overlapping
     * Rollout pushes, and the previous ones will be cancelled.
     */
    Rollout_RolloutStatus[Rollout_RolloutStatus["CANCELLED"] = 3] = "CANCELLED";
    /** FAILED - The Rollout has failed and the rollback attempt has failed too. */
    Rollout_RolloutStatus[Rollout_RolloutStatus["FAILED"] = 4] = "FAILED";
    /** PENDING - The Rollout has not started yet and is pending for execution. */
    Rollout_RolloutStatus[Rollout_RolloutStatus["PENDING"] = 5] = "PENDING";
    /**
     * FAILED_ROLLED_BACK - The Rollout has failed and rolled back to the previous successful
     * Rollout.
     */
    Rollout_RolloutStatus[Rollout_RolloutStatus["FAILED_ROLLED_BACK"] = 6] = "FAILED_ROLLED_BACK";
    Rollout_RolloutStatus[Rollout_RolloutStatus["UNRECOGNIZED"] = -1] = "UNRECOGNIZED";
})(Rollout_RolloutStatus || (exports.Rollout_RolloutStatus = Rollout_RolloutStatus = {}));
exports.Rollout_RolloutStatusSDKType = Rollout_RolloutStatus;
exports.Rollout_RolloutStatusAmino = Rollout_RolloutStatus;
function rollout_RolloutStatusFromJSON(object) {
    switch (object) {
        case 0:
        case "ROLLOUT_STATUS_UNSPECIFIED":
            return Rollout_RolloutStatus.ROLLOUT_STATUS_UNSPECIFIED;
        case 1:
        case "IN_PROGRESS":
            return Rollout_RolloutStatus.IN_PROGRESS;
        case 2:
        case "SUCCESS":
            return Rollout_RolloutStatus.SUCCESS;
        case 3:
        case "CANCELLED":
            return Rollout_RolloutStatus.CANCELLED;
        case 4:
        case "FAILED":
            return Rollout_RolloutStatus.FAILED;
        case 5:
        case "PENDING":
            return Rollout_RolloutStatus.PENDING;
        case 6:
        case "FAILED_ROLLED_BACK":
            return Rollout_RolloutStatus.FAILED_ROLLED_BACK;
        case -1:
        case "UNRECOGNIZED":
        default:
            return Rollout_RolloutStatus.UNRECOGNIZED;
    }
}
function rollout_RolloutStatusToJSON(object) {
    switch (object) {
        case Rollout_RolloutStatus.ROLLOUT_STATUS_UNSPECIFIED:
            return "ROLLOUT_STATUS_UNSPECIFIED";
        case Rollout_RolloutStatus.IN_PROGRESS:
            return "IN_PROGRESS";
        case Rollout_RolloutStatus.SUCCESS:
            return "SUCCESS";
        case Rollout_RolloutStatus.CANCELLED:
            return "CANCELLED";
        case Rollout_RolloutStatus.FAILED:
            return "FAILED";
        case Rollout_RolloutStatus.PENDING:
            return "PENDING";
        case Rollout_RolloutStatus.FAILED_ROLLED_BACK:
            return "FAILED_ROLLED_BACK";
        case Rollout_RolloutStatus.UNRECOGNIZED:
        default:
            return "UNRECOGNIZED";
    }
}
function createBaseManagedService() {
    return {
        serviceName: "",
        producerProjectId: ""
    };
}
exports.ManagedService = {
    typeUrl: "/google.api.servicemanagement.v1.ManagedService",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.serviceName !== "") {
            writer.uint32(18).string(message.serviceName);
        }
        if (message.producerProjectId !== "") {
            writer.uint32(26).string(message.producerProjectId);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseManagedService();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 2:
                    message.serviceName = reader.string();
                    break;
                case 3:
                    message.producerProjectId = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseManagedService();
        message.serviceName = object.serviceName ?? "";
        message.producerProjectId = object.producerProjectId ?? "";
        return message;
    },
    fromAmino(object) {
        const message = createBaseManagedService();
        if (object.service_name !== undefined && object.service_name !== null) {
            message.serviceName = object.service_name;
        }
        if (object.producer_project_id !== undefined && object.producer_project_id !== null) {
            message.producerProjectId = object.producer_project_id;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.service_name = message.serviceName === "" ? undefined : message.serviceName;
        obj.producer_project_id = message.producerProjectId === "" ? undefined : message.producerProjectId;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.ManagedService.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.ManagedService.decode(message.value);
    },
    toProto(message) {
        return exports.ManagedService.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.servicemanagement.v1.ManagedService",
            value: exports.ManagedService.encode(message).finish()
        };
    }
};
function createBaseOperationMetadata() {
    return {
        resourceNames: [],
        steps: [],
        progressPercentage: 0,
        startTime: undefined
    };
}
exports.OperationMetadata = {
    typeUrl: "/google.api.servicemanagement.v1.OperationMetadata",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        for (const v of message.resourceNames) {
            writer.uint32(10).string(v);
        }
        for (const v of message.steps) {
            exports.OperationMetadata_Step.encode(v, writer.uint32(18).fork()).ldelim();
        }
        if (message.progressPercentage !== 0) {
            writer.uint32(24).int32(message.progressPercentage);
        }
        if (message.startTime !== undefined) {
            timestamp_1.Timestamp.encode((0, helpers_1.toTimestamp)(message.startTime), writer.uint32(34).fork()).ldelim();
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseOperationMetadata();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.resourceNames.push(reader.string());
                    break;
                case 2:
                    message.steps.push(exports.OperationMetadata_Step.decode(reader, reader.uint32()));
                    break;
                case 3:
                    message.progressPercentage = reader.int32();
                    break;
                case 4:
                    message.startTime = (0, helpers_1.fromTimestamp)(timestamp_1.Timestamp.decode(reader, reader.uint32()));
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseOperationMetadata();
        message.resourceNames = object.resourceNames?.map(e => e) || [];
        message.steps = object.steps?.map(e => exports.OperationMetadata_Step.fromPartial(e)) || [];
        message.progressPercentage = object.progressPercentage ?? 0;
        message.startTime = object.startTime ?? undefined;
        return message;
    },
    fromAmino(object) {
        const message = createBaseOperationMetadata();
        message.resourceNames = object.resource_names?.map(e => e) || [];
        message.steps = object.steps?.map(e => exports.OperationMetadata_Step.fromAmino(e)) || [];
        if (object.progress_percentage !== undefined && object.progress_percentage !== null) {
            message.progressPercentage = object.progress_percentage;
        }
        if (object.start_time !== undefined && object.start_time !== null) {
            message.startTime = (0, helpers_1.fromTimestamp)(timestamp_1.Timestamp.fromAmino(object.start_time));
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        if (message.resourceNames) {
            obj.resource_names = message.resourceNames.map(e => e);
        }
        else {
            obj.resource_names = message.resourceNames;
        }
        if (message.steps) {
            obj.steps = message.steps.map(e => e ? exports.OperationMetadata_Step.toAmino(e) : undefined);
        }
        else {
            obj.steps = message.steps;
        }
        obj.progress_percentage = message.progressPercentage === 0 ? undefined : message.progressPercentage;
        obj.start_time = message.startTime ? timestamp_1.Timestamp.toAmino((0, helpers_1.toTimestamp)(message.startTime)) : undefined;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.OperationMetadata.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.OperationMetadata.decode(message.value);
    },
    toProto(message) {
        return exports.OperationMetadata.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.servicemanagement.v1.OperationMetadata",
            value: exports.OperationMetadata.encode(message).finish()
        };
    }
};
function createBaseOperationMetadata_Step() {
    return {
        description: "",
        status: 0
    };
}
exports.OperationMetadata_Step = {
    typeUrl: "/google.api.servicemanagement.v1.Step",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.description !== "") {
            writer.uint32(18).string(message.description);
        }
        if (message.status !== 0) {
            writer.uint32(32).int32(message.status);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseOperationMetadata_Step();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 2:
                    message.description = reader.string();
                    break;
                case 4:
                    message.status = reader.int32();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseOperationMetadata_Step();
        message.description = object.description ?? "";
        message.status = object.status ?? 0;
        return message;
    },
    fromAmino(object) {
        const message = createBaseOperationMetadata_Step();
        if (object.description !== undefined && object.description !== null) {
            message.description = object.description;
        }
        if (object.status !== undefined && object.status !== null) {
            message.status = object.status;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.description = message.description === "" ? undefined : message.description;
        obj.status = message.status === 0 ? undefined : message.status;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.OperationMetadata_Step.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.OperationMetadata_Step.decode(message.value);
    },
    toProto(message) {
        return exports.OperationMetadata_Step.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.servicemanagement.v1.Step",
            value: exports.OperationMetadata_Step.encode(message).finish()
        };
    }
};
function createBaseDiagnostic() {
    return {
        location: "",
        kind: 0,
        message: ""
    };
}
exports.Diagnostic = {
    typeUrl: "/google.api.servicemanagement.v1.Diagnostic",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.location !== "") {
            writer.uint32(10).string(message.location);
        }
        if (message.kind !== 0) {
            writer.uint32(16).int32(message.kind);
        }
        if (message.message !== "") {
            writer.uint32(26).string(message.message);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseDiagnostic();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.location = reader.string();
                    break;
                case 2:
                    message.kind = reader.int32();
                    break;
                case 3:
                    message.message = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseDiagnostic();
        message.location = object.location ?? "";
        message.kind = object.kind ?? 0;
        message.message = object.message ?? "";
        return message;
    },
    fromAmino(object) {
        const message = createBaseDiagnostic();
        if (object.location !== undefined && object.location !== null) {
            message.location = object.location;
        }
        if (object.kind !== undefined && object.kind !== null) {
            message.kind = object.kind;
        }
        if (object.message !== undefined && object.message !== null) {
            message.message = object.message;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.location = message.location === "" ? undefined : message.location;
        obj.kind = message.kind === 0 ? undefined : message.kind;
        obj.message = message.message === "" ? undefined : message.message;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.Diagnostic.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.Diagnostic.decode(message.value);
    },
    toProto(message) {
        return exports.Diagnostic.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.servicemanagement.v1.Diagnostic",
            value: exports.Diagnostic.encode(message).finish()
        };
    }
};
function createBaseConfigSource() {
    return {
        id: "",
        files: []
    };
}
exports.ConfigSource = {
    typeUrl: "/google.api.servicemanagement.v1.ConfigSource",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.id !== "") {
            writer.uint32(42).string(message.id);
        }
        for (const v of message.files) {
            exports.ConfigFile.encode(v, writer.uint32(18).fork()).ldelim();
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseConfigSource();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 5:
                    message.id = reader.string();
                    break;
                case 2:
                    message.files.push(exports.ConfigFile.decode(reader, reader.uint32()));
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseConfigSource();
        message.id = object.id ?? "";
        message.files = object.files?.map(e => exports.ConfigFile.fromPartial(e)) || [];
        return message;
    },
    fromAmino(object) {
        const message = createBaseConfigSource();
        if (object.id !== undefined && object.id !== null) {
            message.id = object.id;
        }
        message.files = object.files?.map(e => exports.ConfigFile.fromAmino(e)) || [];
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.id = message.id === "" ? undefined : message.id;
        if (message.files) {
            obj.files = message.files.map(e => e ? exports.ConfigFile.toAmino(e) : undefined);
        }
        else {
            obj.files = message.files;
        }
        return obj;
    },
    fromAminoMsg(object) {
        return exports.ConfigSource.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.ConfigSource.decode(message.value);
    },
    toProto(message) {
        return exports.ConfigSource.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.servicemanagement.v1.ConfigSource",
            value: exports.ConfigSource.encode(message).finish()
        };
    }
};
function createBaseConfigFile() {
    return {
        filePath: "",
        fileContents: new Uint8Array(),
        fileType: 0
    };
}
exports.ConfigFile = {
    typeUrl: "/google.api.servicemanagement.v1.ConfigFile",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.filePath !== "") {
            writer.uint32(10).string(message.filePath);
        }
        if (message.fileContents.length !== 0) {
            writer.uint32(26).bytes(message.fileContents);
        }
        if (message.fileType !== 0) {
            writer.uint32(32).int32(message.fileType);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseConfigFile();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.filePath = reader.string();
                    break;
                case 3:
                    message.fileContents = reader.bytes();
                    break;
                case 4:
                    message.fileType = reader.int32();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseConfigFile();
        message.filePath = object.filePath ?? "";
        message.fileContents = object.fileContents ?? new Uint8Array();
        message.fileType = object.fileType ?? 0;
        return message;
    },
    fromAmino(object) {
        const message = createBaseConfigFile();
        if (object.file_path !== undefined && object.file_path !== null) {
            message.filePath = object.file_path;
        }
        if (object.file_contents !== undefined && object.file_contents !== null) {
            message.fileContents = (0, helpers_1.bytesFromBase64)(object.file_contents);
        }
        if (object.file_type !== undefined && object.file_type !== null) {
            message.fileType = object.file_type;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.file_path = message.filePath === "" ? undefined : message.filePath;
        obj.file_contents = message.fileContents ? (0, helpers_1.base64FromBytes)(message.fileContents) : undefined;
        obj.file_type = message.fileType === 0 ? undefined : message.fileType;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.ConfigFile.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.ConfigFile.decode(message.value);
    },
    toProto(message) {
        return exports.ConfigFile.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.servicemanagement.v1.ConfigFile",
            value: exports.ConfigFile.encode(message).finish()
        };
    }
};
function createBaseConfigRef() {
    return {
        name: ""
    };
}
exports.ConfigRef = {
    typeUrl: "/google.api.servicemanagement.v1.ConfigRef",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.name !== "") {
            writer.uint32(10).string(message.name);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseConfigRef();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.name = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseConfigRef();
        message.name = object.name ?? "";
        return message;
    },
    fromAmino(object) {
        const message = createBaseConfigRef();
        if (object.name !== undefined && object.name !== null) {
            message.name = object.name;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.name = message.name === "" ? undefined : message.name;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.ConfigRef.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.ConfigRef.decode(message.value);
    },
    toProto(message) {
        return exports.ConfigRef.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.servicemanagement.v1.ConfigRef",
            value: exports.ConfigRef.encode(message).finish()
        };
    }
};
function createBaseChangeReport() {
    return {
        configChanges: []
    };
}
exports.ChangeReport = {
    typeUrl: "/google.api.servicemanagement.v1.ChangeReport",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        for (const v of message.configChanges) {
            config_change_1.ConfigChange.encode(v, writer.uint32(10).fork()).ldelim();
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseChangeReport();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.configChanges.push(config_change_1.ConfigChange.decode(reader, reader.uint32()));
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseChangeReport();
        message.configChanges = object.configChanges?.map(e => config_change_1.ConfigChange.fromPartial(e)) || [];
        return message;
    },
    fromAmino(object) {
        const message = createBaseChangeReport();
        message.configChanges = object.config_changes?.map(e => config_change_1.ConfigChange.fromAmino(e)) || [];
        return message;
    },
    toAmino(message) {
        const obj = {};
        if (message.configChanges) {
            obj.config_changes = message.configChanges.map(e => e ? config_change_1.ConfigChange.toAmino(e) : undefined);
        }
        else {
            obj.config_changes = message.configChanges;
        }
        return obj;
    },
    fromAminoMsg(object) {
        return exports.ChangeReport.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.ChangeReport.decode(message.value);
    },
    toProto(message) {
        return exports.ChangeReport.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.servicemanagement.v1.ChangeReport",
            value: exports.ChangeReport.encode(message).finish()
        };
    }
};
function createBaseRollout() {
    return {
        rolloutId: "",
        createTime: undefined,
        createdBy: "",
        status: 0,
        trafficPercentStrategy: undefined,
        deleteServiceStrategy: undefined,
        serviceName: ""
    };
}
exports.Rollout = {
    typeUrl: "/google.api.servicemanagement.v1.Rollout",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.rolloutId !== "") {
            writer.uint32(10).string(message.rolloutId);
        }
        if (message.createTime !== undefined) {
            timestamp_1.Timestamp.encode((0, helpers_1.toTimestamp)(message.createTime), writer.uint32(18).fork()).ldelim();
        }
        if (message.createdBy !== "") {
            writer.uint32(26).string(message.createdBy);
        }
        if (message.status !== 0) {
            writer.uint32(32).int32(message.status);
        }
        if (message.trafficPercentStrategy !== undefined) {
            exports.Rollout_TrafficPercentStrategy.encode(message.trafficPercentStrategy, writer.uint32(42).fork()).ldelim();
        }
        if (message.deleteServiceStrategy !== undefined) {
            exports.Rollout_DeleteServiceStrategy.encode(message.deleteServiceStrategy, writer.uint32(1602).fork()).ldelim();
        }
        if (message.serviceName !== "") {
            writer.uint32(66).string(message.serviceName);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseRollout();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.rolloutId = reader.string();
                    break;
                case 2:
                    message.createTime = (0, helpers_1.fromTimestamp)(timestamp_1.Timestamp.decode(reader, reader.uint32()));
                    break;
                case 3:
                    message.createdBy = reader.string();
                    break;
                case 4:
                    message.status = reader.int32();
                    break;
                case 5:
                    message.trafficPercentStrategy = exports.Rollout_TrafficPercentStrategy.decode(reader, reader.uint32());
                    break;
                case 200:
                    message.deleteServiceStrategy = exports.Rollout_DeleteServiceStrategy.decode(reader, reader.uint32());
                    break;
                case 8:
                    message.serviceName = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseRollout();
        message.rolloutId = object.rolloutId ?? "";
        message.createTime = object.createTime ?? undefined;
        message.createdBy = object.createdBy ?? "";
        message.status = object.status ?? 0;
        message.trafficPercentStrategy = object.trafficPercentStrategy !== undefined && object.trafficPercentStrategy !== null ? exports.Rollout_TrafficPercentStrategy.fromPartial(object.trafficPercentStrategy) : undefined;
        message.deleteServiceStrategy = object.deleteServiceStrategy !== undefined && object.deleteServiceStrategy !== null ? exports.Rollout_DeleteServiceStrategy.fromPartial(object.deleteServiceStrategy) : undefined;
        message.serviceName = object.serviceName ?? "";
        return message;
    },
    fromAmino(object) {
        const message = createBaseRollout();
        if (object.rollout_id !== undefined && object.rollout_id !== null) {
            message.rolloutId = object.rollout_id;
        }
        if (object.create_time !== undefined && object.create_time !== null) {
            message.createTime = (0, helpers_1.fromTimestamp)(timestamp_1.Timestamp.fromAmino(object.create_time));
        }
        if (object.created_by !== undefined && object.created_by !== null) {
            message.createdBy = object.created_by;
        }
        if (object.status !== undefined && object.status !== null) {
            message.status = object.status;
        }
        if (object.traffic_percent_strategy !== undefined && object.traffic_percent_strategy !== null) {
            message.trafficPercentStrategy = exports.Rollout_TrafficPercentStrategy.fromAmino(object.traffic_percent_strategy);
        }
        if (object.delete_service_strategy !== undefined && object.delete_service_strategy !== null) {
            message.deleteServiceStrategy = exports.Rollout_DeleteServiceStrategy.fromAmino(object.delete_service_strategy);
        }
        if (object.service_name !== undefined && object.service_name !== null) {
            message.serviceName = object.service_name;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.rollout_id = message.rolloutId === "" ? undefined : message.rolloutId;
        obj.create_time = message.createTime ? timestamp_1.Timestamp.toAmino((0, helpers_1.toTimestamp)(message.createTime)) : undefined;
        obj.created_by = message.createdBy === "" ? undefined : message.createdBy;
        obj.status = message.status === 0 ? undefined : message.status;
        obj.traffic_percent_strategy = message.trafficPercentStrategy ? exports.Rollout_TrafficPercentStrategy.toAmino(message.trafficPercentStrategy) : undefined;
        obj.delete_service_strategy = message.deleteServiceStrategy ? exports.Rollout_DeleteServiceStrategy.toAmino(message.deleteServiceStrategy) : undefined;
        obj.service_name = message.serviceName === "" ? undefined : message.serviceName;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.Rollout.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.Rollout.decode(message.value);
    },
    toProto(message) {
        return exports.Rollout.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.servicemanagement.v1.Rollout",
            value: exports.Rollout.encode(message).finish()
        };
    }
};
function createBaseRollout_TrafficPercentStrategy_PercentagesEntry() {
    return {
        key: "",
        value: 0
    };
}
exports.Rollout_TrafficPercentStrategy_PercentagesEntry = {
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.key !== "") {
            writer.uint32(10).string(message.key);
        }
        if (message.value !== 0) {
            writer.uint32(17).double(message.value);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseRollout_TrafficPercentStrategy_PercentagesEntry();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.key = reader.string();
                    break;
                case 2:
                    message.value = reader.double();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseRollout_TrafficPercentStrategy_PercentagesEntry();
        message.key = object.key ?? "";
        message.value = object.value ?? 0;
        return message;
    },
    fromAmino(object) {
        const message = createBaseRollout_TrafficPercentStrategy_PercentagesEntry();
        if (object.key !== undefined && object.key !== null) {
            message.key = object.key;
        }
        if (object.value !== undefined && object.value !== null) {
            message.value = object.value;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.key = message.key === "" ? undefined : message.key;
        obj.value = message.value === 0 ? undefined : message.value;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.Rollout_TrafficPercentStrategy_PercentagesEntry.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.Rollout_TrafficPercentStrategy_PercentagesEntry.decode(message.value);
    },
    toProto(message) {
        return exports.Rollout_TrafficPercentStrategy_PercentagesEntry.encode(message).finish();
    }
};
function createBaseRollout_TrafficPercentStrategy() {
    return {
        percentages: {}
    };
}
exports.Rollout_TrafficPercentStrategy = {
    typeUrl: "/google.api.servicemanagement.v1.TrafficPercentStrategy",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        Object.entries(message.percentages).forEach(([key, value]) => {
            exports.Rollout_TrafficPercentStrategy_PercentagesEntry.encode({
                key: key,
                value
            }, writer.uint32(9).fork()).ldelim();
        });
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseRollout_TrafficPercentStrategy();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    const entry1 = exports.Rollout_TrafficPercentStrategy_PercentagesEntry.decode(reader, reader.uint32());
                    if (entry1.value !== undefined) {
                        message.percentages[entry1.key] = entry1.value;
                    }
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseRollout_TrafficPercentStrategy();
        message.percentages = Object.entries(object.percentages ?? {}).reduce((acc, [key, value]) => {
            if (value !== undefined) {
                acc[key] = double.fromPartial(value);
            }
            return acc;
        }, {});
        return message;
    },
    fromAmino(object) {
        const message = createBaseRollout_TrafficPercentStrategy();
        message.percentages = Object.entries(object.percentages ?? {}).reduce((acc, [key, value]) => {
            if (value !== undefined) {
                acc[key] = double.fromAmino(value);
            }
            return acc;
        }, {});
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.percentages = {};
        if (message.percentages) {
            Object.entries(message.percentages).forEach(([k, v]) => {
                obj.percentages[k] = double.toAmino(v);
            });
        }
        return obj;
    },
    fromAminoMsg(object) {
        return exports.Rollout_TrafficPercentStrategy.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.Rollout_TrafficPercentStrategy.decode(message.value);
    },
    toProto(message) {
        return exports.Rollout_TrafficPercentStrategy.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.servicemanagement.v1.TrafficPercentStrategy",
            value: exports.Rollout_TrafficPercentStrategy.encode(message).finish()
        };
    }
};
function createBaseRollout_DeleteServiceStrategy() {
    return {};
}
exports.Rollout_DeleteServiceStrategy = {
    typeUrl: "/google.api.servicemanagement.v1.DeleteServiceStrategy",
    encode(_, writer = binary_1.BinaryWriter.create()) {
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseRollout_DeleteServiceStrategy();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(_) {
        const message = createBaseRollout_DeleteServiceStrategy();
        return message;
    },
    fromAmino(_) {
        const message = createBaseRollout_DeleteServiceStrategy();
        return message;
    },
    toAmino(_) {
        const obj = {};
        return obj;
    },
    fromAminoMsg(object) {
        return exports.Rollout_DeleteServiceStrategy.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.Rollout_DeleteServiceStrategy.decode(message.value);
    },
    toProto(message) {
        return exports.Rollout_DeleteServiceStrategy.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.servicemanagement.v1.DeleteServiceStrategy",
            value: exports.Rollout_DeleteServiceStrategy.encode(message).finish()
        };
    }
};
