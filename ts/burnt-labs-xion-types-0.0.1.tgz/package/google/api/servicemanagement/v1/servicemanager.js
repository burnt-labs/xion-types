"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GenerateConfigReportResponse = exports.GenerateConfigReportRequest = exports.EnableServiceResponse = exports.GetServiceRolloutRequest = exports.ListServiceRolloutsResponse = exports.ListServiceRolloutsRequest = exports.CreateServiceRolloutRequest = exports.SubmitConfigSourceResponse = exports.SubmitConfigSourceRequest = exports.CreateServiceConfigRequest = exports.ListServiceConfigsResponse = exports.ListServiceConfigsRequest = exports.GetServiceConfigRequest = exports.UndeleteServiceResponse = exports.UndeleteServiceRequest = exports.DeleteServiceRequest = exports.CreateServiceRequest = exports.GetServiceRequest = exports.ListServicesResponse = exports.ListServicesRequest = exports.GetServiceConfigRequest_ConfigViewAmino = exports.GetServiceConfigRequest_ConfigViewSDKType = exports.GetServiceConfigRequest_ConfigView = void 0;
exports.getServiceConfigRequest_ConfigViewFromJSON = getServiceConfigRequest_ConfigViewFromJSON;
exports.getServiceConfigRequest_ConfigViewToJSON = getServiceConfigRequest_ConfigViewToJSON;
//@ts-nocheck
const resources_1 = require("./resources");
const service_1 = require("../../service");
const any_1 = require("../../../protobuf/any");
const binary_1 = require("../../../../binary");
var GetServiceConfigRequest_ConfigView;
(function (GetServiceConfigRequest_ConfigView) {
    /** BASIC - Server response includes all fields except SourceInfo. */
    GetServiceConfigRequest_ConfigView[GetServiceConfigRequest_ConfigView["BASIC"] = 0] = "BASIC";
    /**
     * FULL - Server response includes all fields including SourceInfo.
     * SourceFiles are of type 'google.api.servicemanagement.v1.ConfigFile'
     * and are only available for configs created using the
     * SubmitConfigSource method.
     */
    GetServiceConfigRequest_ConfigView[GetServiceConfigRequest_ConfigView["FULL"] = 1] = "FULL";
    GetServiceConfigRequest_ConfigView[GetServiceConfigRequest_ConfigView["UNRECOGNIZED"] = -1] = "UNRECOGNIZED";
})(GetServiceConfigRequest_ConfigView || (exports.GetServiceConfigRequest_ConfigView = GetServiceConfigRequest_ConfigView = {}));
exports.GetServiceConfigRequest_ConfigViewSDKType = GetServiceConfigRequest_ConfigView;
exports.GetServiceConfigRequest_ConfigViewAmino = GetServiceConfigRequest_ConfigView;
function getServiceConfigRequest_ConfigViewFromJSON(object) {
    switch (object) {
        case 0:
        case "BASIC":
            return GetServiceConfigRequest_ConfigView.BASIC;
        case 1:
        case "FULL":
            return GetServiceConfigRequest_ConfigView.FULL;
        case -1:
        case "UNRECOGNIZED":
        default:
            return GetServiceConfigRequest_ConfigView.UNRECOGNIZED;
    }
}
function getServiceConfigRequest_ConfigViewToJSON(object) {
    switch (object) {
        case GetServiceConfigRequest_ConfigView.BASIC:
            return "BASIC";
        case GetServiceConfigRequest_ConfigView.FULL:
            return "FULL";
        case GetServiceConfigRequest_ConfigView.UNRECOGNIZED:
        default:
            return "UNRECOGNIZED";
    }
}
function createBaseListServicesRequest() {
    return {
        producerProjectId: "",
        pageSize: 0,
        pageToken: "",
        consumerId: ""
    };
}
exports.ListServicesRequest = {
    typeUrl: "/google.api.servicemanagement.v1.ListServicesRequest",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.producerProjectId !== "") {
            writer.uint32(10).string(message.producerProjectId);
        }
        if (message.pageSize !== 0) {
            writer.uint32(40).int32(message.pageSize);
        }
        if (message.pageToken !== "") {
            writer.uint32(50).string(message.pageToken);
        }
        if (message.consumerId !== "") {
            writer.uint32(58).string(message.consumerId);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseListServicesRequest();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.producerProjectId = reader.string();
                    break;
                case 5:
                    message.pageSize = reader.int32();
                    break;
                case 6:
                    message.pageToken = reader.string();
                    break;
                case 7:
                    message.consumerId = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseListServicesRequest();
        message.producerProjectId = object.producerProjectId ?? "";
        message.pageSize = object.pageSize ?? 0;
        message.pageToken = object.pageToken ?? "";
        message.consumerId = object.consumerId ?? "";
        return message;
    },
    fromAmino(object) {
        const message = createBaseListServicesRequest();
        if (object.producer_project_id !== undefined && object.producer_project_id !== null) {
            message.producerProjectId = object.producer_project_id;
        }
        if (object.page_size !== undefined && object.page_size !== null) {
            message.pageSize = object.page_size;
        }
        if (object.page_token !== undefined && object.page_token !== null) {
            message.pageToken = object.page_token;
        }
        if (object.consumer_id !== undefined && object.consumer_id !== null) {
            message.consumerId = object.consumer_id;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.producer_project_id = message.producerProjectId === "" ? undefined : message.producerProjectId;
        obj.page_size = message.pageSize === 0 ? undefined : message.pageSize;
        obj.page_token = message.pageToken === "" ? undefined : message.pageToken;
        obj.consumer_id = message.consumerId === "" ? undefined : message.consumerId;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.ListServicesRequest.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.ListServicesRequest.decode(message.value);
    },
    toProto(message) {
        return exports.ListServicesRequest.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.servicemanagement.v1.ListServicesRequest",
            value: exports.ListServicesRequest.encode(message).finish()
        };
    }
};
function createBaseListServicesResponse() {
    return {
        services: [],
        nextPageToken: ""
    };
}
exports.ListServicesResponse = {
    typeUrl: "/google.api.servicemanagement.v1.ListServicesResponse",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        for (const v of message.services) {
            resources_1.ManagedService.encode(v, writer.uint32(10).fork()).ldelim();
        }
        if (message.nextPageToken !== "") {
            writer.uint32(18).string(message.nextPageToken);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseListServicesResponse();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.services.push(resources_1.ManagedService.decode(reader, reader.uint32()));
                    break;
                case 2:
                    message.nextPageToken = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseListServicesResponse();
        message.services = object.services?.map(e => resources_1.ManagedService.fromPartial(e)) || [];
        message.nextPageToken = object.nextPageToken ?? "";
        return message;
    },
    fromAmino(object) {
        const message = createBaseListServicesResponse();
        message.services = object.services?.map(e => resources_1.ManagedService.fromAmino(e)) || [];
        if (object.next_page_token !== undefined && object.next_page_token !== null) {
            message.nextPageToken = object.next_page_token;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        if (message.services) {
            obj.services = message.services.map(e => e ? resources_1.ManagedService.toAmino(e) : undefined);
        }
        else {
            obj.services = message.services;
        }
        obj.next_page_token = message.nextPageToken === "" ? undefined : message.nextPageToken;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.ListServicesResponse.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.ListServicesResponse.decode(message.value);
    },
    toProto(message) {
        return exports.ListServicesResponse.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.servicemanagement.v1.ListServicesResponse",
            value: exports.ListServicesResponse.encode(message).finish()
        };
    }
};
function createBaseGetServiceRequest() {
    return {
        serviceName: ""
    };
}
exports.GetServiceRequest = {
    typeUrl: "/google.api.servicemanagement.v1.GetServiceRequest",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.serviceName !== "") {
            writer.uint32(10).string(message.serviceName);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseGetServiceRequest();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.serviceName = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseGetServiceRequest();
        message.serviceName = object.serviceName ?? "";
        return message;
    },
    fromAmino(object) {
        const message = createBaseGetServiceRequest();
        if (object.service_name !== undefined && object.service_name !== null) {
            message.serviceName = object.service_name;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.service_name = message.serviceName === "" ? undefined : message.serviceName;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.GetServiceRequest.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.GetServiceRequest.decode(message.value);
    },
    toProto(message) {
        return exports.GetServiceRequest.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.servicemanagement.v1.GetServiceRequest",
            value: exports.GetServiceRequest.encode(message).finish()
        };
    }
};
function createBaseCreateServiceRequest() {
    return {
        service: undefined
    };
}
exports.CreateServiceRequest = {
    typeUrl: "/google.api.servicemanagement.v1.CreateServiceRequest",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.service !== undefined) {
            resources_1.ManagedService.encode(message.service, writer.uint32(10).fork()).ldelim();
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseCreateServiceRequest();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.service = resources_1.ManagedService.decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseCreateServiceRequest();
        message.service = object.service !== undefined && object.service !== null ? resources_1.ManagedService.fromPartial(object.service) : undefined;
        return message;
    },
    fromAmino(object) {
        const message = createBaseCreateServiceRequest();
        if (object.service !== undefined && object.service !== null) {
            message.service = resources_1.ManagedService.fromAmino(object.service);
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.service = message.service ? resources_1.ManagedService.toAmino(message.service) : undefined;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.CreateServiceRequest.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.CreateServiceRequest.decode(message.value);
    },
    toProto(message) {
        return exports.CreateServiceRequest.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.servicemanagement.v1.CreateServiceRequest",
            value: exports.CreateServiceRequest.encode(message).finish()
        };
    }
};
function createBaseDeleteServiceRequest() {
    return {
        serviceName: ""
    };
}
exports.DeleteServiceRequest = {
    typeUrl: "/google.api.servicemanagement.v1.DeleteServiceRequest",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.serviceName !== "") {
            writer.uint32(10).string(message.serviceName);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseDeleteServiceRequest();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.serviceName = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseDeleteServiceRequest();
        message.serviceName = object.serviceName ?? "";
        return message;
    },
    fromAmino(object) {
        const message = createBaseDeleteServiceRequest();
        if (object.service_name !== undefined && object.service_name !== null) {
            message.serviceName = object.service_name;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.service_name = message.serviceName === "" ? undefined : message.serviceName;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.DeleteServiceRequest.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.DeleteServiceRequest.decode(message.value);
    },
    toProto(message) {
        return exports.DeleteServiceRequest.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.servicemanagement.v1.DeleteServiceRequest",
            value: exports.DeleteServiceRequest.encode(message).finish()
        };
    }
};
function createBaseUndeleteServiceRequest() {
    return {
        serviceName: ""
    };
}
exports.UndeleteServiceRequest = {
    typeUrl: "/google.api.servicemanagement.v1.UndeleteServiceRequest",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.serviceName !== "") {
            writer.uint32(10).string(message.serviceName);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseUndeleteServiceRequest();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.serviceName = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseUndeleteServiceRequest();
        message.serviceName = object.serviceName ?? "";
        return message;
    },
    fromAmino(object) {
        const message = createBaseUndeleteServiceRequest();
        if (object.service_name !== undefined && object.service_name !== null) {
            message.serviceName = object.service_name;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.service_name = message.serviceName === "" ? undefined : message.serviceName;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.UndeleteServiceRequest.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.UndeleteServiceRequest.decode(message.value);
    },
    toProto(message) {
        return exports.UndeleteServiceRequest.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.servicemanagement.v1.UndeleteServiceRequest",
            value: exports.UndeleteServiceRequest.encode(message).finish()
        };
    }
};
function createBaseUndeleteServiceResponse() {
    return {
        service: undefined
    };
}
exports.UndeleteServiceResponse = {
    typeUrl: "/google.api.servicemanagement.v1.UndeleteServiceResponse",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.service !== undefined) {
            resources_1.ManagedService.encode(message.service, writer.uint32(10).fork()).ldelim();
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseUndeleteServiceResponse();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.service = resources_1.ManagedService.decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseUndeleteServiceResponse();
        message.service = object.service !== undefined && object.service !== null ? resources_1.ManagedService.fromPartial(object.service) : undefined;
        return message;
    },
    fromAmino(object) {
        const message = createBaseUndeleteServiceResponse();
        if (object.service !== undefined && object.service !== null) {
            message.service = resources_1.ManagedService.fromAmino(object.service);
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.service = message.service ? resources_1.ManagedService.toAmino(message.service) : undefined;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.UndeleteServiceResponse.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.UndeleteServiceResponse.decode(message.value);
    },
    toProto(message) {
        return exports.UndeleteServiceResponse.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.servicemanagement.v1.UndeleteServiceResponse",
            value: exports.UndeleteServiceResponse.encode(message).finish()
        };
    }
};
function createBaseGetServiceConfigRequest() {
    return {
        serviceName: "",
        configId: "",
        view: 0
    };
}
exports.GetServiceConfigRequest = {
    typeUrl: "/google.api.servicemanagement.v1.GetServiceConfigRequest",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.serviceName !== "") {
            writer.uint32(10).string(message.serviceName);
        }
        if (message.configId !== "") {
            writer.uint32(18).string(message.configId);
        }
        if (message.view !== 0) {
            writer.uint32(24).int32(message.view);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseGetServiceConfigRequest();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.serviceName = reader.string();
                    break;
                case 2:
                    message.configId = reader.string();
                    break;
                case 3:
                    message.view = reader.int32();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseGetServiceConfigRequest();
        message.serviceName = object.serviceName ?? "";
        message.configId = object.configId ?? "";
        message.view = object.view ?? 0;
        return message;
    },
    fromAmino(object) {
        const message = createBaseGetServiceConfigRequest();
        if (object.service_name !== undefined && object.service_name !== null) {
            message.serviceName = object.service_name;
        }
        if (object.config_id !== undefined && object.config_id !== null) {
            message.configId = object.config_id;
        }
        if (object.view !== undefined && object.view !== null) {
            message.view = object.view;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.service_name = message.serviceName === "" ? undefined : message.serviceName;
        obj.config_id = message.configId === "" ? undefined : message.configId;
        obj.view = message.view === 0 ? undefined : message.view;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.GetServiceConfigRequest.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.GetServiceConfigRequest.decode(message.value);
    },
    toProto(message) {
        return exports.GetServiceConfigRequest.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.servicemanagement.v1.GetServiceConfigRequest",
            value: exports.GetServiceConfigRequest.encode(message).finish()
        };
    }
};
function createBaseListServiceConfigsRequest() {
    return {
        serviceName: "",
        pageToken: "",
        pageSize: 0
    };
}
exports.ListServiceConfigsRequest = {
    typeUrl: "/google.api.servicemanagement.v1.ListServiceConfigsRequest",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.serviceName !== "") {
            writer.uint32(10).string(message.serviceName);
        }
        if (message.pageToken !== "") {
            writer.uint32(18).string(message.pageToken);
        }
        if (message.pageSize !== 0) {
            writer.uint32(24).int32(message.pageSize);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseListServiceConfigsRequest();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.serviceName = reader.string();
                    break;
                case 2:
                    message.pageToken = reader.string();
                    break;
                case 3:
                    message.pageSize = reader.int32();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseListServiceConfigsRequest();
        message.serviceName = object.serviceName ?? "";
        message.pageToken = object.pageToken ?? "";
        message.pageSize = object.pageSize ?? 0;
        return message;
    },
    fromAmino(object) {
        const message = createBaseListServiceConfigsRequest();
        if (object.service_name !== undefined && object.service_name !== null) {
            message.serviceName = object.service_name;
        }
        if (object.page_token !== undefined && object.page_token !== null) {
            message.pageToken = object.page_token;
        }
        if (object.page_size !== undefined && object.page_size !== null) {
            message.pageSize = object.page_size;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.service_name = message.serviceName === "" ? undefined : message.serviceName;
        obj.page_token = message.pageToken === "" ? undefined : message.pageToken;
        obj.page_size = message.pageSize === 0 ? undefined : message.pageSize;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.ListServiceConfigsRequest.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.ListServiceConfigsRequest.decode(message.value);
    },
    toProto(message) {
        return exports.ListServiceConfigsRequest.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.servicemanagement.v1.ListServiceConfigsRequest",
            value: exports.ListServiceConfigsRequest.encode(message).finish()
        };
    }
};
function createBaseListServiceConfigsResponse() {
    return {
        serviceConfigs: [],
        nextPageToken: ""
    };
}
exports.ListServiceConfigsResponse = {
    typeUrl: "/google.api.servicemanagement.v1.ListServiceConfigsResponse",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        for (const v of message.serviceConfigs) {
            service_1.Service.encode(v, writer.uint32(10).fork()).ldelim();
        }
        if (message.nextPageToken !== "") {
            writer.uint32(18).string(message.nextPageToken);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseListServiceConfigsResponse();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.serviceConfigs.push(service_1.Service.decode(reader, reader.uint32()));
                    break;
                case 2:
                    message.nextPageToken = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseListServiceConfigsResponse();
        message.serviceConfigs = object.serviceConfigs?.map(e => service_1.Service.fromPartial(e)) || [];
        message.nextPageToken = object.nextPageToken ?? "";
        return message;
    },
    fromAmino(object) {
        const message = createBaseListServiceConfigsResponse();
        message.serviceConfigs = object.service_configs?.map(e => service_1.Service.fromAmino(e)) || [];
        if (object.next_page_token !== undefined && object.next_page_token !== null) {
            message.nextPageToken = object.next_page_token;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        if (message.serviceConfigs) {
            obj.service_configs = message.serviceConfigs.map(e => e ? service_1.Service.toAmino(e) : undefined);
        }
        else {
            obj.service_configs = message.serviceConfigs;
        }
        obj.next_page_token = message.nextPageToken === "" ? undefined : message.nextPageToken;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.ListServiceConfigsResponse.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.ListServiceConfigsResponse.decode(message.value);
    },
    toProto(message) {
        return exports.ListServiceConfigsResponse.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.servicemanagement.v1.ListServiceConfigsResponse",
            value: exports.ListServiceConfigsResponse.encode(message).finish()
        };
    }
};
function createBaseCreateServiceConfigRequest() {
    return {
        serviceName: "",
        serviceConfig: undefined
    };
}
exports.CreateServiceConfigRequest = {
    typeUrl: "/google.api.servicemanagement.v1.CreateServiceConfigRequest",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.serviceName !== "") {
            writer.uint32(10).string(message.serviceName);
        }
        if (message.serviceConfig !== undefined) {
            service_1.Service.encode(message.serviceConfig, writer.uint32(18).fork()).ldelim();
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseCreateServiceConfigRequest();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.serviceName = reader.string();
                    break;
                case 2:
                    message.serviceConfig = service_1.Service.decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseCreateServiceConfigRequest();
        message.serviceName = object.serviceName ?? "";
        message.serviceConfig = object.serviceConfig !== undefined && object.serviceConfig !== null ? service_1.Service.fromPartial(object.serviceConfig) : undefined;
        return message;
    },
    fromAmino(object) {
        const message = createBaseCreateServiceConfigRequest();
        if (object.service_name !== undefined && object.service_name !== null) {
            message.serviceName = object.service_name;
        }
        if (object.service_config !== undefined && object.service_config !== null) {
            message.serviceConfig = service_1.Service.fromAmino(object.service_config);
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.service_name = message.serviceName === "" ? undefined : message.serviceName;
        obj.service_config = message.serviceConfig ? service_1.Service.toAmino(message.serviceConfig) : undefined;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.CreateServiceConfigRequest.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.CreateServiceConfigRequest.decode(message.value);
    },
    toProto(message) {
        return exports.CreateServiceConfigRequest.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.servicemanagement.v1.CreateServiceConfigRequest",
            value: exports.CreateServiceConfigRequest.encode(message).finish()
        };
    }
};
function createBaseSubmitConfigSourceRequest() {
    return {
        serviceName: "",
        configSource: undefined,
        validateOnly: false
    };
}
exports.SubmitConfigSourceRequest = {
    typeUrl: "/google.api.servicemanagement.v1.SubmitConfigSourceRequest",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.serviceName !== "") {
            writer.uint32(10).string(message.serviceName);
        }
        if (message.configSource !== undefined) {
            resources_1.ConfigSource.encode(message.configSource, writer.uint32(18).fork()).ldelim();
        }
        if (message.validateOnly === true) {
            writer.uint32(24).bool(message.validateOnly);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseSubmitConfigSourceRequest();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.serviceName = reader.string();
                    break;
                case 2:
                    message.configSource = resources_1.ConfigSource.decode(reader, reader.uint32());
                    break;
                case 3:
                    message.validateOnly = reader.bool();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseSubmitConfigSourceRequest();
        message.serviceName = object.serviceName ?? "";
        message.configSource = object.configSource !== undefined && object.configSource !== null ? resources_1.ConfigSource.fromPartial(object.configSource) : undefined;
        message.validateOnly = object.validateOnly ?? false;
        return message;
    },
    fromAmino(object) {
        const message = createBaseSubmitConfigSourceRequest();
        if (object.service_name !== undefined && object.service_name !== null) {
            message.serviceName = object.service_name;
        }
        if (object.config_source !== undefined && object.config_source !== null) {
            message.configSource = resources_1.ConfigSource.fromAmino(object.config_source);
        }
        if (object.validate_only !== undefined && object.validate_only !== null) {
            message.validateOnly = object.validate_only;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.service_name = message.serviceName === "" ? undefined : message.serviceName;
        obj.config_source = message.configSource ? resources_1.ConfigSource.toAmino(message.configSource) : undefined;
        obj.validate_only = message.validateOnly === false ? undefined : message.validateOnly;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.SubmitConfigSourceRequest.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.SubmitConfigSourceRequest.decode(message.value);
    },
    toProto(message) {
        return exports.SubmitConfigSourceRequest.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.servicemanagement.v1.SubmitConfigSourceRequest",
            value: exports.SubmitConfigSourceRequest.encode(message).finish()
        };
    }
};
function createBaseSubmitConfigSourceResponse() {
    return {
        serviceConfig: undefined
    };
}
exports.SubmitConfigSourceResponse = {
    typeUrl: "/google.api.servicemanagement.v1.SubmitConfigSourceResponse",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.serviceConfig !== undefined) {
            service_1.Service.encode(message.serviceConfig, writer.uint32(10).fork()).ldelim();
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseSubmitConfigSourceResponse();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.serviceConfig = service_1.Service.decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseSubmitConfigSourceResponse();
        message.serviceConfig = object.serviceConfig !== undefined && object.serviceConfig !== null ? service_1.Service.fromPartial(object.serviceConfig) : undefined;
        return message;
    },
    fromAmino(object) {
        const message = createBaseSubmitConfigSourceResponse();
        if (object.service_config !== undefined && object.service_config !== null) {
            message.serviceConfig = service_1.Service.fromAmino(object.service_config);
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.service_config = message.serviceConfig ? service_1.Service.toAmino(message.serviceConfig) : undefined;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.SubmitConfigSourceResponse.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.SubmitConfigSourceResponse.decode(message.value);
    },
    toProto(message) {
        return exports.SubmitConfigSourceResponse.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.servicemanagement.v1.SubmitConfigSourceResponse",
            value: exports.SubmitConfigSourceResponse.encode(message).finish()
        };
    }
};
function createBaseCreateServiceRolloutRequest() {
    return {
        serviceName: "",
        rollout: undefined
    };
}
exports.CreateServiceRolloutRequest = {
    typeUrl: "/google.api.servicemanagement.v1.CreateServiceRolloutRequest",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.serviceName !== "") {
            writer.uint32(10).string(message.serviceName);
        }
        if (message.rollout !== undefined) {
            resources_1.Rollout.encode(message.rollout, writer.uint32(18).fork()).ldelim();
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseCreateServiceRolloutRequest();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.serviceName = reader.string();
                    break;
                case 2:
                    message.rollout = resources_1.Rollout.decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseCreateServiceRolloutRequest();
        message.serviceName = object.serviceName ?? "";
        message.rollout = object.rollout !== undefined && object.rollout !== null ? resources_1.Rollout.fromPartial(object.rollout) : undefined;
        return message;
    },
    fromAmino(object) {
        const message = createBaseCreateServiceRolloutRequest();
        if (object.service_name !== undefined && object.service_name !== null) {
            message.serviceName = object.service_name;
        }
        if (object.rollout !== undefined && object.rollout !== null) {
            message.rollout = resources_1.Rollout.fromAmino(object.rollout);
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.service_name = message.serviceName === "" ? undefined : message.serviceName;
        obj.rollout = message.rollout ? resources_1.Rollout.toAmino(message.rollout) : undefined;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.CreateServiceRolloutRequest.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.CreateServiceRolloutRequest.decode(message.value);
    },
    toProto(message) {
        return exports.CreateServiceRolloutRequest.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.servicemanagement.v1.CreateServiceRolloutRequest",
            value: exports.CreateServiceRolloutRequest.encode(message).finish()
        };
    }
};
function createBaseListServiceRolloutsRequest() {
    return {
        serviceName: "",
        pageToken: "",
        pageSize: 0,
        filter: ""
    };
}
exports.ListServiceRolloutsRequest = {
    typeUrl: "/google.api.servicemanagement.v1.ListServiceRolloutsRequest",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.serviceName !== "") {
            writer.uint32(10).string(message.serviceName);
        }
        if (message.pageToken !== "") {
            writer.uint32(18).string(message.pageToken);
        }
        if (message.pageSize !== 0) {
            writer.uint32(24).int32(message.pageSize);
        }
        if (message.filter !== "") {
            writer.uint32(34).string(message.filter);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseListServiceRolloutsRequest();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.serviceName = reader.string();
                    break;
                case 2:
                    message.pageToken = reader.string();
                    break;
                case 3:
                    message.pageSize = reader.int32();
                    break;
                case 4:
                    message.filter = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseListServiceRolloutsRequest();
        message.serviceName = object.serviceName ?? "";
        message.pageToken = object.pageToken ?? "";
        message.pageSize = object.pageSize ?? 0;
        message.filter = object.filter ?? "";
        return message;
    },
    fromAmino(object) {
        const message = createBaseListServiceRolloutsRequest();
        if (object.service_name !== undefined && object.service_name !== null) {
            message.serviceName = object.service_name;
        }
        if (object.page_token !== undefined && object.page_token !== null) {
            message.pageToken = object.page_token;
        }
        if (object.page_size !== undefined && object.page_size !== null) {
            message.pageSize = object.page_size;
        }
        if (object.filter !== undefined && object.filter !== null) {
            message.filter = object.filter;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.service_name = message.serviceName === "" ? undefined : message.serviceName;
        obj.page_token = message.pageToken === "" ? undefined : message.pageToken;
        obj.page_size = message.pageSize === 0 ? undefined : message.pageSize;
        obj.filter = message.filter === "" ? undefined : message.filter;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.ListServiceRolloutsRequest.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.ListServiceRolloutsRequest.decode(message.value);
    },
    toProto(message) {
        return exports.ListServiceRolloutsRequest.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.servicemanagement.v1.ListServiceRolloutsRequest",
            value: exports.ListServiceRolloutsRequest.encode(message).finish()
        };
    }
};
function createBaseListServiceRolloutsResponse() {
    return {
        rollouts: [],
        nextPageToken: ""
    };
}
exports.ListServiceRolloutsResponse = {
    typeUrl: "/google.api.servicemanagement.v1.ListServiceRolloutsResponse",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        for (const v of message.rollouts) {
            resources_1.Rollout.encode(v, writer.uint32(10).fork()).ldelim();
        }
        if (message.nextPageToken !== "") {
            writer.uint32(18).string(message.nextPageToken);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseListServiceRolloutsResponse();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.rollouts.push(resources_1.Rollout.decode(reader, reader.uint32()));
                    break;
                case 2:
                    message.nextPageToken = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseListServiceRolloutsResponse();
        message.rollouts = object.rollouts?.map(e => resources_1.Rollout.fromPartial(e)) || [];
        message.nextPageToken = object.nextPageToken ?? "";
        return message;
    },
    fromAmino(object) {
        const message = createBaseListServiceRolloutsResponse();
        message.rollouts = object.rollouts?.map(e => resources_1.Rollout.fromAmino(e)) || [];
        if (object.next_page_token !== undefined && object.next_page_token !== null) {
            message.nextPageToken = object.next_page_token;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        if (message.rollouts) {
            obj.rollouts = message.rollouts.map(e => e ? resources_1.Rollout.toAmino(e) : undefined);
        }
        else {
            obj.rollouts = message.rollouts;
        }
        obj.next_page_token = message.nextPageToken === "" ? undefined : message.nextPageToken;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.ListServiceRolloutsResponse.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.ListServiceRolloutsResponse.decode(message.value);
    },
    toProto(message) {
        return exports.ListServiceRolloutsResponse.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.servicemanagement.v1.ListServiceRolloutsResponse",
            value: exports.ListServiceRolloutsResponse.encode(message).finish()
        };
    }
};
function createBaseGetServiceRolloutRequest() {
    return {
        serviceName: "",
        rolloutId: ""
    };
}
exports.GetServiceRolloutRequest = {
    typeUrl: "/google.api.servicemanagement.v1.GetServiceRolloutRequest",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.serviceName !== "") {
            writer.uint32(10).string(message.serviceName);
        }
        if (message.rolloutId !== "") {
            writer.uint32(18).string(message.rolloutId);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseGetServiceRolloutRequest();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.serviceName = reader.string();
                    break;
                case 2:
                    message.rolloutId = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseGetServiceRolloutRequest();
        message.serviceName = object.serviceName ?? "";
        message.rolloutId = object.rolloutId ?? "";
        return message;
    },
    fromAmino(object) {
        const message = createBaseGetServiceRolloutRequest();
        if (object.service_name !== undefined && object.service_name !== null) {
            message.serviceName = object.service_name;
        }
        if (object.rollout_id !== undefined && object.rollout_id !== null) {
            message.rolloutId = object.rollout_id;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.service_name = message.serviceName === "" ? undefined : message.serviceName;
        obj.rollout_id = message.rolloutId === "" ? undefined : message.rolloutId;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.GetServiceRolloutRequest.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.GetServiceRolloutRequest.decode(message.value);
    },
    toProto(message) {
        return exports.GetServiceRolloutRequest.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.servicemanagement.v1.GetServiceRolloutRequest",
            value: exports.GetServiceRolloutRequest.encode(message).finish()
        };
    }
};
function createBaseEnableServiceResponse() {
    return {};
}
exports.EnableServiceResponse = {
    typeUrl: "/google.api.servicemanagement.v1.EnableServiceResponse",
    encode(_, writer = binary_1.BinaryWriter.create()) {
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseEnableServiceResponse();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(_) {
        const message = createBaseEnableServiceResponse();
        return message;
    },
    fromAmino(_) {
        const message = createBaseEnableServiceResponse();
        return message;
    },
    toAmino(_) {
        const obj = {};
        return obj;
    },
    fromAminoMsg(object) {
        return exports.EnableServiceResponse.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.EnableServiceResponse.decode(message.value);
    },
    toProto(message) {
        return exports.EnableServiceResponse.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.servicemanagement.v1.EnableServiceResponse",
            value: exports.EnableServiceResponse.encode(message).finish()
        };
    }
};
function createBaseGenerateConfigReportRequest() {
    return {
        newConfig: undefined,
        oldConfig: undefined
    };
}
exports.GenerateConfigReportRequest = {
    typeUrl: "/google.api.servicemanagement.v1.GenerateConfigReportRequest",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.newConfig !== undefined) {
            any_1.Any.encode(message.newConfig, writer.uint32(10).fork()).ldelim();
        }
        if (message.oldConfig !== undefined) {
            any_1.Any.encode(message.oldConfig, writer.uint32(18).fork()).ldelim();
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseGenerateConfigReportRequest();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.newConfig = any_1.Any.decode(reader, reader.uint32());
                    break;
                case 2:
                    message.oldConfig = any_1.Any.decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseGenerateConfigReportRequest();
        message.newConfig = object.newConfig !== undefined && object.newConfig !== null ? any_1.Any.fromPartial(object.newConfig) : undefined;
        message.oldConfig = object.oldConfig !== undefined && object.oldConfig !== null ? any_1.Any.fromPartial(object.oldConfig) : undefined;
        return message;
    },
    fromAmino(object) {
        const message = createBaseGenerateConfigReportRequest();
        if (object.new_config !== undefined && object.new_config !== null) {
            message.newConfig = any_1.Any.fromAmino(object.new_config);
        }
        if (object.old_config !== undefined && object.old_config !== null) {
            message.oldConfig = any_1.Any.fromAmino(object.old_config);
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.new_config = message.newConfig ? any_1.Any.toAmino(message.newConfig) : undefined;
        obj.old_config = message.oldConfig ? any_1.Any.toAmino(message.oldConfig) : undefined;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.GenerateConfigReportRequest.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.GenerateConfigReportRequest.decode(message.value);
    },
    toProto(message) {
        return exports.GenerateConfigReportRequest.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.servicemanagement.v1.GenerateConfigReportRequest",
            value: exports.GenerateConfigReportRequest.encode(message).finish()
        };
    }
};
function createBaseGenerateConfigReportResponse() {
    return {
        serviceName: "",
        id: "",
        changeReports: [],
        diagnostics: []
    };
}
exports.GenerateConfigReportResponse = {
    typeUrl: "/google.api.servicemanagement.v1.GenerateConfigReportResponse",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.serviceName !== "") {
            writer.uint32(10).string(message.serviceName);
        }
        if (message.id !== "") {
            writer.uint32(18).string(message.id);
        }
        for (const v of message.changeReports) {
            resources_1.ChangeReport.encode(v, writer.uint32(26).fork()).ldelim();
        }
        for (const v of message.diagnostics) {
            resources_1.Diagnostic.encode(v, writer.uint32(34).fork()).ldelim();
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseGenerateConfigReportResponse();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.serviceName = reader.string();
                    break;
                case 2:
                    message.id = reader.string();
                    break;
                case 3:
                    message.changeReports.push(resources_1.ChangeReport.decode(reader, reader.uint32()));
                    break;
                case 4:
                    message.diagnostics.push(resources_1.Diagnostic.decode(reader, reader.uint32()));
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseGenerateConfigReportResponse();
        message.serviceName = object.serviceName ?? "";
        message.id = object.id ?? "";
        message.changeReports = object.changeReports?.map(e => resources_1.ChangeReport.fromPartial(e)) || [];
        message.diagnostics = object.diagnostics?.map(e => resources_1.Diagnostic.fromPartial(e)) || [];
        return message;
    },
    fromAmino(object) {
        const message = createBaseGenerateConfigReportResponse();
        if (object.service_name !== undefined && object.service_name !== null) {
            message.serviceName = object.service_name;
        }
        if (object.id !== undefined && object.id !== null) {
            message.id = object.id;
        }
        message.changeReports = object.change_reports?.map(e => resources_1.ChangeReport.fromAmino(e)) || [];
        message.diagnostics = object.diagnostics?.map(e => resources_1.Diagnostic.fromAmino(e)) || [];
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.service_name = message.serviceName === "" ? undefined : message.serviceName;
        obj.id = message.id === "" ? undefined : message.id;
        if (message.changeReports) {
            obj.change_reports = message.changeReports.map(e => e ? resources_1.ChangeReport.toAmino(e) : undefined);
        }
        else {
            obj.change_reports = message.changeReports;
        }
        if (message.diagnostics) {
            obj.diagnostics = message.diagnostics.map(e => e ? resources_1.Diagnostic.toAmino(e) : undefined);
        }
        else {
            obj.diagnostics = message.diagnostics;
        }
        return obj;
    },
    fromAminoMsg(object) {
        return exports.GenerateConfigReportResponse.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.GenerateConfigReportResponse.decode(message.value);
    },
    toProto(message) {
        return exports.GenerateConfigReportResponse.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.servicemanagement.v1.GenerateConfigReportResponse",
            value: exports.GenerateConfigReportResponse.encode(message).finish()
        };
    }
};
