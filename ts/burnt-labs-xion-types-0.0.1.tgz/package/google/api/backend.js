"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.BackendRule = exports.BackendRule_OverridesByRequestProtocolEntry = exports.Backend = exports.BackendRule_PathTranslationAmino = exports.BackendRule_PathTranslationSDKType = exports.BackendRule_PathTranslation = void 0;
exports.backendRule_PathTranslationFromJSON = backendRule_PathTranslationFromJSON;
exports.backendRule_PathTranslationToJSON = backendRule_PathTranslationToJSON;
//@ts-nocheck
const binary_1 = require("../../binary");
/**
 * Path Translation specifies how to combine the backend address with the
 * request path in order to produce the appropriate forwarding URL for the
 * request.
 *
 * Path Translation is applicable only to HTTP-based backends. Backends which
 * do not accept requests over HTTP/HTTPS should leave `path_translation`
 * unspecified.
 */
var BackendRule_PathTranslation;
(function (BackendRule_PathTranslation) {
    BackendRule_PathTranslation[BackendRule_PathTranslation["PATH_TRANSLATION_UNSPECIFIED"] = 0] = "PATH_TRANSLATION_UNSPECIFIED";
    /**
     * CONSTANT_ADDRESS - Use the backend address as-is, with no modification to the path. If the
     * URL pattern contains variables, the variable names and values will be
     * appended to the query string. If a query string parameter and a URL
     * pattern variable have the same name, this may result in duplicate keys in
     * the query string.
     *
     * # Examples
     *
     * Given the following operation config:
     *
     *     Method path:        /api/company/{cid}/user/{uid}
     *     Backend address:    https://example.cloudfunctions.net/getUser
     *
     * Requests to the following request paths will call the backend at the
     * translated path:
     *
     *     Request path: /api/company/widgetworks/user/johndoe
     *     Translated:
     *     https://example.cloudfunctions.net/getUser?cid=widgetworks&uid=johndoe
     *
     *     Request path: /api/company/widgetworks/user/johndoe?timezone=EST
     *     Translated:
     *     https://example.cloudfunctions.net/getUser?timezone=EST&cid=widgetworks&uid=johndoe
     */
    BackendRule_PathTranslation[BackendRule_PathTranslation["CONSTANT_ADDRESS"] = 1] = "CONSTANT_ADDRESS";
    /**
     * APPEND_PATH_TO_ADDRESS - The request path will be appended to the backend address.
     *
     * # Examples
     *
     * Given the following operation config:
     *
     *     Method path:        /api/company/{cid}/user/{uid}
     *     Backend address:    https://example.appspot.com
     *
     * Requests to the following request paths will call the backend at the
     * translated path:
     *
     *     Request path: /api/company/widgetworks/user/johndoe
     *     Translated:
     *     https://example.appspot.com/api/company/widgetworks/user/johndoe
     *
     *     Request path: /api/company/widgetworks/user/johndoe?timezone=EST
     *     Translated:
     *     https://example.appspot.com/api/company/widgetworks/user/johndoe?timezone=EST
     */
    BackendRule_PathTranslation[BackendRule_PathTranslation["APPEND_PATH_TO_ADDRESS"] = 2] = "APPEND_PATH_TO_ADDRESS";
    BackendRule_PathTranslation[BackendRule_PathTranslation["UNRECOGNIZED"] = -1] = "UNRECOGNIZED";
})(BackendRule_PathTranslation || (exports.BackendRule_PathTranslation = BackendRule_PathTranslation = {}));
exports.BackendRule_PathTranslationSDKType = BackendRule_PathTranslation;
exports.BackendRule_PathTranslationAmino = BackendRule_PathTranslation;
function backendRule_PathTranslationFromJSON(object) {
    switch (object) {
        case 0:
        case "PATH_TRANSLATION_UNSPECIFIED":
            return BackendRule_PathTranslation.PATH_TRANSLATION_UNSPECIFIED;
        case 1:
        case "CONSTANT_ADDRESS":
            return BackendRule_PathTranslation.CONSTANT_ADDRESS;
        case 2:
        case "APPEND_PATH_TO_ADDRESS":
            return BackendRule_PathTranslation.APPEND_PATH_TO_ADDRESS;
        case -1:
        case "UNRECOGNIZED":
        default:
            return BackendRule_PathTranslation.UNRECOGNIZED;
    }
}
function backendRule_PathTranslationToJSON(object) {
    switch (object) {
        case BackendRule_PathTranslation.PATH_TRANSLATION_UNSPECIFIED:
            return "PATH_TRANSLATION_UNSPECIFIED";
        case BackendRule_PathTranslation.CONSTANT_ADDRESS:
            return "CONSTANT_ADDRESS";
        case BackendRule_PathTranslation.APPEND_PATH_TO_ADDRESS:
            return "APPEND_PATH_TO_ADDRESS";
        case BackendRule_PathTranslation.UNRECOGNIZED:
        default:
            return "UNRECOGNIZED";
    }
}
function createBaseBackend() {
    return {
        rules: []
    };
}
exports.Backend = {
    typeUrl: "/google.api.Backend",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        for (const v of message.rules) {
            exports.BackendRule.encode(v, writer.uint32(10).fork()).ldelim();
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseBackend();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.rules.push(exports.BackendRule.decode(reader, reader.uint32()));
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseBackend();
        message.rules = object.rules?.map(e => exports.BackendRule.fromPartial(e)) || [];
        return message;
    },
    fromAmino(object) {
        const message = createBaseBackend();
        message.rules = object.rules?.map(e => exports.BackendRule.fromAmino(e)) || [];
        return message;
    },
    toAmino(message) {
        const obj = {};
        if (message.rules) {
            obj.rules = message.rules.map(e => e ? exports.BackendRule.toAmino(e) : undefined);
        }
        else {
            obj.rules = message.rules;
        }
        return obj;
    },
    fromAminoMsg(object) {
        return exports.Backend.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.Backend.decode(message.value);
    },
    toProto(message) {
        return exports.Backend.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.Backend",
            value: exports.Backend.encode(message).finish()
        };
    }
};
function createBaseBackendRule_OverridesByRequestProtocolEntry() {
    return {
        key: "",
        value: undefined
    };
}
exports.BackendRule_OverridesByRequestProtocolEntry = {
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.key !== "") {
            writer.uint32(10).string(message.key);
        }
        if (message.value !== undefined) {
            exports.BackendRule.encode(message.value, writer.uint32(18).fork()).ldelim();
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseBackendRule_OverridesByRequestProtocolEntry();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.key = reader.string();
                    break;
                case 2:
                    message.value = exports.BackendRule.decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseBackendRule_OverridesByRequestProtocolEntry();
        message.key = object.key ?? "";
        message.value = object.value !== undefined && object.value !== null ? exports.BackendRule.fromPartial(object.value) : undefined;
        return message;
    },
    fromAmino(object) {
        const message = createBaseBackendRule_OverridesByRequestProtocolEntry();
        if (object.key !== undefined && object.key !== null) {
            message.key = object.key;
        }
        if (object.value !== undefined && object.value !== null) {
            message.value = exports.BackendRule.fromAmino(object.value);
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.key = message.key === "" ? undefined : message.key;
        obj.value = message.value ? exports.BackendRule.toAmino(message.value) : undefined;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.BackendRule_OverridesByRequestProtocolEntry.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.BackendRule_OverridesByRequestProtocolEntry.decode(message.value);
    },
    toProto(message) {
        return exports.BackendRule_OverridesByRequestProtocolEntry.encode(message).finish();
    }
};
function createBaseBackendRule() {
    return {
        selector: "",
        address: "",
        deadline: 0,
        minDeadline: 0,
        operationDeadline: 0,
        pathTranslation: 0,
        jwtAudience: undefined,
        disableAuth: undefined,
        protocol: "",
        overridesByRequestProtocol: {}
    };
}
exports.BackendRule = {
    typeUrl: "/google.api.BackendRule",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.selector !== "") {
            writer.uint32(10).string(message.selector);
        }
        if (message.address !== "") {
            writer.uint32(18).string(message.address);
        }
        if (message.deadline !== 0) {
            writer.uint32(25).double(message.deadline);
        }
        if (message.minDeadline !== 0) {
            writer.uint32(33).double(message.minDeadline);
        }
        if (message.operationDeadline !== 0) {
            writer.uint32(41).double(message.operationDeadline);
        }
        if (message.pathTranslation !== 0) {
            writer.uint32(48).int32(message.pathTranslation);
        }
        if (message.jwtAudience !== undefined) {
            writer.uint32(58).string(message.jwtAudience);
        }
        if (message.disableAuth !== undefined) {
            writer.uint32(64).bool(message.disableAuth);
        }
        if (message.protocol !== "") {
            writer.uint32(74).string(message.protocol);
        }
        Object.entries(message.overridesByRequestProtocol).forEach(([key, value]) => {
            exports.BackendRule_OverridesByRequestProtocolEntry.encode({
                key: key,
                value
            }, writer.uint32(82).fork()).ldelim();
        });
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseBackendRule();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.selector = reader.string();
                    break;
                case 2:
                    message.address = reader.string();
                    break;
                case 3:
                    message.deadline = reader.double();
                    break;
                case 4:
                    message.minDeadline = reader.double();
                    break;
                case 5:
                    message.operationDeadline = reader.double();
                    break;
                case 6:
                    message.pathTranslation = reader.int32();
                    break;
                case 7:
                    message.jwtAudience = reader.string();
                    break;
                case 8:
                    message.disableAuth = reader.bool();
                    break;
                case 9:
                    message.protocol = reader.string();
                    break;
                case 10:
                    const entry10 = exports.BackendRule_OverridesByRequestProtocolEntry.decode(reader, reader.uint32());
                    if (entry10.value !== undefined) {
                        message.overridesByRequestProtocol[entry10.key] = entry10.value;
                    }
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseBackendRule();
        message.selector = object.selector ?? "";
        message.address = object.address ?? "";
        message.deadline = object.deadline ?? 0;
        message.minDeadline = object.minDeadline ?? 0;
        message.operationDeadline = object.operationDeadline ?? 0;
        message.pathTranslation = object.pathTranslation ?? 0;
        message.jwtAudience = object.jwtAudience ?? undefined;
        message.disableAuth = object.disableAuth ?? undefined;
        message.protocol = object.protocol ?? "";
        message.overridesByRequestProtocol = Object.entries(object.overridesByRequestProtocol ?? {}).reduce((acc, [key, value]) => {
            if (value !== undefined) {
                acc[key] = exports.BackendRule.fromPartial(value);
            }
            return acc;
        }, {});
        return message;
    },
    fromAmino(object) {
        const message = createBaseBackendRule();
        if (object.selector !== undefined && object.selector !== null) {
            message.selector = object.selector;
        }
        if (object.address !== undefined && object.address !== null) {
            message.address = object.address;
        }
        if (object.deadline !== undefined && object.deadline !== null) {
            message.deadline = object.deadline;
        }
        if (object.min_deadline !== undefined && object.min_deadline !== null) {
            message.minDeadline = object.min_deadline;
        }
        if (object.operation_deadline !== undefined && object.operation_deadline !== null) {
            message.operationDeadline = object.operation_deadline;
        }
        if (object.path_translation !== undefined && object.path_translation !== null) {
            message.pathTranslation = object.path_translation;
        }
        if (object.jwt_audience !== undefined && object.jwt_audience !== null) {
            message.jwtAudience = object.jwt_audience;
        }
        if (object.disable_auth !== undefined && object.disable_auth !== null) {
            message.disableAuth = object.disable_auth;
        }
        if (object.protocol !== undefined && object.protocol !== null) {
            message.protocol = object.protocol;
        }
        message.overridesByRequestProtocol = Object.entries(object.overrides_by_request_protocol ?? {}).reduce((acc, [key, value]) => {
            if (value !== undefined) {
                acc[key] = exports.BackendRule.fromAmino(value);
            }
            return acc;
        }, {});
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.selector = message.selector === "" ? undefined : message.selector;
        obj.address = message.address === "" ? undefined : message.address;
        obj.deadline = message.deadline === 0 ? undefined : message.deadline;
        obj.min_deadline = message.minDeadline === 0 ? undefined : message.minDeadline;
        obj.operation_deadline = message.operationDeadline === 0 ? undefined : message.operationDeadline;
        obj.path_translation = message.pathTranslation === 0 ? undefined : message.pathTranslation;
        obj.jwt_audience = message.jwtAudience === null ? undefined : message.jwtAudience;
        obj.disable_auth = message.disableAuth === null ? undefined : message.disableAuth;
        obj.protocol = message.protocol === "" ? undefined : message.protocol;
        obj.overrides_by_request_protocol = {};
        if (message.overridesByRequestProtocol) {
            Object.entries(message.overridesByRequestProtocol).forEach(([k, v]) => {
                obj.overrides_by_request_protocol[k] = exports.BackendRule.toAmino(v);
            });
        }
        return obj;
    },
    fromAminoMsg(object) {
        return exports.BackendRule.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.BackendRule.decode(message.value);
    },
    toProto(message) {
        return exports.BackendRule.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.BackendRule",
            value: exports.BackendRule.encode(message).finish()
        };
    }
};
