"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AuthRequirement = exports.OAuthRequirements = exports.AuthProvider = exports.JwtLocation = exports.AuthenticationRule = exports.Authentication = void 0;
//@ts-nocheck
const binary_1 = require("../../binary");
function createBaseAuthentication() {
    return {
        rules: [],
        providers: []
    };
}
exports.Authentication = {
    typeUrl: "/google.api.Authentication",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        for (const v of message.rules) {
            exports.AuthenticationRule.encode(v, writer.uint32(26).fork()).ldelim();
        }
        for (const v of message.providers) {
            exports.AuthProvider.encode(v, writer.uint32(34).fork()).ldelim();
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseAuthentication();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 3:
                    message.rules.push(exports.AuthenticationRule.decode(reader, reader.uint32()));
                    break;
                case 4:
                    message.providers.push(exports.AuthProvider.decode(reader, reader.uint32()));
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseAuthentication();
        message.rules = object.rules?.map(e => exports.AuthenticationRule.fromPartial(e)) || [];
        message.providers = object.providers?.map(e => exports.AuthProvider.fromPartial(e)) || [];
        return message;
    },
    fromAmino(object) {
        const message = createBaseAuthentication();
        message.rules = object.rules?.map(e => exports.AuthenticationRule.fromAmino(e)) || [];
        message.providers = object.providers?.map(e => exports.AuthProvider.fromAmino(e)) || [];
        return message;
    },
    toAmino(message) {
        const obj = {};
        if (message.rules) {
            obj.rules = message.rules.map(e => e ? exports.AuthenticationRule.toAmino(e) : undefined);
        }
        else {
            obj.rules = message.rules;
        }
        if (message.providers) {
            obj.providers = message.providers.map(e => e ? exports.AuthProvider.toAmino(e) : undefined);
        }
        else {
            obj.providers = message.providers;
        }
        return obj;
    },
    fromAminoMsg(object) {
        return exports.Authentication.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.Authentication.decode(message.value);
    },
    toProto(message) {
        return exports.Authentication.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.Authentication",
            value: exports.Authentication.encode(message).finish()
        };
    }
};
function createBaseAuthenticationRule() {
    return {
        selector: "",
        oauth: undefined,
        allowWithoutCredential: false,
        requirements: []
    };
}
exports.AuthenticationRule = {
    typeUrl: "/google.api.AuthenticationRule",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.selector !== "") {
            writer.uint32(10).string(message.selector);
        }
        if (message.oauth !== undefined) {
            exports.OAuthRequirements.encode(message.oauth, writer.uint32(18).fork()).ldelim();
        }
        if (message.allowWithoutCredential === true) {
            writer.uint32(40).bool(message.allowWithoutCredential);
        }
        for (const v of message.requirements) {
            exports.AuthRequirement.encode(v, writer.uint32(58).fork()).ldelim();
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseAuthenticationRule();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.selector = reader.string();
                    break;
                case 2:
                    message.oauth = exports.OAuthRequirements.decode(reader, reader.uint32());
                    break;
                case 5:
                    message.allowWithoutCredential = reader.bool();
                    break;
                case 7:
                    message.requirements.push(exports.AuthRequirement.decode(reader, reader.uint32()));
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseAuthenticationRule();
        message.selector = object.selector ?? "";
        message.oauth = object.oauth !== undefined && object.oauth !== null ? exports.OAuthRequirements.fromPartial(object.oauth) : undefined;
        message.allowWithoutCredential = object.allowWithoutCredential ?? false;
        message.requirements = object.requirements?.map(e => exports.AuthRequirement.fromPartial(e)) || [];
        return message;
    },
    fromAmino(object) {
        const message = createBaseAuthenticationRule();
        if (object.selector !== undefined && object.selector !== null) {
            message.selector = object.selector;
        }
        if (object.oauth !== undefined && object.oauth !== null) {
            message.oauth = exports.OAuthRequirements.fromAmino(object.oauth);
        }
        if (object.allow_without_credential !== undefined && object.allow_without_credential !== null) {
            message.allowWithoutCredential = object.allow_without_credential;
        }
        message.requirements = object.requirements?.map(e => exports.AuthRequirement.fromAmino(e)) || [];
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.selector = message.selector === "" ? undefined : message.selector;
        obj.oauth = message.oauth ? exports.OAuthRequirements.toAmino(message.oauth) : undefined;
        obj.allow_without_credential = message.allowWithoutCredential === false ? undefined : message.allowWithoutCredential;
        if (message.requirements) {
            obj.requirements = message.requirements.map(e => e ? exports.AuthRequirement.toAmino(e) : undefined);
        }
        else {
            obj.requirements = message.requirements;
        }
        return obj;
    },
    fromAminoMsg(object) {
        return exports.AuthenticationRule.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.AuthenticationRule.decode(message.value);
    },
    toProto(message) {
        return exports.AuthenticationRule.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.AuthenticationRule",
            value: exports.AuthenticationRule.encode(message).finish()
        };
    }
};
function createBaseJwtLocation() {
    return {
        header: undefined,
        query: undefined,
        cookie: undefined,
        valuePrefix: ""
    };
}
exports.JwtLocation = {
    typeUrl: "/google.api.JwtLocation",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.header !== undefined) {
            writer.uint32(10).string(message.header);
        }
        if (message.query !== undefined) {
            writer.uint32(18).string(message.query);
        }
        if (message.cookie !== undefined) {
            writer.uint32(34).string(message.cookie);
        }
        if (message.valuePrefix !== "") {
            writer.uint32(26).string(message.valuePrefix);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseJwtLocation();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.header = reader.string();
                    break;
                case 2:
                    message.query = reader.string();
                    break;
                case 4:
                    message.cookie = reader.string();
                    break;
                case 3:
                    message.valuePrefix = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseJwtLocation();
        message.header = object.header ?? undefined;
        message.query = object.query ?? undefined;
        message.cookie = object.cookie ?? undefined;
        message.valuePrefix = object.valuePrefix ?? "";
        return message;
    },
    fromAmino(object) {
        const message = createBaseJwtLocation();
        if (object.header !== undefined && object.header !== null) {
            message.header = object.header;
        }
        if (object.query !== undefined && object.query !== null) {
            message.query = object.query;
        }
        if (object.cookie !== undefined && object.cookie !== null) {
            message.cookie = object.cookie;
        }
        if (object.value_prefix !== undefined && object.value_prefix !== null) {
            message.valuePrefix = object.value_prefix;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.header = message.header === null ? undefined : message.header;
        obj.query = message.query === null ? undefined : message.query;
        obj.cookie = message.cookie === null ? undefined : message.cookie;
        obj.value_prefix = message.valuePrefix === "" ? undefined : message.valuePrefix;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.JwtLocation.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.JwtLocation.decode(message.value);
    },
    toProto(message) {
        return exports.JwtLocation.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.JwtLocation",
            value: exports.JwtLocation.encode(message).finish()
        };
    }
};
function createBaseAuthProvider() {
    return {
        id: "",
        issuer: "",
        jwksUri: "",
        audiences: "",
        authorizationUrl: "",
        jwtLocations: []
    };
}
exports.AuthProvider = {
    typeUrl: "/google.api.AuthProvider",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.id !== "") {
            writer.uint32(10).string(message.id);
        }
        if (message.issuer !== "") {
            writer.uint32(18).string(message.issuer);
        }
        if (message.jwksUri !== "") {
            writer.uint32(26).string(message.jwksUri);
        }
        if (message.audiences !== "") {
            writer.uint32(34).string(message.audiences);
        }
        if (message.authorizationUrl !== "") {
            writer.uint32(42).string(message.authorizationUrl);
        }
        for (const v of message.jwtLocations) {
            exports.JwtLocation.encode(v, writer.uint32(50).fork()).ldelim();
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseAuthProvider();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.id = reader.string();
                    break;
                case 2:
                    message.issuer = reader.string();
                    break;
                case 3:
                    message.jwksUri = reader.string();
                    break;
                case 4:
                    message.audiences = reader.string();
                    break;
                case 5:
                    message.authorizationUrl = reader.string();
                    break;
                case 6:
                    message.jwtLocations.push(exports.JwtLocation.decode(reader, reader.uint32()));
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseAuthProvider();
        message.id = object.id ?? "";
        message.issuer = object.issuer ?? "";
        message.jwksUri = object.jwksUri ?? "";
        message.audiences = object.audiences ?? "";
        message.authorizationUrl = object.authorizationUrl ?? "";
        message.jwtLocations = object.jwtLocations?.map(e => exports.JwtLocation.fromPartial(e)) || [];
        return message;
    },
    fromAmino(object) {
        const message = createBaseAuthProvider();
        if (object.id !== undefined && object.id !== null) {
            message.id = object.id;
        }
        if (object.issuer !== undefined && object.issuer !== null) {
            message.issuer = object.issuer;
        }
        if (object.jwks_uri !== undefined && object.jwks_uri !== null) {
            message.jwksUri = object.jwks_uri;
        }
        if (object.audiences !== undefined && object.audiences !== null) {
            message.audiences = object.audiences;
        }
        if (object.authorization_url !== undefined && object.authorization_url !== null) {
            message.authorizationUrl = object.authorization_url;
        }
        message.jwtLocations = object.jwt_locations?.map(e => exports.JwtLocation.fromAmino(e)) || [];
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.id = message.id === "" ? undefined : message.id;
        obj.issuer = message.issuer === "" ? undefined : message.issuer;
        obj.jwks_uri = message.jwksUri === "" ? undefined : message.jwksUri;
        obj.audiences = message.audiences === "" ? undefined : message.audiences;
        obj.authorization_url = message.authorizationUrl === "" ? undefined : message.authorizationUrl;
        if (message.jwtLocations) {
            obj.jwt_locations = message.jwtLocations.map(e => e ? exports.JwtLocation.toAmino(e) : undefined);
        }
        else {
            obj.jwt_locations = message.jwtLocations;
        }
        return obj;
    },
    fromAminoMsg(object) {
        return exports.AuthProvider.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.AuthProvider.decode(message.value);
    },
    toProto(message) {
        return exports.AuthProvider.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.AuthProvider",
            value: exports.AuthProvider.encode(message).finish()
        };
    }
};
function createBaseOAuthRequirements() {
    return {
        canonicalScopes: ""
    };
}
exports.OAuthRequirements = {
    typeUrl: "/google.api.OAuthRequirements",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.canonicalScopes !== "") {
            writer.uint32(10).string(message.canonicalScopes);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseOAuthRequirements();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.canonicalScopes = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseOAuthRequirements();
        message.canonicalScopes = object.canonicalScopes ?? "";
        return message;
    },
    fromAmino(object) {
        const message = createBaseOAuthRequirements();
        if (object.canonical_scopes !== undefined && object.canonical_scopes !== null) {
            message.canonicalScopes = object.canonical_scopes;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.canonical_scopes = message.canonicalScopes === "" ? undefined : message.canonicalScopes;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.OAuthRequirements.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.OAuthRequirements.decode(message.value);
    },
    toProto(message) {
        return exports.OAuthRequirements.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.OAuthRequirements",
            value: exports.OAuthRequirements.encode(message).finish()
        };
    }
};
function createBaseAuthRequirement() {
    return {
        providerId: "",
        audiences: ""
    };
}
exports.AuthRequirement = {
    typeUrl: "/google.api.AuthRequirement",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.providerId !== "") {
            writer.uint32(10).string(message.providerId);
        }
        if (message.audiences !== "") {
            writer.uint32(18).string(message.audiences);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseAuthRequirement();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.providerId = reader.string();
                    break;
                case 2:
                    message.audiences = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseAuthRequirement();
        message.providerId = object.providerId ?? "";
        message.audiences = object.audiences ?? "";
        return message;
    },
    fromAmino(object) {
        const message = createBaseAuthRequirement();
        if (object.provider_id !== undefined && object.provider_id !== null) {
            message.providerId = object.provider_id;
        }
        if (object.audiences !== undefined && object.audiences !== null) {
            message.audiences = object.audiences;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.provider_id = message.providerId === "" ? undefined : message.providerId;
        obj.audiences = message.audiences === "" ? undefined : message.audiences;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.AuthRequirement.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.AuthRequirement.decode(message.value);
    },
    toProto(message) {
        return exports.AuthRequirement.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.AuthRequirement",
            value: exports.AuthRequirement.encode(message).finish()
        };
    }
};
