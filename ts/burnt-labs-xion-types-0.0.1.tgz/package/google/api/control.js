"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Control = void 0;
//@ts-nocheck
const policy_1 = require("./policy");
const binary_1 = require("../../binary");
function createBaseControl() {
    return {
        environment: "",
        methodPolicies: []
    };
}
exports.Control = {
    typeUrl: "/google.api.Control",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.environment !== "") {
            writer.uint32(10).string(message.environment);
        }
        for (const v of message.methodPolicies) {
            policy_1.MethodPolicy.encode(v, writer.uint32(34).fork()).ldelim();
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseControl();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.environment = reader.string();
                    break;
                case 4:
                    message.methodPolicies.push(policy_1.MethodPolicy.decode(reader, reader.uint32()));
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseControl();
        message.environment = object.environment ?? "";
        message.methodPolicies = object.methodPolicies?.map(e => policy_1.MethodPolicy.fromPartial(e)) || [];
        return message;
    },
    fromAmino(object) {
        const message = createBaseControl();
        if (object.environment !== undefined && object.environment !== null) {
            message.environment = object.environment;
        }
        message.methodPolicies = object.method_policies?.map(e => policy_1.MethodPolicy.fromAmino(e)) || [];
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.environment = message.environment === "" ? undefined : message.environment;
        if (message.methodPolicies) {
            obj.method_policies = message.methodPolicies.map(e => e ? policy_1.MethodPolicy.toAmino(e) : undefined);
        }
        else {
            obj.method_policies = message.methodPolicies;
        }
        return obj;
    },
    fromAminoMsg(object) {
        return exports.Control.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.Control.decode(message.value);
    },
    toProto(message) {
        return exports.Control.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.Control",
            value: exports.Control.encode(message).finish()
        };
    }
};
