"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Page = exports.DocumentationRule = exports.Documentation = void 0;
//@ts-nocheck
const binary_1 = require("../../binary");
function createBaseDocumentation() {
    return {
        summary: "",
        pages: [],
        rules: [],
        documentationRootUrl: "",
        serviceRootUrl: "",
        overview: ""
    };
}
exports.Documentation = {
    typeUrl: "/google.api.Documentation",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.summary !== "") {
            writer.uint32(10).string(message.summary);
        }
        for (const v of message.pages) {
            exports.Page.encode(v, writer.uint32(42).fork()).ldelim();
        }
        for (const v of message.rules) {
            exports.DocumentationRule.encode(v, writer.uint32(26).fork()).ldelim();
        }
        if (message.documentationRootUrl !== "") {
            writer.uint32(34).string(message.documentationRootUrl);
        }
        if (message.serviceRootUrl !== "") {
            writer.uint32(50).string(message.serviceRootUrl);
        }
        if (message.overview !== "") {
            writer.uint32(18).string(message.overview);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseDocumentation();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.summary = reader.string();
                    break;
                case 5:
                    message.pages.push(exports.Page.decode(reader, reader.uint32()));
                    break;
                case 3:
                    message.rules.push(exports.DocumentationRule.decode(reader, reader.uint32()));
                    break;
                case 4:
                    message.documentationRootUrl = reader.string();
                    break;
                case 6:
                    message.serviceRootUrl = reader.string();
                    break;
                case 2:
                    message.overview = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseDocumentation();
        message.summary = object.summary ?? "";
        message.pages = object.pages?.map(e => exports.Page.fromPartial(e)) || [];
        message.rules = object.rules?.map(e => exports.DocumentationRule.fromPartial(e)) || [];
        message.documentationRootUrl = object.documentationRootUrl ?? "";
        message.serviceRootUrl = object.serviceRootUrl ?? "";
        message.overview = object.overview ?? "";
        return message;
    },
    fromAmino(object) {
        const message = createBaseDocumentation();
        if (object.summary !== undefined && object.summary !== null) {
            message.summary = object.summary;
        }
        message.pages = object.pages?.map(e => exports.Page.fromAmino(e)) || [];
        message.rules = object.rules?.map(e => exports.DocumentationRule.fromAmino(e)) || [];
        if (object.documentation_root_url !== undefined && object.documentation_root_url !== null) {
            message.documentationRootUrl = object.documentation_root_url;
        }
        if (object.service_root_url !== undefined && object.service_root_url !== null) {
            message.serviceRootUrl = object.service_root_url;
        }
        if (object.overview !== undefined && object.overview !== null) {
            message.overview = object.overview;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.summary = message.summary === "" ? undefined : message.summary;
        if (message.pages) {
            obj.pages = message.pages.map(e => e ? exports.Page.toAmino(e) : undefined);
        }
        else {
            obj.pages = message.pages;
        }
        if (message.rules) {
            obj.rules = message.rules.map(e => e ? exports.DocumentationRule.toAmino(e) : undefined);
        }
        else {
            obj.rules = message.rules;
        }
        obj.documentation_root_url = message.documentationRootUrl === "" ? undefined : message.documentationRootUrl;
        obj.service_root_url = message.serviceRootUrl === "" ? undefined : message.serviceRootUrl;
        obj.overview = message.overview === "" ? undefined : message.overview;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.Documentation.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.Documentation.decode(message.value);
    },
    toProto(message) {
        return exports.Documentation.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.Documentation",
            value: exports.Documentation.encode(message).finish()
        };
    }
};
function createBaseDocumentationRule() {
    return {
        selector: "",
        description: "",
        deprecationDescription: ""
    };
}
exports.DocumentationRule = {
    typeUrl: "/google.api.DocumentationRule",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.selector !== "") {
            writer.uint32(10).string(message.selector);
        }
        if (message.description !== "") {
            writer.uint32(18).string(message.description);
        }
        if (message.deprecationDescription !== "") {
            writer.uint32(26).string(message.deprecationDescription);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseDocumentationRule();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.selector = reader.string();
                    break;
                case 2:
                    message.description = reader.string();
                    break;
                case 3:
                    message.deprecationDescription = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseDocumentationRule();
        message.selector = object.selector ?? "";
        message.description = object.description ?? "";
        message.deprecationDescription = object.deprecationDescription ?? "";
        return message;
    },
    fromAmino(object) {
        const message = createBaseDocumentationRule();
        if (object.selector !== undefined && object.selector !== null) {
            message.selector = object.selector;
        }
        if (object.description !== undefined && object.description !== null) {
            message.description = object.description;
        }
        if (object.deprecation_description !== undefined && object.deprecation_description !== null) {
            message.deprecationDescription = object.deprecation_description;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.selector = message.selector === "" ? undefined : message.selector;
        obj.description = message.description === "" ? undefined : message.description;
        obj.deprecation_description = message.deprecationDescription === "" ? undefined : message.deprecationDescription;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.DocumentationRule.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.DocumentationRule.decode(message.value);
    },
    toProto(message) {
        return exports.DocumentationRule.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.DocumentationRule",
            value: exports.DocumentationRule.encode(message).finish()
        };
    }
};
function createBasePage() {
    return {
        name: "",
        content: "",
        subpages: []
    };
}
exports.Page = {
    typeUrl: "/google.api.Page",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.name !== "") {
            writer.uint32(10).string(message.name);
        }
        if (message.content !== "") {
            writer.uint32(18).string(message.content);
        }
        for (const v of message.subpages) {
            exports.Page.encode(v, writer.uint32(26).fork()).ldelim();
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBasePage();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.name = reader.string();
                    break;
                case 2:
                    message.content = reader.string();
                    break;
                case 3:
                    message.subpages.push(exports.Page.decode(reader, reader.uint32()));
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBasePage();
        message.name = object.name ?? "";
        message.content = object.content ?? "";
        message.subpages = object.subpages?.map(e => exports.Page.fromPartial(e)) || [];
        return message;
    },
    fromAmino(object) {
        const message = createBasePage();
        if (object.name !== undefined && object.name !== null) {
            message.name = object.name;
        }
        if (object.content !== undefined && object.content !== null) {
            message.content = object.content;
        }
        message.subpages = object.subpages?.map(e => exports.Page.fromAmino(e)) || [];
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.name = message.name === "" ? undefined : message.name;
        obj.content = message.content === "" ? undefined : message.content;
        if (message.subpages) {
            obj.subpages = message.subpages.map(e => e ? exports.Page.toAmino(e) : undefined);
        }
        else {
            obj.subpages = message.subpages;
        }
        return obj;
    },
    fromAminoMsg(object) {
        return exports.Page.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.Page.decode(message.value);
    },
    toProto(message) {
        return exports.Page.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.Page",
            value: exports.Page.encode(message).finish()
        };
    }
};
