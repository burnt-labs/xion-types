"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Advice = exports.ConfigChange = exports.ChangeTypeAmino = exports.ChangeTypeSDKType = exports.ChangeType = void 0;
exports.changeTypeFromJSON = changeTypeFromJSON;
exports.changeTypeToJSON = changeTypeToJSON;
//@ts-nocheck
const binary_1 = require("../../binary");
/**
 * Classifies set of possible modifications to an object in the service
 * configuration.
 */
var ChangeType;
(function (ChangeType) {
    /** CHANGE_TYPE_UNSPECIFIED - No value was provided. */
    ChangeType[ChangeType["CHANGE_TYPE_UNSPECIFIED"] = 0] = "CHANGE_TYPE_UNSPECIFIED";
    /**
     * ADDED - The changed object exists in the 'new' service configuration, but not
     * in the 'old' service configuration.
     */
    ChangeType[ChangeType["ADDED"] = 1] = "ADDED";
    /**
     * REMOVED - The changed object exists in the 'old' service configuration, but not
     * in the 'new' service configuration.
     */
    ChangeType[ChangeType["REMOVED"] = 2] = "REMOVED";
    /**
     * MODIFIED - The changed object exists in both service configurations, but its value
     * is different.
     */
    ChangeType[ChangeType["MODIFIED"] = 3] = "MODIFIED";
    ChangeType[ChangeType["UNRECOGNIZED"] = -1] = "UNRECOGNIZED";
})(ChangeType || (exports.ChangeType = ChangeType = {}));
exports.ChangeTypeSDKType = ChangeType;
exports.ChangeTypeAmino = ChangeType;
function changeTypeFromJSON(object) {
    switch (object) {
        case 0:
        case "CHANGE_TYPE_UNSPECIFIED":
            return ChangeType.CHANGE_TYPE_UNSPECIFIED;
        case 1:
        case "ADDED":
            return ChangeType.ADDED;
        case 2:
        case "REMOVED":
            return ChangeType.REMOVED;
        case 3:
        case "MODIFIED":
            return ChangeType.MODIFIED;
        case -1:
        case "UNRECOGNIZED":
        default:
            return ChangeType.UNRECOGNIZED;
    }
}
function changeTypeToJSON(object) {
    switch (object) {
        case ChangeType.CHANGE_TYPE_UNSPECIFIED:
            return "CHANGE_TYPE_UNSPECIFIED";
        case ChangeType.ADDED:
            return "ADDED";
        case ChangeType.REMOVED:
            return "REMOVED";
        case ChangeType.MODIFIED:
            return "MODIFIED";
        case ChangeType.UNRECOGNIZED:
        default:
            return "UNRECOGNIZED";
    }
}
function createBaseConfigChange() {
    return {
        element: "",
        oldValue: "",
        newValue: "",
        changeType: 0,
        advices: []
    };
}
exports.ConfigChange = {
    typeUrl: "/google.api.ConfigChange",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.element !== "") {
            writer.uint32(10).string(message.element);
        }
        if (message.oldValue !== "") {
            writer.uint32(18).string(message.oldValue);
        }
        if (message.newValue !== "") {
            writer.uint32(26).string(message.newValue);
        }
        if (message.changeType !== 0) {
            writer.uint32(32).int32(message.changeType);
        }
        for (const v of message.advices) {
            exports.Advice.encode(v, writer.uint32(42).fork()).ldelim();
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseConfigChange();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.element = reader.string();
                    break;
                case 2:
                    message.oldValue = reader.string();
                    break;
                case 3:
                    message.newValue = reader.string();
                    break;
                case 4:
                    message.changeType = reader.int32();
                    break;
                case 5:
                    message.advices.push(exports.Advice.decode(reader, reader.uint32()));
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseConfigChange();
        message.element = object.element ?? "";
        message.oldValue = object.oldValue ?? "";
        message.newValue = object.newValue ?? "";
        message.changeType = object.changeType ?? 0;
        message.advices = object.advices?.map(e => exports.Advice.fromPartial(e)) || [];
        return message;
    },
    fromAmino(object) {
        const message = createBaseConfigChange();
        if (object.element !== undefined && object.element !== null) {
            message.element = object.element;
        }
        if (object.old_value !== undefined && object.old_value !== null) {
            message.oldValue = object.old_value;
        }
        if (object.new_value !== undefined && object.new_value !== null) {
            message.newValue = object.new_value;
        }
        if (object.change_type !== undefined && object.change_type !== null) {
            message.changeType = object.change_type;
        }
        message.advices = object.advices?.map(e => exports.Advice.fromAmino(e)) || [];
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.element = message.element === "" ? undefined : message.element;
        obj.old_value = message.oldValue === "" ? undefined : message.oldValue;
        obj.new_value = message.newValue === "" ? undefined : message.newValue;
        obj.change_type = message.changeType === 0 ? undefined : message.changeType;
        if (message.advices) {
            obj.advices = message.advices.map(e => e ? exports.Advice.toAmino(e) : undefined);
        }
        else {
            obj.advices = message.advices;
        }
        return obj;
    },
    fromAminoMsg(object) {
        return exports.ConfigChange.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.ConfigChange.decode(message.value);
    },
    toProto(message) {
        return exports.ConfigChange.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.ConfigChange",
            value: exports.ConfigChange.encode(message).finish()
        };
    }
};
function createBaseAdvice() {
    return {
        description: ""
    };
}
exports.Advice = {
    typeUrl: "/google.api.Advice",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.description !== "") {
            writer.uint32(18).string(message.description);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseAdvice();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 2:
                    message.description = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseAdvice();
        message.description = object.description ?? "";
        return message;
    },
    fromAmino(object) {
        const message = createBaseAdvice();
        if (object.description !== undefined && object.description !== null) {
            message.description = object.description;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.description = message.description === "" ? undefined : message.description;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.Advice.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.Advice.decode(message.value);
    },
    toProto(message) {
        return exports.Advice.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.Advice",
            value: exports.Advice.encode(message).finish()
        };
    }
};
