"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.MethodPolicy = exports.FieldPolicy = void 0;
//@ts-nocheck
const binary_1 = require("../../binary");
function createBaseFieldPolicy() {
    return {
        selector: "",
        resourcePermission: "",
        resourceType: ""
    };
}
exports.FieldPolicy = {
    typeUrl: "/google.api.FieldPolicy",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.selector !== "") {
            writer.uint32(10).string(message.selector);
        }
        if (message.resourcePermission !== "") {
            writer.uint32(18).string(message.resourcePermission);
        }
        if (message.resourceType !== "") {
            writer.uint32(26).string(message.resourceType);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseFieldPolicy();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.selector = reader.string();
                    break;
                case 2:
                    message.resourcePermission = reader.string();
                    break;
                case 3:
                    message.resourceType = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseFieldPolicy();
        message.selector = object.selector ?? "";
        message.resourcePermission = object.resourcePermission ?? "";
        message.resourceType = object.resourceType ?? "";
        return message;
    },
    fromAmino(object) {
        const message = createBaseFieldPolicy();
        if (object.selector !== undefined && object.selector !== null) {
            message.selector = object.selector;
        }
        if (object.resource_permission !== undefined && object.resource_permission !== null) {
            message.resourcePermission = object.resource_permission;
        }
        if (object.resource_type !== undefined && object.resource_type !== null) {
            message.resourceType = object.resource_type;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.selector = message.selector === "" ? undefined : message.selector;
        obj.resource_permission = message.resourcePermission === "" ? undefined : message.resourcePermission;
        obj.resource_type = message.resourceType === "" ? undefined : message.resourceType;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.FieldPolicy.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.FieldPolicy.decode(message.value);
    },
    toProto(message) {
        return exports.FieldPolicy.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.FieldPolicy",
            value: exports.FieldPolicy.encode(message).finish()
        };
    }
};
function createBaseMethodPolicy() {
    return {
        selector: "",
        requestPolicies: []
    };
}
exports.MethodPolicy = {
    typeUrl: "/google.api.MethodPolicy",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.selector !== "") {
            writer.uint32(74).string(message.selector);
        }
        for (const v of message.requestPolicies) {
            exports.FieldPolicy.encode(v, writer.uint32(18).fork()).ldelim();
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseMethodPolicy();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 9:
                    message.selector = reader.string();
                    break;
                case 2:
                    message.requestPolicies.push(exports.FieldPolicy.decode(reader, reader.uint32()));
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseMethodPolicy();
        message.selector = object.selector ?? "";
        message.requestPolicies = object.requestPolicies?.map(e => exports.FieldPolicy.fromPartial(e)) || [];
        return message;
    },
    fromAmino(object) {
        const message = createBaseMethodPolicy();
        if (object.selector !== undefined && object.selector !== null) {
            message.selector = object.selector;
        }
        message.requestPolicies = object.request_policies?.map(e => exports.FieldPolicy.fromAmino(e)) || [];
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.selector = message.selector === "" ? undefined : message.selector;
        if (message.requestPolicies) {
            obj.request_policies = message.requestPolicies.map(e => e ? exports.FieldPolicy.toAmino(e) : undefined);
        }
        else {
            obj.request_policies = message.requestPolicies;
        }
        return obj;
    },
    fromAminoMsg(object) {
        return exports.MethodPolicy.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.MethodPolicy.decode(message.value);
    },
    toProto(message) {
        return exports.MethodPolicy.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.MethodPolicy",
            value: exports.MethodPolicy.encode(message).finish()
        };
    }
};
