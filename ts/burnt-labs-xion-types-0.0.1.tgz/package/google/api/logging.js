"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Logging_LoggingDestination = exports.Logging = void 0;
//@ts-nocheck
const binary_1 = require("../../binary");
function createBaseLogging() {
    return {
        producerDestinations: [],
        consumerDestinations: []
    };
}
exports.Logging = {
    typeUrl: "/google.api.Logging",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        for (const v of message.producerDestinations) {
            exports.Logging_LoggingDestination.encode(v, writer.uint32(10).fork()).ldelim();
        }
        for (const v of message.consumerDestinations) {
            exports.Logging_LoggingDestination.encode(v, writer.uint32(18).fork()).ldelim();
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseLogging();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.producerDestinations.push(exports.Logging_LoggingDestination.decode(reader, reader.uint32()));
                    break;
                case 2:
                    message.consumerDestinations.push(exports.Logging_LoggingDestination.decode(reader, reader.uint32()));
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseLogging();
        message.producerDestinations = object.producerDestinations?.map(e => exports.Logging_LoggingDestination.fromPartial(e)) || [];
        message.consumerDestinations = object.consumerDestinations?.map(e => exports.Logging_LoggingDestination.fromPartial(e)) || [];
        return message;
    },
    fromAmino(object) {
        const message = createBaseLogging();
        message.producerDestinations = object.producer_destinations?.map(e => exports.Logging_LoggingDestination.fromAmino(e)) || [];
        message.consumerDestinations = object.consumer_destinations?.map(e => exports.Logging_LoggingDestination.fromAmino(e)) || [];
        return message;
    },
    toAmino(message) {
        const obj = {};
        if (message.producerDestinations) {
            obj.producer_destinations = message.producerDestinations.map(e => e ? exports.Logging_LoggingDestination.toAmino(e) : undefined);
        }
        else {
            obj.producer_destinations = message.producerDestinations;
        }
        if (message.consumerDestinations) {
            obj.consumer_destinations = message.consumerDestinations.map(e => e ? exports.Logging_LoggingDestination.toAmino(e) : undefined);
        }
        else {
            obj.consumer_destinations = message.consumerDestinations;
        }
        return obj;
    },
    fromAminoMsg(object) {
        return exports.Logging.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.Logging.decode(message.value);
    },
    toProto(message) {
        return exports.Logging.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.Logging",
            value: exports.Logging.encode(message).finish()
        };
    }
};
function createBaseLogging_LoggingDestination() {
    return {
        monitoredResource: "",
        logs: []
    };
}
exports.Logging_LoggingDestination = {
    typeUrl: "/google.api.LoggingDestination",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.monitoredResource !== "") {
            writer.uint32(26).string(message.monitoredResource);
        }
        for (const v of message.logs) {
            writer.uint32(10).string(v);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseLogging_LoggingDestination();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 3:
                    message.monitoredResource = reader.string();
                    break;
                case 1:
                    message.logs.push(reader.string());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseLogging_LoggingDestination();
        message.monitoredResource = object.monitoredResource ?? "";
        message.logs = object.logs?.map(e => e) || [];
        return message;
    },
    fromAmino(object) {
        const message = createBaseLogging_LoggingDestination();
        if (object.monitored_resource !== undefined && object.monitored_resource !== null) {
            message.monitoredResource = object.monitored_resource;
        }
        message.logs = object.logs?.map(e => e) || [];
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.monitored_resource = message.monitoredResource === "" ? undefined : message.monitoredResource;
        if (message.logs) {
            obj.logs = message.logs.map(e => e);
        }
        else {
            obj.logs = message.logs;
        }
        return obj;
    },
    fromAminoMsg(object) {
        return exports.Logging_LoggingDestination.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.Logging_LoggingDestination.decode(message.value);
    },
    toProto(message) {
        return exports.Logging_LoggingDestination.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.LoggingDestination",
            value: exports.Logging_LoggingDestination.encode(message).finish()
        };
    }
};
