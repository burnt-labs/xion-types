"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SelectiveGapicGeneration = exports.MethodSettings_LongRunning = exports.MethodSettings = exports.GoSettings = exports.GoSettings_RenamedServicesEntry = exports.RubySettings = exports.DotnetSettings = exports.DotnetSettings_RenamedResourcesEntry = exports.DotnetSettings_RenamedServicesEntry = exports.NodeSettings = exports.PythonSettings_ExperimentalFeatures = exports.PythonSettings = exports.PhpSettings = exports.CppSettings = exports.JavaSettings = exports.JavaSettings_ServiceClassNamesEntry = exports.Publishing = exports.ClientLibrarySettings = exports.CommonLanguageSettings = exports.ClientLibraryDestinationAmino = exports.ClientLibraryDestinationSDKType = exports.ClientLibraryDestination = exports.ClientLibraryOrganizationAmino = exports.ClientLibraryOrganizationSDKType = exports.ClientLibraryOrganization = void 0;
exports.clientLibraryOrganizationFromJSON = clientLibraryOrganizationFromJSON;
exports.clientLibraryOrganizationToJSON = clientLibraryOrganizationToJSON;
exports.clientLibraryDestinationFromJSON = clientLibraryDestinationFromJSON;
exports.clientLibraryDestinationToJSON = clientLibraryDestinationToJSON;
const duration_1 = require("../protobuf/duration");
const binary_1 = require("../../binary");
/**
 * The organization for which the client libraries are being published.
 * Affects the url where generated docs are published, etc.
 */
var ClientLibraryOrganization;
(function (ClientLibraryOrganization) {
    /** CLIENT_LIBRARY_ORGANIZATION_UNSPECIFIED - Not useful. */
    ClientLibraryOrganization[ClientLibraryOrganization["CLIENT_LIBRARY_ORGANIZATION_UNSPECIFIED"] = 0] = "CLIENT_LIBRARY_ORGANIZATION_UNSPECIFIED";
    /** CLOUD - Google Cloud Platform Org. */
    ClientLibraryOrganization[ClientLibraryOrganization["CLOUD"] = 1] = "CLOUD";
    /** ADS - Ads (Advertising) Org. */
    ClientLibraryOrganization[ClientLibraryOrganization["ADS"] = 2] = "ADS";
    /** PHOTOS - Photos Org. */
    ClientLibraryOrganization[ClientLibraryOrganization["PHOTOS"] = 3] = "PHOTOS";
    /** STREET_VIEW - Street View Org. */
    ClientLibraryOrganization[ClientLibraryOrganization["STREET_VIEW"] = 4] = "STREET_VIEW";
    /** SHOPPING - Shopping Org. */
    ClientLibraryOrganization[ClientLibraryOrganization["SHOPPING"] = 5] = "SHOPPING";
    /** GEO - Geo Org. */
    ClientLibraryOrganization[ClientLibraryOrganization["GEO"] = 6] = "GEO";
    /** GENERATIVE_AI - Generative AI - https://developers.generativeai.google */
    ClientLibraryOrganization[ClientLibraryOrganization["GENERATIVE_AI"] = 7] = "GENERATIVE_AI";
    ClientLibraryOrganization[ClientLibraryOrganization["UNRECOGNIZED"] = -1] = "UNRECOGNIZED";
})(ClientLibraryOrganization || (exports.ClientLibraryOrganization = ClientLibraryOrganization = {}));
exports.ClientLibraryOrganizationSDKType = ClientLibraryOrganization;
exports.ClientLibraryOrganizationAmino = ClientLibraryOrganization;
function clientLibraryOrganizationFromJSON(object) {
    switch (object) {
        case 0:
        case "CLIENT_LIBRARY_ORGANIZATION_UNSPECIFIED":
            return ClientLibraryOrganization.CLIENT_LIBRARY_ORGANIZATION_UNSPECIFIED;
        case 1:
        case "CLOUD":
            return ClientLibraryOrganization.CLOUD;
        case 2:
        case "ADS":
            return ClientLibraryOrganization.ADS;
        case 3:
        case "PHOTOS":
            return ClientLibraryOrganization.PHOTOS;
        case 4:
        case "STREET_VIEW":
            return ClientLibraryOrganization.STREET_VIEW;
        case 5:
        case "SHOPPING":
            return ClientLibraryOrganization.SHOPPING;
        case 6:
        case "GEO":
            return ClientLibraryOrganization.GEO;
        case 7:
        case "GENERATIVE_AI":
            return ClientLibraryOrganization.GENERATIVE_AI;
        case -1:
        case "UNRECOGNIZED":
        default:
            return ClientLibraryOrganization.UNRECOGNIZED;
    }
}
function clientLibraryOrganizationToJSON(object) {
    switch (object) {
        case ClientLibraryOrganization.CLIENT_LIBRARY_ORGANIZATION_UNSPECIFIED:
            return "CLIENT_LIBRARY_ORGANIZATION_UNSPECIFIED";
        case ClientLibraryOrganization.CLOUD:
            return "CLOUD";
        case ClientLibraryOrganization.ADS:
            return "ADS";
        case ClientLibraryOrganization.PHOTOS:
            return "PHOTOS";
        case ClientLibraryOrganization.STREET_VIEW:
            return "STREET_VIEW";
        case ClientLibraryOrganization.SHOPPING:
            return "SHOPPING";
        case ClientLibraryOrganization.GEO:
            return "GEO";
        case ClientLibraryOrganization.GENERATIVE_AI:
            return "GENERATIVE_AI";
        case ClientLibraryOrganization.UNRECOGNIZED:
        default:
            return "UNRECOGNIZED";
    }
}
/** To where should client libraries be published? */
var ClientLibraryDestination;
(function (ClientLibraryDestination) {
    /**
     * CLIENT_LIBRARY_DESTINATION_UNSPECIFIED - Client libraries will neither be generated nor published to package
     * managers.
     */
    ClientLibraryDestination[ClientLibraryDestination["CLIENT_LIBRARY_DESTINATION_UNSPECIFIED"] = 0] = "CLIENT_LIBRARY_DESTINATION_UNSPECIFIED";
    /**
     * GITHUB - Generate the client library in a repo under github.com/googleapis,
     * but don't publish it to package managers.
     */
    ClientLibraryDestination[ClientLibraryDestination["GITHUB"] = 10] = "GITHUB";
    /** PACKAGE_MANAGER - Publish the library to package managers like nuget.org and npmjs.com. */
    ClientLibraryDestination[ClientLibraryDestination["PACKAGE_MANAGER"] = 20] = "PACKAGE_MANAGER";
    ClientLibraryDestination[ClientLibraryDestination["UNRECOGNIZED"] = -1] = "UNRECOGNIZED";
})(ClientLibraryDestination || (exports.ClientLibraryDestination = ClientLibraryDestination = {}));
exports.ClientLibraryDestinationSDKType = ClientLibraryDestination;
exports.ClientLibraryDestinationAmino = ClientLibraryDestination;
function clientLibraryDestinationFromJSON(object) {
    switch (object) {
        case 0:
        case "CLIENT_LIBRARY_DESTINATION_UNSPECIFIED":
            return ClientLibraryDestination.CLIENT_LIBRARY_DESTINATION_UNSPECIFIED;
        case 10:
        case "GITHUB":
            return ClientLibraryDestination.GITHUB;
        case 20:
        case "PACKAGE_MANAGER":
            return ClientLibraryDestination.PACKAGE_MANAGER;
        case -1:
        case "UNRECOGNIZED":
        default:
            return ClientLibraryDestination.UNRECOGNIZED;
    }
}
function clientLibraryDestinationToJSON(object) {
    switch (object) {
        case ClientLibraryDestination.CLIENT_LIBRARY_DESTINATION_UNSPECIFIED:
            return "CLIENT_LIBRARY_DESTINATION_UNSPECIFIED";
        case ClientLibraryDestination.GITHUB:
            return "GITHUB";
        case ClientLibraryDestination.PACKAGE_MANAGER:
            return "PACKAGE_MANAGER";
        case ClientLibraryDestination.UNRECOGNIZED:
        default:
            return "UNRECOGNIZED";
    }
}
function createBaseCommonLanguageSettings() {
    return {
        referenceDocsUri: "",
        destinations: [],
        selectiveGapicGeneration: undefined
    };
}
exports.CommonLanguageSettings = {
    typeUrl: "/google.api.CommonLanguageSettings",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.referenceDocsUri !== "") {
            writer.uint32(10).string(message.referenceDocsUri);
        }
        writer.uint32(18).fork();
        for (const v of message.destinations) {
            writer.int32(v);
        }
        writer.ldelim();
        if (message.selectiveGapicGeneration !== undefined) {
            exports.SelectiveGapicGeneration.encode(message.selectiveGapicGeneration, writer.uint32(26).fork()).ldelim();
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseCommonLanguageSettings();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.referenceDocsUri = reader.string();
                    break;
                case 2:
                    if ((tag & 7) === 2) {
                        const end2 = reader.uint32() + reader.pos;
                        while (reader.pos < end2) {
                            message.destinations.push(reader.int32());
                        }
                    }
                    else {
                        message.destinations.push(reader.int32());
                    }
                    break;
                case 3:
                    message.selectiveGapicGeneration = exports.SelectiveGapicGeneration.decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseCommonLanguageSettings();
        message.referenceDocsUri = object.referenceDocsUri ?? "";
        message.destinations = object.destinations?.map(e => e) || [];
        message.selectiveGapicGeneration = object.selectiveGapicGeneration !== undefined && object.selectiveGapicGeneration !== null ? exports.SelectiveGapicGeneration.fromPartial(object.selectiveGapicGeneration) : undefined;
        return message;
    },
    fromAmino(object) {
        const message = createBaseCommonLanguageSettings();
        if (object.reference_docs_uri !== undefined && object.reference_docs_uri !== null) {
            message.referenceDocsUri = object.reference_docs_uri;
        }
        message.destinations = object.destinations?.map(e => e) || [];
        if (object.selective_gapic_generation !== undefined && object.selective_gapic_generation !== null) {
            message.selectiveGapicGeneration = exports.SelectiveGapicGeneration.fromAmino(object.selective_gapic_generation);
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.reference_docs_uri = message.referenceDocsUri === "" ? undefined : message.referenceDocsUri;
        if (message.destinations) {
            obj.destinations = message.destinations.map(e => e);
        }
        else {
            obj.destinations = message.destinations;
        }
        obj.selective_gapic_generation = message.selectiveGapicGeneration ? exports.SelectiveGapicGeneration.toAmino(message.selectiveGapicGeneration) : undefined;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.CommonLanguageSettings.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.CommonLanguageSettings.decode(message.value);
    },
    toProto(message) {
        return exports.CommonLanguageSettings.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.CommonLanguageSettings",
            value: exports.CommonLanguageSettings.encode(message).finish()
        };
    }
};
function createBaseClientLibrarySettings() {
    return {
        version: "",
        launchStage: 0,
        restNumericEnums: false,
        javaSettings: undefined,
        cppSettings: undefined,
        phpSettings: undefined,
        pythonSettings: undefined,
        nodeSettings: undefined,
        dotnetSettings: undefined,
        rubySettings: undefined,
        goSettings: undefined
    };
}
exports.ClientLibrarySettings = {
    typeUrl: "/google.api.ClientLibrarySettings",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.version !== "") {
            writer.uint32(10).string(message.version);
        }
        if (message.launchStage !== 0) {
            writer.uint32(16).int32(message.launchStage);
        }
        if (message.restNumericEnums === true) {
            writer.uint32(24).bool(message.restNumericEnums);
        }
        if (message.javaSettings !== undefined) {
            exports.JavaSettings.encode(message.javaSettings, writer.uint32(170).fork()).ldelim();
        }
        if (message.cppSettings !== undefined) {
            exports.CppSettings.encode(message.cppSettings, writer.uint32(178).fork()).ldelim();
        }
        if (message.phpSettings !== undefined) {
            exports.PhpSettings.encode(message.phpSettings, writer.uint32(186).fork()).ldelim();
        }
        if (message.pythonSettings !== undefined) {
            exports.PythonSettings.encode(message.pythonSettings, writer.uint32(194).fork()).ldelim();
        }
        if (message.nodeSettings !== undefined) {
            exports.NodeSettings.encode(message.nodeSettings, writer.uint32(202).fork()).ldelim();
        }
        if (message.dotnetSettings !== undefined) {
            exports.DotnetSettings.encode(message.dotnetSettings, writer.uint32(210).fork()).ldelim();
        }
        if (message.rubySettings !== undefined) {
            exports.RubySettings.encode(message.rubySettings, writer.uint32(218).fork()).ldelim();
        }
        if (message.goSettings !== undefined) {
            exports.GoSettings.encode(message.goSettings, writer.uint32(226).fork()).ldelim();
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseClientLibrarySettings();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.version = reader.string();
                    break;
                case 2:
                    message.launchStage = reader.int32();
                    break;
                case 3:
                    message.restNumericEnums = reader.bool();
                    break;
                case 21:
                    message.javaSettings = exports.JavaSettings.decode(reader, reader.uint32());
                    break;
                case 22:
                    message.cppSettings = exports.CppSettings.decode(reader, reader.uint32());
                    break;
                case 23:
                    message.phpSettings = exports.PhpSettings.decode(reader, reader.uint32());
                    break;
                case 24:
                    message.pythonSettings = exports.PythonSettings.decode(reader, reader.uint32());
                    break;
                case 25:
                    message.nodeSettings = exports.NodeSettings.decode(reader, reader.uint32());
                    break;
                case 26:
                    message.dotnetSettings = exports.DotnetSettings.decode(reader, reader.uint32());
                    break;
                case 27:
                    message.rubySettings = exports.RubySettings.decode(reader, reader.uint32());
                    break;
                case 28:
                    message.goSettings = exports.GoSettings.decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseClientLibrarySettings();
        message.version = object.version ?? "";
        message.launchStage = object.launchStage ?? 0;
        message.restNumericEnums = object.restNumericEnums ?? false;
        message.javaSettings = object.javaSettings !== undefined && object.javaSettings !== null ? exports.JavaSettings.fromPartial(object.javaSettings) : undefined;
        message.cppSettings = object.cppSettings !== undefined && object.cppSettings !== null ? exports.CppSettings.fromPartial(object.cppSettings) : undefined;
        message.phpSettings = object.phpSettings !== undefined && object.phpSettings !== null ? exports.PhpSettings.fromPartial(object.phpSettings) : undefined;
        message.pythonSettings = object.pythonSettings !== undefined && object.pythonSettings !== null ? exports.PythonSettings.fromPartial(object.pythonSettings) : undefined;
        message.nodeSettings = object.nodeSettings !== undefined && object.nodeSettings !== null ? exports.NodeSettings.fromPartial(object.nodeSettings) : undefined;
        message.dotnetSettings = object.dotnetSettings !== undefined && object.dotnetSettings !== null ? exports.DotnetSettings.fromPartial(object.dotnetSettings) : undefined;
        message.rubySettings = object.rubySettings !== undefined && object.rubySettings !== null ? exports.RubySettings.fromPartial(object.rubySettings) : undefined;
        message.goSettings = object.goSettings !== undefined && object.goSettings !== null ? exports.GoSettings.fromPartial(object.goSettings) : undefined;
        return message;
    },
    fromAmino(object) {
        const message = createBaseClientLibrarySettings();
        if (object.version !== undefined && object.version !== null) {
            message.version = object.version;
        }
        if (object.launch_stage !== undefined && object.launch_stage !== null) {
            message.launchStage = object.launch_stage;
        }
        if (object.rest_numeric_enums !== undefined && object.rest_numeric_enums !== null) {
            message.restNumericEnums = object.rest_numeric_enums;
        }
        if (object.java_settings !== undefined && object.java_settings !== null) {
            message.javaSettings = exports.JavaSettings.fromAmino(object.java_settings);
        }
        if (object.cpp_settings !== undefined && object.cpp_settings !== null) {
            message.cppSettings = exports.CppSettings.fromAmino(object.cpp_settings);
        }
        if (object.php_settings !== undefined && object.php_settings !== null) {
            message.phpSettings = exports.PhpSettings.fromAmino(object.php_settings);
        }
        if (object.python_settings !== undefined && object.python_settings !== null) {
            message.pythonSettings = exports.PythonSettings.fromAmino(object.python_settings);
        }
        if (object.node_settings !== undefined && object.node_settings !== null) {
            message.nodeSettings = exports.NodeSettings.fromAmino(object.node_settings);
        }
        if (object.dotnet_settings !== undefined && object.dotnet_settings !== null) {
            message.dotnetSettings = exports.DotnetSettings.fromAmino(object.dotnet_settings);
        }
        if (object.ruby_settings !== undefined && object.ruby_settings !== null) {
            message.rubySettings = exports.RubySettings.fromAmino(object.ruby_settings);
        }
        if (object.go_settings !== undefined && object.go_settings !== null) {
            message.goSettings = exports.GoSettings.fromAmino(object.go_settings);
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.version = message.version === "" ? undefined : message.version;
        obj.launch_stage = message.launchStage === 0 ? undefined : message.launchStage;
        obj.rest_numeric_enums = message.restNumericEnums === false ? undefined : message.restNumericEnums;
        obj.java_settings = message.javaSettings ? exports.JavaSettings.toAmino(message.javaSettings) : undefined;
        obj.cpp_settings = message.cppSettings ? exports.CppSettings.toAmino(message.cppSettings) : undefined;
        obj.php_settings = message.phpSettings ? exports.PhpSettings.toAmino(message.phpSettings) : undefined;
        obj.python_settings = message.pythonSettings ? exports.PythonSettings.toAmino(message.pythonSettings) : undefined;
        obj.node_settings = message.nodeSettings ? exports.NodeSettings.toAmino(message.nodeSettings) : undefined;
        obj.dotnet_settings = message.dotnetSettings ? exports.DotnetSettings.toAmino(message.dotnetSettings) : undefined;
        obj.ruby_settings = message.rubySettings ? exports.RubySettings.toAmino(message.rubySettings) : undefined;
        obj.go_settings = message.goSettings ? exports.GoSettings.toAmino(message.goSettings) : undefined;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.ClientLibrarySettings.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.ClientLibrarySettings.decode(message.value);
    },
    toProto(message) {
        return exports.ClientLibrarySettings.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.ClientLibrarySettings",
            value: exports.ClientLibrarySettings.encode(message).finish()
        };
    }
};
function createBasePublishing() {
    return {
        methodSettings: [],
        newIssueUri: "",
        documentationUri: "",
        apiShortName: "",
        githubLabel: "",
        codeownerGithubTeams: [],
        docTagPrefix: "",
        organization: 0,
        librarySettings: [],
        protoReferenceDocumentationUri: "",
        restReferenceDocumentationUri: ""
    };
}
exports.Publishing = {
    typeUrl: "/google.api.Publishing",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        for (const v of message.methodSettings) {
            exports.MethodSettings.encode(v, writer.uint32(18).fork()).ldelim();
        }
        if (message.newIssueUri !== "") {
            writer.uint32(810).string(message.newIssueUri);
        }
        if (message.documentationUri !== "") {
            writer.uint32(818).string(message.documentationUri);
        }
        if (message.apiShortName !== "") {
            writer.uint32(826).string(message.apiShortName);
        }
        if (message.githubLabel !== "") {
            writer.uint32(834).string(message.githubLabel);
        }
        for (const v of message.codeownerGithubTeams) {
            writer.uint32(842).string(v);
        }
        if (message.docTagPrefix !== "") {
            writer.uint32(850).string(message.docTagPrefix);
        }
        if (message.organization !== 0) {
            writer.uint32(856).int32(message.organization);
        }
        for (const v of message.librarySettings) {
            exports.ClientLibrarySettings.encode(v, writer.uint32(874).fork()).ldelim();
        }
        if (message.protoReferenceDocumentationUri !== "") {
            writer.uint32(882).string(message.protoReferenceDocumentationUri);
        }
        if (message.restReferenceDocumentationUri !== "") {
            writer.uint32(890).string(message.restReferenceDocumentationUri);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBasePublishing();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 2:
                    message.methodSettings.push(exports.MethodSettings.decode(reader, reader.uint32()));
                    break;
                case 101:
                    message.newIssueUri = reader.string();
                    break;
                case 102:
                    message.documentationUri = reader.string();
                    break;
                case 103:
                    message.apiShortName = reader.string();
                    break;
                case 104:
                    message.githubLabel = reader.string();
                    break;
                case 105:
                    message.codeownerGithubTeams.push(reader.string());
                    break;
                case 106:
                    message.docTagPrefix = reader.string();
                    break;
                case 107:
                    message.organization = reader.int32();
                    break;
                case 109:
                    message.librarySettings.push(exports.ClientLibrarySettings.decode(reader, reader.uint32()));
                    break;
                case 110:
                    message.protoReferenceDocumentationUri = reader.string();
                    break;
                case 111:
                    message.restReferenceDocumentationUri = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBasePublishing();
        message.methodSettings = object.methodSettings?.map(e => exports.MethodSettings.fromPartial(e)) || [];
        message.newIssueUri = object.newIssueUri ?? "";
        message.documentationUri = object.documentationUri ?? "";
        message.apiShortName = object.apiShortName ?? "";
        message.githubLabel = object.githubLabel ?? "";
        message.codeownerGithubTeams = object.codeownerGithubTeams?.map(e => e) || [];
        message.docTagPrefix = object.docTagPrefix ?? "";
        message.organization = object.organization ?? 0;
        message.librarySettings = object.librarySettings?.map(e => exports.ClientLibrarySettings.fromPartial(e)) || [];
        message.protoReferenceDocumentationUri = object.protoReferenceDocumentationUri ?? "";
        message.restReferenceDocumentationUri = object.restReferenceDocumentationUri ?? "";
        return message;
    },
    fromAmino(object) {
        const message = createBasePublishing();
        message.methodSettings = object.method_settings?.map(e => exports.MethodSettings.fromAmino(e)) || [];
        if (object.new_issue_uri !== undefined && object.new_issue_uri !== null) {
            message.newIssueUri = object.new_issue_uri;
        }
        if (object.documentation_uri !== undefined && object.documentation_uri !== null) {
            message.documentationUri = object.documentation_uri;
        }
        if (object.api_short_name !== undefined && object.api_short_name !== null) {
            message.apiShortName = object.api_short_name;
        }
        if (object.github_label !== undefined && object.github_label !== null) {
            message.githubLabel = object.github_label;
        }
        message.codeownerGithubTeams = object.codeowner_github_teams?.map(e => e) || [];
        if (object.doc_tag_prefix !== undefined && object.doc_tag_prefix !== null) {
            message.docTagPrefix = object.doc_tag_prefix;
        }
        if (object.organization !== undefined && object.organization !== null) {
            message.organization = object.organization;
        }
        message.librarySettings = object.library_settings?.map(e => exports.ClientLibrarySettings.fromAmino(e)) || [];
        if (object.proto_reference_documentation_uri !== undefined && object.proto_reference_documentation_uri !== null) {
            message.protoReferenceDocumentationUri = object.proto_reference_documentation_uri;
        }
        if (object.rest_reference_documentation_uri !== undefined && object.rest_reference_documentation_uri !== null) {
            message.restReferenceDocumentationUri = object.rest_reference_documentation_uri;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        if (message.methodSettings) {
            obj.method_settings = message.methodSettings.map(e => e ? exports.MethodSettings.toAmino(e) : undefined);
        }
        else {
            obj.method_settings = message.methodSettings;
        }
        obj.new_issue_uri = message.newIssueUri === "" ? undefined : message.newIssueUri;
        obj.documentation_uri = message.documentationUri === "" ? undefined : message.documentationUri;
        obj.api_short_name = message.apiShortName === "" ? undefined : message.apiShortName;
        obj.github_label = message.githubLabel === "" ? undefined : message.githubLabel;
        if (message.codeownerGithubTeams) {
            obj.codeowner_github_teams = message.codeownerGithubTeams.map(e => e);
        }
        else {
            obj.codeowner_github_teams = message.codeownerGithubTeams;
        }
        obj.doc_tag_prefix = message.docTagPrefix === "" ? undefined : message.docTagPrefix;
        obj.organization = message.organization === 0 ? undefined : message.organization;
        if (message.librarySettings) {
            obj.library_settings = message.librarySettings.map(e => e ? exports.ClientLibrarySettings.toAmino(e) : undefined);
        }
        else {
            obj.library_settings = message.librarySettings;
        }
        obj.proto_reference_documentation_uri = message.protoReferenceDocumentationUri === "" ? undefined : message.protoReferenceDocumentationUri;
        obj.rest_reference_documentation_uri = message.restReferenceDocumentationUri === "" ? undefined : message.restReferenceDocumentationUri;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.Publishing.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.Publishing.decode(message.value);
    },
    toProto(message) {
        return exports.Publishing.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.Publishing",
            value: exports.Publishing.encode(message).finish()
        };
    }
};
function createBaseJavaSettings_ServiceClassNamesEntry() {
    return {
        key: "",
        value: ""
    };
}
exports.JavaSettings_ServiceClassNamesEntry = {
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.key !== "") {
            writer.uint32(10).string(message.key);
        }
        if (message.value !== "") {
            writer.uint32(18).string(message.value);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseJavaSettings_ServiceClassNamesEntry();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.key = reader.string();
                    break;
                case 2:
                    message.value = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseJavaSettings_ServiceClassNamesEntry();
        message.key = object.key ?? "";
        message.value = object.value ?? "";
        return message;
    },
    fromAmino(object) {
        const message = createBaseJavaSettings_ServiceClassNamesEntry();
        if (object.key !== undefined && object.key !== null) {
            message.key = object.key;
        }
        if (object.value !== undefined && object.value !== null) {
            message.value = object.value;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.key = message.key === "" ? undefined : message.key;
        obj.value = message.value === "" ? undefined : message.value;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.JavaSettings_ServiceClassNamesEntry.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.JavaSettings_ServiceClassNamesEntry.decode(message.value);
    },
    toProto(message) {
        return exports.JavaSettings_ServiceClassNamesEntry.encode(message).finish();
    }
};
function createBaseJavaSettings() {
    return {
        libraryPackage: "",
        serviceClassNames: {},
        common: undefined
    };
}
exports.JavaSettings = {
    typeUrl: "/google.api.JavaSettings",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.libraryPackage !== "") {
            writer.uint32(10).string(message.libraryPackage);
        }
        Object.entries(message.serviceClassNames).forEach(([key, value]) => {
            exports.JavaSettings_ServiceClassNamesEntry.encode({
                key: key,
                value
            }, writer.uint32(18).fork()).ldelim();
        });
        if (message.common !== undefined) {
            exports.CommonLanguageSettings.encode(message.common, writer.uint32(26).fork()).ldelim();
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseJavaSettings();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.libraryPackage = reader.string();
                    break;
                case 2:
                    const entry2 = exports.JavaSettings_ServiceClassNamesEntry.decode(reader, reader.uint32());
                    if (entry2.value !== undefined) {
                        message.serviceClassNames[entry2.key] = entry2.value;
                    }
                    break;
                case 3:
                    message.common = exports.CommonLanguageSettings.decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseJavaSettings();
        message.libraryPackage = object.libraryPackage ?? "";
        message.serviceClassNames = Object.entries(object.serviceClassNames ?? {}).reduce((acc, [key, value]) => {
            if (value !== undefined) {
                acc[key] = String(value);
            }
            return acc;
        }, {});
        message.common = object.common !== undefined && object.common !== null ? exports.CommonLanguageSettings.fromPartial(object.common) : undefined;
        return message;
    },
    fromAmino(object) {
        const message = createBaseJavaSettings();
        if (object.library_package !== undefined && object.library_package !== null) {
            message.libraryPackage = object.library_package;
        }
        message.serviceClassNames = Object.entries(object.service_class_names ?? {}).reduce((acc, [key, value]) => {
            if (value !== undefined) {
                acc[key] = String(value);
            }
            return acc;
        }, {});
        if (object.common !== undefined && object.common !== null) {
            message.common = exports.CommonLanguageSettings.fromAmino(object.common);
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.library_package = message.libraryPackage === "" ? undefined : message.libraryPackage;
        obj.service_class_names = {};
        if (message.serviceClassNames) {
            Object.entries(message.serviceClassNames).forEach(([k, v]) => {
                obj.service_class_names[k] = v;
            });
        }
        obj.common = message.common ? exports.CommonLanguageSettings.toAmino(message.common) : undefined;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.JavaSettings.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.JavaSettings.decode(message.value);
    },
    toProto(message) {
        return exports.JavaSettings.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.JavaSettings",
            value: exports.JavaSettings.encode(message).finish()
        };
    }
};
function createBaseCppSettings() {
    return {
        common: undefined
    };
}
exports.CppSettings = {
    typeUrl: "/google.api.CppSettings",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.common !== undefined) {
            exports.CommonLanguageSettings.encode(message.common, writer.uint32(10).fork()).ldelim();
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseCppSettings();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.common = exports.CommonLanguageSettings.decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseCppSettings();
        message.common = object.common !== undefined && object.common !== null ? exports.CommonLanguageSettings.fromPartial(object.common) : undefined;
        return message;
    },
    fromAmino(object) {
        const message = createBaseCppSettings();
        if (object.common !== undefined && object.common !== null) {
            message.common = exports.CommonLanguageSettings.fromAmino(object.common);
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.common = message.common ? exports.CommonLanguageSettings.toAmino(message.common) : undefined;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.CppSettings.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.CppSettings.decode(message.value);
    },
    toProto(message) {
        return exports.CppSettings.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.CppSettings",
            value: exports.CppSettings.encode(message).finish()
        };
    }
};
function createBasePhpSettings() {
    return {
        common: undefined
    };
}
exports.PhpSettings = {
    typeUrl: "/google.api.PhpSettings",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.common !== undefined) {
            exports.CommonLanguageSettings.encode(message.common, writer.uint32(10).fork()).ldelim();
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBasePhpSettings();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.common = exports.CommonLanguageSettings.decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBasePhpSettings();
        message.common = object.common !== undefined && object.common !== null ? exports.CommonLanguageSettings.fromPartial(object.common) : undefined;
        return message;
    },
    fromAmino(object) {
        const message = createBasePhpSettings();
        if (object.common !== undefined && object.common !== null) {
            message.common = exports.CommonLanguageSettings.fromAmino(object.common);
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.common = message.common ? exports.CommonLanguageSettings.toAmino(message.common) : undefined;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.PhpSettings.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.PhpSettings.decode(message.value);
    },
    toProto(message) {
        return exports.PhpSettings.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.PhpSettings",
            value: exports.PhpSettings.encode(message).finish()
        };
    }
};
function createBasePythonSettings() {
    return {
        common: undefined,
        experimentalFeatures: undefined
    };
}
exports.PythonSettings = {
    typeUrl: "/google.api.PythonSettings",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.common !== undefined) {
            exports.CommonLanguageSettings.encode(message.common, writer.uint32(10).fork()).ldelim();
        }
        if (message.experimentalFeatures !== undefined) {
            exports.PythonSettings_ExperimentalFeatures.encode(message.experimentalFeatures, writer.uint32(18).fork()).ldelim();
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBasePythonSettings();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.common = exports.CommonLanguageSettings.decode(reader, reader.uint32());
                    break;
                case 2:
                    message.experimentalFeatures = exports.PythonSettings_ExperimentalFeatures.decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBasePythonSettings();
        message.common = object.common !== undefined && object.common !== null ? exports.CommonLanguageSettings.fromPartial(object.common) : undefined;
        message.experimentalFeatures = object.experimentalFeatures !== undefined && object.experimentalFeatures !== null ? exports.PythonSettings_ExperimentalFeatures.fromPartial(object.experimentalFeatures) : undefined;
        return message;
    },
    fromAmino(object) {
        const message = createBasePythonSettings();
        if (object.common !== undefined && object.common !== null) {
            message.common = exports.CommonLanguageSettings.fromAmino(object.common);
        }
        if (object.experimental_features !== undefined && object.experimental_features !== null) {
            message.experimentalFeatures = exports.PythonSettings_ExperimentalFeatures.fromAmino(object.experimental_features);
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.common = message.common ? exports.CommonLanguageSettings.toAmino(message.common) : undefined;
        obj.experimental_features = message.experimentalFeatures ? exports.PythonSettings_ExperimentalFeatures.toAmino(message.experimentalFeatures) : undefined;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.PythonSettings.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.PythonSettings.decode(message.value);
    },
    toProto(message) {
        return exports.PythonSettings.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.PythonSettings",
            value: exports.PythonSettings.encode(message).finish()
        };
    }
};
function createBasePythonSettings_ExperimentalFeatures() {
    return {
        restAsyncIoEnabled: false,
        protobufPythonicTypesEnabled: false,
        unversionedPackageDisabled: false
    };
}
exports.PythonSettings_ExperimentalFeatures = {
    typeUrl: "/google.api.ExperimentalFeatures",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.restAsyncIoEnabled === true) {
            writer.uint32(8).bool(message.restAsyncIoEnabled);
        }
        if (message.protobufPythonicTypesEnabled === true) {
            writer.uint32(16).bool(message.protobufPythonicTypesEnabled);
        }
        if (message.unversionedPackageDisabled === true) {
            writer.uint32(24).bool(message.unversionedPackageDisabled);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBasePythonSettings_ExperimentalFeatures();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.restAsyncIoEnabled = reader.bool();
                    break;
                case 2:
                    message.protobufPythonicTypesEnabled = reader.bool();
                    break;
                case 3:
                    message.unversionedPackageDisabled = reader.bool();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBasePythonSettings_ExperimentalFeatures();
        message.restAsyncIoEnabled = object.restAsyncIoEnabled ?? false;
        message.protobufPythonicTypesEnabled = object.protobufPythonicTypesEnabled ?? false;
        message.unversionedPackageDisabled = object.unversionedPackageDisabled ?? false;
        return message;
    },
    fromAmino(object) {
        const message = createBasePythonSettings_ExperimentalFeatures();
        if (object.rest_async_io_enabled !== undefined && object.rest_async_io_enabled !== null) {
            message.restAsyncIoEnabled = object.rest_async_io_enabled;
        }
        if (object.protobuf_pythonic_types_enabled !== undefined && object.protobuf_pythonic_types_enabled !== null) {
            message.protobufPythonicTypesEnabled = object.protobuf_pythonic_types_enabled;
        }
        if (object.unversioned_package_disabled !== undefined && object.unversioned_package_disabled !== null) {
            message.unversionedPackageDisabled = object.unversioned_package_disabled;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.rest_async_io_enabled = message.restAsyncIoEnabled === false ? undefined : message.restAsyncIoEnabled;
        obj.protobuf_pythonic_types_enabled = message.protobufPythonicTypesEnabled === false ? undefined : message.protobufPythonicTypesEnabled;
        obj.unversioned_package_disabled = message.unversionedPackageDisabled === false ? undefined : message.unversionedPackageDisabled;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.PythonSettings_ExperimentalFeatures.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.PythonSettings_ExperimentalFeatures.decode(message.value);
    },
    toProto(message) {
        return exports.PythonSettings_ExperimentalFeatures.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.ExperimentalFeatures",
            value: exports.PythonSettings_ExperimentalFeatures.encode(message).finish()
        };
    }
};
function createBaseNodeSettings() {
    return {
        common: undefined
    };
}
exports.NodeSettings = {
    typeUrl: "/google.api.NodeSettings",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.common !== undefined) {
            exports.CommonLanguageSettings.encode(message.common, writer.uint32(10).fork()).ldelim();
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseNodeSettings();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.common = exports.CommonLanguageSettings.decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseNodeSettings();
        message.common = object.common !== undefined && object.common !== null ? exports.CommonLanguageSettings.fromPartial(object.common) : undefined;
        return message;
    },
    fromAmino(object) {
        const message = createBaseNodeSettings();
        if (object.common !== undefined && object.common !== null) {
            message.common = exports.CommonLanguageSettings.fromAmino(object.common);
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.common = message.common ? exports.CommonLanguageSettings.toAmino(message.common) : undefined;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.NodeSettings.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.NodeSettings.decode(message.value);
    },
    toProto(message) {
        return exports.NodeSettings.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.NodeSettings",
            value: exports.NodeSettings.encode(message).finish()
        };
    }
};
function createBaseDotnetSettings_RenamedServicesEntry() {
    return {
        key: "",
        value: ""
    };
}
exports.DotnetSettings_RenamedServicesEntry = {
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.key !== "") {
            writer.uint32(10).string(message.key);
        }
        if (message.value !== "") {
            writer.uint32(18).string(message.value);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseDotnetSettings_RenamedServicesEntry();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.key = reader.string();
                    break;
                case 2:
                    message.value = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseDotnetSettings_RenamedServicesEntry();
        message.key = object.key ?? "";
        message.value = object.value ?? "";
        return message;
    },
    fromAmino(object) {
        const message = createBaseDotnetSettings_RenamedServicesEntry();
        if (object.key !== undefined && object.key !== null) {
            message.key = object.key;
        }
        if (object.value !== undefined && object.value !== null) {
            message.value = object.value;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.key = message.key === "" ? undefined : message.key;
        obj.value = message.value === "" ? undefined : message.value;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.DotnetSettings_RenamedServicesEntry.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.DotnetSettings_RenamedServicesEntry.decode(message.value);
    },
    toProto(message) {
        return exports.DotnetSettings_RenamedServicesEntry.encode(message).finish();
    }
};
function createBaseDotnetSettings_RenamedResourcesEntry() {
    return {
        key: "",
        value: ""
    };
}
exports.DotnetSettings_RenamedResourcesEntry = {
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.key !== "") {
            writer.uint32(10).string(message.key);
        }
        if (message.value !== "") {
            writer.uint32(18).string(message.value);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseDotnetSettings_RenamedResourcesEntry();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.key = reader.string();
                    break;
                case 2:
                    message.value = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseDotnetSettings_RenamedResourcesEntry();
        message.key = object.key ?? "";
        message.value = object.value ?? "";
        return message;
    },
    fromAmino(object) {
        const message = createBaseDotnetSettings_RenamedResourcesEntry();
        if (object.key !== undefined && object.key !== null) {
            message.key = object.key;
        }
        if (object.value !== undefined && object.value !== null) {
            message.value = object.value;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.key = message.key === "" ? undefined : message.key;
        obj.value = message.value === "" ? undefined : message.value;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.DotnetSettings_RenamedResourcesEntry.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.DotnetSettings_RenamedResourcesEntry.decode(message.value);
    },
    toProto(message) {
        return exports.DotnetSettings_RenamedResourcesEntry.encode(message).finish();
    }
};
function createBaseDotnetSettings() {
    return {
        common: undefined,
        renamedServices: {},
        renamedResources: {},
        ignoredResources: [],
        forcedNamespaceAliases: [],
        handwrittenSignatures: []
    };
}
exports.DotnetSettings = {
    typeUrl: "/google.api.DotnetSettings",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.common !== undefined) {
            exports.CommonLanguageSettings.encode(message.common, writer.uint32(10).fork()).ldelim();
        }
        Object.entries(message.renamedServices).forEach(([key, value]) => {
            exports.DotnetSettings_RenamedServicesEntry.encode({
                key: key,
                value
            }, writer.uint32(18).fork()).ldelim();
        });
        Object.entries(message.renamedResources).forEach(([key, value]) => {
            exports.DotnetSettings_RenamedResourcesEntry.encode({
                key: key,
                value
            }, writer.uint32(26).fork()).ldelim();
        });
        for (const v of message.ignoredResources) {
            writer.uint32(34).string(v);
        }
        for (const v of message.forcedNamespaceAliases) {
            writer.uint32(42).string(v);
        }
        for (const v of message.handwrittenSignatures) {
            writer.uint32(50).string(v);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseDotnetSettings();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.common = exports.CommonLanguageSettings.decode(reader, reader.uint32());
                    break;
                case 2:
                    const entry2 = exports.DotnetSettings_RenamedServicesEntry.decode(reader, reader.uint32());
                    if (entry2.value !== undefined) {
                        message.renamedServices[entry2.key] = entry2.value;
                    }
                    break;
                case 3:
                    const entry3 = exports.DotnetSettings_RenamedResourcesEntry.decode(reader, reader.uint32());
                    if (entry3.value !== undefined) {
                        message.renamedResources[entry3.key] = entry3.value;
                    }
                    break;
                case 4:
                    message.ignoredResources.push(reader.string());
                    break;
                case 5:
                    message.forcedNamespaceAliases.push(reader.string());
                    break;
                case 6:
                    message.handwrittenSignatures.push(reader.string());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseDotnetSettings();
        message.common = object.common !== undefined && object.common !== null ? exports.CommonLanguageSettings.fromPartial(object.common) : undefined;
        message.renamedServices = Object.entries(object.renamedServices ?? {}).reduce((acc, [key, value]) => {
            if (value !== undefined) {
                acc[key] = String(value);
            }
            return acc;
        }, {});
        message.renamedResources = Object.entries(object.renamedResources ?? {}).reduce((acc, [key, value]) => {
            if (value !== undefined) {
                acc[key] = String(value);
            }
            return acc;
        }, {});
        message.ignoredResources = object.ignoredResources?.map(e => e) || [];
        message.forcedNamespaceAliases = object.forcedNamespaceAliases?.map(e => e) || [];
        message.handwrittenSignatures = object.handwrittenSignatures?.map(e => e) || [];
        return message;
    },
    fromAmino(object) {
        const message = createBaseDotnetSettings();
        if (object.common !== undefined && object.common !== null) {
            message.common = exports.CommonLanguageSettings.fromAmino(object.common);
        }
        message.renamedServices = Object.entries(object.renamed_services ?? {}).reduce((acc, [key, value]) => {
            if (value !== undefined) {
                acc[key] = String(value);
            }
            return acc;
        }, {});
        message.renamedResources = Object.entries(object.renamed_resources ?? {}).reduce((acc, [key, value]) => {
            if (value !== undefined) {
                acc[key] = String(value);
            }
            return acc;
        }, {});
        message.ignoredResources = object.ignored_resources?.map(e => e) || [];
        message.forcedNamespaceAliases = object.forced_namespace_aliases?.map(e => e) || [];
        message.handwrittenSignatures = object.handwritten_signatures?.map(e => e) || [];
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.common = message.common ? exports.CommonLanguageSettings.toAmino(message.common) : undefined;
        obj.renamed_services = {};
        if (message.renamedServices) {
            Object.entries(message.renamedServices).forEach(([k, v]) => {
                obj.renamed_services[k] = v;
            });
        }
        obj.renamed_resources = {};
        if (message.renamedResources) {
            Object.entries(message.renamedResources).forEach(([k, v]) => {
                obj.renamed_resources[k] = v;
            });
        }
        if (message.ignoredResources) {
            obj.ignored_resources = message.ignoredResources.map(e => e);
        }
        else {
            obj.ignored_resources = message.ignoredResources;
        }
        if (message.forcedNamespaceAliases) {
            obj.forced_namespace_aliases = message.forcedNamespaceAliases.map(e => e);
        }
        else {
            obj.forced_namespace_aliases = message.forcedNamespaceAliases;
        }
        if (message.handwrittenSignatures) {
            obj.handwritten_signatures = message.handwrittenSignatures.map(e => e);
        }
        else {
            obj.handwritten_signatures = message.handwrittenSignatures;
        }
        return obj;
    },
    fromAminoMsg(object) {
        return exports.DotnetSettings.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.DotnetSettings.decode(message.value);
    },
    toProto(message) {
        return exports.DotnetSettings.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.DotnetSettings",
            value: exports.DotnetSettings.encode(message).finish()
        };
    }
};
function createBaseRubySettings() {
    return {
        common: undefined
    };
}
exports.RubySettings = {
    typeUrl: "/google.api.RubySettings",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.common !== undefined) {
            exports.CommonLanguageSettings.encode(message.common, writer.uint32(10).fork()).ldelim();
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseRubySettings();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.common = exports.CommonLanguageSettings.decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseRubySettings();
        message.common = object.common !== undefined && object.common !== null ? exports.CommonLanguageSettings.fromPartial(object.common) : undefined;
        return message;
    },
    fromAmino(object) {
        const message = createBaseRubySettings();
        if (object.common !== undefined && object.common !== null) {
            message.common = exports.CommonLanguageSettings.fromAmino(object.common);
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.common = message.common ? exports.CommonLanguageSettings.toAmino(message.common) : undefined;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.RubySettings.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.RubySettings.decode(message.value);
    },
    toProto(message) {
        return exports.RubySettings.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.RubySettings",
            value: exports.RubySettings.encode(message).finish()
        };
    }
};
function createBaseGoSettings_RenamedServicesEntry() {
    return {
        key: "",
        value: ""
    };
}
exports.GoSettings_RenamedServicesEntry = {
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.key !== "") {
            writer.uint32(10).string(message.key);
        }
        if (message.value !== "") {
            writer.uint32(18).string(message.value);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseGoSettings_RenamedServicesEntry();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.key = reader.string();
                    break;
                case 2:
                    message.value = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseGoSettings_RenamedServicesEntry();
        message.key = object.key ?? "";
        message.value = object.value ?? "";
        return message;
    },
    fromAmino(object) {
        const message = createBaseGoSettings_RenamedServicesEntry();
        if (object.key !== undefined && object.key !== null) {
            message.key = object.key;
        }
        if (object.value !== undefined && object.value !== null) {
            message.value = object.value;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.key = message.key === "" ? undefined : message.key;
        obj.value = message.value === "" ? undefined : message.value;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.GoSettings_RenamedServicesEntry.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.GoSettings_RenamedServicesEntry.decode(message.value);
    },
    toProto(message) {
        return exports.GoSettings_RenamedServicesEntry.encode(message).finish();
    }
};
function createBaseGoSettings() {
    return {
        common: undefined,
        renamedServices: {}
    };
}
exports.GoSettings = {
    typeUrl: "/google.api.GoSettings",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.common !== undefined) {
            exports.CommonLanguageSettings.encode(message.common, writer.uint32(10).fork()).ldelim();
        }
        Object.entries(message.renamedServices).forEach(([key, value]) => {
            exports.GoSettings_RenamedServicesEntry.encode({
                key: key,
                value
            }, writer.uint32(18).fork()).ldelim();
        });
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseGoSettings();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.common = exports.CommonLanguageSettings.decode(reader, reader.uint32());
                    break;
                case 2:
                    const entry2 = exports.GoSettings_RenamedServicesEntry.decode(reader, reader.uint32());
                    if (entry2.value !== undefined) {
                        message.renamedServices[entry2.key] = entry2.value;
                    }
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseGoSettings();
        message.common = object.common !== undefined && object.common !== null ? exports.CommonLanguageSettings.fromPartial(object.common) : undefined;
        message.renamedServices = Object.entries(object.renamedServices ?? {}).reduce((acc, [key, value]) => {
            if (value !== undefined) {
                acc[key] = String(value);
            }
            return acc;
        }, {});
        return message;
    },
    fromAmino(object) {
        const message = createBaseGoSettings();
        if (object.common !== undefined && object.common !== null) {
            message.common = exports.CommonLanguageSettings.fromAmino(object.common);
        }
        message.renamedServices = Object.entries(object.renamed_services ?? {}).reduce((acc, [key, value]) => {
            if (value !== undefined) {
                acc[key] = String(value);
            }
            return acc;
        }, {});
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.common = message.common ? exports.CommonLanguageSettings.toAmino(message.common) : undefined;
        obj.renamed_services = {};
        if (message.renamedServices) {
            Object.entries(message.renamedServices).forEach(([k, v]) => {
                obj.renamed_services[k] = v;
            });
        }
        return obj;
    },
    fromAminoMsg(object) {
        return exports.GoSettings.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.GoSettings.decode(message.value);
    },
    toProto(message) {
        return exports.GoSettings.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.GoSettings",
            value: exports.GoSettings.encode(message).finish()
        };
    }
};
function createBaseMethodSettings() {
    return {
        selector: "",
        longRunning: undefined,
        autoPopulatedFields: []
    };
}
exports.MethodSettings = {
    typeUrl: "/google.api.MethodSettings",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.selector !== "") {
            writer.uint32(10).string(message.selector);
        }
        if (message.longRunning !== undefined) {
            exports.MethodSettings_LongRunning.encode(message.longRunning, writer.uint32(18).fork()).ldelim();
        }
        for (const v of message.autoPopulatedFields) {
            writer.uint32(26).string(v);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseMethodSettings();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.selector = reader.string();
                    break;
                case 2:
                    message.longRunning = exports.MethodSettings_LongRunning.decode(reader, reader.uint32());
                    break;
                case 3:
                    message.autoPopulatedFields.push(reader.string());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseMethodSettings();
        message.selector = object.selector ?? "";
        message.longRunning = object.longRunning !== undefined && object.longRunning !== null ? exports.MethodSettings_LongRunning.fromPartial(object.longRunning) : undefined;
        message.autoPopulatedFields = object.autoPopulatedFields?.map(e => e) || [];
        return message;
    },
    fromAmino(object) {
        const message = createBaseMethodSettings();
        if (object.selector !== undefined && object.selector !== null) {
            message.selector = object.selector;
        }
        if (object.long_running !== undefined && object.long_running !== null) {
            message.longRunning = exports.MethodSettings_LongRunning.fromAmino(object.long_running);
        }
        message.autoPopulatedFields = object.auto_populated_fields?.map(e => e) || [];
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.selector = message.selector === "" ? undefined : message.selector;
        obj.long_running = message.longRunning ? exports.MethodSettings_LongRunning.toAmino(message.longRunning) : undefined;
        if (message.autoPopulatedFields) {
            obj.auto_populated_fields = message.autoPopulatedFields.map(e => e);
        }
        else {
            obj.auto_populated_fields = message.autoPopulatedFields;
        }
        return obj;
    },
    fromAminoMsg(object) {
        return exports.MethodSettings.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.MethodSettings.decode(message.value);
    },
    toProto(message) {
        return exports.MethodSettings.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.MethodSettings",
            value: exports.MethodSettings.encode(message).finish()
        };
    }
};
function createBaseMethodSettings_LongRunning() {
    return {
        initialPollDelay: undefined,
        pollDelayMultiplier: 0,
        maxPollDelay: undefined,
        totalPollTimeout: undefined
    };
}
exports.MethodSettings_LongRunning = {
    typeUrl: "/google.api.LongRunning",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.initialPollDelay !== undefined) {
            duration_1.Duration.encode(message.initialPollDelay, writer.uint32(10).fork()).ldelim();
        }
        if (message.pollDelayMultiplier !== 0) {
            writer.uint32(21).float(message.pollDelayMultiplier);
        }
        if (message.maxPollDelay !== undefined) {
            duration_1.Duration.encode(message.maxPollDelay, writer.uint32(26).fork()).ldelim();
        }
        if (message.totalPollTimeout !== undefined) {
            duration_1.Duration.encode(message.totalPollTimeout, writer.uint32(34).fork()).ldelim();
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseMethodSettings_LongRunning();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.initialPollDelay = duration_1.Duration.decode(reader, reader.uint32());
                    break;
                case 2:
                    message.pollDelayMultiplier = reader.float();
                    break;
                case 3:
                    message.maxPollDelay = duration_1.Duration.decode(reader, reader.uint32());
                    break;
                case 4:
                    message.totalPollTimeout = duration_1.Duration.decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseMethodSettings_LongRunning();
        message.initialPollDelay = object.initialPollDelay !== undefined && object.initialPollDelay !== null ? duration_1.Duration.fromPartial(object.initialPollDelay) : undefined;
        message.pollDelayMultiplier = object.pollDelayMultiplier ?? 0;
        message.maxPollDelay = object.maxPollDelay !== undefined && object.maxPollDelay !== null ? duration_1.Duration.fromPartial(object.maxPollDelay) : undefined;
        message.totalPollTimeout = object.totalPollTimeout !== undefined && object.totalPollTimeout !== null ? duration_1.Duration.fromPartial(object.totalPollTimeout) : undefined;
        return message;
    },
    fromAmino(object) {
        const message = createBaseMethodSettings_LongRunning();
        if (object.initial_poll_delay !== undefined && object.initial_poll_delay !== null) {
            message.initialPollDelay = duration_1.Duration.fromAmino(object.initial_poll_delay);
        }
        if (object.poll_delay_multiplier !== undefined && object.poll_delay_multiplier !== null) {
            message.pollDelayMultiplier = object.poll_delay_multiplier;
        }
        if (object.max_poll_delay !== undefined && object.max_poll_delay !== null) {
            message.maxPollDelay = duration_1.Duration.fromAmino(object.max_poll_delay);
        }
        if (object.total_poll_timeout !== undefined && object.total_poll_timeout !== null) {
            message.totalPollTimeout = duration_1.Duration.fromAmino(object.total_poll_timeout);
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.initial_poll_delay = message.initialPollDelay ? duration_1.Duration.toAmino(message.initialPollDelay) : undefined;
        obj.poll_delay_multiplier = message.pollDelayMultiplier === 0 ? undefined : message.pollDelayMultiplier;
        obj.max_poll_delay = message.maxPollDelay ? duration_1.Duration.toAmino(message.maxPollDelay) : undefined;
        obj.total_poll_timeout = message.totalPollTimeout ? duration_1.Duration.toAmino(message.totalPollTimeout) : undefined;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.MethodSettings_LongRunning.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.MethodSettings_LongRunning.decode(message.value);
    },
    toProto(message) {
        return exports.MethodSettings_LongRunning.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.LongRunning",
            value: exports.MethodSettings_LongRunning.encode(message).finish()
        };
    }
};
function createBaseSelectiveGapicGeneration() {
    return {
        methods: [],
        generateOmittedAsInternal: false
    };
}
exports.SelectiveGapicGeneration = {
    typeUrl: "/google.api.SelectiveGapicGeneration",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        for (const v of message.methods) {
            writer.uint32(10).string(v);
        }
        if (message.generateOmittedAsInternal === true) {
            writer.uint32(16).bool(message.generateOmittedAsInternal);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseSelectiveGapicGeneration();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.methods.push(reader.string());
                    break;
                case 2:
                    message.generateOmittedAsInternal = reader.bool();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseSelectiveGapicGeneration();
        message.methods = object.methods?.map(e => e) || [];
        message.generateOmittedAsInternal = object.generateOmittedAsInternal ?? false;
        return message;
    },
    fromAmino(object) {
        const message = createBaseSelectiveGapicGeneration();
        message.methods = object.methods?.map(e => e) || [];
        if (object.generate_omitted_as_internal !== undefined && object.generate_omitted_as_internal !== null) {
            message.generateOmittedAsInternal = object.generate_omitted_as_internal;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        if (message.methods) {
            obj.methods = message.methods.map(e => e);
        }
        else {
            obj.methods = message.methods;
        }
        obj.generate_omitted_as_internal = message.generateOmittedAsInternal === false ? undefined : message.generateOmittedAsInternal;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.SelectiveGapicGeneration.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.SelectiveGapicGeneration.decode(message.value);
    },
    toProto(message) {
        return exports.SelectiveGapicGeneration.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.SelectiveGapicGeneration",
            value: exports.SelectiveGapicGeneration.encode(message).finish()
        };
    }
};
