"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Monitoring_MonitoringDestination = exports.Monitoring = void 0;
//@ts-nocheck
const binary_1 = require("../../binary");
function createBaseMonitoring() {
    return {
        producerDestinations: [],
        consumerDestinations: []
    };
}
exports.Monitoring = {
    typeUrl: "/google.api.Monitoring",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        for (const v of message.producerDestinations) {
            exports.Monitoring_MonitoringDestination.encode(v, writer.uint32(10).fork()).ldelim();
        }
        for (const v of message.consumerDestinations) {
            exports.Monitoring_MonitoringDestination.encode(v, writer.uint32(18).fork()).ldelim();
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseMonitoring();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.producerDestinations.push(exports.Monitoring_MonitoringDestination.decode(reader, reader.uint32()));
                    break;
                case 2:
                    message.consumerDestinations.push(exports.Monitoring_MonitoringDestination.decode(reader, reader.uint32()));
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseMonitoring();
        message.producerDestinations = object.producerDestinations?.map(e => exports.Monitoring_MonitoringDestination.fromPartial(e)) || [];
        message.consumerDestinations = object.consumerDestinations?.map(e => exports.Monitoring_MonitoringDestination.fromPartial(e)) || [];
        return message;
    },
    fromAmino(object) {
        const message = createBaseMonitoring();
        message.producerDestinations = object.producer_destinations?.map(e => exports.Monitoring_MonitoringDestination.fromAmino(e)) || [];
        message.consumerDestinations = object.consumer_destinations?.map(e => exports.Monitoring_MonitoringDestination.fromAmino(e)) || [];
        return message;
    },
    toAmino(message) {
        const obj = {};
        if (message.producerDestinations) {
            obj.producer_destinations = message.producerDestinations.map(e => e ? exports.Monitoring_MonitoringDestination.toAmino(e) : undefined);
        }
        else {
            obj.producer_destinations = message.producerDestinations;
        }
        if (message.consumerDestinations) {
            obj.consumer_destinations = message.consumerDestinations.map(e => e ? exports.Monitoring_MonitoringDestination.toAmino(e) : undefined);
        }
        else {
            obj.consumer_destinations = message.consumerDestinations;
        }
        return obj;
    },
    fromAminoMsg(object) {
        return exports.Monitoring.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.Monitoring.decode(message.value);
    },
    toProto(message) {
        return exports.Monitoring.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.Monitoring",
            value: exports.Monitoring.encode(message).finish()
        };
    }
};
function createBaseMonitoring_MonitoringDestination() {
    return {
        monitoredResource: "",
        metrics: []
    };
}
exports.Monitoring_MonitoringDestination = {
    typeUrl: "/google.api.MonitoringDestination",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.monitoredResource !== "") {
            writer.uint32(10).string(message.monitoredResource);
        }
        for (const v of message.metrics) {
            writer.uint32(18).string(v);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseMonitoring_MonitoringDestination();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.monitoredResource = reader.string();
                    break;
                case 2:
                    message.metrics.push(reader.string());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseMonitoring_MonitoringDestination();
        message.monitoredResource = object.monitoredResource ?? "";
        message.metrics = object.metrics?.map(e => e) || [];
        return message;
    },
    fromAmino(object) {
        const message = createBaseMonitoring_MonitoringDestination();
        if (object.monitored_resource !== undefined && object.monitored_resource !== null) {
            message.monitoredResource = object.monitored_resource;
        }
        message.metrics = object.metrics?.map(e => e) || [];
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.monitored_resource = message.monitoredResource === "" ? undefined : message.monitoredResource;
        if (message.metrics) {
            obj.metrics = message.metrics.map(e => e);
        }
        else {
            obj.metrics = message.metrics;
        }
        return obj;
    },
    fromAminoMsg(object) {
        return exports.Monitoring_MonitoringDestination.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.Monitoring_MonitoringDestination.decode(message.value);
    },
    toProto(message) {
        return exports.Monitoring_MonitoringDestination.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.MonitoringDestination",
            value: exports.Monitoring_MonitoringDestination.encode(message).finish()
        };
    }
};
