"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.LabelDescriptor = exports.LabelDescriptor_ValueTypeAmino = exports.LabelDescriptor_ValueTypeSDKType = exports.LabelDescriptor_ValueType = void 0;
exports.labelDescriptor_ValueTypeFromJSON = labelDescriptor_ValueTypeFromJSON;
exports.labelDescriptor_ValueTypeToJSON = labelDescriptor_ValueTypeToJSON;
//@ts-nocheck
const binary_1 = require("../../binary");
/** Value types that can be used as label values. */
var LabelDescriptor_ValueType;
(function (LabelDescriptor_ValueType) {
    /** STRING - A variable-length string. This is the default. */
    LabelDescriptor_ValueType[LabelDescriptor_ValueType["STRING"] = 0] = "STRING";
    /** BOOL - Boolean; true or false. */
    LabelDescriptor_ValueType[LabelDescriptor_ValueType["BOOL"] = 1] = "BOOL";
    /** INT64 - A 64-bit signed integer. */
    LabelDescriptor_ValueType[LabelDescriptor_ValueType["INT64"] = 2] = "INT64";
    LabelDescriptor_ValueType[LabelDescriptor_ValueType["UNRECOGNIZED"] = -1] = "UNRECOGNIZED";
})(LabelDescriptor_ValueType || (exports.LabelDescriptor_ValueType = LabelDescriptor_ValueType = {}));
exports.LabelDescriptor_ValueTypeSDKType = LabelDescriptor_ValueType;
exports.LabelDescriptor_ValueTypeAmino = LabelDescriptor_ValueType;
function labelDescriptor_ValueTypeFromJSON(object) {
    switch (object) {
        case 0:
        case "STRING":
            return LabelDescriptor_ValueType.STRING;
        case 1:
        case "BOOL":
            return LabelDescriptor_ValueType.BOOL;
        case 2:
        case "INT64":
            return LabelDescriptor_ValueType.INT64;
        case -1:
        case "UNRECOGNIZED":
        default:
            return LabelDescriptor_ValueType.UNRECOGNIZED;
    }
}
function labelDescriptor_ValueTypeToJSON(object) {
    switch (object) {
        case LabelDescriptor_ValueType.STRING:
            return "STRING";
        case LabelDescriptor_ValueType.BOOL:
            return "BOOL";
        case LabelDescriptor_ValueType.INT64:
            return "INT64";
        case LabelDescriptor_ValueType.UNRECOGNIZED:
        default:
            return "UNRECOGNIZED";
    }
}
function createBaseLabelDescriptor() {
    return {
        key: "",
        valueType: 0,
        description: ""
    };
}
exports.LabelDescriptor = {
    typeUrl: "/google.api.LabelDescriptor",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.key !== "") {
            writer.uint32(10).string(message.key);
        }
        if (message.valueType !== 0) {
            writer.uint32(16).int32(message.valueType);
        }
        if (message.description !== "") {
            writer.uint32(26).string(message.description);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseLabelDescriptor();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.key = reader.string();
                    break;
                case 2:
                    message.valueType = reader.int32();
                    break;
                case 3:
                    message.description = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseLabelDescriptor();
        message.key = object.key ?? "";
        message.valueType = object.valueType ?? 0;
        message.description = object.description ?? "";
        return message;
    },
    fromAmino(object) {
        const message = createBaseLabelDescriptor();
        if (object.key !== undefined && object.key !== null) {
            message.key = object.key;
        }
        if (object.value_type !== undefined && object.value_type !== null) {
            message.valueType = object.value_type;
        }
        if (object.description !== undefined && object.description !== null) {
            message.description = object.description;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.key = message.key === "" ? undefined : message.key;
        obj.value_type = message.valueType === 0 ? undefined : message.valueType;
        obj.description = message.description === "" ? undefined : message.description;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.LabelDescriptor.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.LabelDescriptor.decode(message.value);
    },
    toProto(message) {
        return exports.LabelDescriptor.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.LabelDescriptor",
            value: exports.LabelDescriptor.encode(message).finish()
        };
    }
};
