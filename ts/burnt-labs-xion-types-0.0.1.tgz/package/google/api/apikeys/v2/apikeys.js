"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.LookupKeyResponse = exports.LookupKeyRequest = exports.UndeleteKeyRequest = exports.DeleteKeyRequest = exports.UpdateKeyRequest = exports.GetKeyStringResponse = exports.GetKeyStringRequest = exports.GetKeyRequest = exports.ListKeysResponse = exports.ListKeysRequest = exports.CreateKeyRequest = void 0;
//@ts-nocheck
const resources_1 = require("./resources");
const field_mask_1 = require("../../../protobuf/field_mask");
const binary_1 = require("../../../../binary");
function createBaseCreateKeyRequest() {
    return {
        parent: "",
        key: undefined,
        keyId: ""
    };
}
exports.CreateKeyRequest = {
    typeUrl: "/google.api.apikeys.v2.CreateKeyRequest",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.parent !== "") {
            writer.uint32(10).string(message.parent);
        }
        if (message.key !== undefined) {
            resources_1.Key.encode(message.key, writer.uint32(18).fork()).ldelim();
        }
        if (message.keyId !== "") {
            writer.uint32(26).string(message.keyId);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseCreateKeyRequest();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.parent = reader.string();
                    break;
                case 2:
                    message.key = resources_1.Key.decode(reader, reader.uint32());
                    break;
                case 3:
                    message.keyId = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseCreateKeyRequest();
        message.parent = object.parent ?? "";
        message.key = object.key !== undefined && object.key !== null ? resources_1.Key.fromPartial(object.key) : undefined;
        message.keyId = object.keyId ?? "";
        return message;
    },
    fromAmino(object) {
        const message = createBaseCreateKeyRequest();
        if (object.parent !== undefined && object.parent !== null) {
            message.parent = object.parent;
        }
        if (object.key !== undefined && object.key !== null) {
            message.key = resources_1.Key.fromAmino(object.key);
        }
        if (object.key_id !== undefined && object.key_id !== null) {
            message.keyId = object.key_id;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.parent = message.parent === "" ? undefined : message.parent;
        obj.key = message.key ? resources_1.Key.toAmino(message.key) : undefined;
        obj.key_id = message.keyId === "" ? undefined : message.keyId;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.CreateKeyRequest.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.CreateKeyRequest.decode(message.value);
    },
    toProto(message) {
        return exports.CreateKeyRequest.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.apikeys.v2.CreateKeyRequest",
            value: exports.CreateKeyRequest.encode(message).finish()
        };
    }
};
function createBaseListKeysRequest() {
    return {
        parent: "",
        pageSize: 0,
        pageToken: "",
        showDeleted: false
    };
}
exports.ListKeysRequest = {
    typeUrl: "/google.api.apikeys.v2.ListKeysRequest",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.parent !== "") {
            writer.uint32(10).string(message.parent);
        }
        if (message.pageSize !== 0) {
            writer.uint32(16).int32(message.pageSize);
        }
        if (message.pageToken !== "") {
            writer.uint32(26).string(message.pageToken);
        }
        if (message.showDeleted === true) {
            writer.uint32(48).bool(message.showDeleted);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseListKeysRequest();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.parent = reader.string();
                    break;
                case 2:
                    message.pageSize = reader.int32();
                    break;
                case 3:
                    message.pageToken = reader.string();
                    break;
                case 6:
                    message.showDeleted = reader.bool();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseListKeysRequest();
        message.parent = object.parent ?? "";
        message.pageSize = object.pageSize ?? 0;
        message.pageToken = object.pageToken ?? "";
        message.showDeleted = object.showDeleted ?? false;
        return message;
    },
    fromAmino(object) {
        const message = createBaseListKeysRequest();
        if (object.parent !== undefined && object.parent !== null) {
            message.parent = object.parent;
        }
        if (object.page_size !== undefined && object.page_size !== null) {
            message.pageSize = object.page_size;
        }
        if (object.page_token !== undefined && object.page_token !== null) {
            message.pageToken = object.page_token;
        }
        if (object.show_deleted !== undefined && object.show_deleted !== null) {
            message.showDeleted = object.show_deleted;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.parent = message.parent === "" ? undefined : message.parent;
        obj.page_size = message.pageSize === 0 ? undefined : message.pageSize;
        obj.page_token = message.pageToken === "" ? undefined : message.pageToken;
        obj.show_deleted = message.showDeleted === false ? undefined : message.showDeleted;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.ListKeysRequest.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.ListKeysRequest.decode(message.value);
    },
    toProto(message) {
        return exports.ListKeysRequest.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.apikeys.v2.ListKeysRequest",
            value: exports.ListKeysRequest.encode(message).finish()
        };
    }
};
function createBaseListKeysResponse() {
    return {
        keys: [],
        nextPageToken: ""
    };
}
exports.ListKeysResponse = {
    typeUrl: "/google.api.apikeys.v2.ListKeysResponse",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        for (const v of message.keys) {
            resources_1.Key.encode(v, writer.uint32(10).fork()).ldelim();
        }
        if (message.nextPageToken !== "") {
            writer.uint32(18).string(message.nextPageToken);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseListKeysResponse();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.keys.push(resources_1.Key.decode(reader, reader.uint32()));
                    break;
                case 2:
                    message.nextPageToken = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseListKeysResponse();
        message.keys = object.keys?.map(e => resources_1.Key.fromPartial(e)) || [];
        message.nextPageToken = object.nextPageToken ?? "";
        return message;
    },
    fromAmino(object) {
        const message = createBaseListKeysResponse();
        message.keys = object.keys?.map(e => resources_1.Key.fromAmino(e)) || [];
        if (object.next_page_token !== undefined && object.next_page_token !== null) {
            message.nextPageToken = object.next_page_token;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        if (message.keys) {
            obj.keys = message.keys.map(e => e ? resources_1.Key.toAmino(e) : undefined);
        }
        else {
            obj.keys = message.keys;
        }
        obj.next_page_token = message.nextPageToken === "" ? undefined : message.nextPageToken;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.ListKeysResponse.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.ListKeysResponse.decode(message.value);
    },
    toProto(message) {
        return exports.ListKeysResponse.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.apikeys.v2.ListKeysResponse",
            value: exports.ListKeysResponse.encode(message).finish()
        };
    }
};
function createBaseGetKeyRequest() {
    return {
        name: ""
    };
}
exports.GetKeyRequest = {
    typeUrl: "/google.api.apikeys.v2.GetKeyRequest",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.name !== "") {
            writer.uint32(10).string(message.name);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseGetKeyRequest();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.name = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseGetKeyRequest();
        message.name = object.name ?? "";
        return message;
    },
    fromAmino(object) {
        const message = createBaseGetKeyRequest();
        if (object.name !== undefined && object.name !== null) {
            message.name = object.name;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.name = message.name === "" ? undefined : message.name;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.GetKeyRequest.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.GetKeyRequest.decode(message.value);
    },
    toProto(message) {
        return exports.GetKeyRequest.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.apikeys.v2.GetKeyRequest",
            value: exports.GetKeyRequest.encode(message).finish()
        };
    }
};
function createBaseGetKeyStringRequest() {
    return {
        name: ""
    };
}
exports.GetKeyStringRequest = {
    typeUrl: "/google.api.apikeys.v2.GetKeyStringRequest",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.name !== "") {
            writer.uint32(10).string(message.name);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseGetKeyStringRequest();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.name = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseGetKeyStringRequest();
        message.name = object.name ?? "";
        return message;
    },
    fromAmino(object) {
        const message = createBaseGetKeyStringRequest();
        if (object.name !== undefined && object.name !== null) {
            message.name = object.name;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.name = message.name === "" ? undefined : message.name;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.GetKeyStringRequest.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.GetKeyStringRequest.decode(message.value);
    },
    toProto(message) {
        return exports.GetKeyStringRequest.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.apikeys.v2.GetKeyStringRequest",
            value: exports.GetKeyStringRequest.encode(message).finish()
        };
    }
};
function createBaseGetKeyStringResponse() {
    return {
        keyString: ""
    };
}
exports.GetKeyStringResponse = {
    typeUrl: "/google.api.apikeys.v2.GetKeyStringResponse",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.keyString !== "") {
            writer.uint32(10).string(message.keyString);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseGetKeyStringResponse();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.keyString = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseGetKeyStringResponse();
        message.keyString = object.keyString ?? "";
        return message;
    },
    fromAmino(object) {
        const message = createBaseGetKeyStringResponse();
        if (object.key_string !== undefined && object.key_string !== null) {
            message.keyString = object.key_string;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.key_string = message.keyString === "" ? undefined : message.keyString;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.GetKeyStringResponse.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.GetKeyStringResponse.decode(message.value);
    },
    toProto(message) {
        return exports.GetKeyStringResponse.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.apikeys.v2.GetKeyStringResponse",
            value: exports.GetKeyStringResponse.encode(message).finish()
        };
    }
};
function createBaseUpdateKeyRequest() {
    return {
        key: undefined,
        updateMask: undefined
    };
}
exports.UpdateKeyRequest = {
    typeUrl: "/google.api.apikeys.v2.UpdateKeyRequest",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.key !== undefined) {
            resources_1.Key.encode(message.key, writer.uint32(10).fork()).ldelim();
        }
        if (message.updateMask !== undefined) {
            field_mask_1.FieldMask.encode(message.updateMask, writer.uint32(18).fork()).ldelim();
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseUpdateKeyRequest();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.key = resources_1.Key.decode(reader, reader.uint32());
                    break;
                case 2:
                    message.updateMask = field_mask_1.FieldMask.decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseUpdateKeyRequest();
        message.key = object.key !== undefined && object.key !== null ? resources_1.Key.fromPartial(object.key) : undefined;
        message.updateMask = object.updateMask !== undefined && object.updateMask !== null ? field_mask_1.FieldMask.fromPartial(object.updateMask) : undefined;
        return message;
    },
    fromAmino(object) {
        const message = createBaseUpdateKeyRequest();
        if (object.key !== undefined && object.key !== null) {
            message.key = resources_1.Key.fromAmino(object.key);
        }
        if (object.update_mask !== undefined && object.update_mask !== null) {
            message.updateMask = field_mask_1.FieldMask.fromAmino(object.update_mask);
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.key = message.key ? resources_1.Key.toAmino(message.key) : undefined;
        obj.update_mask = message.updateMask ? field_mask_1.FieldMask.toAmino(message.updateMask) : undefined;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.UpdateKeyRequest.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.UpdateKeyRequest.decode(message.value);
    },
    toProto(message) {
        return exports.UpdateKeyRequest.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.apikeys.v2.UpdateKeyRequest",
            value: exports.UpdateKeyRequest.encode(message).finish()
        };
    }
};
function createBaseDeleteKeyRequest() {
    return {
        name: "",
        etag: ""
    };
}
exports.DeleteKeyRequest = {
    typeUrl: "/google.api.apikeys.v2.DeleteKeyRequest",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.name !== "") {
            writer.uint32(10).string(message.name);
        }
        if (message.etag !== "") {
            writer.uint32(18).string(message.etag);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseDeleteKeyRequest();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.name = reader.string();
                    break;
                case 2:
                    message.etag = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseDeleteKeyRequest();
        message.name = object.name ?? "";
        message.etag = object.etag ?? "";
        return message;
    },
    fromAmino(object) {
        const message = createBaseDeleteKeyRequest();
        if (object.name !== undefined && object.name !== null) {
            message.name = object.name;
        }
        if (object.etag !== undefined && object.etag !== null) {
            message.etag = object.etag;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.name = message.name === "" ? undefined : message.name;
        obj.etag = message.etag === "" ? undefined : message.etag;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.DeleteKeyRequest.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.DeleteKeyRequest.decode(message.value);
    },
    toProto(message) {
        return exports.DeleteKeyRequest.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.apikeys.v2.DeleteKeyRequest",
            value: exports.DeleteKeyRequest.encode(message).finish()
        };
    }
};
function createBaseUndeleteKeyRequest() {
    return {
        name: ""
    };
}
exports.UndeleteKeyRequest = {
    typeUrl: "/google.api.apikeys.v2.UndeleteKeyRequest",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.name !== "") {
            writer.uint32(10).string(message.name);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseUndeleteKeyRequest();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.name = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseUndeleteKeyRequest();
        message.name = object.name ?? "";
        return message;
    },
    fromAmino(object) {
        const message = createBaseUndeleteKeyRequest();
        if (object.name !== undefined && object.name !== null) {
            message.name = object.name;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.name = message.name === "" ? undefined : message.name;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.UndeleteKeyRequest.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.UndeleteKeyRequest.decode(message.value);
    },
    toProto(message) {
        return exports.UndeleteKeyRequest.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.apikeys.v2.UndeleteKeyRequest",
            value: exports.UndeleteKeyRequest.encode(message).finish()
        };
    }
};
function createBaseLookupKeyRequest() {
    return {
        keyString: ""
    };
}
exports.LookupKeyRequest = {
    typeUrl: "/google.api.apikeys.v2.LookupKeyRequest",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.keyString !== "") {
            writer.uint32(10).string(message.keyString);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseLookupKeyRequest();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.keyString = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseLookupKeyRequest();
        message.keyString = object.keyString ?? "";
        return message;
    },
    fromAmino(object) {
        const message = createBaseLookupKeyRequest();
        if (object.key_string !== undefined && object.key_string !== null) {
            message.keyString = object.key_string;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.key_string = message.keyString === "" ? undefined : message.keyString;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.LookupKeyRequest.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.LookupKeyRequest.decode(message.value);
    },
    toProto(message) {
        return exports.LookupKeyRequest.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.apikeys.v2.LookupKeyRequest",
            value: exports.LookupKeyRequest.encode(message).finish()
        };
    }
};
function createBaseLookupKeyResponse() {
    return {
        parent: "",
        name: ""
    };
}
exports.LookupKeyResponse = {
    typeUrl: "/google.api.apikeys.v2.LookupKeyResponse",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.parent !== "") {
            writer.uint32(10).string(message.parent);
        }
        if (message.name !== "") {
            writer.uint32(18).string(message.name);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseLookupKeyResponse();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.parent = reader.string();
                    break;
                case 2:
                    message.name = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseLookupKeyResponse();
        message.parent = object.parent ?? "";
        message.name = object.name ?? "";
        return message;
    },
    fromAmino(object) {
        const message = createBaseLookupKeyResponse();
        if (object.parent !== undefined && object.parent !== null) {
            message.parent = object.parent;
        }
        if (object.name !== undefined && object.name !== null) {
            message.name = object.name;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.parent = message.parent === "" ? undefined : message.parent;
        obj.name = message.name === "" ? undefined : message.name;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.LookupKeyResponse.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.LookupKeyResponse.decode(message.value);
    },
    toProto(message) {
        return exports.LookupKeyResponse.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.apikeys.v2.LookupKeyResponse",
            value: exports.LookupKeyResponse.encode(message).finish()
        };
    }
};
