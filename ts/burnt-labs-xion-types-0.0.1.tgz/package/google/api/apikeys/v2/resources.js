"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ApiTarget = exports.IosKeyRestrictions = exports.AndroidApplication = exports.AndroidKeyRestrictions = exports.ServerKeyRestrictions = exports.BrowserKeyRestrictions = exports.Restrictions = exports.Key = exports.Key_AnnotationsEntry = void 0;
//@ts-nocheck
const timestamp_1 = require("../../../protobuf/timestamp");
const binary_1 = require("../../../../binary");
const helpers_1 = require("../../../../helpers");
function createBaseKey_AnnotationsEntry() {
    return {
        key: "",
        value: ""
    };
}
exports.Key_AnnotationsEntry = {
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.key !== "") {
            writer.uint32(10).string(message.key);
        }
        if (message.value !== "") {
            writer.uint32(18).string(message.value);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseKey_AnnotationsEntry();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.key = reader.string();
                    break;
                case 2:
                    message.value = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseKey_AnnotationsEntry();
        message.key = object.key ?? "";
        message.value = object.value ?? "";
        return message;
    },
    fromAmino(object) {
        const message = createBaseKey_AnnotationsEntry();
        if (object.key !== undefined && object.key !== null) {
            message.key = object.key;
        }
        if (object.value !== undefined && object.value !== null) {
            message.value = object.value;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.key = message.key === "" ? undefined : message.key;
        obj.value = message.value === "" ? undefined : message.value;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.Key_AnnotationsEntry.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.Key_AnnotationsEntry.decode(message.value);
    },
    toProto(message) {
        return exports.Key_AnnotationsEntry.encode(message).finish();
    }
};
function createBaseKey() {
    return {
        name: "",
        uid: "",
        displayName: "",
        keyString: "",
        createTime: undefined,
        updateTime: undefined,
        deleteTime: undefined,
        annotations: {},
        restrictions: undefined,
        etag: ""
    };
}
exports.Key = {
    typeUrl: "/google.api.apikeys.v2.Key",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.name !== "") {
            writer.uint32(10).string(message.name);
        }
        if (message.uid !== "") {
            writer.uint32(42).string(message.uid);
        }
        if (message.displayName !== "") {
            writer.uint32(18).string(message.displayName);
        }
        if (message.keyString !== "") {
            writer.uint32(26).string(message.keyString);
        }
        if (message.createTime !== undefined) {
            timestamp_1.Timestamp.encode((0, helpers_1.toTimestamp)(message.createTime), writer.uint32(34).fork()).ldelim();
        }
        if (message.updateTime !== undefined) {
            timestamp_1.Timestamp.encode((0, helpers_1.toTimestamp)(message.updateTime), writer.uint32(50).fork()).ldelim();
        }
        if (message.deleteTime !== undefined) {
            timestamp_1.Timestamp.encode((0, helpers_1.toTimestamp)(message.deleteTime), writer.uint32(58).fork()).ldelim();
        }
        Object.entries(message.annotations).forEach(([key, value]) => {
            exports.Key_AnnotationsEntry.encode({
                key: key,
                value
            }, writer.uint32(66).fork()).ldelim();
        });
        if (message.restrictions !== undefined) {
            exports.Restrictions.encode(message.restrictions, writer.uint32(74).fork()).ldelim();
        }
        if (message.etag !== "") {
            writer.uint32(90).string(message.etag);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseKey();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.name = reader.string();
                    break;
                case 5:
                    message.uid = reader.string();
                    break;
                case 2:
                    message.displayName = reader.string();
                    break;
                case 3:
                    message.keyString = reader.string();
                    break;
                case 4:
                    message.createTime = (0, helpers_1.fromTimestamp)(timestamp_1.Timestamp.decode(reader, reader.uint32()));
                    break;
                case 6:
                    message.updateTime = (0, helpers_1.fromTimestamp)(timestamp_1.Timestamp.decode(reader, reader.uint32()));
                    break;
                case 7:
                    message.deleteTime = (0, helpers_1.fromTimestamp)(timestamp_1.Timestamp.decode(reader, reader.uint32()));
                    break;
                case 8:
                    const entry8 = exports.Key_AnnotationsEntry.decode(reader, reader.uint32());
                    if (entry8.value !== undefined) {
                        message.annotations[entry8.key] = entry8.value;
                    }
                    break;
                case 9:
                    message.restrictions = exports.Restrictions.decode(reader, reader.uint32());
                    break;
                case 11:
                    message.etag = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseKey();
        message.name = object.name ?? "";
        message.uid = object.uid ?? "";
        message.displayName = object.displayName ?? "";
        message.keyString = object.keyString ?? "";
        message.createTime = object.createTime ?? undefined;
        message.updateTime = object.updateTime ?? undefined;
        message.deleteTime = object.deleteTime ?? undefined;
        message.annotations = Object.entries(object.annotations ?? {}).reduce((acc, [key, value]) => {
            if (value !== undefined) {
                acc[key] = String(value);
            }
            return acc;
        }, {});
        message.restrictions = object.restrictions !== undefined && object.restrictions !== null ? exports.Restrictions.fromPartial(object.restrictions) : undefined;
        message.etag = object.etag ?? "";
        return message;
    },
    fromAmino(object) {
        const message = createBaseKey();
        if (object.name !== undefined && object.name !== null) {
            message.name = object.name;
        }
        if (object.uid !== undefined && object.uid !== null) {
            message.uid = object.uid;
        }
        if (object.display_name !== undefined && object.display_name !== null) {
            message.displayName = object.display_name;
        }
        if (object.key_string !== undefined && object.key_string !== null) {
            message.keyString = object.key_string;
        }
        if (object.create_time !== undefined && object.create_time !== null) {
            message.createTime = (0, helpers_1.fromTimestamp)(timestamp_1.Timestamp.fromAmino(object.create_time));
        }
        if (object.update_time !== undefined && object.update_time !== null) {
            message.updateTime = (0, helpers_1.fromTimestamp)(timestamp_1.Timestamp.fromAmino(object.update_time));
        }
        if (object.delete_time !== undefined && object.delete_time !== null) {
            message.deleteTime = (0, helpers_1.fromTimestamp)(timestamp_1.Timestamp.fromAmino(object.delete_time));
        }
        message.annotations = Object.entries(object.annotations ?? {}).reduce((acc, [key, value]) => {
            if (value !== undefined) {
                acc[key] = String(value);
            }
            return acc;
        }, {});
        if (object.restrictions !== undefined && object.restrictions !== null) {
            message.restrictions = exports.Restrictions.fromAmino(object.restrictions);
        }
        if (object.etag !== undefined && object.etag !== null) {
            message.etag = object.etag;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.name = message.name === "" ? undefined : message.name;
        obj.uid = message.uid === "" ? undefined : message.uid;
        obj.display_name = message.displayName === "" ? undefined : message.displayName;
        obj.key_string = message.keyString === "" ? undefined : message.keyString;
        obj.create_time = message.createTime ? timestamp_1.Timestamp.toAmino((0, helpers_1.toTimestamp)(message.createTime)) : undefined;
        obj.update_time = message.updateTime ? timestamp_1.Timestamp.toAmino((0, helpers_1.toTimestamp)(message.updateTime)) : undefined;
        obj.delete_time = message.deleteTime ? timestamp_1.Timestamp.toAmino((0, helpers_1.toTimestamp)(message.deleteTime)) : undefined;
        obj.annotations = {};
        if (message.annotations) {
            Object.entries(message.annotations).forEach(([k, v]) => {
                obj.annotations[k] = v;
            });
        }
        obj.restrictions = message.restrictions ? exports.Restrictions.toAmino(message.restrictions) : undefined;
        obj.etag = message.etag === "" ? undefined : message.etag;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.Key.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.Key.decode(message.value);
    },
    toProto(message) {
        return exports.Key.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.apikeys.v2.Key",
            value: exports.Key.encode(message).finish()
        };
    }
};
function createBaseRestrictions() {
    return {
        browserKeyRestrictions: undefined,
        serverKeyRestrictions: undefined,
        androidKeyRestrictions: undefined,
        iosKeyRestrictions: undefined,
        apiTargets: []
    };
}
exports.Restrictions = {
    typeUrl: "/google.api.apikeys.v2.Restrictions",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.browserKeyRestrictions !== undefined) {
            exports.BrowserKeyRestrictions.encode(message.browserKeyRestrictions, writer.uint32(10).fork()).ldelim();
        }
        if (message.serverKeyRestrictions !== undefined) {
            exports.ServerKeyRestrictions.encode(message.serverKeyRestrictions, writer.uint32(18).fork()).ldelim();
        }
        if (message.androidKeyRestrictions !== undefined) {
            exports.AndroidKeyRestrictions.encode(message.androidKeyRestrictions, writer.uint32(26).fork()).ldelim();
        }
        if (message.iosKeyRestrictions !== undefined) {
            exports.IosKeyRestrictions.encode(message.iosKeyRestrictions, writer.uint32(34).fork()).ldelim();
        }
        for (const v of message.apiTargets) {
            exports.ApiTarget.encode(v, writer.uint32(42).fork()).ldelim();
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseRestrictions();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.browserKeyRestrictions = exports.BrowserKeyRestrictions.decode(reader, reader.uint32());
                    break;
                case 2:
                    message.serverKeyRestrictions = exports.ServerKeyRestrictions.decode(reader, reader.uint32());
                    break;
                case 3:
                    message.androidKeyRestrictions = exports.AndroidKeyRestrictions.decode(reader, reader.uint32());
                    break;
                case 4:
                    message.iosKeyRestrictions = exports.IosKeyRestrictions.decode(reader, reader.uint32());
                    break;
                case 5:
                    message.apiTargets.push(exports.ApiTarget.decode(reader, reader.uint32()));
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseRestrictions();
        message.browserKeyRestrictions = object.browserKeyRestrictions !== undefined && object.browserKeyRestrictions !== null ? exports.BrowserKeyRestrictions.fromPartial(object.browserKeyRestrictions) : undefined;
        message.serverKeyRestrictions = object.serverKeyRestrictions !== undefined && object.serverKeyRestrictions !== null ? exports.ServerKeyRestrictions.fromPartial(object.serverKeyRestrictions) : undefined;
        message.androidKeyRestrictions = object.androidKeyRestrictions !== undefined && object.androidKeyRestrictions !== null ? exports.AndroidKeyRestrictions.fromPartial(object.androidKeyRestrictions) : undefined;
        message.iosKeyRestrictions = object.iosKeyRestrictions !== undefined && object.iosKeyRestrictions !== null ? exports.IosKeyRestrictions.fromPartial(object.iosKeyRestrictions) : undefined;
        message.apiTargets = object.apiTargets?.map(e => exports.ApiTarget.fromPartial(e)) || [];
        return message;
    },
    fromAmino(object) {
        const message = createBaseRestrictions();
        if (object.browser_key_restrictions !== undefined && object.browser_key_restrictions !== null) {
            message.browserKeyRestrictions = exports.BrowserKeyRestrictions.fromAmino(object.browser_key_restrictions);
        }
        if (object.server_key_restrictions !== undefined && object.server_key_restrictions !== null) {
            message.serverKeyRestrictions = exports.ServerKeyRestrictions.fromAmino(object.server_key_restrictions);
        }
        if (object.android_key_restrictions !== undefined && object.android_key_restrictions !== null) {
            message.androidKeyRestrictions = exports.AndroidKeyRestrictions.fromAmino(object.android_key_restrictions);
        }
        if (object.ios_key_restrictions !== undefined && object.ios_key_restrictions !== null) {
            message.iosKeyRestrictions = exports.IosKeyRestrictions.fromAmino(object.ios_key_restrictions);
        }
        message.apiTargets = object.api_targets?.map(e => exports.ApiTarget.fromAmino(e)) || [];
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.browser_key_restrictions = message.browserKeyRestrictions ? exports.BrowserKeyRestrictions.toAmino(message.browserKeyRestrictions) : undefined;
        obj.server_key_restrictions = message.serverKeyRestrictions ? exports.ServerKeyRestrictions.toAmino(message.serverKeyRestrictions) : undefined;
        obj.android_key_restrictions = message.androidKeyRestrictions ? exports.AndroidKeyRestrictions.toAmino(message.androidKeyRestrictions) : undefined;
        obj.ios_key_restrictions = message.iosKeyRestrictions ? exports.IosKeyRestrictions.toAmino(message.iosKeyRestrictions) : undefined;
        if (message.apiTargets) {
            obj.api_targets = message.apiTargets.map(e => e ? exports.ApiTarget.toAmino(e) : undefined);
        }
        else {
            obj.api_targets = message.apiTargets;
        }
        return obj;
    },
    fromAminoMsg(object) {
        return exports.Restrictions.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.Restrictions.decode(message.value);
    },
    toProto(message) {
        return exports.Restrictions.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.apikeys.v2.Restrictions",
            value: exports.Restrictions.encode(message).finish()
        };
    }
};
function createBaseBrowserKeyRestrictions() {
    return {
        allowedReferrers: []
    };
}
exports.BrowserKeyRestrictions = {
    typeUrl: "/google.api.apikeys.v2.BrowserKeyRestrictions",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        for (const v of message.allowedReferrers) {
            writer.uint32(10).string(v);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseBrowserKeyRestrictions();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.allowedReferrers.push(reader.string());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseBrowserKeyRestrictions();
        message.allowedReferrers = object.allowedReferrers?.map(e => e) || [];
        return message;
    },
    fromAmino(object) {
        const message = createBaseBrowserKeyRestrictions();
        message.allowedReferrers = object.allowed_referrers?.map(e => e) || [];
        return message;
    },
    toAmino(message) {
        const obj = {};
        if (message.allowedReferrers) {
            obj.allowed_referrers = message.allowedReferrers.map(e => e);
        }
        else {
            obj.allowed_referrers = message.allowedReferrers;
        }
        return obj;
    },
    fromAminoMsg(object) {
        return exports.BrowserKeyRestrictions.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.BrowserKeyRestrictions.decode(message.value);
    },
    toProto(message) {
        return exports.BrowserKeyRestrictions.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.apikeys.v2.BrowserKeyRestrictions",
            value: exports.BrowserKeyRestrictions.encode(message).finish()
        };
    }
};
function createBaseServerKeyRestrictions() {
    return {
        allowedIps: []
    };
}
exports.ServerKeyRestrictions = {
    typeUrl: "/google.api.apikeys.v2.ServerKeyRestrictions",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        for (const v of message.allowedIps) {
            writer.uint32(10).string(v);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseServerKeyRestrictions();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.allowedIps.push(reader.string());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseServerKeyRestrictions();
        message.allowedIps = object.allowedIps?.map(e => e) || [];
        return message;
    },
    fromAmino(object) {
        const message = createBaseServerKeyRestrictions();
        message.allowedIps = object.allowed_ips?.map(e => e) || [];
        return message;
    },
    toAmino(message) {
        const obj = {};
        if (message.allowedIps) {
            obj.allowed_ips = message.allowedIps.map(e => e);
        }
        else {
            obj.allowed_ips = message.allowedIps;
        }
        return obj;
    },
    fromAminoMsg(object) {
        return exports.ServerKeyRestrictions.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.ServerKeyRestrictions.decode(message.value);
    },
    toProto(message) {
        return exports.ServerKeyRestrictions.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.apikeys.v2.ServerKeyRestrictions",
            value: exports.ServerKeyRestrictions.encode(message).finish()
        };
    }
};
function createBaseAndroidKeyRestrictions() {
    return {
        allowedApplications: []
    };
}
exports.AndroidKeyRestrictions = {
    typeUrl: "/google.api.apikeys.v2.AndroidKeyRestrictions",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        for (const v of message.allowedApplications) {
            exports.AndroidApplication.encode(v, writer.uint32(10).fork()).ldelim();
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseAndroidKeyRestrictions();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.allowedApplications.push(exports.AndroidApplication.decode(reader, reader.uint32()));
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseAndroidKeyRestrictions();
        message.allowedApplications = object.allowedApplications?.map(e => exports.AndroidApplication.fromPartial(e)) || [];
        return message;
    },
    fromAmino(object) {
        const message = createBaseAndroidKeyRestrictions();
        message.allowedApplications = object.allowed_applications?.map(e => exports.AndroidApplication.fromAmino(e)) || [];
        return message;
    },
    toAmino(message) {
        const obj = {};
        if (message.allowedApplications) {
            obj.allowed_applications = message.allowedApplications.map(e => e ? exports.AndroidApplication.toAmino(e) : undefined);
        }
        else {
            obj.allowed_applications = message.allowedApplications;
        }
        return obj;
    },
    fromAminoMsg(object) {
        return exports.AndroidKeyRestrictions.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.AndroidKeyRestrictions.decode(message.value);
    },
    toProto(message) {
        return exports.AndroidKeyRestrictions.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.apikeys.v2.AndroidKeyRestrictions",
            value: exports.AndroidKeyRestrictions.encode(message).finish()
        };
    }
};
function createBaseAndroidApplication() {
    return {
        sha1Fingerprint: "",
        packageName: ""
    };
}
exports.AndroidApplication = {
    typeUrl: "/google.api.apikeys.v2.AndroidApplication",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.sha1Fingerprint !== "") {
            writer.uint32(10).string(message.sha1Fingerprint);
        }
        if (message.packageName !== "") {
            writer.uint32(18).string(message.packageName);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseAndroidApplication();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.sha1Fingerprint = reader.string();
                    break;
                case 2:
                    message.packageName = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseAndroidApplication();
        message.sha1Fingerprint = object.sha1Fingerprint ?? "";
        message.packageName = object.packageName ?? "";
        return message;
    },
    fromAmino(object) {
        const message = createBaseAndroidApplication();
        if (object.sha1_fingerprint !== undefined && object.sha1_fingerprint !== null) {
            message.sha1Fingerprint = object.sha1_fingerprint;
        }
        if (object.package_name !== undefined && object.package_name !== null) {
            message.packageName = object.package_name;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.sha1_fingerprint = message.sha1Fingerprint === "" ? undefined : message.sha1Fingerprint;
        obj.package_name = message.packageName === "" ? undefined : message.packageName;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.AndroidApplication.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.AndroidApplication.decode(message.value);
    },
    toProto(message) {
        return exports.AndroidApplication.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.apikeys.v2.AndroidApplication",
            value: exports.AndroidApplication.encode(message).finish()
        };
    }
};
function createBaseIosKeyRestrictions() {
    return {
        allowedBundleIds: []
    };
}
exports.IosKeyRestrictions = {
    typeUrl: "/google.api.apikeys.v2.IosKeyRestrictions",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        for (const v of message.allowedBundleIds) {
            writer.uint32(10).string(v);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseIosKeyRestrictions();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.allowedBundleIds.push(reader.string());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseIosKeyRestrictions();
        message.allowedBundleIds = object.allowedBundleIds?.map(e => e) || [];
        return message;
    },
    fromAmino(object) {
        const message = createBaseIosKeyRestrictions();
        message.allowedBundleIds = object.allowed_bundle_ids?.map(e => e) || [];
        return message;
    },
    toAmino(message) {
        const obj = {};
        if (message.allowedBundleIds) {
            obj.allowed_bundle_ids = message.allowedBundleIds.map(e => e);
        }
        else {
            obj.allowed_bundle_ids = message.allowedBundleIds;
        }
        return obj;
    },
    fromAminoMsg(object) {
        return exports.IosKeyRestrictions.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.IosKeyRestrictions.decode(message.value);
    },
    toProto(message) {
        return exports.IosKeyRestrictions.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.apikeys.v2.IosKeyRestrictions",
            value: exports.IosKeyRestrictions.encode(message).finish()
        };
    }
};
function createBaseApiTarget() {
    return {
        service: "",
        methods: []
    };
}
exports.ApiTarget = {
    typeUrl: "/google.api.apikeys.v2.ApiTarget",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.service !== "") {
            writer.uint32(10).string(message.service);
        }
        for (const v of message.methods) {
            writer.uint32(18).string(v);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseApiTarget();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.service = reader.string();
                    break;
                case 2:
                    message.methods.push(reader.string());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseApiTarget();
        message.service = object.service ?? "";
        message.methods = object.methods?.map(e => e) || [];
        return message;
    },
    fromAmino(object) {
        const message = createBaseApiTarget();
        if (object.service !== undefined && object.service !== null) {
            message.service = object.service;
        }
        message.methods = object.methods?.map(e => e) || [];
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.service = message.service === "" ? undefined : message.service;
        if (message.methods) {
            obj.methods = message.methods.map(e => e);
        }
        else {
            obj.methods = message.methods;
        }
        return obj;
    },
    fromAminoMsg(object) {
        return exports.ApiTarget.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.ApiTarget.decode(message.value);
    },
    toProto(message) {
        return exports.ApiTarget.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.apikeys.v2.ApiTarget",
            value: exports.ApiTarget.encode(message).finish()
        };
    }
};
