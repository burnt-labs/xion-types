"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Service = void 0;
//@ts-nocheck
const api_1 = require("../protobuf/api");
const type_1 = require("../protobuf/type");
const documentation_1 = require("./documentation");
const backend_1 = require("./backend");
const http_1 = require("./http");
const quota_1 = require("./quota");
const auth_1 = require("./auth");
const context_1 = require("./context");
const usage_1 = require("./usage");
const endpoint_1 = require("./endpoint");
const control_1 = require("./control");
const log_1 = require("./log");
const metric_1 = require("./metric");
const monitored_resource_1 = require("./monitored_resource");
const billing_1 = require("./billing");
const logging_1 = require("./logging");
const monitoring_1 = require("./monitoring");
const system_parameter_1 = require("./system_parameter");
const source_info_1 = require("./source_info");
const client_1 = require("./client");
const wrappers_1 = require("../protobuf/wrappers");
const binary_1 = require("../../binary");
function createBaseService() {
    return {
        name: "",
        title: "",
        producerProjectId: "",
        id: "",
        apis: [],
        types: [],
        enums: [],
        documentation: undefined,
        backend: undefined,
        http: undefined,
        quota: undefined,
        authentication: undefined,
        context: undefined,
        usage: undefined,
        endpoints: [],
        control: undefined,
        logs: [],
        metrics: [],
        monitoredResources: [],
        billing: undefined,
        logging: undefined,
        monitoring: undefined,
        systemParameters: undefined,
        sourceInfo: undefined,
        publishing: undefined,
        configVersion: undefined
    };
}
exports.Service = {
    typeUrl: "/google.api.Service",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.name !== "") {
            writer.uint32(10).string(message.name);
        }
        if (message.title !== "") {
            writer.uint32(18).string(message.title);
        }
        if (message.producerProjectId !== "") {
            writer.uint32(178).string(message.producerProjectId);
        }
        if (message.id !== "") {
            writer.uint32(266).string(message.id);
        }
        for (const v of message.apis) {
            api_1.Api.encode(v, writer.uint32(26).fork()).ldelim();
        }
        for (const v of message.types) {
            type_1.Type.encode(v, writer.uint32(34).fork()).ldelim();
        }
        for (const v of message.enums) {
            type_1.Enum.encode(v, writer.uint32(42).fork()).ldelim();
        }
        if (message.documentation !== undefined) {
            documentation_1.Documentation.encode(message.documentation, writer.uint32(50).fork()).ldelim();
        }
        if (message.backend !== undefined) {
            backend_1.Backend.encode(message.backend, writer.uint32(66).fork()).ldelim();
        }
        if (message.http !== undefined) {
            http_1.Http.encode(message.http, writer.uint32(74).fork()).ldelim();
        }
        if (message.quota !== undefined) {
            quota_1.Quota.encode(message.quota, writer.uint32(82).fork()).ldelim();
        }
        if (message.authentication !== undefined) {
            auth_1.Authentication.encode(message.authentication, writer.uint32(90).fork()).ldelim();
        }
        if (message.context !== undefined) {
            context_1.Context.encode(message.context, writer.uint32(98).fork()).ldelim();
        }
        if (message.usage !== undefined) {
            usage_1.Usage.encode(message.usage, writer.uint32(122).fork()).ldelim();
        }
        for (const v of message.endpoints) {
            endpoint_1.Endpoint.encode(v, writer.uint32(146).fork()).ldelim();
        }
        if (message.control !== undefined) {
            control_1.Control.encode(message.control, writer.uint32(170).fork()).ldelim();
        }
        for (const v of message.logs) {
            log_1.LogDescriptor.encode(v, writer.uint32(186).fork()).ldelim();
        }
        for (const v of message.metrics) {
            metric_1.MetricDescriptor.encode(v, writer.uint32(194).fork()).ldelim();
        }
        for (const v of message.monitoredResources) {
            monitored_resource_1.MonitoredResourceDescriptor.encode(v, writer.uint32(202).fork()).ldelim();
        }
        if (message.billing !== undefined) {
            billing_1.Billing.encode(message.billing, writer.uint32(210).fork()).ldelim();
        }
        if (message.logging !== undefined) {
            logging_1.Logging.encode(message.logging, writer.uint32(218).fork()).ldelim();
        }
        if (message.monitoring !== undefined) {
            monitoring_1.Monitoring.encode(message.monitoring, writer.uint32(226).fork()).ldelim();
        }
        if (message.systemParameters !== undefined) {
            system_parameter_1.SystemParameters.encode(message.systemParameters, writer.uint32(234).fork()).ldelim();
        }
        if (message.sourceInfo !== undefined) {
            source_info_1.SourceInfo.encode(message.sourceInfo, writer.uint32(298).fork()).ldelim();
        }
        if (message.publishing !== undefined) {
            client_1.Publishing.encode(message.publishing, writer.uint32(362).fork()).ldelim();
        }
        if (message.configVersion !== undefined) {
            wrappers_1.UInt32Value.encode(message.configVersion, writer.uint32(162).fork()).ldelim();
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseService();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.name = reader.string();
                    break;
                case 2:
                    message.title = reader.string();
                    break;
                case 22:
                    message.producerProjectId = reader.string();
                    break;
                case 33:
                    message.id = reader.string();
                    break;
                case 3:
                    message.apis.push(api_1.Api.decode(reader, reader.uint32()));
                    break;
                case 4:
                    message.types.push(type_1.Type.decode(reader, reader.uint32()));
                    break;
                case 5:
                    message.enums.push(type_1.Enum.decode(reader, reader.uint32()));
                    break;
                case 6:
                    message.documentation = documentation_1.Documentation.decode(reader, reader.uint32());
                    break;
                case 8:
                    message.backend = backend_1.Backend.decode(reader, reader.uint32());
                    break;
                case 9:
                    message.http = http_1.Http.decode(reader, reader.uint32());
                    break;
                case 10:
                    message.quota = quota_1.Quota.decode(reader, reader.uint32());
                    break;
                case 11:
                    message.authentication = auth_1.Authentication.decode(reader, reader.uint32());
                    break;
                case 12:
                    message.context = context_1.Context.decode(reader, reader.uint32());
                    break;
                case 15:
                    message.usage = usage_1.Usage.decode(reader, reader.uint32());
                    break;
                case 18:
                    message.endpoints.push(endpoint_1.Endpoint.decode(reader, reader.uint32()));
                    break;
                case 21:
                    message.control = control_1.Control.decode(reader, reader.uint32());
                    break;
                case 23:
                    message.logs.push(log_1.LogDescriptor.decode(reader, reader.uint32()));
                    break;
                case 24:
                    message.metrics.push(metric_1.MetricDescriptor.decode(reader, reader.uint32()));
                    break;
                case 25:
                    message.monitoredResources.push(monitored_resource_1.MonitoredResourceDescriptor.decode(reader, reader.uint32()));
                    break;
                case 26:
                    message.billing = billing_1.Billing.decode(reader, reader.uint32());
                    break;
                case 27:
                    message.logging = logging_1.Logging.decode(reader, reader.uint32());
                    break;
                case 28:
                    message.monitoring = monitoring_1.Monitoring.decode(reader, reader.uint32());
                    break;
                case 29:
                    message.systemParameters = system_parameter_1.SystemParameters.decode(reader, reader.uint32());
                    break;
                case 37:
                    message.sourceInfo = source_info_1.SourceInfo.decode(reader, reader.uint32());
                    break;
                case 45:
                    message.publishing = client_1.Publishing.decode(reader, reader.uint32());
                    break;
                case 20:
                    message.configVersion = wrappers_1.UInt32Value.decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseService();
        message.name = object.name ?? "";
        message.title = object.title ?? "";
        message.producerProjectId = object.producerProjectId ?? "";
        message.id = object.id ?? "";
        message.apis = object.apis?.map(e => api_1.Api.fromPartial(e)) || [];
        message.types = object.types?.map(e => type_1.Type.fromPartial(e)) || [];
        message.enums = object.enums?.map(e => type_1.Enum.fromPartial(e)) || [];
        message.documentation = object.documentation !== undefined && object.documentation !== null ? documentation_1.Documentation.fromPartial(object.documentation) : undefined;
        message.backend = object.backend !== undefined && object.backend !== null ? backend_1.Backend.fromPartial(object.backend) : undefined;
        message.http = object.http !== undefined && object.http !== null ? http_1.Http.fromPartial(object.http) : undefined;
        message.quota = object.quota !== undefined && object.quota !== null ? quota_1.Quota.fromPartial(object.quota) : undefined;
        message.authentication = object.authentication !== undefined && object.authentication !== null ? auth_1.Authentication.fromPartial(object.authentication) : undefined;
        message.context = object.context !== undefined && object.context !== null ? context_1.Context.fromPartial(object.context) : undefined;
        message.usage = object.usage !== undefined && object.usage !== null ? usage_1.Usage.fromPartial(object.usage) : undefined;
        message.endpoints = object.endpoints?.map(e => endpoint_1.Endpoint.fromPartial(e)) || [];
        message.control = object.control !== undefined && object.control !== null ? control_1.Control.fromPartial(object.control) : undefined;
        message.logs = object.logs?.map(e => log_1.LogDescriptor.fromPartial(e)) || [];
        message.metrics = object.metrics?.map(e => metric_1.MetricDescriptor.fromPartial(e)) || [];
        message.monitoredResources = object.monitoredResources?.map(e => monitored_resource_1.MonitoredResourceDescriptor.fromPartial(e)) || [];
        message.billing = object.billing !== undefined && object.billing !== null ? billing_1.Billing.fromPartial(object.billing) : undefined;
        message.logging = object.logging !== undefined && object.logging !== null ? logging_1.Logging.fromPartial(object.logging) : undefined;
        message.monitoring = object.monitoring !== undefined && object.monitoring !== null ? monitoring_1.Monitoring.fromPartial(object.monitoring) : undefined;
        message.systemParameters = object.systemParameters !== undefined && object.systemParameters !== null ? system_parameter_1.SystemParameters.fromPartial(object.systemParameters) : undefined;
        message.sourceInfo = object.sourceInfo !== undefined && object.sourceInfo !== null ? source_info_1.SourceInfo.fromPartial(object.sourceInfo) : undefined;
        message.publishing = object.publishing !== undefined && object.publishing !== null ? client_1.Publishing.fromPartial(object.publishing) : undefined;
        message.configVersion = object.configVersion !== undefined && object.configVersion !== null ? wrappers_1.UInt32Value.fromPartial(object.configVersion) : undefined;
        return message;
    },
    fromAmino(object) {
        const message = createBaseService();
        if (object.name !== undefined && object.name !== null) {
            message.name = object.name;
        }
        if (object.title !== undefined && object.title !== null) {
            message.title = object.title;
        }
        if (object.producer_project_id !== undefined && object.producer_project_id !== null) {
            message.producerProjectId = object.producer_project_id;
        }
        if (object.id !== undefined && object.id !== null) {
            message.id = object.id;
        }
        message.apis = object.apis?.map(e => api_1.Api.fromAmino(e)) || [];
        message.types = object.types?.map(e => type_1.Type.fromAmino(e)) || [];
        message.enums = object.enums?.map(e => type_1.Enum.fromAmino(e)) || [];
        if (object.documentation !== undefined && object.documentation !== null) {
            message.documentation = documentation_1.Documentation.fromAmino(object.documentation);
        }
        if (object.backend !== undefined && object.backend !== null) {
            message.backend = backend_1.Backend.fromAmino(object.backend);
        }
        if (object.http !== undefined && object.http !== null) {
            message.http = http_1.Http.fromAmino(object.http);
        }
        if (object.quota !== undefined && object.quota !== null) {
            message.quota = quota_1.Quota.fromAmino(object.quota);
        }
        if (object.authentication !== undefined && object.authentication !== null) {
            message.authentication = auth_1.Authentication.fromAmino(object.authentication);
        }
        if (object.context !== undefined && object.context !== null) {
            message.context = context_1.Context.fromAmino(object.context);
        }
        if (object.usage !== undefined && object.usage !== null) {
            message.usage = usage_1.Usage.fromAmino(object.usage);
        }
        message.endpoints = object.endpoints?.map(e => endpoint_1.Endpoint.fromAmino(e)) || [];
        if (object.control !== undefined && object.control !== null) {
            message.control = control_1.Control.fromAmino(object.control);
        }
        message.logs = object.logs?.map(e => log_1.LogDescriptor.fromAmino(e)) || [];
        message.metrics = object.metrics?.map(e => metric_1.MetricDescriptor.fromAmino(e)) || [];
        message.monitoredResources = object.monitored_resources?.map(e => monitored_resource_1.MonitoredResourceDescriptor.fromAmino(e)) || [];
        if (object.billing !== undefined && object.billing !== null) {
            message.billing = billing_1.Billing.fromAmino(object.billing);
        }
        if (object.logging !== undefined && object.logging !== null) {
            message.logging = logging_1.Logging.fromAmino(object.logging);
        }
        if (object.monitoring !== undefined && object.monitoring !== null) {
            message.monitoring = monitoring_1.Monitoring.fromAmino(object.monitoring);
        }
        if (object.system_parameters !== undefined && object.system_parameters !== null) {
            message.systemParameters = system_parameter_1.SystemParameters.fromAmino(object.system_parameters);
        }
        if (object.source_info !== undefined && object.source_info !== null) {
            message.sourceInfo = source_info_1.SourceInfo.fromAmino(object.source_info);
        }
        if (object.publishing !== undefined && object.publishing !== null) {
            message.publishing = client_1.Publishing.fromAmino(object.publishing);
        }
        if (object.config_version !== undefined && object.config_version !== null) {
            message.configVersion = wrappers_1.UInt32Value.fromAmino(object.config_version);
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.name = message.name === "" ? undefined : message.name;
        obj.title = message.title === "" ? undefined : message.title;
        obj.producer_project_id = message.producerProjectId === "" ? undefined : message.producerProjectId;
        obj.id = message.id === "" ? undefined : message.id;
        if (message.apis) {
            obj.apis = message.apis.map(e => e ? api_1.Api.toAmino(e) : undefined);
        }
        else {
            obj.apis = message.apis;
        }
        if (message.types) {
            obj.types = message.types.map(e => e ? type_1.Type.toAmino(e) : undefined);
        }
        else {
            obj.types = message.types;
        }
        if (message.enums) {
            obj.enums = message.enums.map(e => e ? type_1.Enum.toAmino(e) : undefined);
        }
        else {
            obj.enums = message.enums;
        }
        obj.documentation = message.documentation ? documentation_1.Documentation.toAmino(message.documentation) : undefined;
        obj.backend = message.backend ? backend_1.Backend.toAmino(message.backend) : undefined;
        obj.http = message.http ? http_1.Http.toAmino(message.http) : undefined;
        obj.quota = message.quota ? quota_1.Quota.toAmino(message.quota) : undefined;
        obj.authentication = message.authentication ? auth_1.Authentication.toAmino(message.authentication) : undefined;
        obj.context = message.context ? context_1.Context.toAmino(message.context) : undefined;
        obj.usage = message.usage ? usage_1.Usage.toAmino(message.usage) : undefined;
        if (message.endpoints) {
            obj.endpoints = message.endpoints.map(e => e ? endpoint_1.Endpoint.toAmino(e) : undefined);
        }
        else {
            obj.endpoints = message.endpoints;
        }
        obj.control = message.control ? control_1.Control.toAmino(message.control) : undefined;
        if (message.logs) {
            obj.logs = message.logs.map(e => e ? log_1.LogDescriptor.toAmino(e) : undefined);
        }
        else {
            obj.logs = message.logs;
        }
        if (message.metrics) {
            obj.metrics = message.metrics.map(e => e ? metric_1.MetricDescriptor.toAmino(e) : undefined);
        }
        else {
            obj.metrics = message.metrics;
        }
        if (message.monitoredResources) {
            obj.monitored_resources = message.monitoredResources.map(e => e ? monitored_resource_1.MonitoredResourceDescriptor.toAmino(e) : undefined);
        }
        else {
            obj.monitored_resources = message.monitoredResources;
        }
        obj.billing = message.billing ? billing_1.Billing.toAmino(message.billing) : undefined;
        obj.logging = message.logging ? logging_1.Logging.toAmino(message.logging) : undefined;
        obj.monitoring = message.monitoring ? monitoring_1.Monitoring.toAmino(message.monitoring) : undefined;
        obj.system_parameters = message.systemParameters ? system_parameter_1.SystemParameters.toAmino(message.systemParameters) : undefined;
        obj.source_info = message.sourceInfo ? source_info_1.SourceInfo.toAmino(message.sourceInfo) : undefined;
        obj.publishing = message.publishing ? client_1.Publishing.toAmino(message.publishing) : undefined;
        obj.config_version = message.configVersion ? wrappers_1.UInt32Value.toAmino(message.configVersion) : undefined;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.Service.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.Service.decode(message.value);
    },
    toProto(message) {
        return exports.Service.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.Service",
            value: exports.Service.encode(message).finish()
        };
    }
};
