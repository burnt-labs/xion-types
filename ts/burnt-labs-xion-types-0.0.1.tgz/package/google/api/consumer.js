"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Property = exports.ProjectProperties = exports.Property_PropertyTypeAmino = exports.Property_PropertyTypeSDKType = exports.Property_PropertyType = void 0;
exports.property_PropertyTypeFromJSON = property_PropertyTypeFromJSON;
exports.property_PropertyTypeToJSON = property_PropertyTypeToJSON;
//@ts-nocheck
const binary_1 = require("../../binary");
/** Supported data type of the property values */
var Property_PropertyType;
(function (Property_PropertyType) {
    /** UNSPECIFIED - The type is unspecified, and will result in an error. */
    Property_PropertyType[Property_PropertyType["UNSPECIFIED"] = 0] = "UNSPECIFIED";
    /** INT64 - The type is `int64`. */
    Property_PropertyType[Property_PropertyType["INT64"] = 1] = "INT64";
    /** BOOL - The type is `bool`. */
    Property_PropertyType[Property_PropertyType["BOOL"] = 2] = "BOOL";
    /** STRING - The type is `string`. */
    Property_PropertyType[Property_PropertyType["STRING"] = 3] = "STRING";
    /** DOUBLE - The type is 'double'. */
    Property_PropertyType[Property_PropertyType["DOUBLE"] = 4] = "DOUBLE";
    Property_PropertyType[Property_PropertyType["UNRECOGNIZED"] = -1] = "UNRECOGNIZED";
})(Property_PropertyType || (exports.Property_PropertyType = Property_PropertyType = {}));
exports.Property_PropertyTypeSDKType = Property_PropertyType;
exports.Property_PropertyTypeAmino = Property_PropertyType;
function property_PropertyTypeFromJSON(object) {
    switch (object) {
        case 0:
        case "UNSPECIFIED":
            return Property_PropertyType.UNSPECIFIED;
        case 1:
        case "INT64":
            return Property_PropertyType.INT64;
        case 2:
        case "BOOL":
            return Property_PropertyType.BOOL;
        case 3:
        case "STRING":
            return Property_PropertyType.STRING;
        case 4:
        case "DOUBLE":
            return Property_PropertyType.DOUBLE;
        case -1:
        case "UNRECOGNIZED":
        default:
            return Property_PropertyType.UNRECOGNIZED;
    }
}
function property_PropertyTypeToJSON(object) {
    switch (object) {
        case Property_PropertyType.UNSPECIFIED:
            return "UNSPECIFIED";
        case Property_PropertyType.INT64:
            return "INT64";
        case Property_PropertyType.BOOL:
            return "BOOL";
        case Property_PropertyType.STRING:
            return "STRING";
        case Property_PropertyType.DOUBLE:
            return "DOUBLE";
        case Property_PropertyType.UNRECOGNIZED:
        default:
            return "UNRECOGNIZED";
    }
}
function createBaseProjectProperties() {
    return {
        properties: []
    };
}
exports.ProjectProperties = {
    typeUrl: "/google.api.ProjectProperties",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        for (const v of message.properties) {
            exports.Property.encode(v, writer.uint32(10).fork()).ldelim();
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseProjectProperties();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.properties.push(exports.Property.decode(reader, reader.uint32()));
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseProjectProperties();
        message.properties = object.properties?.map(e => exports.Property.fromPartial(e)) || [];
        return message;
    },
    fromAmino(object) {
        const message = createBaseProjectProperties();
        message.properties = object.properties?.map(e => exports.Property.fromAmino(e)) || [];
        return message;
    },
    toAmino(message) {
        const obj = {};
        if (message.properties) {
            obj.properties = message.properties.map(e => e ? exports.Property.toAmino(e) : undefined);
        }
        else {
            obj.properties = message.properties;
        }
        return obj;
    },
    fromAminoMsg(object) {
        return exports.ProjectProperties.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.ProjectProperties.decode(message.value);
    },
    toProto(message) {
        return exports.ProjectProperties.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.ProjectProperties",
            value: exports.ProjectProperties.encode(message).finish()
        };
    }
};
function createBaseProperty() {
    return {
        name: "",
        type: 0,
        description: ""
    };
}
exports.Property = {
    typeUrl: "/google.api.Property",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.name !== "") {
            writer.uint32(10).string(message.name);
        }
        if (message.type !== 0) {
            writer.uint32(16).int32(message.type);
        }
        if (message.description !== "") {
            writer.uint32(26).string(message.description);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseProperty();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.name = reader.string();
                    break;
                case 2:
                    message.type = reader.int32();
                    break;
                case 3:
                    message.description = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseProperty();
        message.name = object.name ?? "";
        message.type = object.type ?? 0;
        message.description = object.description ?? "";
        return message;
    },
    fromAmino(object) {
        const message = createBaseProperty();
        if (object.name !== undefined && object.name !== null) {
            message.name = object.name;
        }
        if (object.type !== undefined && object.type !== null) {
            message.type = object.type;
        }
        if (object.description !== undefined && object.description !== null) {
            message.description = object.description;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.name = message.name === "" ? undefined : message.name;
        obj.type = message.type === 0 ? undefined : message.type;
        obj.description = message.description === "" ? undefined : message.description;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.Property.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.Property.decode(message.value);
    },
    toProto(message) {
        return exports.Property.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.Property",
            value: exports.Property.encode(message).finish()
        };
    }
};
