"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Endpoint = void 0;
//@ts-nocheck
const binary_1 = require("../../binary");
function createBaseEndpoint() {
    return {
        name: "",
        aliases: [],
        target: "",
        allowCors: false
    };
}
exports.Endpoint = {
    typeUrl: "/google.api.Endpoint",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.name !== "") {
            writer.uint32(10).string(message.name);
        }
        for (const v of message.aliases) {
            writer.uint32(18).string(v);
        }
        if (message.target !== "") {
            writer.uint32(810).string(message.target);
        }
        if (message.allowCors === true) {
            writer.uint32(40).bool(message.allowCors);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseEndpoint();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.name = reader.string();
                    break;
                case 2:
                    message.aliases.push(reader.string());
                    break;
                case 101:
                    message.target = reader.string();
                    break;
                case 5:
                    message.allowCors = reader.bool();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseEndpoint();
        message.name = object.name ?? "";
        message.aliases = object.aliases?.map(e => e) || [];
        message.target = object.target ?? "";
        message.allowCors = object.allowCors ?? false;
        return message;
    },
    fromAmino(object) {
        const message = createBaseEndpoint();
        if (object.name !== undefined && object.name !== null) {
            message.name = object.name;
        }
        message.aliases = object.aliases?.map(e => e) || [];
        if (object.target !== undefined && object.target !== null) {
            message.target = object.target;
        }
        if (object.allow_cors !== undefined && object.allow_cors !== null) {
            message.allowCors = object.allow_cors;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.name = message.name === "" ? undefined : message.name;
        if (message.aliases) {
            obj.aliases = message.aliases.map(e => e);
        }
        else {
            obj.aliases = message.aliases;
        }
        obj.target = message.target === "" ? undefined : message.target;
        obj.allow_cors = message.allowCors === false ? undefined : message.allowCors;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.Endpoint.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.Endpoint.decode(message.value);
    },
    toProto(message) {
        return exports.Endpoint.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.Endpoint",
            value: exports.Endpoint.encode(message).finish()
        };
    }
};
