"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.HttpBody = void 0;
//@ts-nocheck
const any_1 = require("../protobuf/any");
const binary_1 = require("../../binary");
const helpers_1 = require("../../helpers");
function createBaseHttpBody() {
    return {
        contentType: "",
        data: new Uint8Array(),
        extensions: []
    };
}
exports.HttpBody = {
    typeUrl: "/google.api.HttpBody",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.contentType !== "") {
            writer.uint32(10).string(message.contentType);
        }
        if (message.data.length !== 0) {
            writer.uint32(18).bytes(message.data);
        }
        for (const v of message.extensions) {
            any_1.Any.encode(v, writer.uint32(26).fork()).ldelim();
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseHttpBody();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.contentType = reader.string();
                    break;
                case 2:
                    message.data = reader.bytes();
                    break;
                case 3:
                    message.extensions.push(any_1.Any.decode(reader, reader.uint32()));
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseHttpBody();
        message.contentType = object.contentType ?? "";
        message.data = object.data ?? new Uint8Array();
        message.extensions = object.extensions?.map(e => any_1.Any.fromPartial(e)) || [];
        return message;
    },
    fromAmino(object) {
        const message = createBaseHttpBody();
        if (object.content_type !== undefined && object.content_type !== null) {
            message.contentType = object.content_type;
        }
        if (object.data !== undefined && object.data !== null) {
            message.data = (0, helpers_1.bytesFromBase64)(object.data);
        }
        message.extensions = object.extensions?.map(e => any_1.Any.fromAmino(e)) || [];
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.content_type = message.contentType === "" ? undefined : message.contentType;
        obj.data = message.data ? (0, helpers_1.base64FromBytes)(message.data) : undefined;
        if (message.extensions) {
            obj.extensions = message.extensions.map(e => e ? any_1.Any.toAmino(e) : undefined);
        }
        else {
            obj.extensions = message.extensions;
        }
        return obj;
    },
    fromAminoMsg(object) {
        return exports.HttpBody.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.HttpBody.decode(message.value);
    },
    toProto(message) {
        return exports.HttpBody.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.HttpBody",
            value: exports.HttpBody.encode(message).finish()
        };
    }
};
