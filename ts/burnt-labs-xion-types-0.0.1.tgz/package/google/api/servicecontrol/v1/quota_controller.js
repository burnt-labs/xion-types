"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.QuotaError = exports.AllocateQuotaResponse = exports.QuotaOperation = exports.QuotaOperation_LabelsEntry = exports.AllocateQuotaRequest = exports.QuotaError_CodeAmino = exports.QuotaError_CodeSDKType = exports.QuotaError_Code = exports.QuotaOperation_QuotaModeAmino = exports.QuotaOperation_QuotaModeSDKType = exports.QuotaOperation_QuotaMode = void 0;
exports.quotaOperation_QuotaModeFromJSON = quotaOperation_QuotaModeFromJSON;
exports.quotaOperation_QuotaModeToJSON = quotaOperation_QuotaModeToJSON;
exports.quotaError_CodeFromJSON = quotaError_CodeFromJSON;
exports.quotaError_CodeToJSON = quotaError_CodeToJSON;
//@ts-nocheck
const metric_value_1 = require("./metric_value");
const status_1 = require("../../../rpc/status");
const binary_1 = require("../../../../binary");
/** Supported quota modes. */
var QuotaOperation_QuotaMode;
(function (QuotaOperation_QuotaMode) {
    /** UNSPECIFIED - Guard against implicit default. Must not be used. */
    QuotaOperation_QuotaMode[QuotaOperation_QuotaMode["UNSPECIFIED"] = 0] = "UNSPECIFIED";
    /**
     * NORMAL - For AllocateQuota request, allocates quota for the amount specified in
     * the service configuration or specified using the quota metrics. If the
     * amount is higher than the available quota, allocation error will be
     * returned and no quota will be allocated.
     * If multiple quotas are part of the request, and one fails, none of the
     * quotas are allocated or released.
     */
    QuotaOperation_QuotaMode[QuotaOperation_QuotaMode["NORMAL"] = 1] = "NORMAL";
    /**
     * BEST_EFFORT - The operation allocates quota for the amount specified in the service
     * configuration or specified using the quota metrics. If the amount is
     * higher than the available quota, request does not fail but all available
     * quota will be allocated.
     * For rate quota, BEST_EFFORT will continue to deduct from other groups
     * even if one does not have enough quota. For allocation, it will find the
     * minimum available amount across all groups and deduct that amount from
     * all the affected groups.
     */
    QuotaOperation_QuotaMode[QuotaOperation_QuotaMode["BEST_EFFORT"] = 2] = "BEST_EFFORT";
    /**
     * CHECK_ONLY - For AllocateQuota request, only checks if there is enough quota
     * available and does not change the available quota. No lock is placed on
     * the available quota either.
     */
    QuotaOperation_QuotaMode[QuotaOperation_QuotaMode["CHECK_ONLY"] = 3] = "CHECK_ONLY";
    /**
     * QUERY_ONLY - Unimplemented. When used in AllocateQuotaRequest, this returns the
     * effective quota limit(s) in the response, and no quota check will be
     * performed. Not supported for other requests, and even for
     * AllocateQuotaRequest, this is currently supported only for allowlisted
     * services.
     */
    QuotaOperation_QuotaMode[QuotaOperation_QuotaMode["QUERY_ONLY"] = 4] = "QUERY_ONLY";
    /**
     * ADJUST_ONLY - The operation allocates quota for the amount specified in the service
     * configuration or specified using the quota metrics. If the requested
     * amount is higher than the available quota, request does not fail and
     * remaining quota would become negative (going over the limit).
     * Not supported for Rate Quota.
     */
    QuotaOperation_QuotaMode[QuotaOperation_QuotaMode["ADJUST_ONLY"] = 5] = "ADJUST_ONLY";
    QuotaOperation_QuotaMode[QuotaOperation_QuotaMode["UNRECOGNIZED"] = -1] = "UNRECOGNIZED";
})(QuotaOperation_QuotaMode || (exports.QuotaOperation_QuotaMode = QuotaOperation_QuotaMode = {}));
exports.QuotaOperation_QuotaModeSDKType = QuotaOperation_QuotaMode;
exports.QuotaOperation_QuotaModeAmino = QuotaOperation_QuotaMode;
function quotaOperation_QuotaModeFromJSON(object) {
    switch (object) {
        case 0:
        case "UNSPECIFIED":
            return QuotaOperation_QuotaMode.UNSPECIFIED;
        case 1:
        case "NORMAL":
            return QuotaOperation_QuotaMode.NORMAL;
        case 2:
        case "BEST_EFFORT":
            return QuotaOperation_QuotaMode.BEST_EFFORT;
        case 3:
        case "CHECK_ONLY":
            return QuotaOperation_QuotaMode.CHECK_ONLY;
        case 4:
        case "QUERY_ONLY":
            return QuotaOperation_QuotaMode.QUERY_ONLY;
        case 5:
        case "ADJUST_ONLY":
            return QuotaOperation_QuotaMode.ADJUST_ONLY;
        case -1:
        case "UNRECOGNIZED":
        default:
            return QuotaOperation_QuotaMode.UNRECOGNIZED;
    }
}
function quotaOperation_QuotaModeToJSON(object) {
    switch (object) {
        case QuotaOperation_QuotaMode.UNSPECIFIED:
            return "UNSPECIFIED";
        case QuotaOperation_QuotaMode.NORMAL:
            return "NORMAL";
        case QuotaOperation_QuotaMode.BEST_EFFORT:
            return "BEST_EFFORT";
        case QuotaOperation_QuotaMode.CHECK_ONLY:
            return "CHECK_ONLY";
        case QuotaOperation_QuotaMode.QUERY_ONLY:
            return "QUERY_ONLY";
        case QuotaOperation_QuotaMode.ADJUST_ONLY:
            return "ADJUST_ONLY";
        case QuotaOperation_QuotaMode.UNRECOGNIZED:
        default:
            return "UNRECOGNIZED";
    }
}
/**
 * Error codes related to project config validations are deprecated since the
 * quota controller methods do not perform these validations. Instead services
 * have to call the Check method, without quota_properties field, to perform
 * these validations before calling the quota controller methods. These
 * methods check only for project deletion to be wipe out compliant.
 */
var QuotaError_Code;
(function (QuotaError_Code) {
    /** UNSPECIFIED - This is never used. */
    QuotaError_Code[QuotaError_Code["UNSPECIFIED"] = 0] = "UNSPECIFIED";
    /**
     * RESOURCE_EXHAUSTED - Quota allocation failed.
     * Same as [google.rpc.Code.RESOURCE_EXHAUSTED][google.rpc.Code.RESOURCE_EXHAUSTED].
     */
    QuotaError_Code[QuotaError_Code["RESOURCE_EXHAUSTED"] = 8] = "RESOURCE_EXHAUSTED";
    /**
     * BILLING_NOT_ACTIVE - Consumer cannot access the service because the service requires active
     * billing.
     */
    QuotaError_Code[QuotaError_Code["BILLING_NOT_ACTIVE"] = 107] = "BILLING_NOT_ACTIVE";
    /** PROJECT_DELETED - Consumer's project has been marked as deleted (soft deletion). */
    QuotaError_Code[QuotaError_Code["PROJECT_DELETED"] = 108] = "PROJECT_DELETED";
    /** API_KEY_INVALID - Specified API key is invalid. */
    QuotaError_Code[QuotaError_Code["API_KEY_INVALID"] = 105] = "API_KEY_INVALID";
    /** API_KEY_EXPIRED - Specified API Key has expired. */
    QuotaError_Code[QuotaError_Code["API_KEY_EXPIRED"] = 112] = "API_KEY_EXPIRED";
    QuotaError_Code[QuotaError_Code["UNRECOGNIZED"] = -1] = "UNRECOGNIZED";
})(QuotaError_Code || (exports.QuotaError_Code = QuotaError_Code = {}));
exports.QuotaError_CodeSDKType = QuotaError_Code;
exports.QuotaError_CodeAmino = QuotaError_Code;
function quotaError_CodeFromJSON(object) {
    switch (object) {
        case 0:
        case "UNSPECIFIED":
            return QuotaError_Code.UNSPECIFIED;
        case 8:
        case "RESOURCE_EXHAUSTED":
            return QuotaError_Code.RESOURCE_EXHAUSTED;
        case 107:
        case "BILLING_NOT_ACTIVE":
            return QuotaError_Code.BILLING_NOT_ACTIVE;
        case 108:
        case "PROJECT_DELETED":
            return QuotaError_Code.PROJECT_DELETED;
        case 105:
        case "API_KEY_INVALID":
            return QuotaError_Code.API_KEY_INVALID;
        case 112:
        case "API_KEY_EXPIRED":
            return QuotaError_Code.API_KEY_EXPIRED;
        case -1:
        case "UNRECOGNIZED":
        default:
            return QuotaError_Code.UNRECOGNIZED;
    }
}
function quotaError_CodeToJSON(object) {
    switch (object) {
        case QuotaError_Code.UNSPECIFIED:
            return "UNSPECIFIED";
        case QuotaError_Code.RESOURCE_EXHAUSTED:
            return "RESOURCE_EXHAUSTED";
        case QuotaError_Code.BILLING_NOT_ACTIVE:
            return "BILLING_NOT_ACTIVE";
        case QuotaError_Code.PROJECT_DELETED:
            return "PROJECT_DELETED";
        case QuotaError_Code.API_KEY_INVALID:
            return "API_KEY_INVALID";
        case QuotaError_Code.API_KEY_EXPIRED:
            return "API_KEY_EXPIRED";
        case QuotaError_Code.UNRECOGNIZED:
        default:
            return "UNRECOGNIZED";
    }
}
function createBaseAllocateQuotaRequest() {
    return {
        serviceName: "",
        allocateOperation: undefined,
        serviceConfigId: ""
    };
}
exports.AllocateQuotaRequest = {
    typeUrl: "/google.api.servicecontrol.v1.AllocateQuotaRequest",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.serviceName !== "") {
            writer.uint32(10).string(message.serviceName);
        }
        if (message.allocateOperation !== undefined) {
            exports.QuotaOperation.encode(message.allocateOperation, writer.uint32(18).fork()).ldelim();
        }
        if (message.serviceConfigId !== "") {
            writer.uint32(34).string(message.serviceConfigId);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseAllocateQuotaRequest();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.serviceName = reader.string();
                    break;
                case 2:
                    message.allocateOperation = exports.QuotaOperation.decode(reader, reader.uint32());
                    break;
                case 4:
                    message.serviceConfigId = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseAllocateQuotaRequest();
        message.serviceName = object.serviceName ?? "";
        message.allocateOperation = object.allocateOperation !== undefined && object.allocateOperation !== null ? exports.QuotaOperation.fromPartial(object.allocateOperation) : undefined;
        message.serviceConfigId = object.serviceConfigId ?? "";
        return message;
    },
    fromAmino(object) {
        const message = createBaseAllocateQuotaRequest();
        if (object.service_name !== undefined && object.service_name !== null) {
            message.serviceName = object.service_name;
        }
        if (object.allocate_operation !== undefined && object.allocate_operation !== null) {
            message.allocateOperation = exports.QuotaOperation.fromAmino(object.allocate_operation);
        }
        if (object.service_config_id !== undefined && object.service_config_id !== null) {
            message.serviceConfigId = object.service_config_id;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.service_name = message.serviceName === "" ? undefined : message.serviceName;
        obj.allocate_operation = message.allocateOperation ? exports.QuotaOperation.toAmino(message.allocateOperation) : undefined;
        obj.service_config_id = message.serviceConfigId === "" ? undefined : message.serviceConfigId;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.AllocateQuotaRequest.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.AllocateQuotaRequest.decode(message.value);
    },
    toProto(message) {
        return exports.AllocateQuotaRequest.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.servicecontrol.v1.AllocateQuotaRequest",
            value: exports.AllocateQuotaRequest.encode(message).finish()
        };
    }
};
function createBaseQuotaOperation_LabelsEntry() {
    return {
        key: "",
        value: ""
    };
}
exports.QuotaOperation_LabelsEntry = {
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.key !== "") {
            writer.uint32(10).string(message.key);
        }
        if (message.value !== "") {
            writer.uint32(18).string(message.value);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseQuotaOperation_LabelsEntry();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.key = reader.string();
                    break;
                case 2:
                    message.value = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseQuotaOperation_LabelsEntry();
        message.key = object.key ?? "";
        message.value = object.value ?? "";
        return message;
    },
    fromAmino(object) {
        const message = createBaseQuotaOperation_LabelsEntry();
        if (object.key !== undefined && object.key !== null) {
            message.key = object.key;
        }
        if (object.value !== undefined && object.value !== null) {
            message.value = object.value;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.key = message.key === "" ? undefined : message.key;
        obj.value = message.value === "" ? undefined : message.value;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.QuotaOperation_LabelsEntry.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.QuotaOperation_LabelsEntry.decode(message.value);
    },
    toProto(message) {
        return exports.QuotaOperation_LabelsEntry.encode(message).finish();
    }
};
function createBaseQuotaOperation() {
    return {
        operationId: "",
        methodName: "",
        consumerId: "",
        labels: {},
        quotaMetrics: [],
        quotaMode: 0
    };
}
exports.QuotaOperation = {
    typeUrl: "/google.api.servicecontrol.v1.QuotaOperation",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.operationId !== "") {
            writer.uint32(10).string(message.operationId);
        }
        if (message.methodName !== "") {
            writer.uint32(18).string(message.methodName);
        }
        if (message.consumerId !== "") {
            writer.uint32(26).string(message.consumerId);
        }
        Object.entries(message.labels).forEach(([key, value]) => {
            exports.QuotaOperation_LabelsEntry.encode({
                key: key,
                value
            }, writer.uint32(34).fork()).ldelim();
        });
        for (const v of message.quotaMetrics) {
            metric_value_1.MetricValueSet.encode(v, writer.uint32(42).fork()).ldelim();
        }
        if (message.quotaMode !== 0) {
            writer.uint32(48).int32(message.quotaMode);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseQuotaOperation();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.operationId = reader.string();
                    break;
                case 2:
                    message.methodName = reader.string();
                    break;
                case 3:
                    message.consumerId = reader.string();
                    break;
                case 4:
                    const entry4 = exports.QuotaOperation_LabelsEntry.decode(reader, reader.uint32());
                    if (entry4.value !== undefined) {
                        message.labels[entry4.key] = entry4.value;
                    }
                    break;
                case 5:
                    message.quotaMetrics.push(metric_value_1.MetricValueSet.decode(reader, reader.uint32()));
                    break;
                case 6:
                    message.quotaMode = reader.int32();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseQuotaOperation();
        message.operationId = object.operationId ?? "";
        message.methodName = object.methodName ?? "";
        message.consumerId = object.consumerId ?? "";
        message.labels = Object.entries(object.labels ?? {}).reduce((acc, [key, value]) => {
            if (value !== undefined) {
                acc[key] = String(value);
            }
            return acc;
        }, {});
        message.quotaMetrics = object.quotaMetrics?.map(e => metric_value_1.MetricValueSet.fromPartial(e)) || [];
        message.quotaMode = object.quotaMode ?? 0;
        return message;
    },
    fromAmino(object) {
        const message = createBaseQuotaOperation();
        if (object.operation_id !== undefined && object.operation_id !== null) {
            message.operationId = object.operation_id;
        }
        if (object.method_name !== undefined && object.method_name !== null) {
            message.methodName = object.method_name;
        }
        if (object.consumer_id !== undefined && object.consumer_id !== null) {
            message.consumerId = object.consumer_id;
        }
        message.labels = Object.entries(object.labels ?? {}).reduce((acc, [key, value]) => {
            if (value !== undefined) {
                acc[key] = String(value);
            }
            return acc;
        }, {});
        message.quotaMetrics = object.quota_metrics?.map(e => metric_value_1.MetricValueSet.fromAmino(e)) || [];
        if (object.quota_mode !== undefined && object.quota_mode !== null) {
            message.quotaMode = object.quota_mode;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.operation_id = message.operationId === "" ? undefined : message.operationId;
        obj.method_name = message.methodName === "" ? undefined : message.methodName;
        obj.consumer_id = message.consumerId === "" ? undefined : message.consumerId;
        obj.labels = {};
        if (message.labels) {
            Object.entries(message.labels).forEach(([k, v]) => {
                obj.labels[k] = v;
            });
        }
        if (message.quotaMetrics) {
            obj.quota_metrics = message.quotaMetrics.map(e => e ? metric_value_1.MetricValueSet.toAmino(e) : undefined);
        }
        else {
            obj.quota_metrics = message.quotaMetrics;
        }
        obj.quota_mode = message.quotaMode === 0 ? undefined : message.quotaMode;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.QuotaOperation.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.QuotaOperation.decode(message.value);
    },
    toProto(message) {
        return exports.QuotaOperation.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.servicecontrol.v1.QuotaOperation",
            value: exports.QuotaOperation.encode(message).finish()
        };
    }
};
function createBaseAllocateQuotaResponse() {
    return {
        operationId: "",
        allocateErrors: [],
        quotaMetrics: [],
        serviceConfigId: ""
    };
}
exports.AllocateQuotaResponse = {
    typeUrl: "/google.api.servicecontrol.v1.AllocateQuotaResponse",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.operationId !== "") {
            writer.uint32(10).string(message.operationId);
        }
        for (const v of message.allocateErrors) {
            exports.QuotaError.encode(v, writer.uint32(18).fork()).ldelim();
        }
        for (const v of message.quotaMetrics) {
            metric_value_1.MetricValueSet.encode(v, writer.uint32(26).fork()).ldelim();
        }
        if (message.serviceConfigId !== "") {
            writer.uint32(34).string(message.serviceConfigId);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseAllocateQuotaResponse();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.operationId = reader.string();
                    break;
                case 2:
                    message.allocateErrors.push(exports.QuotaError.decode(reader, reader.uint32()));
                    break;
                case 3:
                    message.quotaMetrics.push(metric_value_1.MetricValueSet.decode(reader, reader.uint32()));
                    break;
                case 4:
                    message.serviceConfigId = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseAllocateQuotaResponse();
        message.operationId = object.operationId ?? "";
        message.allocateErrors = object.allocateErrors?.map(e => exports.QuotaError.fromPartial(e)) || [];
        message.quotaMetrics = object.quotaMetrics?.map(e => metric_value_1.MetricValueSet.fromPartial(e)) || [];
        message.serviceConfigId = object.serviceConfigId ?? "";
        return message;
    },
    fromAmino(object) {
        const message = createBaseAllocateQuotaResponse();
        if (object.operation_id !== undefined && object.operation_id !== null) {
            message.operationId = object.operation_id;
        }
        message.allocateErrors = object.allocate_errors?.map(e => exports.QuotaError.fromAmino(e)) || [];
        message.quotaMetrics = object.quota_metrics?.map(e => metric_value_1.MetricValueSet.fromAmino(e)) || [];
        if (object.service_config_id !== undefined && object.service_config_id !== null) {
            message.serviceConfigId = object.service_config_id;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.operation_id = message.operationId === "" ? undefined : message.operationId;
        if (message.allocateErrors) {
            obj.allocate_errors = message.allocateErrors.map(e => e ? exports.QuotaError.toAmino(e) : undefined);
        }
        else {
            obj.allocate_errors = message.allocateErrors;
        }
        if (message.quotaMetrics) {
            obj.quota_metrics = message.quotaMetrics.map(e => e ? metric_value_1.MetricValueSet.toAmino(e) : undefined);
        }
        else {
            obj.quota_metrics = message.quotaMetrics;
        }
        obj.service_config_id = message.serviceConfigId === "" ? undefined : message.serviceConfigId;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.AllocateQuotaResponse.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.AllocateQuotaResponse.decode(message.value);
    },
    toProto(message) {
        return exports.AllocateQuotaResponse.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.servicecontrol.v1.AllocateQuotaResponse",
            value: exports.AllocateQuotaResponse.encode(message).finish()
        };
    }
};
function createBaseQuotaError() {
    return {
        code: 0,
        subject: "",
        description: "",
        status: undefined
    };
}
exports.QuotaError = {
    typeUrl: "/google.api.servicecontrol.v1.QuotaError",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.code !== 0) {
            writer.uint32(8).int32(message.code);
        }
        if (message.subject !== "") {
            writer.uint32(18).string(message.subject);
        }
        if (message.description !== "") {
            writer.uint32(26).string(message.description);
        }
        if (message.status !== undefined) {
            status_1.Status.encode(message.status, writer.uint32(34).fork()).ldelim();
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseQuotaError();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.code = reader.int32();
                    break;
                case 2:
                    message.subject = reader.string();
                    break;
                case 3:
                    message.description = reader.string();
                    break;
                case 4:
                    message.status = status_1.Status.decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseQuotaError();
        message.code = object.code ?? 0;
        message.subject = object.subject ?? "";
        message.description = object.description ?? "";
        message.status = object.status !== undefined && object.status !== null ? status_1.Status.fromPartial(object.status) : undefined;
        return message;
    },
    fromAmino(object) {
        const message = createBaseQuotaError();
        if (object.code !== undefined && object.code !== null) {
            message.code = object.code;
        }
        if (object.subject !== undefined && object.subject !== null) {
            message.subject = object.subject;
        }
        if (object.description !== undefined && object.description !== null) {
            message.description = object.description;
        }
        if (object.status !== undefined && object.status !== null) {
            message.status = status_1.Status.fromAmino(object.status);
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.code = message.code === 0 ? undefined : message.code;
        obj.subject = message.subject === "" ? undefined : message.subject;
        obj.description = message.description === "" ? undefined : message.description;
        obj.status = message.status ? status_1.Status.toAmino(message.status) : undefined;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.QuotaError.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.QuotaError.decode(message.value);
    },
    toProto(message) {
        return exports.QuotaError.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.servicecontrol.v1.QuotaError",
            value: exports.QuotaError.encode(message).finish()
        };
    }
};
