"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ReportResponse_ReportError = exports.ReportResponse = exports.ReportRequest = exports.CheckResponse_ConsumerInfo = exports.CheckResponse_CheckInfo = exports.CheckResponse = exports.CheckRequest = exports.CheckResponse_ConsumerInfo_ConsumerTypeAmino = exports.CheckResponse_ConsumerInfo_ConsumerTypeSDKType = exports.CheckResponse_ConsumerInfo_ConsumerType = void 0;
exports.checkResponse_ConsumerInfo_ConsumerTypeFromJSON = checkResponse_ConsumerInfo_ConsumerTypeFromJSON;
exports.checkResponse_ConsumerInfo_ConsumerTypeToJSON = checkResponse_ConsumerInfo_ConsumerTypeToJSON;
//@ts-nocheck
const operation_1 = require("./operation");
const check_error_1 = require("./check_error");
const status_1 = require("../../../rpc/status");
const binary_1 = require("../../../../binary");
/**
 * The type of the consumer as defined in
 * [Google Resource Manager](https://cloud.google.com/resource-manager/).
 */
var CheckResponse_ConsumerInfo_ConsumerType;
(function (CheckResponse_ConsumerInfo_ConsumerType) {
    /** CONSUMER_TYPE_UNSPECIFIED - This is never used. */
    CheckResponse_ConsumerInfo_ConsumerType[CheckResponse_ConsumerInfo_ConsumerType["CONSUMER_TYPE_UNSPECIFIED"] = 0] = "CONSUMER_TYPE_UNSPECIFIED";
    /** PROJECT - The consumer is a Google Cloud Project. */
    CheckResponse_ConsumerInfo_ConsumerType[CheckResponse_ConsumerInfo_ConsumerType["PROJECT"] = 1] = "PROJECT";
    /** FOLDER - The consumer is a Google Cloud Folder. */
    CheckResponse_ConsumerInfo_ConsumerType[CheckResponse_ConsumerInfo_ConsumerType["FOLDER"] = 2] = "FOLDER";
    /** ORGANIZATION - The consumer is a Google Cloud Organization. */
    CheckResponse_ConsumerInfo_ConsumerType[CheckResponse_ConsumerInfo_ConsumerType["ORGANIZATION"] = 3] = "ORGANIZATION";
    /**
     * SERVICE_SPECIFIC - Service-specific resource container which is defined by the service
     * producer to offer their users the ability to manage service control
     * functionalities at a finer level of granularity than the PROJECT.
     */
    CheckResponse_ConsumerInfo_ConsumerType[CheckResponse_ConsumerInfo_ConsumerType["SERVICE_SPECIFIC"] = 4] = "SERVICE_SPECIFIC";
    CheckResponse_ConsumerInfo_ConsumerType[CheckResponse_ConsumerInfo_ConsumerType["UNRECOGNIZED"] = -1] = "UNRECOGNIZED";
})(CheckResponse_ConsumerInfo_ConsumerType || (exports.CheckResponse_ConsumerInfo_ConsumerType = CheckResponse_ConsumerInfo_ConsumerType = {}));
exports.CheckResponse_ConsumerInfo_ConsumerTypeSDKType = CheckResponse_ConsumerInfo_ConsumerType;
exports.CheckResponse_ConsumerInfo_ConsumerTypeAmino = CheckResponse_ConsumerInfo_ConsumerType;
function checkResponse_ConsumerInfo_ConsumerTypeFromJSON(object) {
    switch (object) {
        case 0:
        case "CONSUMER_TYPE_UNSPECIFIED":
            return CheckResponse_ConsumerInfo_ConsumerType.CONSUMER_TYPE_UNSPECIFIED;
        case 1:
        case "PROJECT":
            return CheckResponse_ConsumerInfo_ConsumerType.PROJECT;
        case 2:
        case "FOLDER":
            return CheckResponse_ConsumerInfo_ConsumerType.FOLDER;
        case 3:
        case "ORGANIZATION":
            return CheckResponse_ConsumerInfo_ConsumerType.ORGANIZATION;
        case 4:
        case "SERVICE_SPECIFIC":
            return CheckResponse_ConsumerInfo_ConsumerType.SERVICE_SPECIFIC;
        case -1:
        case "UNRECOGNIZED":
        default:
            return CheckResponse_ConsumerInfo_ConsumerType.UNRECOGNIZED;
    }
}
function checkResponse_ConsumerInfo_ConsumerTypeToJSON(object) {
    switch (object) {
        case CheckResponse_ConsumerInfo_ConsumerType.CONSUMER_TYPE_UNSPECIFIED:
            return "CONSUMER_TYPE_UNSPECIFIED";
        case CheckResponse_ConsumerInfo_ConsumerType.PROJECT:
            return "PROJECT";
        case CheckResponse_ConsumerInfo_ConsumerType.FOLDER:
            return "FOLDER";
        case CheckResponse_ConsumerInfo_ConsumerType.ORGANIZATION:
            return "ORGANIZATION";
        case CheckResponse_ConsumerInfo_ConsumerType.SERVICE_SPECIFIC:
            return "SERVICE_SPECIFIC";
        case CheckResponse_ConsumerInfo_ConsumerType.UNRECOGNIZED:
        default:
            return "UNRECOGNIZED";
    }
}
function createBaseCheckRequest() {
    return {
        serviceName: "",
        operation: undefined,
        serviceConfigId: ""
    };
}
exports.CheckRequest = {
    typeUrl: "/google.api.servicecontrol.v1.CheckRequest",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.serviceName !== "") {
            writer.uint32(10).string(message.serviceName);
        }
        if (message.operation !== undefined) {
            operation_1.Operation.encode(message.operation, writer.uint32(18).fork()).ldelim();
        }
        if (message.serviceConfigId !== "") {
            writer.uint32(34).string(message.serviceConfigId);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseCheckRequest();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.serviceName = reader.string();
                    break;
                case 2:
                    message.operation = operation_1.Operation.decode(reader, reader.uint32());
                    break;
                case 4:
                    message.serviceConfigId = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseCheckRequest();
        message.serviceName = object.serviceName ?? "";
        message.operation = object.operation !== undefined && object.operation !== null ? operation_1.Operation.fromPartial(object.operation) : undefined;
        message.serviceConfigId = object.serviceConfigId ?? "";
        return message;
    },
    fromAmino(object) {
        const message = createBaseCheckRequest();
        if (object.service_name !== undefined && object.service_name !== null) {
            message.serviceName = object.service_name;
        }
        if (object.operation !== undefined && object.operation !== null) {
            message.operation = operation_1.Operation.fromAmino(object.operation);
        }
        if (object.service_config_id !== undefined && object.service_config_id !== null) {
            message.serviceConfigId = object.service_config_id;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.service_name = message.serviceName === "" ? undefined : message.serviceName;
        obj.operation = message.operation ? operation_1.Operation.toAmino(message.operation) : undefined;
        obj.service_config_id = message.serviceConfigId === "" ? undefined : message.serviceConfigId;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.CheckRequest.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.CheckRequest.decode(message.value);
    },
    toProto(message) {
        return exports.CheckRequest.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.servicecontrol.v1.CheckRequest",
            value: exports.CheckRequest.encode(message).finish()
        };
    }
};
function createBaseCheckResponse() {
    return {
        operationId: "",
        checkErrors: [],
        serviceConfigId: "",
        serviceRolloutId: "",
        checkInfo: undefined
    };
}
exports.CheckResponse = {
    typeUrl: "/google.api.servicecontrol.v1.CheckResponse",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.operationId !== "") {
            writer.uint32(10).string(message.operationId);
        }
        for (const v of message.checkErrors) {
            check_error_1.CheckError.encode(v, writer.uint32(18).fork()).ldelim();
        }
        if (message.serviceConfigId !== "") {
            writer.uint32(42).string(message.serviceConfigId);
        }
        if (message.serviceRolloutId !== "") {
            writer.uint32(90).string(message.serviceRolloutId);
        }
        if (message.checkInfo !== undefined) {
            exports.CheckResponse_CheckInfo.encode(message.checkInfo, writer.uint32(50).fork()).ldelim();
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseCheckResponse();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.operationId = reader.string();
                    break;
                case 2:
                    message.checkErrors.push(check_error_1.CheckError.decode(reader, reader.uint32()));
                    break;
                case 5:
                    message.serviceConfigId = reader.string();
                    break;
                case 11:
                    message.serviceRolloutId = reader.string();
                    break;
                case 6:
                    message.checkInfo = exports.CheckResponse_CheckInfo.decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseCheckResponse();
        message.operationId = object.operationId ?? "";
        message.checkErrors = object.checkErrors?.map(e => check_error_1.CheckError.fromPartial(e)) || [];
        message.serviceConfigId = object.serviceConfigId ?? "";
        message.serviceRolloutId = object.serviceRolloutId ?? "";
        message.checkInfo = object.checkInfo !== undefined && object.checkInfo !== null ? exports.CheckResponse_CheckInfo.fromPartial(object.checkInfo) : undefined;
        return message;
    },
    fromAmino(object) {
        const message = createBaseCheckResponse();
        if (object.operation_id !== undefined && object.operation_id !== null) {
            message.operationId = object.operation_id;
        }
        message.checkErrors = object.check_errors?.map(e => check_error_1.CheckError.fromAmino(e)) || [];
        if (object.service_config_id !== undefined && object.service_config_id !== null) {
            message.serviceConfigId = object.service_config_id;
        }
        if (object.service_rollout_id !== undefined && object.service_rollout_id !== null) {
            message.serviceRolloutId = object.service_rollout_id;
        }
        if (object.check_info !== undefined && object.check_info !== null) {
            message.checkInfo = exports.CheckResponse_CheckInfo.fromAmino(object.check_info);
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.operation_id = message.operationId === "" ? undefined : message.operationId;
        if (message.checkErrors) {
            obj.check_errors = message.checkErrors.map(e => e ? check_error_1.CheckError.toAmino(e) : undefined);
        }
        else {
            obj.check_errors = message.checkErrors;
        }
        obj.service_config_id = message.serviceConfigId === "" ? undefined : message.serviceConfigId;
        obj.service_rollout_id = message.serviceRolloutId === "" ? undefined : message.serviceRolloutId;
        obj.check_info = message.checkInfo ? exports.CheckResponse_CheckInfo.toAmino(message.checkInfo) : undefined;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.CheckResponse.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.CheckResponse.decode(message.value);
    },
    toProto(message) {
        return exports.CheckResponse.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.servicecontrol.v1.CheckResponse",
            value: exports.CheckResponse.encode(message).finish()
        };
    }
};
function createBaseCheckResponse_CheckInfo() {
    return {
        unusedArguments: [],
        consumerInfo: undefined,
        apiKeyUid: ""
    };
}
exports.CheckResponse_CheckInfo = {
    typeUrl: "/google.api.servicecontrol.v1.CheckInfo",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        for (const v of message.unusedArguments) {
            writer.uint32(10).string(v);
        }
        if (message.consumerInfo !== undefined) {
            exports.CheckResponse_ConsumerInfo.encode(message.consumerInfo, writer.uint32(18).fork()).ldelim();
        }
        if (message.apiKeyUid !== "") {
            writer.uint32(42).string(message.apiKeyUid);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseCheckResponse_CheckInfo();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.unusedArguments.push(reader.string());
                    break;
                case 2:
                    message.consumerInfo = exports.CheckResponse_ConsumerInfo.decode(reader, reader.uint32());
                    break;
                case 5:
                    message.apiKeyUid = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseCheckResponse_CheckInfo();
        message.unusedArguments = object.unusedArguments?.map(e => e) || [];
        message.consumerInfo = object.consumerInfo !== undefined && object.consumerInfo !== null ? exports.CheckResponse_ConsumerInfo.fromPartial(object.consumerInfo) : undefined;
        message.apiKeyUid = object.apiKeyUid ?? "";
        return message;
    },
    fromAmino(object) {
        const message = createBaseCheckResponse_CheckInfo();
        message.unusedArguments = object.unused_arguments?.map(e => e) || [];
        if (object.consumer_info !== undefined && object.consumer_info !== null) {
            message.consumerInfo = exports.CheckResponse_ConsumerInfo.fromAmino(object.consumer_info);
        }
        if (object.api_key_uid !== undefined && object.api_key_uid !== null) {
            message.apiKeyUid = object.api_key_uid;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        if (message.unusedArguments) {
            obj.unused_arguments = message.unusedArguments.map(e => e);
        }
        else {
            obj.unused_arguments = message.unusedArguments;
        }
        obj.consumer_info = message.consumerInfo ? exports.CheckResponse_ConsumerInfo.toAmino(message.consumerInfo) : undefined;
        obj.api_key_uid = message.apiKeyUid === "" ? undefined : message.apiKeyUid;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.CheckResponse_CheckInfo.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.CheckResponse_CheckInfo.decode(message.value);
    },
    toProto(message) {
        return exports.CheckResponse_CheckInfo.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.servicecontrol.v1.CheckInfo",
            value: exports.CheckResponse_CheckInfo.encode(message).finish()
        };
    }
};
function createBaseCheckResponse_ConsumerInfo() {
    return {
        projectNumber: BigInt(0),
        type: 0,
        consumerNumber: BigInt(0)
    };
}
exports.CheckResponse_ConsumerInfo = {
    typeUrl: "/google.api.servicecontrol.v1.ConsumerInfo",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.projectNumber !== BigInt(0)) {
            writer.uint32(8).int64(message.projectNumber);
        }
        if (message.type !== 0) {
            writer.uint32(16).int32(message.type);
        }
        if (message.consumerNumber !== BigInt(0)) {
            writer.uint32(24).int64(message.consumerNumber);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseCheckResponse_ConsumerInfo();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.projectNumber = reader.int64();
                    break;
                case 2:
                    message.type = reader.int32();
                    break;
                case 3:
                    message.consumerNumber = reader.int64();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseCheckResponse_ConsumerInfo();
        message.projectNumber = object.projectNumber !== undefined && object.projectNumber !== null ? BigInt(object.projectNumber.toString()) : BigInt(0);
        message.type = object.type ?? 0;
        message.consumerNumber = object.consumerNumber !== undefined && object.consumerNumber !== null ? BigInt(object.consumerNumber.toString()) : BigInt(0);
        return message;
    },
    fromAmino(object) {
        const message = createBaseCheckResponse_ConsumerInfo();
        if (object.project_number !== undefined && object.project_number !== null) {
            message.projectNumber = BigInt(object.project_number);
        }
        if (object.type !== undefined && object.type !== null) {
            message.type = object.type;
        }
        if (object.consumer_number !== undefined && object.consumer_number !== null) {
            message.consumerNumber = BigInt(object.consumer_number);
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.project_number = message.projectNumber !== BigInt(0) ? message.projectNumber?.toString() : undefined;
        obj.type = message.type === 0 ? undefined : message.type;
        obj.consumer_number = message.consumerNumber !== BigInt(0) ? message.consumerNumber?.toString() : undefined;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.CheckResponse_ConsumerInfo.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.CheckResponse_ConsumerInfo.decode(message.value);
    },
    toProto(message) {
        return exports.CheckResponse_ConsumerInfo.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.servicecontrol.v1.ConsumerInfo",
            value: exports.CheckResponse_ConsumerInfo.encode(message).finish()
        };
    }
};
function createBaseReportRequest() {
    return {
        serviceName: "",
        operations: [],
        serviceConfigId: ""
    };
}
exports.ReportRequest = {
    typeUrl: "/google.api.servicecontrol.v1.ReportRequest",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.serviceName !== "") {
            writer.uint32(10).string(message.serviceName);
        }
        for (const v of message.operations) {
            operation_1.Operation.encode(v, writer.uint32(18).fork()).ldelim();
        }
        if (message.serviceConfigId !== "") {
            writer.uint32(26).string(message.serviceConfigId);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseReportRequest();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.serviceName = reader.string();
                    break;
                case 2:
                    message.operations.push(operation_1.Operation.decode(reader, reader.uint32()));
                    break;
                case 3:
                    message.serviceConfigId = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseReportRequest();
        message.serviceName = object.serviceName ?? "";
        message.operations = object.operations?.map(e => operation_1.Operation.fromPartial(e)) || [];
        message.serviceConfigId = object.serviceConfigId ?? "";
        return message;
    },
    fromAmino(object) {
        const message = createBaseReportRequest();
        if (object.service_name !== undefined && object.service_name !== null) {
            message.serviceName = object.service_name;
        }
        message.operations = object.operations?.map(e => operation_1.Operation.fromAmino(e)) || [];
        if (object.service_config_id !== undefined && object.service_config_id !== null) {
            message.serviceConfigId = object.service_config_id;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.service_name = message.serviceName === "" ? undefined : message.serviceName;
        if (message.operations) {
            obj.operations = message.operations.map(e => e ? operation_1.Operation.toAmino(e) : undefined);
        }
        else {
            obj.operations = message.operations;
        }
        obj.service_config_id = message.serviceConfigId === "" ? undefined : message.serviceConfigId;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.ReportRequest.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.ReportRequest.decode(message.value);
    },
    toProto(message) {
        return exports.ReportRequest.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.servicecontrol.v1.ReportRequest",
            value: exports.ReportRequest.encode(message).finish()
        };
    }
};
function createBaseReportResponse() {
    return {
        reportErrors: [],
        serviceConfigId: "",
        serviceRolloutId: ""
    };
}
exports.ReportResponse = {
    typeUrl: "/google.api.servicecontrol.v1.ReportResponse",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        for (const v of message.reportErrors) {
            exports.ReportResponse_ReportError.encode(v, writer.uint32(10).fork()).ldelim();
        }
        if (message.serviceConfigId !== "") {
            writer.uint32(18).string(message.serviceConfigId);
        }
        if (message.serviceRolloutId !== "") {
            writer.uint32(34).string(message.serviceRolloutId);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseReportResponse();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.reportErrors.push(exports.ReportResponse_ReportError.decode(reader, reader.uint32()));
                    break;
                case 2:
                    message.serviceConfigId = reader.string();
                    break;
                case 4:
                    message.serviceRolloutId = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseReportResponse();
        message.reportErrors = object.reportErrors?.map(e => exports.ReportResponse_ReportError.fromPartial(e)) || [];
        message.serviceConfigId = object.serviceConfigId ?? "";
        message.serviceRolloutId = object.serviceRolloutId ?? "";
        return message;
    },
    fromAmino(object) {
        const message = createBaseReportResponse();
        message.reportErrors = object.report_errors?.map(e => exports.ReportResponse_ReportError.fromAmino(e)) || [];
        if (object.service_config_id !== undefined && object.service_config_id !== null) {
            message.serviceConfigId = object.service_config_id;
        }
        if (object.service_rollout_id !== undefined && object.service_rollout_id !== null) {
            message.serviceRolloutId = object.service_rollout_id;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        if (message.reportErrors) {
            obj.report_errors = message.reportErrors.map(e => e ? exports.ReportResponse_ReportError.toAmino(e) : undefined);
        }
        else {
            obj.report_errors = message.reportErrors;
        }
        obj.service_config_id = message.serviceConfigId === "" ? undefined : message.serviceConfigId;
        obj.service_rollout_id = message.serviceRolloutId === "" ? undefined : message.serviceRolloutId;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.ReportResponse.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.ReportResponse.decode(message.value);
    },
    toProto(message) {
        return exports.ReportResponse.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.servicecontrol.v1.ReportResponse",
            value: exports.ReportResponse.encode(message).finish()
        };
    }
};
function createBaseReportResponse_ReportError() {
    return {
        operationId: "",
        status: undefined
    };
}
exports.ReportResponse_ReportError = {
    typeUrl: "/google.api.servicecontrol.v1.ReportError",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.operationId !== "") {
            writer.uint32(10).string(message.operationId);
        }
        if (message.status !== undefined) {
            status_1.Status.encode(message.status, writer.uint32(18).fork()).ldelim();
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseReportResponse_ReportError();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.operationId = reader.string();
                    break;
                case 2:
                    message.status = status_1.Status.decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseReportResponse_ReportError();
        message.operationId = object.operationId ?? "";
        message.status = object.status !== undefined && object.status !== null ? status_1.Status.fromPartial(object.status) : undefined;
        return message;
    },
    fromAmino(object) {
        const message = createBaseReportResponse_ReportError();
        if (object.operation_id !== undefined && object.operation_id !== null) {
            message.operationId = object.operation_id;
        }
        if (object.status !== undefined && object.status !== null) {
            message.status = status_1.Status.fromAmino(object.status);
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.operation_id = message.operationId === "" ? undefined : message.operationId;
        obj.status = message.status ? status_1.Status.toAmino(message.status) : undefined;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.ReportResponse_ReportError.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.ReportResponse_ReportError.decode(message.value);
    },
    toProto(message) {
        return exports.ReportResponse_ReportError.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.servicecontrol.v1.ReportError",
            value: exports.ReportResponse_ReportError.encode(message).finish()
        };
    }
};
