"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Operation = exports.Operation_LabelsEntry = exports.Operation_ImportanceAmino = exports.Operation_ImportanceSDKType = exports.Operation_Importance = void 0;
exports.operation_ImportanceFromJSON = operation_ImportanceFromJSON;
exports.operation_ImportanceToJSON = operation_ImportanceToJSON;
//@ts-nocheck
const timestamp_1 = require("../../../protobuf/timestamp");
const metric_value_1 = require("./metric_value");
const log_entry_1 = require("./log_entry");
const any_1 = require("../../../protobuf/any");
const binary_1 = require("../../../../binary");
const helpers_1 = require("../../../../helpers");
/** Defines the importance of the data contained in the operation. */
var Operation_Importance;
(function (Operation_Importance) {
    /**
     * LOW - Allows data caching, batching, and aggregation. It provides
     * higher performance with higher data loss risk.
     */
    Operation_Importance[Operation_Importance["LOW"] = 0] = "LOW";
    /**
     * HIGH - Disables data aggregation to minimize data loss. It is for operations
     * that contains significant monetary value or audit trail. This feature
     * only applies to the client libraries.
     */
    Operation_Importance[Operation_Importance["HIGH"] = 1] = "HIGH";
    Operation_Importance[Operation_Importance["UNRECOGNIZED"] = -1] = "UNRECOGNIZED";
})(Operation_Importance || (exports.Operation_Importance = Operation_Importance = {}));
exports.Operation_ImportanceSDKType = Operation_Importance;
exports.Operation_ImportanceAmino = Operation_Importance;
function operation_ImportanceFromJSON(object) {
    switch (object) {
        case 0:
        case "LOW":
            return Operation_Importance.LOW;
        case 1:
        case "HIGH":
            return Operation_Importance.HIGH;
        case -1:
        case "UNRECOGNIZED":
        default:
            return Operation_Importance.UNRECOGNIZED;
    }
}
function operation_ImportanceToJSON(object) {
    switch (object) {
        case Operation_Importance.LOW:
            return "LOW";
        case Operation_Importance.HIGH:
            return "HIGH";
        case Operation_Importance.UNRECOGNIZED:
        default:
            return "UNRECOGNIZED";
    }
}
function createBaseOperation_LabelsEntry() {
    return {
        key: "",
        value: ""
    };
}
exports.Operation_LabelsEntry = {
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.key !== "") {
            writer.uint32(10).string(message.key);
        }
        if (message.value !== "") {
            writer.uint32(18).string(message.value);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseOperation_LabelsEntry();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.key = reader.string();
                    break;
                case 2:
                    message.value = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseOperation_LabelsEntry();
        message.key = object.key ?? "";
        message.value = object.value ?? "";
        return message;
    },
    fromAmino(object) {
        const message = createBaseOperation_LabelsEntry();
        if (object.key !== undefined && object.key !== null) {
            message.key = object.key;
        }
        if (object.value !== undefined && object.value !== null) {
            message.value = object.value;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.key = message.key === "" ? undefined : message.key;
        obj.value = message.value === "" ? undefined : message.value;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.Operation_LabelsEntry.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.Operation_LabelsEntry.decode(message.value);
    },
    toProto(message) {
        return exports.Operation_LabelsEntry.encode(message).finish();
    }
};
function createBaseOperation() {
    return {
        operationId: "",
        operationName: "",
        consumerId: "",
        startTime: undefined,
        endTime: undefined,
        labels: {},
        metricValueSets: [],
        logEntries: [],
        importance: 0,
        extensions: []
    };
}
exports.Operation = {
    typeUrl: "/google.api.servicecontrol.v1.Operation",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.operationId !== "") {
            writer.uint32(10).string(message.operationId);
        }
        if (message.operationName !== "") {
            writer.uint32(18).string(message.operationName);
        }
        if (message.consumerId !== "") {
            writer.uint32(26).string(message.consumerId);
        }
        if (message.startTime !== undefined) {
            timestamp_1.Timestamp.encode((0, helpers_1.toTimestamp)(message.startTime), writer.uint32(34).fork()).ldelim();
        }
        if (message.endTime !== undefined) {
            timestamp_1.Timestamp.encode((0, helpers_1.toTimestamp)(message.endTime), writer.uint32(42).fork()).ldelim();
        }
        Object.entries(message.labels).forEach(([key, value]) => {
            exports.Operation_LabelsEntry.encode({
                key: key,
                value
            }, writer.uint32(50).fork()).ldelim();
        });
        for (const v of message.metricValueSets) {
            metric_value_1.MetricValueSet.encode(v, writer.uint32(58).fork()).ldelim();
        }
        for (const v of message.logEntries) {
            log_entry_1.LogEntry.encode(v, writer.uint32(66).fork()).ldelim();
        }
        if (message.importance !== 0) {
            writer.uint32(88).int32(message.importance);
        }
        for (const v of message.extensions) {
            any_1.Any.encode(v, writer.uint32(130).fork()).ldelim();
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseOperation();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.operationId = reader.string();
                    break;
                case 2:
                    message.operationName = reader.string();
                    break;
                case 3:
                    message.consumerId = reader.string();
                    break;
                case 4:
                    message.startTime = (0, helpers_1.fromTimestamp)(timestamp_1.Timestamp.decode(reader, reader.uint32()));
                    break;
                case 5:
                    message.endTime = (0, helpers_1.fromTimestamp)(timestamp_1.Timestamp.decode(reader, reader.uint32()));
                    break;
                case 6:
                    const entry6 = exports.Operation_LabelsEntry.decode(reader, reader.uint32());
                    if (entry6.value !== undefined) {
                        message.labels[entry6.key] = entry6.value;
                    }
                    break;
                case 7:
                    message.metricValueSets.push(metric_value_1.MetricValueSet.decode(reader, reader.uint32()));
                    break;
                case 8:
                    message.logEntries.push(log_entry_1.LogEntry.decode(reader, reader.uint32()));
                    break;
                case 11:
                    message.importance = reader.int32();
                    break;
                case 16:
                    message.extensions.push(any_1.Any.decode(reader, reader.uint32()));
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseOperation();
        message.operationId = object.operationId ?? "";
        message.operationName = object.operationName ?? "";
        message.consumerId = object.consumerId ?? "";
        message.startTime = object.startTime ?? undefined;
        message.endTime = object.endTime ?? undefined;
        message.labels = Object.entries(object.labels ?? {}).reduce((acc, [key, value]) => {
            if (value !== undefined) {
                acc[key] = String(value);
            }
            return acc;
        }, {});
        message.metricValueSets = object.metricValueSets?.map(e => metric_value_1.MetricValueSet.fromPartial(e)) || [];
        message.logEntries = object.logEntries?.map(e => log_entry_1.LogEntry.fromPartial(e)) || [];
        message.importance = object.importance ?? 0;
        message.extensions = object.extensions?.map(e => any_1.Any.fromPartial(e)) || [];
        return message;
    },
    fromAmino(object) {
        const message = createBaseOperation();
        if (object.operation_id !== undefined && object.operation_id !== null) {
            message.operationId = object.operation_id;
        }
        if (object.operation_name !== undefined && object.operation_name !== null) {
            message.operationName = object.operation_name;
        }
        if (object.consumer_id !== undefined && object.consumer_id !== null) {
            message.consumerId = object.consumer_id;
        }
        if (object.start_time !== undefined && object.start_time !== null) {
            message.startTime = (0, helpers_1.fromTimestamp)(timestamp_1.Timestamp.fromAmino(object.start_time));
        }
        if (object.end_time !== undefined && object.end_time !== null) {
            message.endTime = (0, helpers_1.fromTimestamp)(timestamp_1.Timestamp.fromAmino(object.end_time));
        }
        message.labels = Object.entries(object.labels ?? {}).reduce((acc, [key, value]) => {
            if (value !== undefined) {
                acc[key] = String(value);
            }
            return acc;
        }, {});
        message.metricValueSets = object.metric_value_sets?.map(e => metric_value_1.MetricValueSet.fromAmino(e)) || [];
        message.logEntries = object.log_entries?.map(e => log_entry_1.LogEntry.fromAmino(e)) || [];
        if (object.importance !== undefined && object.importance !== null) {
            message.importance = object.importance;
        }
        message.extensions = object.extensions?.map(e => any_1.Any.fromAmino(e)) || [];
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.operation_id = message.operationId === "" ? undefined : message.operationId;
        obj.operation_name = message.operationName === "" ? undefined : message.operationName;
        obj.consumer_id = message.consumerId === "" ? undefined : message.consumerId;
        obj.start_time = message.startTime ? timestamp_1.Timestamp.toAmino((0, helpers_1.toTimestamp)(message.startTime)) : undefined;
        obj.end_time = message.endTime ? timestamp_1.Timestamp.toAmino((0, helpers_1.toTimestamp)(message.endTime)) : undefined;
        obj.labels = {};
        if (message.labels) {
            Object.entries(message.labels).forEach(([k, v]) => {
                obj.labels[k] = v;
            });
        }
        if (message.metricValueSets) {
            obj.metric_value_sets = message.metricValueSets.map(e => e ? metric_value_1.MetricValueSet.toAmino(e) : undefined);
        }
        else {
            obj.metric_value_sets = message.metricValueSets;
        }
        if (message.logEntries) {
            obj.log_entries = message.logEntries.map(e => e ? log_entry_1.LogEntry.toAmino(e) : undefined);
        }
        else {
            obj.log_entries = message.logEntries;
        }
        obj.importance = message.importance === 0 ? undefined : message.importance;
        if (message.extensions) {
            obj.extensions = message.extensions.map(e => e ? any_1.Any.toAmino(e) : undefined);
        }
        else {
            obj.extensions = message.extensions;
        }
        return obj;
    },
    fromAminoMsg(object) {
        return exports.Operation.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.Operation.decode(message.value);
    },
    toProto(message) {
        return exports.Operation.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.servicecontrol.v1.Operation",
            value: exports.Operation.encode(message).finish()
        };
    }
};
