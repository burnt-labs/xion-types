"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Distribution_ExplicitBuckets = exports.Distribution_ExponentialBuckets = exports.Distribution_LinearBuckets = exports.Distribution = void 0;
//@ts-nocheck
const distribution_1 = require("../../distribution");
const binary_1 = require("../../../../binary");
function createBaseDistribution() {
    return {
        count: BigInt(0),
        mean: 0,
        minimum: 0,
        maximum: 0,
        sumOfSquaredDeviation: 0,
        bucketCounts: [],
        linearBuckets: undefined,
        exponentialBuckets: undefined,
        explicitBuckets: undefined,
        exemplars: []
    };
}
exports.Distribution = {
    typeUrl: "/google.api.servicecontrol.v1.Distribution",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.count !== BigInt(0)) {
            writer.uint32(8).int64(message.count);
        }
        if (message.mean !== 0) {
            writer.uint32(17).double(message.mean);
        }
        if (message.minimum !== 0) {
            writer.uint32(25).double(message.minimum);
        }
        if (message.maximum !== 0) {
            writer.uint32(33).double(message.maximum);
        }
        if (message.sumOfSquaredDeviation !== 0) {
            writer.uint32(41).double(message.sumOfSquaredDeviation);
        }
        writer.uint32(50).fork();
        for (const v of message.bucketCounts) {
            writer.int64(v);
        }
        writer.ldelim();
        if (message.linearBuckets !== undefined) {
            exports.Distribution_LinearBuckets.encode(message.linearBuckets, writer.uint32(58).fork()).ldelim();
        }
        if (message.exponentialBuckets !== undefined) {
            exports.Distribution_ExponentialBuckets.encode(message.exponentialBuckets, writer.uint32(66).fork()).ldelim();
        }
        if (message.explicitBuckets !== undefined) {
            exports.Distribution_ExplicitBuckets.encode(message.explicitBuckets, writer.uint32(74).fork()).ldelim();
        }
        for (const v of message.exemplars) {
            distribution_1.Distribution_Exemplar.encode(v, writer.uint32(82).fork()).ldelim();
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseDistribution();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.count = reader.int64();
                    break;
                case 2:
                    message.mean = reader.double();
                    break;
                case 3:
                    message.minimum = reader.double();
                    break;
                case 4:
                    message.maximum = reader.double();
                    break;
                case 5:
                    message.sumOfSquaredDeviation = reader.double();
                    break;
                case 6:
                    if ((tag & 7) === 2) {
                        const end2 = reader.uint32() + reader.pos;
                        while (reader.pos < end2) {
                            message.bucketCounts.push(reader.int64());
                        }
                    }
                    else {
                        message.bucketCounts.push(reader.int64());
                    }
                    break;
                case 7:
                    message.linearBuckets = exports.Distribution_LinearBuckets.decode(reader, reader.uint32());
                    break;
                case 8:
                    message.exponentialBuckets = exports.Distribution_ExponentialBuckets.decode(reader, reader.uint32());
                    break;
                case 9:
                    message.explicitBuckets = exports.Distribution_ExplicitBuckets.decode(reader, reader.uint32());
                    break;
                case 10:
                    message.exemplars.push(distribution_1.Distribution_Exemplar.decode(reader, reader.uint32()));
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseDistribution();
        message.count = object.count !== undefined && object.count !== null ? BigInt(object.count.toString()) : BigInt(0);
        message.mean = object.mean ?? 0;
        message.minimum = object.minimum ?? 0;
        message.maximum = object.maximum ?? 0;
        message.sumOfSquaredDeviation = object.sumOfSquaredDeviation ?? 0;
        message.bucketCounts = object.bucketCounts?.map(e => BigInt(e.toString())) || [];
        message.linearBuckets = object.linearBuckets !== undefined && object.linearBuckets !== null ? exports.Distribution_LinearBuckets.fromPartial(object.linearBuckets) : undefined;
        message.exponentialBuckets = object.exponentialBuckets !== undefined && object.exponentialBuckets !== null ? exports.Distribution_ExponentialBuckets.fromPartial(object.exponentialBuckets) : undefined;
        message.explicitBuckets = object.explicitBuckets !== undefined && object.explicitBuckets !== null ? exports.Distribution_ExplicitBuckets.fromPartial(object.explicitBuckets) : undefined;
        message.exemplars = object.exemplars?.map(e => distribution_1.Distribution_Exemplar.fromPartial(e)) || [];
        return message;
    },
    fromAmino(object) {
        const message = createBaseDistribution();
        if (object.count !== undefined && object.count !== null) {
            message.count = BigInt(object.count);
        }
        if (object.mean !== undefined && object.mean !== null) {
            message.mean = object.mean;
        }
        if (object.minimum !== undefined && object.minimum !== null) {
            message.minimum = object.minimum;
        }
        if (object.maximum !== undefined && object.maximum !== null) {
            message.maximum = object.maximum;
        }
        if (object.sum_of_squared_deviation !== undefined && object.sum_of_squared_deviation !== null) {
            message.sumOfSquaredDeviation = object.sum_of_squared_deviation;
        }
        message.bucketCounts = object.bucket_counts?.map(e => BigInt(e)) || [];
        if (object.linear_buckets !== undefined && object.linear_buckets !== null) {
            message.linearBuckets = exports.Distribution_LinearBuckets.fromAmino(object.linear_buckets);
        }
        if (object.exponential_buckets !== undefined && object.exponential_buckets !== null) {
            message.exponentialBuckets = exports.Distribution_ExponentialBuckets.fromAmino(object.exponential_buckets);
        }
        if (object.explicit_buckets !== undefined && object.explicit_buckets !== null) {
            message.explicitBuckets = exports.Distribution_ExplicitBuckets.fromAmino(object.explicit_buckets);
        }
        message.exemplars = object.exemplars?.map(e => distribution_1.Distribution_Exemplar.fromAmino(e)) || [];
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.count = message.count !== BigInt(0) ? message.count?.toString() : undefined;
        obj.mean = message.mean === 0 ? undefined : message.mean;
        obj.minimum = message.minimum === 0 ? undefined : message.minimum;
        obj.maximum = message.maximum === 0 ? undefined : message.maximum;
        obj.sum_of_squared_deviation = message.sumOfSquaredDeviation === 0 ? undefined : message.sumOfSquaredDeviation;
        if (message.bucketCounts) {
            obj.bucket_counts = message.bucketCounts.map(e => e.toString());
        }
        else {
            obj.bucket_counts = message.bucketCounts;
        }
        obj.linear_buckets = message.linearBuckets ? exports.Distribution_LinearBuckets.toAmino(message.linearBuckets) : undefined;
        obj.exponential_buckets = message.exponentialBuckets ? exports.Distribution_ExponentialBuckets.toAmino(message.exponentialBuckets) : undefined;
        obj.explicit_buckets = message.explicitBuckets ? exports.Distribution_ExplicitBuckets.toAmino(message.explicitBuckets) : undefined;
        if (message.exemplars) {
            obj.exemplars = message.exemplars.map(e => e ? distribution_1.Distribution_Exemplar.toAmino(e) : undefined);
        }
        else {
            obj.exemplars = message.exemplars;
        }
        return obj;
    },
    fromAminoMsg(object) {
        return exports.Distribution.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.Distribution.decode(message.value);
    },
    toProto(message) {
        return exports.Distribution.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.servicecontrol.v1.Distribution",
            value: exports.Distribution.encode(message).finish()
        };
    }
};
function createBaseDistribution_LinearBuckets() {
    return {
        numFiniteBuckets: 0,
        width: 0,
        offset: 0
    };
}
exports.Distribution_LinearBuckets = {
    typeUrl: "/google.api.servicecontrol.v1.LinearBuckets",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.numFiniteBuckets !== 0) {
            writer.uint32(8).int32(message.numFiniteBuckets);
        }
        if (message.width !== 0) {
            writer.uint32(17).double(message.width);
        }
        if (message.offset !== 0) {
            writer.uint32(25).double(message.offset);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseDistribution_LinearBuckets();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.numFiniteBuckets = reader.int32();
                    break;
                case 2:
                    message.width = reader.double();
                    break;
                case 3:
                    message.offset = reader.double();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseDistribution_LinearBuckets();
        message.numFiniteBuckets = object.numFiniteBuckets ?? 0;
        message.width = object.width ?? 0;
        message.offset = object.offset ?? 0;
        return message;
    },
    fromAmino(object) {
        const message = createBaseDistribution_LinearBuckets();
        if (object.num_finite_buckets !== undefined && object.num_finite_buckets !== null) {
            message.numFiniteBuckets = object.num_finite_buckets;
        }
        if (object.width !== undefined && object.width !== null) {
            message.width = object.width;
        }
        if (object.offset !== undefined && object.offset !== null) {
            message.offset = object.offset;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.num_finite_buckets = message.numFiniteBuckets === 0 ? undefined : message.numFiniteBuckets;
        obj.width = message.width === 0 ? undefined : message.width;
        obj.offset = message.offset === 0 ? undefined : message.offset;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.Distribution_LinearBuckets.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.Distribution_LinearBuckets.decode(message.value);
    },
    toProto(message) {
        return exports.Distribution_LinearBuckets.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.servicecontrol.v1.LinearBuckets",
            value: exports.Distribution_LinearBuckets.encode(message).finish()
        };
    }
};
function createBaseDistribution_ExponentialBuckets() {
    return {
        numFiniteBuckets: 0,
        growthFactor: 0,
        scale: 0
    };
}
exports.Distribution_ExponentialBuckets = {
    typeUrl: "/google.api.servicecontrol.v1.ExponentialBuckets",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.numFiniteBuckets !== 0) {
            writer.uint32(8).int32(message.numFiniteBuckets);
        }
        if (message.growthFactor !== 0) {
            writer.uint32(17).double(message.growthFactor);
        }
        if (message.scale !== 0) {
            writer.uint32(25).double(message.scale);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseDistribution_ExponentialBuckets();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.numFiniteBuckets = reader.int32();
                    break;
                case 2:
                    message.growthFactor = reader.double();
                    break;
                case 3:
                    message.scale = reader.double();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseDistribution_ExponentialBuckets();
        message.numFiniteBuckets = object.numFiniteBuckets ?? 0;
        message.growthFactor = object.growthFactor ?? 0;
        message.scale = object.scale ?? 0;
        return message;
    },
    fromAmino(object) {
        const message = createBaseDistribution_ExponentialBuckets();
        if (object.num_finite_buckets !== undefined && object.num_finite_buckets !== null) {
            message.numFiniteBuckets = object.num_finite_buckets;
        }
        if (object.growth_factor !== undefined && object.growth_factor !== null) {
            message.growthFactor = object.growth_factor;
        }
        if (object.scale !== undefined && object.scale !== null) {
            message.scale = object.scale;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.num_finite_buckets = message.numFiniteBuckets === 0 ? undefined : message.numFiniteBuckets;
        obj.growth_factor = message.growthFactor === 0 ? undefined : message.growthFactor;
        obj.scale = message.scale === 0 ? undefined : message.scale;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.Distribution_ExponentialBuckets.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.Distribution_ExponentialBuckets.decode(message.value);
    },
    toProto(message) {
        return exports.Distribution_ExponentialBuckets.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.servicecontrol.v1.ExponentialBuckets",
            value: exports.Distribution_ExponentialBuckets.encode(message).finish()
        };
    }
};
function createBaseDistribution_ExplicitBuckets() {
    return {
        bounds: []
    };
}
exports.Distribution_ExplicitBuckets = {
    typeUrl: "/google.api.servicecontrol.v1.ExplicitBuckets",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        writer.uint32(10).fork();
        for (const v of message.bounds) {
            writer.double(v);
        }
        writer.ldelim();
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseDistribution_ExplicitBuckets();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    if ((tag & 7) === 2) {
                        const end2 = reader.uint32() + reader.pos;
                        while (reader.pos < end2) {
                            message.bounds.push(reader.double());
                        }
                    }
                    else {
                        message.bounds.push(reader.double());
                    }
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseDistribution_ExplicitBuckets();
        message.bounds = object.bounds?.map(e => e) || [];
        return message;
    },
    fromAmino(object) {
        const message = createBaseDistribution_ExplicitBuckets();
        message.bounds = object.bounds?.map(e => e) || [];
        return message;
    },
    toAmino(message) {
        const obj = {};
        if (message.bounds) {
            obj.bounds = message.bounds.map(e => e);
        }
        else {
            obj.bounds = message.bounds;
        }
        return obj;
    },
    fromAminoMsg(object) {
        return exports.Distribution_ExplicitBuckets.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.Distribution_ExplicitBuckets.decode(message.value);
    },
    toProto(message) {
        return exports.Distribution_ExplicitBuckets.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.servicecontrol.v1.ExplicitBuckets",
            value: exports.Distribution_ExplicitBuckets.encode(message).finish()
        };
    }
};
