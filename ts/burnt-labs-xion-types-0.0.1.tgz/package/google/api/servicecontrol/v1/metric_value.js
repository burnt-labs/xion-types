"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.MetricValueSet = exports.MetricValue = exports.MetricValue_LabelsEntry = void 0;
//@ts-nocheck
const timestamp_1 = require("../../../protobuf/timestamp");
const distribution_1 = require("./distribution");
const binary_1 = require("../../../../binary");
const helpers_1 = require("../../../../helpers");
function createBaseMetricValue_LabelsEntry() {
    return {
        key: "",
        value: ""
    };
}
exports.MetricValue_LabelsEntry = {
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.key !== "") {
            writer.uint32(10).string(message.key);
        }
        if (message.value !== "") {
            writer.uint32(18).string(message.value);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseMetricValue_LabelsEntry();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.key = reader.string();
                    break;
                case 2:
                    message.value = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseMetricValue_LabelsEntry();
        message.key = object.key ?? "";
        message.value = object.value ?? "";
        return message;
    },
    fromAmino(object) {
        const message = createBaseMetricValue_LabelsEntry();
        if (object.key !== undefined && object.key !== null) {
            message.key = object.key;
        }
        if (object.value !== undefined && object.value !== null) {
            message.value = object.value;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.key = message.key === "" ? undefined : message.key;
        obj.value = message.value === "" ? undefined : message.value;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.MetricValue_LabelsEntry.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.MetricValue_LabelsEntry.decode(message.value);
    },
    toProto(message) {
        return exports.MetricValue_LabelsEntry.encode(message).finish();
    }
};
function createBaseMetricValue() {
    return {
        labels: {},
        startTime: undefined,
        endTime: undefined,
        boolValue: undefined,
        int64Value: undefined,
        doubleValue: undefined,
        stringValue: undefined,
        distributionValue: undefined
    };
}
exports.MetricValue = {
    typeUrl: "/google.api.servicecontrol.v1.MetricValue",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        Object.entries(message.labels).forEach(([key, value]) => {
            exports.MetricValue_LabelsEntry.encode({
                key: key,
                value
            }, writer.uint32(10).fork()).ldelim();
        });
        if (message.startTime !== undefined) {
            timestamp_1.Timestamp.encode((0, helpers_1.toTimestamp)(message.startTime), writer.uint32(18).fork()).ldelim();
        }
        if (message.endTime !== undefined) {
            timestamp_1.Timestamp.encode((0, helpers_1.toTimestamp)(message.endTime), writer.uint32(26).fork()).ldelim();
        }
        if (message.boolValue !== undefined) {
            writer.uint32(32).bool(message.boolValue);
        }
        if (message.int64Value !== undefined) {
            writer.uint32(40).int64(message.int64Value);
        }
        if (message.doubleValue !== undefined) {
            writer.uint32(49).double(message.doubleValue);
        }
        if (message.stringValue !== undefined) {
            writer.uint32(58).string(message.stringValue);
        }
        if (message.distributionValue !== undefined) {
            distribution_1.Distribution.encode(message.distributionValue, writer.uint32(66).fork()).ldelim();
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseMetricValue();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    const entry1 = exports.MetricValue_LabelsEntry.decode(reader, reader.uint32());
                    if (entry1.value !== undefined) {
                        message.labels[entry1.key] = entry1.value;
                    }
                    break;
                case 2:
                    message.startTime = (0, helpers_1.fromTimestamp)(timestamp_1.Timestamp.decode(reader, reader.uint32()));
                    break;
                case 3:
                    message.endTime = (0, helpers_1.fromTimestamp)(timestamp_1.Timestamp.decode(reader, reader.uint32()));
                    break;
                case 4:
                    message.boolValue = reader.bool();
                    break;
                case 5:
                    message.int64Value = reader.int64();
                    break;
                case 6:
                    message.doubleValue = reader.double();
                    break;
                case 7:
                    message.stringValue = reader.string();
                    break;
                case 8:
                    message.distributionValue = distribution_1.Distribution.decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseMetricValue();
        message.labels = Object.entries(object.labels ?? {}).reduce((acc, [key, value]) => {
            if (value !== undefined) {
                acc[key] = String(value);
            }
            return acc;
        }, {});
        message.startTime = object.startTime ?? undefined;
        message.endTime = object.endTime ?? undefined;
        message.boolValue = object.boolValue ?? undefined;
        message.int64Value = object.int64Value !== undefined && object.int64Value !== null ? BigInt(object.int64Value.toString()) : undefined;
        message.doubleValue = object.doubleValue ?? undefined;
        message.stringValue = object.stringValue ?? undefined;
        message.distributionValue = object.distributionValue !== undefined && object.distributionValue !== null ? distribution_1.Distribution.fromPartial(object.distributionValue) : undefined;
        return message;
    },
    fromAmino(object) {
        const message = createBaseMetricValue();
        message.labels = Object.entries(object.labels ?? {}).reduce((acc, [key, value]) => {
            if (value !== undefined) {
                acc[key] = String(value);
            }
            return acc;
        }, {});
        if (object.start_time !== undefined && object.start_time !== null) {
            message.startTime = (0, helpers_1.fromTimestamp)(timestamp_1.Timestamp.fromAmino(object.start_time));
        }
        if (object.end_time !== undefined && object.end_time !== null) {
            message.endTime = (0, helpers_1.fromTimestamp)(timestamp_1.Timestamp.fromAmino(object.end_time));
        }
        if (object.bool_value !== undefined && object.bool_value !== null) {
            message.boolValue = object.bool_value;
        }
        if (object.int64_value !== undefined && object.int64_value !== null) {
            message.int64Value = BigInt(object.int64_value);
        }
        if (object.double_value !== undefined && object.double_value !== null) {
            message.doubleValue = object.double_value;
        }
        if (object.string_value !== undefined && object.string_value !== null) {
            message.stringValue = object.string_value;
        }
        if (object.distribution_value !== undefined && object.distribution_value !== null) {
            message.distributionValue = distribution_1.Distribution.fromAmino(object.distribution_value);
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.labels = {};
        if (message.labels) {
            Object.entries(message.labels).forEach(([k, v]) => {
                obj.labels[k] = v;
            });
        }
        obj.start_time = message.startTime ? timestamp_1.Timestamp.toAmino((0, helpers_1.toTimestamp)(message.startTime)) : undefined;
        obj.end_time = message.endTime ? timestamp_1.Timestamp.toAmino((0, helpers_1.toTimestamp)(message.endTime)) : undefined;
        obj.bool_value = message.boolValue === null ? undefined : message.boolValue;
        obj.int64_value = message.int64Value !== BigInt(0) ? message.int64Value?.toString() : undefined;
        obj.double_value = message.doubleValue === null ? undefined : message.doubleValue;
        obj.string_value = message.stringValue === null ? undefined : message.stringValue;
        obj.distribution_value = message.distributionValue ? distribution_1.Distribution.toAmino(message.distributionValue) : undefined;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.MetricValue.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.MetricValue.decode(message.value);
    },
    toProto(message) {
        return exports.MetricValue.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.servicecontrol.v1.MetricValue",
            value: exports.MetricValue.encode(message).finish()
        };
    }
};
function createBaseMetricValueSet() {
    return {
        metricName: "",
        metricValues: []
    };
}
exports.MetricValueSet = {
    typeUrl: "/google.api.servicecontrol.v1.MetricValueSet",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.metricName !== "") {
            writer.uint32(10).string(message.metricName);
        }
        for (const v of message.metricValues) {
            exports.MetricValue.encode(v, writer.uint32(18).fork()).ldelim();
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseMetricValueSet();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.metricName = reader.string();
                    break;
                case 2:
                    message.metricValues.push(exports.MetricValue.decode(reader, reader.uint32()));
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseMetricValueSet();
        message.metricName = object.metricName ?? "";
        message.metricValues = object.metricValues?.map(e => exports.MetricValue.fromPartial(e)) || [];
        return message;
    },
    fromAmino(object) {
        const message = createBaseMetricValueSet();
        if (object.metric_name !== undefined && object.metric_name !== null) {
            message.metricName = object.metric_name;
        }
        message.metricValues = object.metric_values?.map(e => exports.MetricValue.fromAmino(e)) || [];
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.metric_name = message.metricName === "" ? undefined : message.metricName;
        if (message.metricValues) {
            obj.metric_values = message.metricValues.map(e => e ? exports.MetricValue.toAmino(e) : undefined);
        }
        else {
            obj.metric_values = message.metricValues;
        }
        return obj;
    },
    fromAminoMsg(object) {
        return exports.MetricValueSet.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.MetricValueSet.decode(message.value);
    },
    toProto(message) {
        return exports.MetricValueSet.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.servicecontrol.v1.MetricValueSet",
            value: exports.MetricValueSet.encode(message).finish()
        };
    }
};
