"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CheckError = exports.CheckError_CodeAmino = exports.CheckError_CodeSDKType = exports.CheckError_Code = void 0;
exports.checkError_CodeFromJSON = checkError_CodeFromJSON;
exports.checkError_CodeToJSON = checkError_CodeToJSON;
//@ts-nocheck
const status_1 = require("../../../rpc/status");
const binary_1 = require("../../../../binary");
/** Error codes for Check responses. */
var CheckError_Code;
(function (CheckError_Code) {
    /** ERROR_CODE_UNSPECIFIED - This is never used in `CheckResponse`. */
    CheckError_Code[CheckError_Code["ERROR_CODE_UNSPECIFIED"] = 0] = "ERROR_CODE_UNSPECIFIED";
    /**
     * NOT_FOUND - The consumer's project id, network container, or resource container was
     * not found. Same as [google.rpc.Code.NOT_FOUND][google.rpc.Code.NOT_FOUND].
     */
    CheckError_Code[CheckError_Code["NOT_FOUND"] = 5] = "NOT_FOUND";
    /**
     * PERMISSION_DENIED - The consumer doesn't have access to the specified resource.
     * Same as [google.rpc.Code.PERMISSION_DENIED][google.rpc.Code.PERMISSION_DENIED].
     */
    CheckError_Code[CheckError_Code["PERMISSION_DENIED"] = 7] = "PERMISSION_DENIED";
    /** RESOURCE_EXHAUSTED - Quota check failed. Same as [google.rpc.Code.RESOURCE_EXHAUSTED][google.rpc.Code.RESOURCE_EXHAUSTED]. */
    CheckError_Code[CheckError_Code["RESOURCE_EXHAUSTED"] = 8] = "RESOURCE_EXHAUSTED";
    /** SERVICE_NOT_ACTIVATED - The consumer hasn't activated the service. */
    CheckError_Code[CheckError_Code["SERVICE_NOT_ACTIVATED"] = 104] = "SERVICE_NOT_ACTIVATED";
    /** BILLING_DISABLED - The consumer cannot access the service because billing is disabled. */
    CheckError_Code[CheckError_Code["BILLING_DISABLED"] = 107] = "BILLING_DISABLED";
    /** PROJECT_DELETED - The consumer's project has been marked as deleted (soft deletion). */
    CheckError_Code[CheckError_Code["PROJECT_DELETED"] = 108] = "PROJECT_DELETED";
    /** PROJECT_INVALID - The consumer's project number or id does not represent a valid project. */
    CheckError_Code[CheckError_Code["PROJECT_INVALID"] = 114] = "PROJECT_INVALID";
    /**
     * CONSUMER_INVALID - The input consumer info does not represent a valid consumer folder or
     * organization.
     */
    CheckError_Code[CheckError_Code["CONSUMER_INVALID"] = 125] = "CONSUMER_INVALID";
    /**
     * IP_ADDRESS_BLOCKED - The IP address of the consumer is invalid for the specific consumer
     * project.
     */
    CheckError_Code[CheckError_Code["IP_ADDRESS_BLOCKED"] = 109] = "IP_ADDRESS_BLOCKED";
    /**
     * REFERER_BLOCKED - The referer address of the consumer request is invalid for the specific
     * consumer project.
     */
    CheckError_Code[CheckError_Code["REFERER_BLOCKED"] = 110] = "REFERER_BLOCKED";
    /**
     * CLIENT_APP_BLOCKED - The client application of the consumer request is invalid for the
     * specific consumer project.
     */
    CheckError_Code[CheckError_Code["CLIENT_APP_BLOCKED"] = 111] = "CLIENT_APP_BLOCKED";
    /**
     * API_TARGET_BLOCKED - The API targeted by this request is invalid for the specified consumer
     * project.
     */
    CheckError_Code[CheckError_Code["API_TARGET_BLOCKED"] = 122] = "API_TARGET_BLOCKED";
    /** API_KEY_INVALID - The consumer's API key is invalid. */
    CheckError_Code[CheckError_Code["API_KEY_INVALID"] = 105] = "API_KEY_INVALID";
    /** API_KEY_EXPIRED - The consumer's API Key has expired. */
    CheckError_Code[CheckError_Code["API_KEY_EXPIRED"] = 112] = "API_KEY_EXPIRED";
    /** API_KEY_NOT_FOUND - The consumer's API Key was not found in config record. */
    CheckError_Code[CheckError_Code["API_KEY_NOT_FOUND"] = 113] = "API_KEY_NOT_FOUND";
    /** INVALID_CREDENTIAL - The credential in the request can not be verified. */
    CheckError_Code[CheckError_Code["INVALID_CREDENTIAL"] = 123] = "INVALID_CREDENTIAL";
    /** NAMESPACE_LOOKUP_UNAVAILABLE - The backend server for looking up project id/number is unavailable. */
    CheckError_Code[CheckError_Code["NAMESPACE_LOOKUP_UNAVAILABLE"] = 300] = "NAMESPACE_LOOKUP_UNAVAILABLE";
    /** SERVICE_STATUS_UNAVAILABLE - The backend server for checking service status is unavailable. */
    CheckError_Code[CheckError_Code["SERVICE_STATUS_UNAVAILABLE"] = 301] = "SERVICE_STATUS_UNAVAILABLE";
    /** BILLING_STATUS_UNAVAILABLE - The backend server for checking billing status is unavailable. */
    CheckError_Code[CheckError_Code["BILLING_STATUS_UNAVAILABLE"] = 302] = "BILLING_STATUS_UNAVAILABLE";
    /** CLOUD_RESOURCE_MANAGER_BACKEND_UNAVAILABLE - Cloud Resource Manager backend server is unavailable. */
    CheckError_Code[CheckError_Code["CLOUD_RESOURCE_MANAGER_BACKEND_UNAVAILABLE"] = 305] = "CLOUD_RESOURCE_MANAGER_BACKEND_UNAVAILABLE";
    CheckError_Code[CheckError_Code["UNRECOGNIZED"] = -1] = "UNRECOGNIZED";
})(CheckError_Code || (exports.CheckError_Code = CheckError_Code = {}));
exports.CheckError_CodeSDKType = CheckError_Code;
exports.CheckError_CodeAmino = CheckError_Code;
function checkError_CodeFromJSON(object) {
    switch (object) {
        case 0:
        case "ERROR_CODE_UNSPECIFIED":
            return CheckError_Code.ERROR_CODE_UNSPECIFIED;
        case 5:
        case "NOT_FOUND":
            return CheckError_Code.NOT_FOUND;
        case 7:
        case "PERMISSION_DENIED":
            return CheckError_Code.PERMISSION_DENIED;
        case 8:
        case "RESOURCE_EXHAUSTED":
            return CheckError_Code.RESOURCE_EXHAUSTED;
        case 104:
        case "SERVICE_NOT_ACTIVATED":
            return CheckError_Code.SERVICE_NOT_ACTIVATED;
        case 107:
        case "BILLING_DISABLED":
            return CheckError_Code.BILLING_DISABLED;
        case 108:
        case "PROJECT_DELETED":
            return CheckError_Code.PROJECT_DELETED;
        case 114:
        case "PROJECT_INVALID":
            return CheckError_Code.PROJECT_INVALID;
        case 125:
        case "CONSUMER_INVALID":
            return CheckError_Code.CONSUMER_INVALID;
        case 109:
        case "IP_ADDRESS_BLOCKED":
            return CheckError_Code.IP_ADDRESS_BLOCKED;
        case 110:
        case "REFERER_BLOCKED":
            return CheckError_Code.REFERER_BLOCKED;
        case 111:
        case "CLIENT_APP_BLOCKED":
            return CheckError_Code.CLIENT_APP_BLOCKED;
        case 122:
        case "API_TARGET_BLOCKED":
            return CheckError_Code.API_TARGET_BLOCKED;
        case 105:
        case "API_KEY_INVALID":
            return CheckError_Code.API_KEY_INVALID;
        case 112:
        case "API_KEY_EXPIRED":
            return CheckError_Code.API_KEY_EXPIRED;
        case 113:
        case "API_KEY_NOT_FOUND":
            return CheckError_Code.API_KEY_NOT_FOUND;
        case 123:
        case "INVALID_CREDENTIAL":
            return CheckError_Code.INVALID_CREDENTIAL;
        case 300:
        case "NAMESPACE_LOOKUP_UNAVAILABLE":
            return CheckError_Code.NAMESPACE_LOOKUP_UNAVAILABLE;
        case 301:
        case "SERVICE_STATUS_UNAVAILABLE":
            return CheckError_Code.SERVICE_STATUS_UNAVAILABLE;
        case 302:
        case "BILLING_STATUS_UNAVAILABLE":
            return CheckError_Code.BILLING_STATUS_UNAVAILABLE;
        case 305:
        case "CLOUD_RESOURCE_MANAGER_BACKEND_UNAVAILABLE":
            return CheckError_Code.CLOUD_RESOURCE_MANAGER_BACKEND_UNAVAILABLE;
        case -1:
        case "UNRECOGNIZED":
        default:
            return CheckError_Code.UNRECOGNIZED;
    }
}
function checkError_CodeToJSON(object) {
    switch (object) {
        case CheckError_Code.ERROR_CODE_UNSPECIFIED:
            return "ERROR_CODE_UNSPECIFIED";
        case CheckError_Code.NOT_FOUND:
            return "NOT_FOUND";
        case CheckError_Code.PERMISSION_DENIED:
            return "PERMISSION_DENIED";
        case CheckError_Code.RESOURCE_EXHAUSTED:
            return "RESOURCE_EXHAUSTED";
        case CheckError_Code.SERVICE_NOT_ACTIVATED:
            return "SERVICE_NOT_ACTIVATED";
        case CheckError_Code.BILLING_DISABLED:
            return "BILLING_DISABLED";
        case CheckError_Code.PROJECT_DELETED:
            return "PROJECT_DELETED";
        case CheckError_Code.PROJECT_INVALID:
            return "PROJECT_INVALID";
        case CheckError_Code.CONSUMER_INVALID:
            return "CONSUMER_INVALID";
        case CheckError_Code.IP_ADDRESS_BLOCKED:
            return "IP_ADDRESS_BLOCKED";
        case CheckError_Code.REFERER_BLOCKED:
            return "REFERER_BLOCKED";
        case CheckError_Code.CLIENT_APP_BLOCKED:
            return "CLIENT_APP_BLOCKED";
        case CheckError_Code.API_TARGET_BLOCKED:
            return "API_TARGET_BLOCKED";
        case CheckError_Code.API_KEY_INVALID:
            return "API_KEY_INVALID";
        case CheckError_Code.API_KEY_EXPIRED:
            return "API_KEY_EXPIRED";
        case CheckError_Code.API_KEY_NOT_FOUND:
            return "API_KEY_NOT_FOUND";
        case CheckError_Code.INVALID_CREDENTIAL:
            return "INVALID_CREDENTIAL";
        case CheckError_Code.NAMESPACE_LOOKUP_UNAVAILABLE:
            return "NAMESPACE_LOOKUP_UNAVAILABLE";
        case CheckError_Code.SERVICE_STATUS_UNAVAILABLE:
            return "SERVICE_STATUS_UNAVAILABLE";
        case CheckError_Code.BILLING_STATUS_UNAVAILABLE:
            return "BILLING_STATUS_UNAVAILABLE";
        case CheckError_Code.CLOUD_RESOURCE_MANAGER_BACKEND_UNAVAILABLE:
            return "CLOUD_RESOURCE_MANAGER_BACKEND_UNAVAILABLE";
        case CheckError_Code.UNRECOGNIZED:
        default:
            return "UNRECOGNIZED";
    }
}
function createBaseCheckError() {
    return {
        code: 0,
        subject: "",
        detail: "",
        status: undefined
    };
}
exports.CheckError = {
    typeUrl: "/google.api.servicecontrol.v1.CheckError",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.code !== 0) {
            writer.uint32(8).int32(message.code);
        }
        if (message.subject !== "") {
            writer.uint32(34).string(message.subject);
        }
        if (message.detail !== "") {
            writer.uint32(18).string(message.detail);
        }
        if (message.status !== undefined) {
            status_1.Status.encode(message.status, writer.uint32(26).fork()).ldelim();
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseCheckError();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.code = reader.int32();
                    break;
                case 4:
                    message.subject = reader.string();
                    break;
                case 2:
                    message.detail = reader.string();
                    break;
                case 3:
                    message.status = status_1.Status.decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseCheckError();
        message.code = object.code ?? 0;
        message.subject = object.subject ?? "";
        message.detail = object.detail ?? "";
        message.status = object.status !== undefined && object.status !== null ? status_1.Status.fromPartial(object.status) : undefined;
        return message;
    },
    fromAmino(object) {
        const message = createBaseCheckError();
        if (object.code !== undefined && object.code !== null) {
            message.code = object.code;
        }
        if (object.subject !== undefined && object.subject !== null) {
            message.subject = object.subject;
        }
        if (object.detail !== undefined && object.detail !== null) {
            message.detail = object.detail;
        }
        if (object.status !== undefined && object.status !== null) {
            message.status = status_1.Status.fromAmino(object.status);
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.code = message.code === 0 ? undefined : message.code;
        obj.subject = message.subject === "" ? undefined : message.subject;
        obj.detail = message.detail === "" ? undefined : message.detail;
        obj.status = message.status ? status_1.Status.toAmino(message.status) : undefined;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.CheckError.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.CheckError.decode(message.value);
    },
    toProto(message) {
        return exports.CheckError.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.servicecontrol.v1.CheckError",
            value: exports.CheckError.encode(message).finish()
        };
    }
};
