"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.HttpRequest = void 0;
//@ts-nocheck
const duration_1 = require("../../../protobuf/duration");
const binary_1 = require("../../../../binary");
function createBaseHttpRequest() {
    return {
        requestMethod: "",
        requestUrl: "",
        requestSize: BigInt(0),
        status: 0,
        responseSize: BigInt(0),
        userAgent: "",
        remoteIp: "",
        serverIp: "",
        referer: "",
        latency: undefined,
        cacheLookup: false,
        cacheHit: false,
        cacheValidatedWithOriginServer: false,
        cacheFillBytes: BigInt(0),
        protocol: ""
    };
}
exports.HttpRequest = {
    typeUrl: "/google.api.servicecontrol.v1.HttpRequest",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.requestMethod !== "") {
            writer.uint32(10).string(message.requestMethod);
        }
        if (message.requestUrl !== "") {
            writer.uint32(18).string(message.requestUrl);
        }
        if (message.requestSize !== BigInt(0)) {
            writer.uint32(24).int64(message.requestSize);
        }
        if (message.status !== 0) {
            writer.uint32(32).int32(message.status);
        }
        if (message.responseSize !== BigInt(0)) {
            writer.uint32(40).int64(message.responseSize);
        }
        if (message.userAgent !== "") {
            writer.uint32(50).string(message.userAgent);
        }
        if (message.remoteIp !== "") {
            writer.uint32(58).string(message.remoteIp);
        }
        if (message.serverIp !== "") {
            writer.uint32(106).string(message.serverIp);
        }
        if (message.referer !== "") {
            writer.uint32(66).string(message.referer);
        }
        if (message.latency !== undefined) {
            duration_1.Duration.encode(message.latency, writer.uint32(114).fork()).ldelim();
        }
        if (message.cacheLookup === true) {
            writer.uint32(88).bool(message.cacheLookup);
        }
        if (message.cacheHit === true) {
            writer.uint32(72).bool(message.cacheHit);
        }
        if (message.cacheValidatedWithOriginServer === true) {
            writer.uint32(80).bool(message.cacheValidatedWithOriginServer);
        }
        if (message.cacheFillBytes !== BigInt(0)) {
            writer.uint32(96).int64(message.cacheFillBytes);
        }
        if (message.protocol !== "") {
            writer.uint32(122).string(message.protocol);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseHttpRequest();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.requestMethod = reader.string();
                    break;
                case 2:
                    message.requestUrl = reader.string();
                    break;
                case 3:
                    message.requestSize = reader.int64();
                    break;
                case 4:
                    message.status = reader.int32();
                    break;
                case 5:
                    message.responseSize = reader.int64();
                    break;
                case 6:
                    message.userAgent = reader.string();
                    break;
                case 7:
                    message.remoteIp = reader.string();
                    break;
                case 13:
                    message.serverIp = reader.string();
                    break;
                case 8:
                    message.referer = reader.string();
                    break;
                case 14:
                    message.latency = duration_1.Duration.decode(reader, reader.uint32());
                    break;
                case 11:
                    message.cacheLookup = reader.bool();
                    break;
                case 9:
                    message.cacheHit = reader.bool();
                    break;
                case 10:
                    message.cacheValidatedWithOriginServer = reader.bool();
                    break;
                case 12:
                    message.cacheFillBytes = reader.int64();
                    break;
                case 15:
                    message.protocol = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseHttpRequest();
        message.requestMethod = object.requestMethod ?? "";
        message.requestUrl = object.requestUrl ?? "";
        message.requestSize = object.requestSize !== undefined && object.requestSize !== null ? BigInt(object.requestSize.toString()) : BigInt(0);
        message.status = object.status ?? 0;
        message.responseSize = object.responseSize !== undefined && object.responseSize !== null ? BigInt(object.responseSize.toString()) : BigInt(0);
        message.userAgent = object.userAgent ?? "";
        message.remoteIp = object.remoteIp ?? "";
        message.serverIp = object.serverIp ?? "";
        message.referer = object.referer ?? "";
        message.latency = object.latency !== undefined && object.latency !== null ? duration_1.Duration.fromPartial(object.latency) : undefined;
        message.cacheLookup = object.cacheLookup ?? false;
        message.cacheHit = object.cacheHit ?? false;
        message.cacheValidatedWithOriginServer = object.cacheValidatedWithOriginServer ?? false;
        message.cacheFillBytes = object.cacheFillBytes !== undefined && object.cacheFillBytes !== null ? BigInt(object.cacheFillBytes.toString()) : BigInt(0);
        message.protocol = object.protocol ?? "";
        return message;
    },
    fromAmino(object) {
        const message = createBaseHttpRequest();
        if (object.request_method !== undefined && object.request_method !== null) {
            message.requestMethod = object.request_method;
        }
        if (object.request_url !== undefined && object.request_url !== null) {
            message.requestUrl = object.request_url;
        }
        if (object.request_size !== undefined && object.request_size !== null) {
            message.requestSize = BigInt(object.request_size);
        }
        if (object.status !== undefined && object.status !== null) {
            message.status = object.status;
        }
        if (object.response_size !== undefined && object.response_size !== null) {
            message.responseSize = BigInt(object.response_size);
        }
        if (object.user_agent !== undefined && object.user_agent !== null) {
            message.userAgent = object.user_agent;
        }
        if (object.remote_ip !== undefined && object.remote_ip !== null) {
            message.remoteIp = object.remote_ip;
        }
        if (object.server_ip !== undefined && object.server_ip !== null) {
            message.serverIp = object.server_ip;
        }
        if (object.referer !== undefined && object.referer !== null) {
            message.referer = object.referer;
        }
        if (object.latency !== undefined && object.latency !== null) {
            message.latency = duration_1.Duration.fromAmino(object.latency);
        }
        if (object.cache_lookup !== undefined && object.cache_lookup !== null) {
            message.cacheLookup = object.cache_lookup;
        }
        if (object.cache_hit !== undefined && object.cache_hit !== null) {
            message.cacheHit = object.cache_hit;
        }
        if (object.cache_validated_with_origin_server !== undefined && object.cache_validated_with_origin_server !== null) {
            message.cacheValidatedWithOriginServer = object.cache_validated_with_origin_server;
        }
        if (object.cache_fill_bytes !== undefined && object.cache_fill_bytes !== null) {
            message.cacheFillBytes = BigInt(object.cache_fill_bytes);
        }
        if (object.protocol !== undefined && object.protocol !== null) {
            message.protocol = object.protocol;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.request_method = message.requestMethod === "" ? undefined : message.requestMethod;
        obj.request_url = message.requestUrl === "" ? undefined : message.requestUrl;
        obj.request_size = message.requestSize !== BigInt(0) ? message.requestSize?.toString() : undefined;
        obj.status = message.status === 0 ? undefined : message.status;
        obj.response_size = message.responseSize !== BigInt(0) ? message.responseSize?.toString() : undefined;
        obj.user_agent = message.userAgent === "" ? undefined : message.userAgent;
        obj.remote_ip = message.remoteIp === "" ? undefined : message.remoteIp;
        obj.server_ip = message.serverIp === "" ? undefined : message.serverIp;
        obj.referer = message.referer === "" ? undefined : message.referer;
        obj.latency = message.latency ? duration_1.Duration.toAmino(message.latency) : undefined;
        obj.cache_lookup = message.cacheLookup === false ? undefined : message.cacheLookup;
        obj.cache_hit = message.cacheHit === false ? undefined : message.cacheHit;
        obj.cache_validated_with_origin_server = message.cacheValidatedWithOriginServer === false ? undefined : message.cacheValidatedWithOriginServer;
        obj.cache_fill_bytes = message.cacheFillBytes !== BigInt(0) ? message.cacheFillBytes?.toString() : undefined;
        obj.protocol = message.protocol === "" ? undefined : message.protocol;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.HttpRequest.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.HttpRequest.decode(message.value);
    },
    toProto(message) {
        return exports.HttpRequest.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.servicecontrol.v1.HttpRequest",
            value: exports.HttpRequest.encode(message).finish()
        };
    }
};
