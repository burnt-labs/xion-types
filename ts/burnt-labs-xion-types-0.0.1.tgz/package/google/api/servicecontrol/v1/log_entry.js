"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.LogEntrySourceLocation = exports.LogEntryOperation = exports.LogEntry = exports.LogEntry_LabelsEntry = void 0;
//@ts-nocheck
const timestamp_1 = require("../../../protobuf/timestamp");
const http_request_1 = require("./http_request");
const any_1 = require("../../../protobuf/any");
const struct_1 = require("../../../protobuf/struct");
const binary_1 = require("../../../../binary");
const helpers_1 = require("../../../../helpers");
function createBaseLogEntry_LabelsEntry() {
    return {
        key: "",
        value: ""
    };
}
exports.LogEntry_LabelsEntry = {
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.key !== "") {
            writer.uint32(10).string(message.key);
        }
        if (message.value !== "") {
            writer.uint32(18).string(message.value);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseLogEntry_LabelsEntry();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.key = reader.string();
                    break;
                case 2:
                    message.value = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseLogEntry_LabelsEntry();
        message.key = object.key ?? "";
        message.value = object.value ?? "";
        return message;
    },
    fromAmino(object) {
        const message = createBaseLogEntry_LabelsEntry();
        if (object.key !== undefined && object.key !== null) {
            message.key = object.key;
        }
        if (object.value !== undefined && object.value !== null) {
            message.value = object.value;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.key = message.key === "" ? undefined : message.key;
        obj.value = message.value === "" ? undefined : message.value;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.LogEntry_LabelsEntry.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.LogEntry_LabelsEntry.decode(message.value);
    },
    toProto(message) {
        return exports.LogEntry_LabelsEntry.encode(message).finish();
    }
};
function createBaseLogEntry() {
    return {
        name: "",
        timestamp: undefined,
        severity: 0,
        httpRequest: undefined,
        trace: "",
        insertId: "",
        labels: {},
        protoPayload: undefined,
        textPayload: undefined,
        structPayload: undefined,
        operation: undefined,
        sourceLocation: undefined
    };
}
exports.LogEntry = {
    typeUrl: "/google.api.servicecontrol.v1.LogEntry",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.name !== "") {
            writer.uint32(82).string(message.name);
        }
        if (message.timestamp !== undefined) {
            timestamp_1.Timestamp.encode((0, helpers_1.toTimestamp)(message.timestamp), writer.uint32(90).fork()).ldelim();
        }
        if (message.severity !== 0) {
            writer.uint32(96).int32(message.severity);
        }
        if (message.httpRequest !== undefined) {
            http_request_1.HttpRequest.encode(message.httpRequest, writer.uint32(114).fork()).ldelim();
        }
        if (message.trace !== "") {
            writer.uint32(122).string(message.trace);
        }
        if (message.insertId !== "") {
            writer.uint32(34).string(message.insertId);
        }
        Object.entries(message.labels).forEach(([key, value]) => {
            exports.LogEntry_LabelsEntry.encode({
                key: key,
                value
            }, writer.uint32(106).fork()).ldelim();
        });
        if (message.protoPayload !== undefined) {
            any_1.Any.encode(message.protoPayload, writer.uint32(18).fork()).ldelim();
        }
        if (message.textPayload !== undefined) {
            writer.uint32(26).string(message.textPayload);
        }
        if (message.structPayload !== undefined) {
            struct_1.Struct.encode(message.structPayload, writer.uint32(50).fork()).ldelim();
        }
        if (message.operation !== undefined) {
            exports.LogEntryOperation.encode(message.operation, writer.uint32(130).fork()).ldelim();
        }
        if (message.sourceLocation !== undefined) {
            exports.LogEntrySourceLocation.encode(message.sourceLocation, writer.uint32(138).fork()).ldelim();
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseLogEntry();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 10:
                    message.name = reader.string();
                    break;
                case 11:
                    message.timestamp = (0, helpers_1.fromTimestamp)(timestamp_1.Timestamp.decode(reader, reader.uint32()));
                    break;
                case 12:
                    message.severity = reader.int32();
                    break;
                case 14:
                    message.httpRequest = http_request_1.HttpRequest.decode(reader, reader.uint32());
                    break;
                case 15:
                    message.trace = reader.string();
                    break;
                case 4:
                    message.insertId = reader.string();
                    break;
                case 13:
                    const entry13 = exports.LogEntry_LabelsEntry.decode(reader, reader.uint32());
                    if (entry13.value !== undefined) {
                        message.labels[entry13.key] = entry13.value;
                    }
                    break;
                case 2:
                    message.protoPayload = any_1.Any.decode(reader, reader.uint32());
                    break;
                case 3:
                    message.textPayload = reader.string();
                    break;
                case 6:
                    message.structPayload = struct_1.Struct.decode(reader, reader.uint32());
                    break;
                case 16:
                    message.operation = exports.LogEntryOperation.decode(reader, reader.uint32());
                    break;
                case 17:
                    message.sourceLocation = exports.LogEntrySourceLocation.decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseLogEntry();
        message.name = object.name ?? "";
        message.timestamp = object.timestamp ?? undefined;
        message.severity = object.severity ?? 0;
        message.httpRequest = object.httpRequest !== undefined && object.httpRequest !== null ? http_request_1.HttpRequest.fromPartial(object.httpRequest) : undefined;
        message.trace = object.trace ?? "";
        message.insertId = object.insertId ?? "";
        message.labels = Object.entries(object.labels ?? {}).reduce((acc, [key, value]) => {
            if (value !== undefined) {
                acc[key] = String(value);
            }
            return acc;
        }, {});
        message.protoPayload = object.protoPayload !== undefined && object.protoPayload !== null ? any_1.Any.fromPartial(object.protoPayload) : undefined;
        message.textPayload = object.textPayload ?? undefined;
        message.structPayload = object.structPayload !== undefined && object.structPayload !== null ? struct_1.Struct.fromPartial(object.structPayload) : undefined;
        message.operation = object.operation !== undefined && object.operation !== null ? exports.LogEntryOperation.fromPartial(object.operation) : undefined;
        message.sourceLocation = object.sourceLocation !== undefined && object.sourceLocation !== null ? exports.LogEntrySourceLocation.fromPartial(object.sourceLocation) : undefined;
        return message;
    },
    fromAmino(object) {
        const message = createBaseLogEntry();
        if (object.name !== undefined && object.name !== null) {
            message.name = object.name;
        }
        if (object.timestamp !== undefined && object.timestamp !== null) {
            message.timestamp = (0, helpers_1.fromTimestamp)(timestamp_1.Timestamp.fromAmino(object.timestamp));
        }
        if (object.severity !== undefined && object.severity !== null) {
            message.severity = object.severity;
        }
        if (object.http_request !== undefined && object.http_request !== null) {
            message.httpRequest = http_request_1.HttpRequest.fromAmino(object.http_request);
        }
        if (object.trace !== undefined && object.trace !== null) {
            message.trace = object.trace;
        }
        if (object.insert_id !== undefined && object.insert_id !== null) {
            message.insertId = object.insert_id;
        }
        message.labels = Object.entries(object.labels ?? {}).reduce((acc, [key, value]) => {
            if (value !== undefined) {
                acc[key] = String(value);
            }
            return acc;
        }, {});
        if (object.proto_payload !== undefined && object.proto_payload !== null) {
            message.protoPayload = any_1.Any.fromAmino(object.proto_payload);
        }
        if (object.text_payload !== undefined && object.text_payload !== null) {
            message.textPayload = object.text_payload;
        }
        if (object.struct_payload !== undefined && object.struct_payload !== null) {
            message.structPayload = struct_1.Struct.fromAmino(object.struct_payload);
        }
        if (object.operation !== undefined && object.operation !== null) {
            message.operation = exports.LogEntryOperation.fromAmino(object.operation);
        }
        if (object.source_location !== undefined && object.source_location !== null) {
            message.sourceLocation = exports.LogEntrySourceLocation.fromAmino(object.source_location);
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.name = message.name === "" ? undefined : message.name;
        obj.timestamp = message.timestamp ? timestamp_1.Timestamp.toAmino((0, helpers_1.toTimestamp)(message.timestamp)) : undefined;
        obj.severity = message.severity === 0 ? undefined : message.severity;
        obj.http_request = message.httpRequest ? http_request_1.HttpRequest.toAmino(message.httpRequest) : undefined;
        obj.trace = message.trace === "" ? undefined : message.trace;
        obj.insert_id = message.insertId === "" ? undefined : message.insertId;
        obj.labels = {};
        if (message.labels) {
            Object.entries(message.labels).forEach(([k, v]) => {
                obj.labels[k] = v;
            });
        }
        obj.proto_payload = message.protoPayload ? any_1.Any.toAmino(message.protoPayload) : undefined;
        obj.text_payload = message.textPayload === null ? undefined : message.textPayload;
        obj.struct_payload = message.structPayload ? struct_1.Struct.toAmino(message.structPayload) : undefined;
        obj.operation = message.operation ? exports.LogEntryOperation.toAmino(message.operation) : undefined;
        obj.source_location = message.sourceLocation ? exports.LogEntrySourceLocation.toAmino(message.sourceLocation) : undefined;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.LogEntry.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.LogEntry.decode(message.value);
    },
    toProto(message) {
        return exports.LogEntry.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.servicecontrol.v1.LogEntry",
            value: exports.LogEntry.encode(message).finish()
        };
    }
};
function createBaseLogEntryOperation() {
    return {
        id: "",
        producer: "",
        first: false,
        last: false
    };
}
exports.LogEntryOperation = {
    typeUrl: "/google.api.servicecontrol.v1.LogEntryOperation",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.id !== "") {
            writer.uint32(10).string(message.id);
        }
        if (message.producer !== "") {
            writer.uint32(18).string(message.producer);
        }
        if (message.first === true) {
            writer.uint32(24).bool(message.first);
        }
        if (message.last === true) {
            writer.uint32(32).bool(message.last);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseLogEntryOperation();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.id = reader.string();
                    break;
                case 2:
                    message.producer = reader.string();
                    break;
                case 3:
                    message.first = reader.bool();
                    break;
                case 4:
                    message.last = reader.bool();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseLogEntryOperation();
        message.id = object.id ?? "";
        message.producer = object.producer ?? "";
        message.first = object.first ?? false;
        message.last = object.last ?? false;
        return message;
    },
    fromAmino(object) {
        const message = createBaseLogEntryOperation();
        if (object.id !== undefined && object.id !== null) {
            message.id = object.id;
        }
        if (object.producer !== undefined && object.producer !== null) {
            message.producer = object.producer;
        }
        if (object.first !== undefined && object.first !== null) {
            message.first = object.first;
        }
        if (object.last !== undefined && object.last !== null) {
            message.last = object.last;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.id = message.id === "" ? undefined : message.id;
        obj.producer = message.producer === "" ? undefined : message.producer;
        obj.first = message.first === false ? undefined : message.first;
        obj.last = message.last === false ? undefined : message.last;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.LogEntryOperation.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.LogEntryOperation.decode(message.value);
    },
    toProto(message) {
        return exports.LogEntryOperation.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.servicecontrol.v1.LogEntryOperation",
            value: exports.LogEntryOperation.encode(message).finish()
        };
    }
};
function createBaseLogEntrySourceLocation() {
    return {
        file: "",
        line: BigInt(0),
        function: ""
    };
}
exports.LogEntrySourceLocation = {
    typeUrl: "/google.api.servicecontrol.v1.LogEntrySourceLocation",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.file !== "") {
            writer.uint32(10).string(message.file);
        }
        if (message.line !== BigInt(0)) {
            writer.uint32(16).int64(message.line);
        }
        if (message.function !== "") {
            writer.uint32(26).string(message.function);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseLogEntrySourceLocation();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.file = reader.string();
                    break;
                case 2:
                    message.line = reader.int64();
                    break;
                case 3:
                    message.function = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseLogEntrySourceLocation();
        message.file = object.file ?? "";
        message.line = object.line !== undefined && object.line !== null ? BigInt(object.line.toString()) : BigInt(0);
        message.function = object.function ?? "";
        return message;
    },
    fromAmino(object) {
        const message = createBaseLogEntrySourceLocation();
        if (object.file !== undefined && object.file !== null) {
            message.file = object.file;
        }
        if (object.line !== undefined && object.line !== null) {
            message.line = BigInt(object.line);
        }
        if (object.function !== undefined && object.function !== null) {
            message.function = object.function;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.file = message.file === "" ? undefined : message.file;
        obj.line = message.line !== BigInt(0) ? message.line?.toString() : undefined;
        obj.function = message.function === "" ? undefined : message.function;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.LogEntrySourceLocation.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.LogEntrySourceLocation.decode(message.value);
    },
    toProto(message) {
        return exports.LogEntrySourceLocation.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.servicecontrol.v1.LogEntrySourceLocation",
            value: exports.LogEntrySourceLocation.encode(message).finish()
        };
    }
};
