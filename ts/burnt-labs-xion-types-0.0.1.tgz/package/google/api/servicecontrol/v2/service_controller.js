"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ResourceInfoList = exports.ReportResponse = exports.ReportRequest = exports.CheckResponse = exports.CheckResponse_HeadersEntry = exports.ResourceInfo = exports.CheckRequest = void 0;
//@ts-nocheck
const attribute_context_1 = require("../../../rpc/context/attribute_context");
const status_1 = require("../../../rpc/status");
const binary_1 = require("../../../../binary");
function createBaseCheckRequest() {
    return {
        serviceName: "",
        serviceConfigId: "",
        attributes: undefined,
        resources: [],
        flags: ""
    };
}
exports.CheckRequest = {
    typeUrl: "/google.api.servicecontrol.v2.CheckRequest",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.serviceName !== "") {
            writer.uint32(10).string(message.serviceName);
        }
        if (message.serviceConfigId !== "") {
            writer.uint32(18).string(message.serviceConfigId);
        }
        if (message.attributes !== undefined) {
            attribute_context_1.AttributeContext.encode(message.attributes, writer.uint32(26).fork()).ldelim();
        }
        for (const v of message.resources) {
            exports.ResourceInfo.encode(v, writer.uint32(34).fork()).ldelim();
        }
        if (message.flags !== "") {
            writer.uint32(42).string(message.flags);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseCheckRequest();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.serviceName = reader.string();
                    break;
                case 2:
                    message.serviceConfigId = reader.string();
                    break;
                case 3:
                    message.attributes = attribute_context_1.AttributeContext.decode(reader, reader.uint32());
                    break;
                case 4:
                    message.resources.push(exports.ResourceInfo.decode(reader, reader.uint32()));
                    break;
                case 5:
                    message.flags = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseCheckRequest();
        message.serviceName = object.serviceName ?? "";
        message.serviceConfigId = object.serviceConfigId ?? "";
        message.attributes = object.attributes !== undefined && object.attributes !== null ? attribute_context_1.AttributeContext.fromPartial(object.attributes) : undefined;
        message.resources = object.resources?.map(e => exports.ResourceInfo.fromPartial(e)) || [];
        message.flags = object.flags ?? "";
        return message;
    },
    fromAmino(object) {
        const message = createBaseCheckRequest();
        if (object.service_name !== undefined && object.service_name !== null) {
            message.serviceName = object.service_name;
        }
        if (object.service_config_id !== undefined && object.service_config_id !== null) {
            message.serviceConfigId = object.service_config_id;
        }
        if (object.attributes !== undefined && object.attributes !== null) {
            message.attributes = attribute_context_1.AttributeContext.fromAmino(object.attributes);
        }
        message.resources = object.resources?.map(e => exports.ResourceInfo.fromAmino(e)) || [];
        if (object.flags !== undefined && object.flags !== null) {
            message.flags = object.flags;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.service_name = message.serviceName === "" ? undefined : message.serviceName;
        obj.service_config_id = message.serviceConfigId === "" ? undefined : message.serviceConfigId;
        obj.attributes = message.attributes ? attribute_context_1.AttributeContext.toAmino(message.attributes) : undefined;
        if (message.resources) {
            obj.resources = message.resources.map(e => e ? exports.ResourceInfo.toAmino(e) : undefined);
        }
        else {
            obj.resources = message.resources;
        }
        obj.flags = message.flags === "" ? undefined : message.flags;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.CheckRequest.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.CheckRequest.decode(message.value);
    },
    toProto(message) {
        return exports.CheckRequest.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.servicecontrol.v2.CheckRequest",
            value: exports.CheckRequest.encode(message).finish()
        };
    }
};
function createBaseResourceInfo() {
    return {
        name: "",
        type: "",
        permission: "",
        container: "",
        location: ""
    };
}
exports.ResourceInfo = {
    typeUrl: "/google.api.servicecontrol.v2.ResourceInfo",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.name !== "") {
            writer.uint32(10).string(message.name);
        }
        if (message.type !== "") {
            writer.uint32(18).string(message.type);
        }
        if (message.permission !== "") {
            writer.uint32(26).string(message.permission);
        }
        if (message.container !== "") {
            writer.uint32(34).string(message.container);
        }
        if (message.location !== "") {
            writer.uint32(42).string(message.location);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseResourceInfo();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.name = reader.string();
                    break;
                case 2:
                    message.type = reader.string();
                    break;
                case 3:
                    message.permission = reader.string();
                    break;
                case 4:
                    message.container = reader.string();
                    break;
                case 5:
                    message.location = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseResourceInfo();
        message.name = object.name ?? "";
        message.type = object.type ?? "";
        message.permission = object.permission ?? "";
        message.container = object.container ?? "";
        message.location = object.location ?? "";
        return message;
    },
    fromAmino(object) {
        const message = createBaseResourceInfo();
        if (object.name !== undefined && object.name !== null) {
            message.name = object.name;
        }
        if (object.type !== undefined && object.type !== null) {
            message.type = object.type;
        }
        if (object.permission !== undefined && object.permission !== null) {
            message.permission = object.permission;
        }
        if (object.container !== undefined && object.container !== null) {
            message.container = object.container;
        }
        if (object.location !== undefined && object.location !== null) {
            message.location = object.location;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.name = message.name === "" ? undefined : message.name;
        obj.type = message.type === "" ? undefined : message.type;
        obj.permission = message.permission === "" ? undefined : message.permission;
        obj.container = message.container === "" ? undefined : message.container;
        obj.location = message.location === "" ? undefined : message.location;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.ResourceInfo.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.ResourceInfo.decode(message.value);
    },
    toProto(message) {
        return exports.ResourceInfo.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.servicecontrol.v2.ResourceInfo",
            value: exports.ResourceInfo.encode(message).finish()
        };
    }
};
function createBaseCheckResponse_HeadersEntry() {
    return {
        key: "",
        value: ""
    };
}
exports.CheckResponse_HeadersEntry = {
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.key !== "") {
            writer.uint32(10).string(message.key);
        }
        if (message.value !== "") {
            writer.uint32(18).string(message.value);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseCheckResponse_HeadersEntry();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.key = reader.string();
                    break;
                case 2:
                    message.value = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseCheckResponse_HeadersEntry();
        message.key = object.key ?? "";
        message.value = object.value ?? "";
        return message;
    },
    fromAmino(object) {
        const message = createBaseCheckResponse_HeadersEntry();
        if (object.key !== undefined && object.key !== null) {
            message.key = object.key;
        }
        if (object.value !== undefined && object.value !== null) {
            message.value = object.value;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.key = message.key === "" ? undefined : message.key;
        obj.value = message.value === "" ? undefined : message.value;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.CheckResponse_HeadersEntry.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.CheckResponse_HeadersEntry.decode(message.value);
    },
    toProto(message) {
        return exports.CheckResponse_HeadersEntry.encode(message).finish();
    }
};
function createBaseCheckResponse() {
    return {
        status: undefined,
        headers: {}
    };
}
exports.CheckResponse = {
    typeUrl: "/google.api.servicecontrol.v2.CheckResponse",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.status !== undefined) {
            status_1.Status.encode(message.status, writer.uint32(10).fork()).ldelim();
        }
        Object.entries(message.headers).forEach(([key, value]) => {
            exports.CheckResponse_HeadersEntry.encode({
                key: key,
                value
            }, writer.uint32(18).fork()).ldelim();
        });
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseCheckResponse();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.status = status_1.Status.decode(reader, reader.uint32());
                    break;
                case 2:
                    const entry2 = exports.CheckResponse_HeadersEntry.decode(reader, reader.uint32());
                    if (entry2.value !== undefined) {
                        message.headers[entry2.key] = entry2.value;
                    }
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseCheckResponse();
        message.status = object.status !== undefined && object.status !== null ? status_1.Status.fromPartial(object.status) : undefined;
        message.headers = Object.entries(object.headers ?? {}).reduce((acc, [key, value]) => {
            if (value !== undefined) {
                acc[key] = String(value);
            }
            return acc;
        }, {});
        return message;
    },
    fromAmino(object) {
        const message = createBaseCheckResponse();
        if (object.status !== undefined && object.status !== null) {
            message.status = status_1.Status.fromAmino(object.status);
        }
        message.headers = Object.entries(object.headers ?? {}).reduce((acc, [key, value]) => {
            if (value !== undefined) {
                acc[key] = String(value);
            }
            return acc;
        }, {});
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.status = message.status ? status_1.Status.toAmino(message.status) : undefined;
        obj.headers = {};
        if (message.headers) {
            Object.entries(message.headers).forEach(([k, v]) => {
                obj.headers[k] = v;
            });
        }
        return obj;
    },
    fromAminoMsg(object) {
        return exports.CheckResponse.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.CheckResponse.decode(message.value);
    },
    toProto(message) {
        return exports.CheckResponse.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.servicecontrol.v2.CheckResponse",
            value: exports.CheckResponse.encode(message).finish()
        };
    }
};
function createBaseReportRequest() {
    return {
        serviceName: "",
        serviceConfigId: "",
        operations: []
    };
}
exports.ReportRequest = {
    typeUrl: "/google.api.servicecontrol.v2.ReportRequest",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.serviceName !== "") {
            writer.uint32(10).string(message.serviceName);
        }
        if (message.serviceConfigId !== "") {
            writer.uint32(18).string(message.serviceConfigId);
        }
        for (const v of message.operations) {
            attribute_context_1.AttributeContext.encode(v, writer.uint32(26).fork()).ldelim();
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseReportRequest();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.serviceName = reader.string();
                    break;
                case 2:
                    message.serviceConfigId = reader.string();
                    break;
                case 3:
                    message.operations.push(attribute_context_1.AttributeContext.decode(reader, reader.uint32()));
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseReportRequest();
        message.serviceName = object.serviceName ?? "";
        message.serviceConfigId = object.serviceConfigId ?? "";
        message.operations = object.operations?.map(e => attribute_context_1.AttributeContext.fromPartial(e)) || [];
        return message;
    },
    fromAmino(object) {
        const message = createBaseReportRequest();
        if (object.service_name !== undefined && object.service_name !== null) {
            message.serviceName = object.service_name;
        }
        if (object.service_config_id !== undefined && object.service_config_id !== null) {
            message.serviceConfigId = object.service_config_id;
        }
        message.operations = object.operations?.map(e => attribute_context_1.AttributeContext.fromAmino(e)) || [];
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.service_name = message.serviceName === "" ? undefined : message.serviceName;
        obj.service_config_id = message.serviceConfigId === "" ? undefined : message.serviceConfigId;
        if (message.operations) {
            obj.operations = message.operations.map(e => e ? attribute_context_1.AttributeContext.toAmino(e) : undefined);
        }
        else {
            obj.operations = message.operations;
        }
        return obj;
    },
    fromAminoMsg(object) {
        return exports.ReportRequest.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.ReportRequest.decode(message.value);
    },
    toProto(message) {
        return exports.ReportRequest.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.servicecontrol.v2.ReportRequest",
            value: exports.ReportRequest.encode(message).finish()
        };
    }
};
function createBaseReportResponse() {
    return {};
}
exports.ReportResponse = {
    typeUrl: "/google.api.servicecontrol.v2.ReportResponse",
    encode(_, writer = binary_1.BinaryWriter.create()) {
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseReportResponse();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(_) {
        const message = createBaseReportResponse();
        return message;
    },
    fromAmino(_) {
        const message = createBaseReportResponse();
        return message;
    },
    toAmino(_) {
        const obj = {};
        return obj;
    },
    fromAminoMsg(object) {
        return exports.ReportResponse.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.ReportResponse.decode(message.value);
    },
    toProto(message) {
        return exports.ReportResponse.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.servicecontrol.v2.ReportResponse",
            value: exports.ReportResponse.encode(message).finish()
        };
    }
};
function createBaseResourceInfoList() {
    return {
        resources: []
    };
}
exports.ResourceInfoList = {
    typeUrl: "/google.api.servicecontrol.v2.ResourceInfoList",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        for (const v of message.resources) {
            exports.ResourceInfo.encode(v, writer.uint32(10).fork()).ldelim();
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseResourceInfoList();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.resources.push(exports.ResourceInfo.decode(reader, reader.uint32()));
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseResourceInfoList();
        message.resources = object.resources?.map(e => exports.ResourceInfo.fromPartial(e)) || [];
        return message;
    },
    fromAmino(object) {
        const message = createBaseResourceInfoList();
        message.resources = object.resources?.map(e => exports.ResourceInfo.fromAmino(e)) || [];
        return message;
    },
    toAmino(message) {
        const obj = {};
        if (message.resources) {
            obj.resources = message.resources.map(e => e ? exports.ResourceInfo.toAmino(e) : undefined);
        }
        else {
            obj.resources = message.resources;
        }
        return obj;
    },
    fromAminoMsg(object) {
        return exports.ResourceInfoList.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.ResourceInfoList.decode(message.value);
    },
    toProto(message) {
        return exports.ResourceInfoList.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.servicecontrol.v2.ResourceInfoList",
            value: exports.ResourceInfoList.encode(message).finish()
        };
    }
};
