"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.RolloutInfo = exports.QuotaDetails = exports.DimensionsInfo = exports.DimensionsInfo_DimensionsEntry = exports.QuotaConfig = exports.QuotaConfig_AnnotationsEntry = exports.QuotaPreference = exports.QuotaPreference_DimensionsEntry = exports.QuotaIncreaseEligibility = exports.QuotaInfo = exports.QuotaConfig_OriginAmino = exports.QuotaConfig_OriginSDKType = exports.QuotaConfig_Origin = exports.QuotaIncreaseEligibility_IneligibilityReasonAmino = exports.QuotaIncreaseEligibility_IneligibilityReasonSDKType = exports.QuotaIncreaseEligibility_IneligibilityReason = exports.QuotaInfo_ContainerTypeAmino = exports.QuotaInfo_ContainerTypeSDKType = exports.QuotaInfo_ContainerType = exports.QuotaSafetyCheckAmino = exports.QuotaSafetyCheckSDKType = exports.QuotaSafetyCheck = void 0;
exports.quotaSafetyCheckFromJSON = quotaSafetyCheckFromJSON;
exports.quotaSafetyCheckToJSON = quotaSafetyCheckToJSON;
exports.quotaInfo_ContainerTypeFromJSON = quotaInfo_ContainerTypeFromJSON;
exports.quotaInfo_ContainerTypeToJSON = quotaInfo_ContainerTypeToJSON;
exports.quotaIncreaseEligibility_IneligibilityReasonFromJSON = quotaIncreaseEligibility_IneligibilityReasonFromJSON;
exports.quotaIncreaseEligibility_IneligibilityReasonToJSON = quotaIncreaseEligibility_IneligibilityReasonToJSON;
exports.quotaConfig_OriginFromJSON = quotaConfig_OriginFromJSON;
exports.quotaConfig_OriginToJSON = quotaConfig_OriginToJSON;
//@ts-nocheck
const timestamp_1 = require("../../../protobuf/timestamp");
const wrappers_1 = require("../../../protobuf/wrappers");
const binary_1 = require("../../../../binary");
const helpers_1 = require("../../../../helpers");
/** Enumerations of quota safety checks. */
var QuotaSafetyCheck;
(function (QuotaSafetyCheck) {
    /** QUOTA_SAFETY_CHECK_UNSPECIFIED - Unspecified quota safety check. */
    QuotaSafetyCheck[QuotaSafetyCheck["QUOTA_SAFETY_CHECK_UNSPECIFIED"] = 0] = "QUOTA_SAFETY_CHECK_UNSPECIFIED";
    /**
     * QUOTA_DECREASE_BELOW_USAGE - Validates that a quota mutation would not cause the consumer's effective
     * limit to be lower than the consumer's quota usage.
     */
    QuotaSafetyCheck[QuotaSafetyCheck["QUOTA_DECREASE_BELOW_USAGE"] = 1] = "QUOTA_DECREASE_BELOW_USAGE";
    /**
     * QUOTA_DECREASE_PERCENTAGE_TOO_HIGH - Validates that a quota mutation would not cause the consumer's effective
     * limit to decrease by more than 10 percent.
     */
    QuotaSafetyCheck[QuotaSafetyCheck["QUOTA_DECREASE_PERCENTAGE_TOO_HIGH"] = 2] = "QUOTA_DECREASE_PERCENTAGE_TOO_HIGH";
    QuotaSafetyCheck[QuotaSafetyCheck["UNRECOGNIZED"] = -1] = "UNRECOGNIZED";
})(QuotaSafetyCheck || (exports.QuotaSafetyCheck = QuotaSafetyCheck = {}));
exports.QuotaSafetyCheckSDKType = QuotaSafetyCheck;
exports.QuotaSafetyCheckAmino = QuotaSafetyCheck;
function quotaSafetyCheckFromJSON(object) {
    switch (object) {
        case 0:
        case "QUOTA_SAFETY_CHECK_UNSPECIFIED":
            return QuotaSafetyCheck.QUOTA_SAFETY_CHECK_UNSPECIFIED;
        case 1:
        case "QUOTA_DECREASE_BELOW_USAGE":
            return QuotaSafetyCheck.QUOTA_DECREASE_BELOW_USAGE;
        case 2:
        case "QUOTA_DECREASE_PERCENTAGE_TOO_HIGH":
            return QuotaSafetyCheck.QUOTA_DECREASE_PERCENTAGE_TOO_HIGH;
        case -1:
        case "UNRECOGNIZED":
        default:
            return QuotaSafetyCheck.UNRECOGNIZED;
    }
}
function quotaSafetyCheckToJSON(object) {
    switch (object) {
        case QuotaSafetyCheck.QUOTA_SAFETY_CHECK_UNSPECIFIED:
            return "QUOTA_SAFETY_CHECK_UNSPECIFIED";
        case QuotaSafetyCheck.QUOTA_DECREASE_BELOW_USAGE:
            return "QUOTA_DECREASE_BELOW_USAGE";
        case QuotaSafetyCheck.QUOTA_DECREASE_PERCENTAGE_TOO_HIGH:
            return "QUOTA_DECREASE_PERCENTAGE_TOO_HIGH";
        case QuotaSafetyCheck.UNRECOGNIZED:
        default:
            return "UNRECOGNIZED";
    }
}
/** The enumeration of the types of a cloud resource container. */
var QuotaInfo_ContainerType;
(function (QuotaInfo_ContainerType) {
    /** CONTAINER_TYPE_UNSPECIFIED - Unspecified container type. */
    QuotaInfo_ContainerType[QuotaInfo_ContainerType["CONTAINER_TYPE_UNSPECIFIED"] = 0] = "CONTAINER_TYPE_UNSPECIFIED";
    /** PROJECT - consumer project */
    QuotaInfo_ContainerType[QuotaInfo_ContainerType["PROJECT"] = 1] = "PROJECT";
    /** FOLDER - folder */
    QuotaInfo_ContainerType[QuotaInfo_ContainerType["FOLDER"] = 2] = "FOLDER";
    /** ORGANIZATION - organization */
    QuotaInfo_ContainerType[QuotaInfo_ContainerType["ORGANIZATION"] = 3] = "ORGANIZATION";
    QuotaInfo_ContainerType[QuotaInfo_ContainerType["UNRECOGNIZED"] = -1] = "UNRECOGNIZED";
})(QuotaInfo_ContainerType || (exports.QuotaInfo_ContainerType = QuotaInfo_ContainerType = {}));
exports.QuotaInfo_ContainerTypeSDKType = QuotaInfo_ContainerType;
exports.QuotaInfo_ContainerTypeAmino = QuotaInfo_ContainerType;
function quotaInfo_ContainerTypeFromJSON(object) {
    switch (object) {
        case 0:
        case "CONTAINER_TYPE_UNSPECIFIED":
            return QuotaInfo_ContainerType.CONTAINER_TYPE_UNSPECIFIED;
        case 1:
        case "PROJECT":
            return QuotaInfo_ContainerType.PROJECT;
        case 2:
        case "FOLDER":
            return QuotaInfo_ContainerType.FOLDER;
        case 3:
        case "ORGANIZATION":
            return QuotaInfo_ContainerType.ORGANIZATION;
        case -1:
        case "UNRECOGNIZED":
        default:
            return QuotaInfo_ContainerType.UNRECOGNIZED;
    }
}
function quotaInfo_ContainerTypeToJSON(object) {
    switch (object) {
        case QuotaInfo_ContainerType.CONTAINER_TYPE_UNSPECIFIED:
            return "CONTAINER_TYPE_UNSPECIFIED";
        case QuotaInfo_ContainerType.PROJECT:
            return "PROJECT";
        case QuotaInfo_ContainerType.FOLDER:
            return "FOLDER";
        case QuotaInfo_ContainerType.ORGANIZATION:
            return "ORGANIZATION";
        case QuotaInfo_ContainerType.UNRECOGNIZED:
        default:
            return "UNRECOGNIZED";
    }
}
/**
 * The enumeration of reasons when it is ineligible to request increase
 * adjustment.
 */
var QuotaIncreaseEligibility_IneligibilityReason;
(function (QuotaIncreaseEligibility_IneligibilityReason) {
    /** INELIGIBILITY_REASON_UNSPECIFIED - Default value when is_eligible is true. */
    QuotaIncreaseEligibility_IneligibilityReason[QuotaIncreaseEligibility_IneligibilityReason["INELIGIBILITY_REASON_UNSPECIFIED"] = 0] = "INELIGIBILITY_REASON_UNSPECIFIED";
    /** NO_VALID_BILLING_ACCOUNT - The container is not linked with a valid billing account. */
    QuotaIncreaseEligibility_IneligibilityReason[QuotaIncreaseEligibility_IneligibilityReason["NO_VALID_BILLING_ACCOUNT"] = 1] = "NO_VALID_BILLING_ACCOUNT";
    /** NOT_SUPPORTED - Quota increase is not supported for the quota. */
    QuotaIncreaseEligibility_IneligibilityReason[QuotaIncreaseEligibility_IneligibilityReason["NOT_SUPPORTED"] = 3] = "NOT_SUPPORTED";
    /** NOT_ENOUGH_USAGE_HISTORY - There is not enough usage history to determine the eligibility. */
    QuotaIncreaseEligibility_IneligibilityReason[QuotaIncreaseEligibility_IneligibilityReason["NOT_ENOUGH_USAGE_HISTORY"] = 4] = "NOT_ENOUGH_USAGE_HISTORY";
    /** OTHER - Other reasons. */
    QuotaIncreaseEligibility_IneligibilityReason[QuotaIncreaseEligibility_IneligibilityReason["OTHER"] = 2] = "OTHER";
    QuotaIncreaseEligibility_IneligibilityReason[QuotaIncreaseEligibility_IneligibilityReason["UNRECOGNIZED"] = -1] = "UNRECOGNIZED";
})(QuotaIncreaseEligibility_IneligibilityReason || (exports.QuotaIncreaseEligibility_IneligibilityReason = QuotaIncreaseEligibility_IneligibilityReason = {}));
exports.QuotaIncreaseEligibility_IneligibilityReasonSDKType = QuotaIncreaseEligibility_IneligibilityReason;
exports.QuotaIncreaseEligibility_IneligibilityReasonAmino = QuotaIncreaseEligibility_IneligibilityReason;
function quotaIncreaseEligibility_IneligibilityReasonFromJSON(object) {
    switch (object) {
        case 0:
        case "INELIGIBILITY_REASON_UNSPECIFIED":
            return QuotaIncreaseEligibility_IneligibilityReason.INELIGIBILITY_REASON_UNSPECIFIED;
        case 1:
        case "NO_VALID_BILLING_ACCOUNT":
            return QuotaIncreaseEligibility_IneligibilityReason.NO_VALID_BILLING_ACCOUNT;
        case 3:
        case "NOT_SUPPORTED":
            return QuotaIncreaseEligibility_IneligibilityReason.NOT_SUPPORTED;
        case 4:
        case "NOT_ENOUGH_USAGE_HISTORY":
            return QuotaIncreaseEligibility_IneligibilityReason.NOT_ENOUGH_USAGE_HISTORY;
        case 2:
        case "OTHER":
            return QuotaIncreaseEligibility_IneligibilityReason.OTHER;
        case -1:
        case "UNRECOGNIZED":
        default:
            return QuotaIncreaseEligibility_IneligibilityReason.UNRECOGNIZED;
    }
}
function quotaIncreaseEligibility_IneligibilityReasonToJSON(object) {
    switch (object) {
        case QuotaIncreaseEligibility_IneligibilityReason.INELIGIBILITY_REASON_UNSPECIFIED:
            return "INELIGIBILITY_REASON_UNSPECIFIED";
        case QuotaIncreaseEligibility_IneligibilityReason.NO_VALID_BILLING_ACCOUNT:
            return "NO_VALID_BILLING_ACCOUNT";
        case QuotaIncreaseEligibility_IneligibilityReason.NOT_SUPPORTED:
            return "NOT_SUPPORTED";
        case QuotaIncreaseEligibility_IneligibilityReason.NOT_ENOUGH_USAGE_HISTORY:
            return "NOT_ENOUGH_USAGE_HISTORY";
        case QuotaIncreaseEligibility_IneligibilityReason.OTHER:
            return "OTHER";
        case QuotaIncreaseEligibility_IneligibilityReason.UNRECOGNIZED:
        default:
            return "UNRECOGNIZED";
    }
}
/** The enumeration of the origins of quota preference requests. */
var QuotaConfig_Origin;
(function (QuotaConfig_Origin) {
    /** ORIGIN_UNSPECIFIED - The unspecified value. */
    QuotaConfig_Origin[QuotaConfig_Origin["ORIGIN_UNSPECIFIED"] = 0] = "ORIGIN_UNSPECIFIED";
    /** CLOUD_CONSOLE - Created through Cloud Console. */
    QuotaConfig_Origin[QuotaConfig_Origin["CLOUD_CONSOLE"] = 1] = "CLOUD_CONSOLE";
    /** AUTO_ADJUSTER - Generated by automatic quota adjustment. */
    QuotaConfig_Origin[QuotaConfig_Origin["AUTO_ADJUSTER"] = 2] = "AUTO_ADJUSTER";
    QuotaConfig_Origin[QuotaConfig_Origin["UNRECOGNIZED"] = -1] = "UNRECOGNIZED";
})(QuotaConfig_Origin || (exports.QuotaConfig_Origin = QuotaConfig_Origin = {}));
exports.QuotaConfig_OriginSDKType = QuotaConfig_Origin;
exports.QuotaConfig_OriginAmino = QuotaConfig_Origin;
function quotaConfig_OriginFromJSON(object) {
    switch (object) {
        case 0:
        case "ORIGIN_UNSPECIFIED":
            return QuotaConfig_Origin.ORIGIN_UNSPECIFIED;
        case 1:
        case "CLOUD_CONSOLE":
            return QuotaConfig_Origin.CLOUD_CONSOLE;
        case 2:
        case "AUTO_ADJUSTER":
            return QuotaConfig_Origin.AUTO_ADJUSTER;
        case -1:
        case "UNRECOGNIZED":
        default:
            return QuotaConfig_Origin.UNRECOGNIZED;
    }
}
function quotaConfig_OriginToJSON(object) {
    switch (object) {
        case QuotaConfig_Origin.ORIGIN_UNSPECIFIED:
            return "ORIGIN_UNSPECIFIED";
        case QuotaConfig_Origin.CLOUD_CONSOLE:
            return "CLOUD_CONSOLE";
        case QuotaConfig_Origin.AUTO_ADJUSTER:
            return "AUTO_ADJUSTER";
        case QuotaConfig_Origin.UNRECOGNIZED:
        default:
            return "UNRECOGNIZED";
    }
}
function createBaseQuotaInfo() {
    return {
        name: "",
        quotaId: "",
        metric: "",
        service: "",
        isPrecise: false,
        refreshInterval: "",
        containerType: 0,
        dimensions: [],
        metricDisplayName: "",
        quotaDisplayName: "",
        metricUnit: "",
        quotaIncreaseEligibility: undefined,
        isFixed: false,
        dimensionsInfos: [],
        isConcurrent: false,
        serviceRequestQuotaUri: ""
    };
}
exports.QuotaInfo = {
    typeUrl: "/google.api.cloudquotas.v1beta.QuotaInfo",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.name !== "") {
            writer.uint32(10).string(message.name);
        }
        if (message.quotaId !== "") {
            writer.uint32(18).string(message.quotaId);
        }
        if (message.metric !== "") {
            writer.uint32(26).string(message.metric);
        }
        if (message.service !== "") {
            writer.uint32(34).string(message.service);
        }
        if (message.isPrecise === true) {
            writer.uint32(40).bool(message.isPrecise);
        }
        if (message.refreshInterval !== "") {
            writer.uint32(50).string(message.refreshInterval);
        }
        if (message.containerType !== 0) {
            writer.uint32(56).int32(message.containerType);
        }
        for (const v of message.dimensions) {
            writer.uint32(66).string(v);
        }
        if (message.metricDisplayName !== "") {
            writer.uint32(74).string(message.metricDisplayName);
        }
        if (message.quotaDisplayName !== "") {
            writer.uint32(82).string(message.quotaDisplayName);
        }
        if (message.metricUnit !== "") {
            writer.uint32(90).string(message.metricUnit);
        }
        if (message.quotaIncreaseEligibility !== undefined) {
            exports.QuotaIncreaseEligibility.encode(message.quotaIncreaseEligibility, writer.uint32(98).fork()).ldelim();
        }
        if (message.isFixed === true) {
            writer.uint32(104).bool(message.isFixed);
        }
        for (const v of message.dimensionsInfos) {
            exports.DimensionsInfo.encode(v, writer.uint32(114).fork()).ldelim();
        }
        if (message.isConcurrent === true) {
            writer.uint32(120).bool(message.isConcurrent);
        }
        if (message.serviceRequestQuotaUri !== "") {
            writer.uint32(138).string(message.serviceRequestQuotaUri);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseQuotaInfo();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.name = reader.string();
                    break;
                case 2:
                    message.quotaId = reader.string();
                    break;
                case 3:
                    message.metric = reader.string();
                    break;
                case 4:
                    message.service = reader.string();
                    break;
                case 5:
                    message.isPrecise = reader.bool();
                    break;
                case 6:
                    message.refreshInterval = reader.string();
                    break;
                case 7:
                    message.containerType = reader.int32();
                    break;
                case 8:
                    message.dimensions.push(reader.string());
                    break;
                case 9:
                    message.metricDisplayName = reader.string();
                    break;
                case 10:
                    message.quotaDisplayName = reader.string();
                    break;
                case 11:
                    message.metricUnit = reader.string();
                    break;
                case 12:
                    message.quotaIncreaseEligibility = exports.QuotaIncreaseEligibility.decode(reader, reader.uint32());
                    break;
                case 13:
                    message.isFixed = reader.bool();
                    break;
                case 14:
                    message.dimensionsInfos.push(exports.DimensionsInfo.decode(reader, reader.uint32()));
                    break;
                case 15:
                    message.isConcurrent = reader.bool();
                    break;
                case 17:
                    message.serviceRequestQuotaUri = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseQuotaInfo();
        message.name = object.name ?? "";
        message.quotaId = object.quotaId ?? "";
        message.metric = object.metric ?? "";
        message.service = object.service ?? "";
        message.isPrecise = object.isPrecise ?? false;
        message.refreshInterval = object.refreshInterval ?? "";
        message.containerType = object.containerType ?? 0;
        message.dimensions = object.dimensions?.map(e => e) || [];
        message.metricDisplayName = object.metricDisplayName ?? "";
        message.quotaDisplayName = object.quotaDisplayName ?? "";
        message.metricUnit = object.metricUnit ?? "";
        message.quotaIncreaseEligibility = object.quotaIncreaseEligibility !== undefined && object.quotaIncreaseEligibility !== null ? exports.QuotaIncreaseEligibility.fromPartial(object.quotaIncreaseEligibility) : undefined;
        message.isFixed = object.isFixed ?? false;
        message.dimensionsInfos = object.dimensionsInfos?.map(e => exports.DimensionsInfo.fromPartial(e)) || [];
        message.isConcurrent = object.isConcurrent ?? false;
        message.serviceRequestQuotaUri = object.serviceRequestQuotaUri ?? "";
        return message;
    },
    fromAmino(object) {
        const message = createBaseQuotaInfo();
        if (object.name !== undefined && object.name !== null) {
            message.name = object.name;
        }
        if (object.quota_id !== undefined && object.quota_id !== null) {
            message.quotaId = object.quota_id;
        }
        if (object.metric !== undefined && object.metric !== null) {
            message.metric = object.metric;
        }
        if (object.service !== undefined && object.service !== null) {
            message.service = object.service;
        }
        if (object.is_precise !== undefined && object.is_precise !== null) {
            message.isPrecise = object.is_precise;
        }
        if (object.refresh_interval !== undefined && object.refresh_interval !== null) {
            message.refreshInterval = object.refresh_interval;
        }
        if (object.container_type !== undefined && object.container_type !== null) {
            message.containerType = object.container_type;
        }
        message.dimensions = object.dimensions?.map(e => e) || [];
        if (object.metric_display_name !== undefined && object.metric_display_name !== null) {
            message.metricDisplayName = object.metric_display_name;
        }
        if (object.quota_display_name !== undefined && object.quota_display_name !== null) {
            message.quotaDisplayName = object.quota_display_name;
        }
        if (object.metric_unit !== undefined && object.metric_unit !== null) {
            message.metricUnit = object.metric_unit;
        }
        if (object.quota_increase_eligibility !== undefined && object.quota_increase_eligibility !== null) {
            message.quotaIncreaseEligibility = exports.QuotaIncreaseEligibility.fromAmino(object.quota_increase_eligibility);
        }
        if (object.is_fixed !== undefined && object.is_fixed !== null) {
            message.isFixed = object.is_fixed;
        }
        message.dimensionsInfos = object.dimensions_infos?.map(e => exports.DimensionsInfo.fromAmino(e)) || [];
        if (object.is_concurrent !== undefined && object.is_concurrent !== null) {
            message.isConcurrent = object.is_concurrent;
        }
        if (object.service_request_quota_uri !== undefined && object.service_request_quota_uri !== null) {
            message.serviceRequestQuotaUri = object.service_request_quota_uri;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.name = message.name === "" ? undefined : message.name;
        obj.quota_id = message.quotaId === "" ? undefined : message.quotaId;
        obj.metric = message.metric === "" ? undefined : message.metric;
        obj.service = message.service === "" ? undefined : message.service;
        obj.is_precise = message.isPrecise === false ? undefined : message.isPrecise;
        obj.refresh_interval = message.refreshInterval === "" ? undefined : message.refreshInterval;
        obj.container_type = message.containerType === 0 ? undefined : message.containerType;
        if (message.dimensions) {
            obj.dimensions = message.dimensions.map(e => e);
        }
        else {
            obj.dimensions = message.dimensions;
        }
        obj.metric_display_name = message.metricDisplayName === "" ? undefined : message.metricDisplayName;
        obj.quota_display_name = message.quotaDisplayName === "" ? undefined : message.quotaDisplayName;
        obj.metric_unit = message.metricUnit === "" ? undefined : message.metricUnit;
        obj.quota_increase_eligibility = message.quotaIncreaseEligibility ? exports.QuotaIncreaseEligibility.toAmino(message.quotaIncreaseEligibility) : undefined;
        obj.is_fixed = message.isFixed === false ? undefined : message.isFixed;
        if (message.dimensionsInfos) {
            obj.dimensions_infos = message.dimensionsInfos.map(e => e ? exports.DimensionsInfo.toAmino(e) : undefined);
        }
        else {
            obj.dimensions_infos = message.dimensionsInfos;
        }
        obj.is_concurrent = message.isConcurrent === false ? undefined : message.isConcurrent;
        obj.service_request_quota_uri = message.serviceRequestQuotaUri === "" ? undefined : message.serviceRequestQuotaUri;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.QuotaInfo.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.QuotaInfo.decode(message.value);
    },
    toProto(message) {
        return exports.QuotaInfo.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.cloudquotas.v1beta.QuotaInfo",
            value: exports.QuotaInfo.encode(message).finish()
        };
    }
};
function createBaseQuotaIncreaseEligibility() {
    return {
        isEligible: false,
        ineligibilityReason: 0
    };
}
exports.QuotaIncreaseEligibility = {
    typeUrl: "/google.api.cloudquotas.v1beta.QuotaIncreaseEligibility",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.isEligible === true) {
            writer.uint32(8).bool(message.isEligible);
        }
        if (message.ineligibilityReason !== 0) {
            writer.uint32(16).int32(message.ineligibilityReason);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseQuotaIncreaseEligibility();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.isEligible = reader.bool();
                    break;
                case 2:
                    message.ineligibilityReason = reader.int32();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseQuotaIncreaseEligibility();
        message.isEligible = object.isEligible ?? false;
        message.ineligibilityReason = object.ineligibilityReason ?? 0;
        return message;
    },
    fromAmino(object) {
        const message = createBaseQuotaIncreaseEligibility();
        if (object.is_eligible !== undefined && object.is_eligible !== null) {
            message.isEligible = object.is_eligible;
        }
        if (object.ineligibility_reason !== undefined && object.ineligibility_reason !== null) {
            message.ineligibilityReason = object.ineligibility_reason;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.is_eligible = message.isEligible === false ? undefined : message.isEligible;
        obj.ineligibility_reason = message.ineligibilityReason === 0 ? undefined : message.ineligibilityReason;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.QuotaIncreaseEligibility.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.QuotaIncreaseEligibility.decode(message.value);
    },
    toProto(message) {
        return exports.QuotaIncreaseEligibility.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.cloudquotas.v1beta.QuotaIncreaseEligibility",
            value: exports.QuotaIncreaseEligibility.encode(message).finish()
        };
    }
};
function createBaseQuotaPreference_DimensionsEntry() {
    return {
        key: "",
        value: ""
    };
}
exports.QuotaPreference_DimensionsEntry = {
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.key !== "") {
            writer.uint32(10).string(message.key);
        }
        if (message.value !== "") {
            writer.uint32(18).string(message.value);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseQuotaPreference_DimensionsEntry();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.key = reader.string();
                    break;
                case 2:
                    message.value = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseQuotaPreference_DimensionsEntry();
        message.key = object.key ?? "";
        message.value = object.value ?? "";
        return message;
    },
    fromAmino(object) {
        const message = createBaseQuotaPreference_DimensionsEntry();
        if (object.key !== undefined && object.key !== null) {
            message.key = object.key;
        }
        if (object.value !== undefined && object.value !== null) {
            message.value = object.value;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.key = message.key === "" ? undefined : message.key;
        obj.value = message.value === "" ? undefined : message.value;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.QuotaPreference_DimensionsEntry.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.QuotaPreference_DimensionsEntry.decode(message.value);
    },
    toProto(message) {
        return exports.QuotaPreference_DimensionsEntry.encode(message).finish();
    }
};
function createBaseQuotaPreference() {
    return {
        name: "",
        dimensions: {},
        quotaConfig: undefined,
        etag: "",
        createTime: undefined,
        updateTime: undefined,
        service: "",
        quotaId: "",
        reconciling: false,
        justification: "",
        contactEmail: ""
    };
}
exports.QuotaPreference = {
    typeUrl: "/google.api.cloudquotas.v1beta.QuotaPreference",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.name !== "") {
            writer.uint32(10).string(message.name);
        }
        Object.entries(message.dimensions).forEach(([key, value]) => {
            exports.QuotaPreference_DimensionsEntry.encode({
                key: key,
                value
            }, writer.uint32(18).fork()).ldelim();
        });
        if (message.quotaConfig !== undefined) {
            exports.QuotaConfig.encode(message.quotaConfig, writer.uint32(26).fork()).ldelim();
        }
        if (message.etag !== "") {
            writer.uint32(34).string(message.etag);
        }
        if (message.createTime !== undefined) {
            timestamp_1.Timestamp.encode((0, helpers_1.toTimestamp)(message.createTime), writer.uint32(42).fork()).ldelim();
        }
        if (message.updateTime !== undefined) {
            timestamp_1.Timestamp.encode((0, helpers_1.toTimestamp)(message.updateTime), writer.uint32(50).fork()).ldelim();
        }
        if (message.service !== "") {
            writer.uint32(58).string(message.service);
        }
        if (message.quotaId !== "") {
            writer.uint32(66).string(message.quotaId);
        }
        if (message.reconciling === true) {
            writer.uint32(80).bool(message.reconciling);
        }
        if (message.justification !== "") {
            writer.uint32(90).string(message.justification);
        }
        if (message.contactEmail !== "") {
            writer.uint32(98).string(message.contactEmail);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseQuotaPreference();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.name = reader.string();
                    break;
                case 2:
                    const entry2 = exports.QuotaPreference_DimensionsEntry.decode(reader, reader.uint32());
                    if (entry2.value !== undefined) {
                        message.dimensions[entry2.key] = entry2.value;
                    }
                    break;
                case 3:
                    message.quotaConfig = exports.QuotaConfig.decode(reader, reader.uint32());
                    break;
                case 4:
                    message.etag = reader.string();
                    break;
                case 5:
                    message.createTime = (0, helpers_1.fromTimestamp)(timestamp_1.Timestamp.decode(reader, reader.uint32()));
                    break;
                case 6:
                    message.updateTime = (0, helpers_1.fromTimestamp)(timestamp_1.Timestamp.decode(reader, reader.uint32()));
                    break;
                case 7:
                    message.service = reader.string();
                    break;
                case 8:
                    message.quotaId = reader.string();
                    break;
                case 10:
                    message.reconciling = reader.bool();
                    break;
                case 11:
                    message.justification = reader.string();
                    break;
                case 12:
                    message.contactEmail = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseQuotaPreference();
        message.name = object.name ?? "";
        message.dimensions = Object.entries(object.dimensions ?? {}).reduce((acc, [key, value]) => {
            if (value !== undefined) {
                acc[key] = String(value);
            }
            return acc;
        }, {});
        message.quotaConfig = object.quotaConfig !== undefined && object.quotaConfig !== null ? exports.QuotaConfig.fromPartial(object.quotaConfig) : undefined;
        message.etag = object.etag ?? "";
        message.createTime = object.createTime ?? undefined;
        message.updateTime = object.updateTime ?? undefined;
        message.service = object.service ?? "";
        message.quotaId = object.quotaId ?? "";
        message.reconciling = object.reconciling ?? false;
        message.justification = object.justification ?? "";
        message.contactEmail = object.contactEmail ?? "";
        return message;
    },
    fromAmino(object) {
        const message = createBaseQuotaPreference();
        if (object.name !== undefined && object.name !== null) {
            message.name = object.name;
        }
        message.dimensions = Object.entries(object.dimensions ?? {}).reduce((acc, [key, value]) => {
            if (value !== undefined) {
                acc[key] = String(value);
            }
            return acc;
        }, {});
        if (object.quota_config !== undefined && object.quota_config !== null) {
            message.quotaConfig = exports.QuotaConfig.fromAmino(object.quota_config);
        }
        if (object.etag !== undefined && object.etag !== null) {
            message.etag = object.etag;
        }
        if (object.create_time !== undefined && object.create_time !== null) {
            message.createTime = (0, helpers_1.fromTimestamp)(timestamp_1.Timestamp.fromAmino(object.create_time));
        }
        if (object.update_time !== undefined && object.update_time !== null) {
            message.updateTime = (0, helpers_1.fromTimestamp)(timestamp_1.Timestamp.fromAmino(object.update_time));
        }
        if (object.service !== undefined && object.service !== null) {
            message.service = object.service;
        }
        if (object.quota_id !== undefined && object.quota_id !== null) {
            message.quotaId = object.quota_id;
        }
        if (object.reconciling !== undefined && object.reconciling !== null) {
            message.reconciling = object.reconciling;
        }
        if (object.justification !== undefined && object.justification !== null) {
            message.justification = object.justification;
        }
        if (object.contact_email !== undefined && object.contact_email !== null) {
            message.contactEmail = object.contact_email;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.name = message.name === "" ? undefined : message.name;
        obj.dimensions = {};
        if (message.dimensions) {
            Object.entries(message.dimensions).forEach(([k, v]) => {
                obj.dimensions[k] = v;
            });
        }
        obj.quota_config = message.quotaConfig ? exports.QuotaConfig.toAmino(message.quotaConfig) : undefined;
        obj.etag = message.etag === "" ? undefined : message.etag;
        obj.create_time = message.createTime ? timestamp_1.Timestamp.toAmino((0, helpers_1.toTimestamp)(message.createTime)) : undefined;
        obj.update_time = message.updateTime ? timestamp_1.Timestamp.toAmino((0, helpers_1.toTimestamp)(message.updateTime)) : undefined;
        obj.service = message.service === "" ? undefined : message.service;
        obj.quota_id = message.quotaId === "" ? undefined : message.quotaId;
        obj.reconciling = message.reconciling === false ? undefined : message.reconciling;
        obj.justification = message.justification === "" ? undefined : message.justification;
        obj.contact_email = message.contactEmail === "" ? undefined : message.contactEmail;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.QuotaPreference.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.QuotaPreference.decode(message.value);
    },
    toProto(message) {
        return exports.QuotaPreference.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.cloudquotas.v1beta.QuotaPreference",
            value: exports.QuotaPreference.encode(message).finish()
        };
    }
};
function createBaseQuotaConfig_AnnotationsEntry() {
    return {
        key: "",
        value: ""
    };
}
exports.QuotaConfig_AnnotationsEntry = {
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.key !== "") {
            writer.uint32(10).string(message.key);
        }
        if (message.value !== "") {
            writer.uint32(18).string(message.value);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseQuotaConfig_AnnotationsEntry();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.key = reader.string();
                    break;
                case 2:
                    message.value = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseQuotaConfig_AnnotationsEntry();
        message.key = object.key ?? "";
        message.value = object.value ?? "";
        return message;
    },
    fromAmino(object) {
        const message = createBaseQuotaConfig_AnnotationsEntry();
        if (object.key !== undefined && object.key !== null) {
            message.key = object.key;
        }
        if (object.value !== undefined && object.value !== null) {
            message.value = object.value;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.key = message.key === "" ? undefined : message.key;
        obj.value = message.value === "" ? undefined : message.value;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.QuotaConfig_AnnotationsEntry.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.QuotaConfig_AnnotationsEntry.decode(message.value);
    },
    toProto(message) {
        return exports.QuotaConfig_AnnotationsEntry.encode(message).finish();
    }
};
function createBaseQuotaConfig() {
    return {
        preferredValue: BigInt(0),
        stateDetail: "",
        grantedValue: undefined,
        traceId: "",
        annotations: {},
        requestOrigin: 0
    };
}
exports.QuotaConfig = {
    typeUrl: "/google.api.cloudquotas.v1beta.QuotaConfig",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.preferredValue !== BigInt(0)) {
            writer.uint32(8).int64(message.preferredValue);
        }
        if (message.stateDetail !== "") {
            writer.uint32(18).string(message.stateDetail);
        }
        if (message.grantedValue !== undefined) {
            wrappers_1.Int64Value.encode(message.grantedValue, writer.uint32(26).fork()).ldelim();
        }
        if (message.traceId !== "") {
            writer.uint32(34).string(message.traceId);
        }
        Object.entries(message.annotations).forEach(([key, value]) => {
            exports.QuotaConfig_AnnotationsEntry.encode({
                key: key,
                value
            }, writer.uint32(42).fork()).ldelim();
        });
        if (message.requestOrigin !== 0) {
            writer.uint32(48).int32(message.requestOrigin);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseQuotaConfig();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.preferredValue = reader.int64();
                    break;
                case 2:
                    message.stateDetail = reader.string();
                    break;
                case 3:
                    message.grantedValue = wrappers_1.Int64Value.decode(reader, reader.uint32());
                    break;
                case 4:
                    message.traceId = reader.string();
                    break;
                case 5:
                    const entry5 = exports.QuotaConfig_AnnotationsEntry.decode(reader, reader.uint32());
                    if (entry5.value !== undefined) {
                        message.annotations[entry5.key] = entry5.value;
                    }
                    break;
                case 6:
                    message.requestOrigin = reader.int32();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseQuotaConfig();
        message.preferredValue = object.preferredValue !== undefined && object.preferredValue !== null ? BigInt(object.preferredValue.toString()) : BigInt(0);
        message.stateDetail = object.stateDetail ?? "";
        message.grantedValue = object.grantedValue !== undefined && object.grantedValue !== null ? wrappers_1.Int64Value.fromPartial(object.grantedValue) : undefined;
        message.traceId = object.traceId ?? "";
        message.annotations = Object.entries(object.annotations ?? {}).reduce((acc, [key, value]) => {
            if (value !== undefined) {
                acc[key] = String(value);
            }
            return acc;
        }, {});
        message.requestOrigin = object.requestOrigin ?? 0;
        return message;
    },
    fromAmino(object) {
        const message = createBaseQuotaConfig();
        if (object.preferred_value !== undefined && object.preferred_value !== null) {
            message.preferredValue = BigInt(object.preferred_value);
        }
        if (object.state_detail !== undefined && object.state_detail !== null) {
            message.stateDetail = object.state_detail;
        }
        if (object.granted_value !== undefined && object.granted_value !== null) {
            message.grantedValue = wrappers_1.Int64Value.fromAmino(object.granted_value);
        }
        if (object.trace_id !== undefined && object.trace_id !== null) {
            message.traceId = object.trace_id;
        }
        message.annotations = Object.entries(object.annotations ?? {}).reduce((acc, [key, value]) => {
            if (value !== undefined) {
                acc[key] = String(value);
            }
            return acc;
        }, {});
        if (object.request_origin !== undefined && object.request_origin !== null) {
            message.requestOrigin = object.request_origin;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.preferred_value = message.preferredValue !== BigInt(0) ? message.preferredValue?.toString() : undefined;
        obj.state_detail = message.stateDetail === "" ? undefined : message.stateDetail;
        obj.granted_value = message.grantedValue ? wrappers_1.Int64Value.toAmino(message.grantedValue) : undefined;
        obj.trace_id = message.traceId === "" ? undefined : message.traceId;
        obj.annotations = {};
        if (message.annotations) {
            Object.entries(message.annotations).forEach(([k, v]) => {
                obj.annotations[k] = v;
            });
        }
        obj.request_origin = message.requestOrigin === 0 ? undefined : message.requestOrigin;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.QuotaConfig.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.QuotaConfig.decode(message.value);
    },
    toProto(message) {
        return exports.QuotaConfig.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.cloudquotas.v1beta.QuotaConfig",
            value: exports.QuotaConfig.encode(message).finish()
        };
    }
};
function createBaseDimensionsInfo_DimensionsEntry() {
    return {
        key: "",
        value: ""
    };
}
exports.DimensionsInfo_DimensionsEntry = {
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.key !== "") {
            writer.uint32(10).string(message.key);
        }
        if (message.value !== "") {
            writer.uint32(18).string(message.value);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseDimensionsInfo_DimensionsEntry();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.key = reader.string();
                    break;
                case 2:
                    message.value = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseDimensionsInfo_DimensionsEntry();
        message.key = object.key ?? "";
        message.value = object.value ?? "";
        return message;
    },
    fromAmino(object) {
        const message = createBaseDimensionsInfo_DimensionsEntry();
        if (object.key !== undefined && object.key !== null) {
            message.key = object.key;
        }
        if (object.value !== undefined && object.value !== null) {
            message.value = object.value;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.key = message.key === "" ? undefined : message.key;
        obj.value = message.value === "" ? undefined : message.value;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.DimensionsInfo_DimensionsEntry.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.DimensionsInfo_DimensionsEntry.decode(message.value);
    },
    toProto(message) {
        return exports.DimensionsInfo_DimensionsEntry.encode(message).finish();
    }
};
function createBaseDimensionsInfo() {
    return {
        dimensions: {},
        details: undefined,
        applicableLocations: []
    };
}
exports.DimensionsInfo = {
    typeUrl: "/google.api.cloudquotas.v1beta.DimensionsInfo",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        Object.entries(message.dimensions).forEach(([key, value]) => {
            exports.DimensionsInfo_DimensionsEntry.encode({
                key: key,
                value
            }, writer.uint32(10).fork()).ldelim();
        });
        if (message.details !== undefined) {
            exports.QuotaDetails.encode(message.details, writer.uint32(18).fork()).ldelim();
        }
        for (const v of message.applicableLocations) {
            writer.uint32(26).string(v);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseDimensionsInfo();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    const entry1 = exports.DimensionsInfo_DimensionsEntry.decode(reader, reader.uint32());
                    if (entry1.value !== undefined) {
                        message.dimensions[entry1.key] = entry1.value;
                    }
                    break;
                case 2:
                    message.details = exports.QuotaDetails.decode(reader, reader.uint32());
                    break;
                case 3:
                    message.applicableLocations.push(reader.string());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseDimensionsInfo();
        message.dimensions = Object.entries(object.dimensions ?? {}).reduce((acc, [key, value]) => {
            if (value !== undefined) {
                acc[key] = String(value);
            }
            return acc;
        }, {});
        message.details = object.details !== undefined && object.details !== null ? exports.QuotaDetails.fromPartial(object.details) : undefined;
        message.applicableLocations = object.applicableLocations?.map(e => e) || [];
        return message;
    },
    fromAmino(object) {
        const message = createBaseDimensionsInfo();
        message.dimensions = Object.entries(object.dimensions ?? {}).reduce((acc, [key, value]) => {
            if (value !== undefined) {
                acc[key] = String(value);
            }
            return acc;
        }, {});
        if (object.details !== undefined && object.details !== null) {
            message.details = exports.QuotaDetails.fromAmino(object.details);
        }
        message.applicableLocations = object.applicable_locations?.map(e => e) || [];
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.dimensions = {};
        if (message.dimensions) {
            Object.entries(message.dimensions).forEach(([k, v]) => {
                obj.dimensions[k] = v;
            });
        }
        obj.details = message.details ? exports.QuotaDetails.toAmino(message.details) : undefined;
        if (message.applicableLocations) {
            obj.applicable_locations = message.applicableLocations.map(e => e);
        }
        else {
            obj.applicable_locations = message.applicableLocations;
        }
        return obj;
    },
    fromAminoMsg(object) {
        return exports.DimensionsInfo.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.DimensionsInfo.decode(message.value);
    },
    toProto(message) {
        return exports.DimensionsInfo.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.cloudquotas.v1beta.DimensionsInfo",
            value: exports.DimensionsInfo.encode(message).finish()
        };
    }
};
function createBaseQuotaDetails() {
    return {
        value: BigInt(0),
        rolloutInfo: undefined
    };
}
exports.QuotaDetails = {
    typeUrl: "/google.api.cloudquotas.v1beta.QuotaDetails",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.value !== BigInt(0)) {
            writer.uint32(8).int64(message.value);
        }
        if (message.rolloutInfo !== undefined) {
            exports.RolloutInfo.encode(message.rolloutInfo, writer.uint32(26).fork()).ldelim();
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseQuotaDetails();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.value = reader.int64();
                    break;
                case 3:
                    message.rolloutInfo = exports.RolloutInfo.decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseQuotaDetails();
        message.value = object.value !== undefined && object.value !== null ? BigInt(object.value.toString()) : BigInt(0);
        message.rolloutInfo = object.rolloutInfo !== undefined && object.rolloutInfo !== null ? exports.RolloutInfo.fromPartial(object.rolloutInfo) : undefined;
        return message;
    },
    fromAmino(object) {
        const message = createBaseQuotaDetails();
        if (object.value !== undefined && object.value !== null) {
            message.value = BigInt(object.value);
        }
        if (object.rollout_info !== undefined && object.rollout_info !== null) {
            message.rolloutInfo = exports.RolloutInfo.fromAmino(object.rollout_info);
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.value = message.value !== BigInt(0) ? message.value?.toString() : undefined;
        obj.rollout_info = message.rolloutInfo ? exports.RolloutInfo.toAmino(message.rolloutInfo) : undefined;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.QuotaDetails.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.QuotaDetails.decode(message.value);
    },
    toProto(message) {
        return exports.QuotaDetails.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.cloudquotas.v1beta.QuotaDetails",
            value: exports.QuotaDetails.encode(message).finish()
        };
    }
};
function createBaseRolloutInfo() {
    return {
        ongoingRollout: false
    };
}
exports.RolloutInfo = {
    typeUrl: "/google.api.cloudquotas.v1beta.RolloutInfo",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.ongoingRollout === true) {
            writer.uint32(8).bool(message.ongoingRollout);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseRolloutInfo();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.ongoingRollout = reader.bool();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseRolloutInfo();
        message.ongoingRollout = object.ongoingRollout ?? false;
        return message;
    },
    fromAmino(object) {
        const message = createBaseRolloutInfo();
        if (object.ongoing_rollout !== undefined && object.ongoing_rollout !== null) {
            message.ongoingRollout = object.ongoing_rollout;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.ongoing_rollout = message.ongoingRollout === false ? undefined : message.ongoingRollout;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.RolloutInfo.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.RolloutInfo.decode(message.value);
    },
    toProto(message) {
        return exports.RolloutInfo.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.cloudquotas.v1beta.RolloutInfo",
            value: exports.RolloutInfo.encode(message).finish()
        };
    }
};
