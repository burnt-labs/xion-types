"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.QuotaAdjusterSettings = exports.UpdateQuotaAdjusterSettingsRequest = exports.GetQuotaAdjusterSettingsRequest = exports.QuotaAdjusterSettings_EnablementAmino = exports.QuotaAdjusterSettings_EnablementSDKType = exports.QuotaAdjusterSettings_Enablement = void 0;
exports.quotaAdjusterSettings_EnablementFromJSON = quotaAdjusterSettings_EnablementFromJSON;
exports.quotaAdjusterSettings_EnablementToJSON = quotaAdjusterSettings_EnablementToJSON;
//@ts-nocheck
const field_mask_1 = require("../../../protobuf/field_mask");
const timestamp_1 = require("../../../protobuf/timestamp");
const binary_1 = require("../../../../binary");
const helpers_1 = require("../../../../helpers");
/** The enablement status of the quota adjuster. */
var QuotaAdjusterSettings_Enablement;
(function (QuotaAdjusterSettings_Enablement) {
    /** ENABLEMENT_UNSPECIFIED - The quota adjuster is in an unknown state. */
    QuotaAdjusterSettings_Enablement[QuotaAdjusterSettings_Enablement["ENABLEMENT_UNSPECIFIED"] = 0] = "ENABLEMENT_UNSPECIFIED";
    /** ENABLED - The quota adjuster is enabled. */
    QuotaAdjusterSettings_Enablement[QuotaAdjusterSettings_Enablement["ENABLED"] = 2] = "ENABLED";
    /** DISABLED - The quota adjuster is disabled. */
    QuotaAdjusterSettings_Enablement[QuotaAdjusterSettings_Enablement["DISABLED"] = 3] = "DISABLED";
    QuotaAdjusterSettings_Enablement[QuotaAdjusterSettings_Enablement["UNRECOGNIZED"] = -1] = "UNRECOGNIZED";
})(QuotaAdjusterSettings_Enablement || (exports.QuotaAdjusterSettings_Enablement = QuotaAdjusterSettings_Enablement = {}));
exports.QuotaAdjusterSettings_EnablementSDKType = QuotaAdjusterSettings_Enablement;
exports.QuotaAdjusterSettings_EnablementAmino = QuotaAdjusterSettings_Enablement;
function quotaAdjusterSettings_EnablementFromJSON(object) {
    switch (object) {
        case 0:
        case "ENABLEMENT_UNSPECIFIED":
            return QuotaAdjusterSettings_Enablement.ENABLEMENT_UNSPECIFIED;
        case 2:
        case "ENABLED":
            return QuotaAdjusterSettings_Enablement.ENABLED;
        case 3:
        case "DISABLED":
            return QuotaAdjusterSettings_Enablement.DISABLED;
        case -1:
        case "UNRECOGNIZED":
        default:
            return QuotaAdjusterSettings_Enablement.UNRECOGNIZED;
    }
}
function quotaAdjusterSettings_EnablementToJSON(object) {
    switch (object) {
        case QuotaAdjusterSettings_Enablement.ENABLEMENT_UNSPECIFIED:
            return "ENABLEMENT_UNSPECIFIED";
        case QuotaAdjusterSettings_Enablement.ENABLED:
            return "ENABLED";
        case QuotaAdjusterSettings_Enablement.DISABLED:
            return "DISABLED";
        case QuotaAdjusterSettings_Enablement.UNRECOGNIZED:
        default:
            return "UNRECOGNIZED";
    }
}
function createBaseGetQuotaAdjusterSettingsRequest() {
    return {
        name: ""
    };
}
exports.GetQuotaAdjusterSettingsRequest = {
    typeUrl: "/google.api.cloudquotas.v1beta.GetQuotaAdjusterSettingsRequest",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.name !== "") {
            writer.uint32(10).string(message.name);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseGetQuotaAdjusterSettingsRequest();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.name = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseGetQuotaAdjusterSettingsRequest();
        message.name = object.name ?? "";
        return message;
    },
    fromAmino(object) {
        const message = createBaseGetQuotaAdjusterSettingsRequest();
        if (object.name !== undefined && object.name !== null) {
            message.name = object.name;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.name = message.name === "" ? undefined : message.name;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.GetQuotaAdjusterSettingsRequest.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.GetQuotaAdjusterSettingsRequest.decode(message.value);
    },
    toProto(message) {
        return exports.GetQuotaAdjusterSettingsRequest.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.cloudquotas.v1beta.GetQuotaAdjusterSettingsRequest",
            value: exports.GetQuotaAdjusterSettingsRequest.encode(message).finish()
        };
    }
};
function createBaseUpdateQuotaAdjusterSettingsRequest() {
    return {
        quotaAdjusterSettings: undefined,
        updateMask: undefined,
        validateOnly: false
    };
}
exports.UpdateQuotaAdjusterSettingsRequest = {
    typeUrl: "/google.api.cloudquotas.v1beta.UpdateQuotaAdjusterSettingsRequest",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.quotaAdjusterSettings !== undefined) {
            exports.QuotaAdjusterSettings.encode(message.quotaAdjusterSettings, writer.uint32(10).fork()).ldelim();
        }
        if (message.updateMask !== undefined) {
            field_mask_1.FieldMask.encode(message.updateMask, writer.uint32(18).fork()).ldelim();
        }
        if (message.validateOnly === true) {
            writer.uint32(24).bool(message.validateOnly);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseUpdateQuotaAdjusterSettingsRequest();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.quotaAdjusterSettings = exports.QuotaAdjusterSettings.decode(reader, reader.uint32());
                    break;
                case 2:
                    message.updateMask = field_mask_1.FieldMask.decode(reader, reader.uint32());
                    break;
                case 3:
                    message.validateOnly = reader.bool();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseUpdateQuotaAdjusterSettingsRequest();
        message.quotaAdjusterSettings = object.quotaAdjusterSettings !== undefined && object.quotaAdjusterSettings !== null ? exports.QuotaAdjusterSettings.fromPartial(object.quotaAdjusterSettings) : undefined;
        message.updateMask = object.updateMask !== undefined && object.updateMask !== null ? field_mask_1.FieldMask.fromPartial(object.updateMask) : undefined;
        message.validateOnly = object.validateOnly ?? false;
        return message;
    },
    fromAmino(object) {
        const message = createBaseUpdateQuotaAdjusterSettingsRequest();
        if (object.quota_adjuster_settings !== undefined && object.quota_adjuster_settings !== null) {
            message.quotaAdjusterSettings = exports.QuotaAdjusterSettings.fromAmino(object.quota_adjuster_settings);
        }
        if (object.update_mask !== undefined && object.update_mask !== null) {
            message.updateMask = field_mask_1.FieldMask.fromAmino(object.update_mask);
        }
        if (object.validate_only !== undefined && object.validate_only !== null) {
            message.validateOnly = object.validate_only;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.quota_adjuster_settings = message.quotaAdjusterSettings ? exports.QuotaAdjusterSettings.toAmino(message.quotaAdjusterSettings) : undefined;
        obj.update_mask = message.updateMask ? field_mask_1.FieldMask.toAmino(message.updateMask) : undefined;
        obj.validate_only = message.validateOnly === false ? undefined : message.validateOnly;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.UpdateQuotaAdjusterSettingsRequest.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.UpdateQuotaAdjusterSettingsRequest.decode(message.value);
    },
    toProto(message) {
        return exports.UpdateQuotaAdjusterSettingsRequest.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.cloudquotas.v1beta.UpdateQuotaAdjusterSettingsRequest",
            value: exports.UpdateQuotaAdjusterSettingsRequest.encode(message).finish()
        };
    }
};
function createBaseQuotaAdjusterSettings() {
    return {
        name: "",
        enablement: 0,
        updateTime: undefined,
        etag: "",
        inherited: false,
        inheritedFrom: ""
    };
}
exports.QuotaAdjusterSettings = {
    typeUrl: "/google.api.cloudquotas.v1beta.QuotaAdjusterSettings",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.name !== "") {
            writer.uint32(10).string(message.name);
        }
        if (message.enablement !== 0) {
            writer.uint32(16).int32(message.enablement);
        }
        if (message.updateTime !== undefined) {
            timestamp_1.Timestamp.encode((0, helpers_1.toTimestamp)(message.updateTime), writer.uint32(42).fork()).ldelim();
        }
        if (message.etag !== "") {
            writer.uint32(50).string(message.etag);
        }
        if (message.inherited === true) {
            writer.uint32(56).bool(message.inherited);
        }
        if (message.inheritedFrom !== "") {
            writer.uint32(66).string(message.inheritedFrom);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseQuotaAdjusterSettings();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.name = reader.string();
                    break;
                case 2:
                    message.enablement = reader.int32();
                    break;
                case 5:
                    message.updateTime = (0, helpers_1.fromTimestamp)(timestamp_1.Timestamp.decode(reader, reader.uint32()));
                    break;
                case 6:
                    message.etag = reader.string();
                    break;
                case 7:
                    message.inherited = reader.bool();
                    break;
                case 8:
                    message.inheritedFrom = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseQuotaAdjusterSettings();
        message.name = object.name ?? "";
        message.enablement = object.enablement ?? 0;
        message.updateTime = object.updateTime ?? undefined;
        message.etag = object.etag ?? "";
        message.inherited = object.inherited ?? false;
        message.inheritedFrom = object.inheritedFrom ?? "";
        return message;
    },
    fromAmino(object) {
        const message = createBaseQuotaAdjusterSettings();
        if (object.name !== undefined && object.name !== null) {
            message.name = object.name;
        }
        if (object.enablement !== undefined && object.enablement !== null) {
            message.enablement = object.enablement;
        }
        if (object.update_time !== undefined && object.update_time !== null) {
            message.updateTime = (0, helpers_1.fromTimestamp)(timestamp_1.Timestamp.fromAmino(object.update_time));
        }
        if (object.etag !== undefined && object.etag !== null) {
            message.etag = object.etag;
        }
        if (object.inherited !== undefined && object.inherited !== null) {
            message.inherited = object.inherited;
        }
        if (object.inherited_from !== undefined && object.inherited_from !== null) {
            message.inheritedFrom = object.inherited_from;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.name = message.name === "" ? undefined : message.name;
        obj.enablement = message.enablement === 0 ? undefined : message.enablement;
        obj.update_time = message.updateTime ? timestamp_1.Timestamp.toAmino((0, helpers_1.toTimestamp)(message.updateTime)) : undefined;
        obj.etag = message.etag === "" ? undefined : message.etag;
        obj.inherited = message.inherited === false ? undefined : message.inherited;
        obj.inherited_from = message.inheritedFrom === "" ? undefined : message.inheritedFrom;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.QuotaAdjusterSettings.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.QuotaAdjusterSettings.decode(message.value);
    },
    toProto(message) {
        return exports.QuotaAdjusterSettings.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.cloudquotas.v1beta.QuotaAdjusterSettings",
            value: exports.QuotaAdjusterSettings.encode(message).finish()
        };
    }
};
