"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.UpdateQuotaPreferenceRequest = exports.CreateQuotaPreferenceRequest = exports.GetQuotaPreferenceRequest = exports.ListQuotaPreferencesResponse = exports.ListQuotaPreferencesRequest = exports.GetQuotaInfoRequest = exports.ListQuotaInfosResponse = exports.ListQuotaInfosRequest = void 0;
//@ts-nocheck
const resources_1 = require("./resources");
const field_mask_1 = require("../../../protobuf/field_mask");
const binary_1 = require("../../../../binary");
function createBaseListQuotaInfosRequest() {
    return {
        parent: "",
        pageSize: 0,
        pageToken: ""
    };
}
exports.ListQuotaInfosRequest = {
    typeUrl: "/google.api.cloudquotas.v1beta.ListQuotaInfosRequest",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.parent !== "") {
            writer.uint32(10).string(message.parent);
        }
        if (message.pageSize !== 0) {
            writer.uint32(16).int32(message.pageSize);
        }
        if (message.pageToken !== "") {
            writer.uint32(26).string(message.pageToken);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseListQuotaInfosRequest();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.parent = reader.string();
                    break;
                case 2:
                    message.pageSize = reader.int32();
                    break;
                case 3:
                    message.pageToken = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseListQuotaInfosRequest();
        message.parent = object.parent ?? "";
        message.pageSize = object.pageSize ?? 0;
        message.pageToken = object.pageToken ?? "";
        return message;
    },
    fromAmino(object) {
        const message = createBaseListQuotaInfosRequest();
        if (object.parent !== undefined && object.parent !== null) {
            message.parent = object.parent;
        }
        if (object.page_size !== undefined && object.page_size !== null) {
            message.pageSize = object.page_size;
        }
        if (object.page_token !== undefined && object.page_token !== null) {
            message.pageToken = object.page_token;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.parent = message.parent === "" ? undefined : message.parent;
        obj.page_size = message.pageSize === 0 ? undefined : message.pageSize;
        obj.page_token = message.pageToken === "" ? undefined : message.pageToken;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.ListQuotaInfosRequest.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.ListQuotaInfosRequest.decode(message.value);
    },
    toProto(message) {
        return exports.ListQuotaInfosRequest.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.cloudquotas.v1beta.ListQuotaInfosRequest",
            value: exports.ListQuotaInfosRequest.encode(message).finish()
        };
    }
};
function createBaseListQuotaInfosResponse() {
    return {
        quotaInfos: [],
        nextPageToken: ""
    };
}
exports.ListQuotaInfosResponse = {
    typeUrl: "/google.api.cloudquotas.v1beta.ListQuotaInfosResponse",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        for (const v of message.quotaInfos) {
            resources_1.QuotaInfo.encode(v, writer.uint32(10).fork()).ldelim();
        }
        if (message.nextPageToken !== "") {
            writer.uint32(18).string(message.nextPageToken);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseListQuotaInfosResponse();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.quotaInfos.push(resources_1.QuotaInfo.decode(reader, reader.uint32()));
                    break;
                case 2:
                    message.nextPageToken = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseListQuotaInfosResponse();
        message.quotaInfos = object.quotaInfos?.map(e => resources_1.QuotaInfo.fromPartial(e)) || [];
        message.nextPageToken = object.nextPageToken ?? "";
        return message;
    },
    fromAmino(object) {
        const message = createBaseListQuotaInfosResponse();
        message.quotaInfos = object.quota_infos?.map(e => resources_1.QuotaInfo.fromAmino(e)) || [];
        if (object.next_page_token !== undefined && object.next_page_token !== null) {
            message.nextPageToken = object.next_page_token;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        if (message.quotaInfos) {
            obj.quota_infos = message.quotaInfos.map(e => e ? resources_1.QuotaInfo.toAmino(e) : undefined);
        }
        else {
            obj.quota_infos = message.quotaInfos;
        }
        obj.next_page_token = message.nextPageToken === "" ? undefined : message.nextPageToken;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.ListQuotaInfosResponse.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.ListQuotaInfosResponse.decode(message.value);
    },
    toProto(message) {
        return exports.ListQuotaInfosResponse.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.cloudquotas.v1beta.ListQuotaInfosResponse",
            value: exports.ListQuotaInfosResponse.encode(message).finish()
        };
    }
};
function createBaseGetQuotaInfoRequest() {
    return {
        name: ""
    };
}
exports.GetQuotaInfoRequest = {
    typeUrl: "/google.api.cloudquotas.v1beta.GetQuotaInfoRequest",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.name !== "") {
            writer.uint32(10).string(message.name);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseGetQuotaInfoRequest();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.name = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseGetQuotaInfoRequest();
        message.name = object.name ?? "";
        return message;
    },
    fromAmino(object) {
        const message = createBaseGetQuotaInfoRequest();
        if (object.name !== undefined && object.name !== null) {
            message.name = object.name;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.name = message.name === "" ? undefined : message.name;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.GetQuotaInfoRequest.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.GetQuotaInfoRequest.decode(message.value);
    },
    toProto(message) {
        return exports.GetQuotaInfoRequest.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.cloudquotas.v1beta.GetQuotaInfoRequest",
            value: exports.GetQuotaInfoRequest.encode(message).finish()
        };
    }
};
function createBaseListQuotaPreferencesRequest() {
    return {
        parent: "",
        pageSize: 0,
        pageToken: "",
        filter: "",
        orderBy: ""
    };
}
exports.ListQuotaPreferencesRequest = {
    typeUrl: "/google.api.cloudquotas.v1beta.ListQuotaPreferencesRequest",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.parent !== "") {
            writer.uint32(10).string(message.parent);
        }
        if (message.pageSize !== 0) {
            writer.uint32(16).int32(message.pageSize);
        }
        if (message.pageToken !== "") {
            writer.uint32(26).string(message.pageToken);
        }
        if (message.filter !== "") {
            writer.uint32(34).string(message.filter);
        }
        if (message.orderBy !== "") {
            writer.uint32(42).string(message.orderBy);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseListQuotaPreferencesRequest();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.parent = reader.string();
                    break;
                case 2:
                    message.pageSize = reader.int32();
                    break;
                case 3:
                    message.pageToken = reader.string();
                    break;
                case 4:
                    message.filter = reader.string();
                    break;
                case 5:
                    message.orderBy = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseListQuotaPreferencesRequest();
        message.parent = object.parent ?? "";
        message.pageSize = object.pageSize ?? 0;
        message.pageToken = object.pageToken ?? "";
        message.filter = object.filter ?? "";
        message.orderBy = object.orderBy ?? "";
        return message;
    },
    fromAmino(object) {
        const message = createBaseListQuotaPreferencesRequest();
        if (object.parent !== undefined && object.parent !== null) {
            message.parent = object.parent;
        }
        if (object.page_size !== undefined && object.page_size !== null) {
            message.pageSize = object.page_size;
        }
        if (object.page_token !== undefined && object.page_token !== null) {
            message.pageToken = object.page_token;
        }
        if (object.filter !== undefined && object.filter !== null) {
            message.filter = object.filter;
        }
        if (object.order_by !== undefined && object.order_by !== null) {
            message.orderBy = object.order_by;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.parent = message.parent === "" ? undefined : message.parent;
        obj.page_size = message.pageSize === 0 ? undefined : message.pageSize;
        obj.page_token = message.pageToken === "" ? undefined : message.pageToken;
        obj.filter = message.filter === "" ? undefined : message.filter;
        obj.order_by = message.orderBy === "" ? undefined : message.orderBy;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.ListQuotaPreferencesRequest.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.ListQuotaPreferencesRequest.decode(message.value);
    },
    toProto(message) {
        return exports.ListQuotaPreferencesRequest.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.cloudquotas.v1beta.ListQuotaPreferencesRequest",
            value: exports.ListQuotaPreferencesRequest.encode(message).finish()
        };
    }
};
function createBaseListQuotaPreferencesResponse() {
    return {
        quotaPreferences: [],
        nextPageToken: "",
        unreachable: []
    };
}
exports.ListQuotaPreferencesResponse = {
    typeUrl: "/google.api.cloudquotas.v1beta.ListQuotaPreferencesResponse",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        for (const v of message.quotaPreferences) {
            resources_1.QuotaPreference.encode(v, writer.uint32(10).fork()).ldelim();
        }
        if (message.nextPageToken !== "") {
            writer.uint32(18).string(message.nextPageToken);
        }
        for (const v of message.unreachable) {
            writer.uint32(26).string(v);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseListQuotaPreferencesResponse();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.quotaPreferences.push(resources_1.QuotaPreference.decode(reader, reader.uint32()));
                    break;
                case 2:
                    message.nextPageToken = reader.string();
                    break;
                case 3:
                    message.unreachable.push(reader.string());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseListQuotaPreferencesResponse();
        message.quotaPreferences = object.quotaPreferences?.map(e => resources_1.QuotaPreference.fromPartial(e)) || [];
        message.nextPageToken = object.nextPageToken ?? "";
        message.unreachable = object.unreachable?.map(e => e) || [];
        return message;
    },
    fromAmino(object) {
        const message = createBaseListQuotaPreferencesResponse();
        message.quotaPreferences = object.quota_preferences?.map(e => resources_1.QuotaPreference.fromAmino(e)) || [];
        if (object.next_page_token !== undefined && object.next_page_token !== null) {
            message.nextPageToken = object.next_page_token;
        }
        message.unreachable = object.unreachable?.map(e => e) || [];
        return message;
    },
    toAmino(message) {
        const obj = {};
        if (message.quotaPreferences) {
            obj.quota_preferences = message.quotaPreferences.map(e => e ? resources_1.QuotaPreference.toAmino(e) : undefined);
        }
        else {
            obj.quota_preferences = message.quotaPreferences;
        }
        obj.next_page_token = message.nextPageToken === "" ? undefined : message.nextPageToken;
        if (message.unreachable) {
            obj.unreachable = message.unreachable.map(e => e);
        }
        else {
            obj.unreachable = message.unreachable;
        }
        return obj;
    },
    fromAminoMsg(object) {
        return exports.ListQuotaPreferencesResponse.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.ListQuotaPreferencesResponse.decode(message.value);
    },
    toProto(message) {
        return exports.ListQuotaPreferencesResponse.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.cloudquotas.v1beta.ListQuotaPreferencesResponse",
            value: exports.ListQuotaPreferencesResponse.encode(message).finish()
        };
    }
};
function createBaseGetQuotaPreferenceRequest() {
    return {
        name: ""
    };
}
exports.GetQuotaPreferenceRequest = {
    typeUrl: "/google.api.cloudquotas.v1beta.GetQuotaPreferenceRequest",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.name !== "") {
            writer.uint32(10).string(message.name);
        }
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseGetQuotaPreferenceRequest();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.name = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseGetQuotaPreferenceRequest();
        message.name = object.name ?? "";
        return message;
    },
    fromAmino(object) {
        const message = createBaseGetQuotaPreferenceRequest();
        if (object.name !== undefined && object.name !== null) {
            message.name = object.name;
        }
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.name = message.name === "" ? undefined : message.name;
        return obj;
    },
    fromAminoMsg(object) {
        return exports.GetQuotaPreferenceRequest.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.GetQuotaPreferenceRequest.decode(message.value);
    },
    toProto(message) {
        return exports.GetQuotaPreferenceRequest.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.cloudquotas.v1beta.GetQuotaPreferenceRequest",
            value: exports.GetQuotaPreferenceRequest.encode(message).finish()
        };
    }
};
function createBaseCreateQuotaPreferenceRequest() {
    return {
        parent: "",
        quotaPreferenceId: "",
        quotaPreference: undefined,
        ignoreSafetyChecks: []
    };
}
exports.CreateQuotaPreferenceRequest = {
    typeUrl: "/google.api.cloudquotas.v1beta.CreateQuotaPreferenceRequest",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.parent !== "") {
            writer.uint32(10).string(message.parent);
        }
        if (message.quotaPreferenceId !== "") {
            writer.uint32(18).string(message.quotaPreferenceId);
        }
        if (message.quotaPreference !== undefined) {
            resources_1.QuotaPreference.encode(message.quotaPreference, writer.uint32(26).fork()).ldelim();
        }
        writer.uint32(34).fork();
        for (const v of message.ignoreSafetyChecks) {
            writer.int32(v);
        }
        writer.ldelim();
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseCreateQuotaPreferenceRequest();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.parent = reader.string();
                    break;
                case 2:
                    message.quotaPreferenceId = reader.string();
                    break;
                case 3:
                    message.quotaPreference = resources_1.QuotaPreference.decode(reader, reader.uint32());
                    break;
                case 4:
                    if ((tag & 7) === 2) {
                        const end2 = reader.uint32() + reader.pos;
                        while (reader.pos < end2) {
                            message.ignoreSafetyChecks.push(reader.int32());
                        }
                    }
                    else {
                        message.ignoreSafetyChecks.push(reader.int32());
                    }
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseCreateQuotaPreferenceRequest();
        message.parent = object.parent ?? "";
        message.quotaPreferenceId = object.quotaPreferenceId ?? "";
        message.quotaPreference = object.quotaPreference !== undefined && object.quotaPreference !== null ? resources_1.QuotaPreference.fromPartial(object.quotaPreference) : undefined;
        message.ignoreSafetyChecks = object.ignoreSafetyChecks?.map(e => e) || [];
        return message;
    },
    fromAmino(object) {
        const message = createBaseCreateQuotaPreferenceRequest();
        if (object.parent !== undefined && object.parent !== null) {
            message.parent = object.parent;
        }
        if (object.quota_preference_id !== undefined && object.quota_preference_id !== null) {
            message.quotaPreferenceId = object.quota_preference_id;
        }
        if (object.quota_preference !== undefined && object.quota_preference !== null) {
            message.quotaPreference = resources_1.QuotaPreference.fromAmino(object.quota_preference);
        }
        message.ignoreSafetyChecks = object.ignore_safety_checks?.map(e => e) || [];
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.parent = message.parent === "" ? undefined : message.parent;
        obj.quota_preference_id = message.quotaPreferenceId === "" ? undefined : message.quotaPreferenceId;
        obj.quota_preference = message.quotaPreference ? resources_1.QuotaPreference.toAmino(message.quotaPreference) : undefined;
        if (message.ignoreSafetyChecks) {
            obj.ignore_safety_checks = message.ignoreSafetyChecks.map(e => e);
        }
        else {
            obj.ignore_safety_checks = message.ignoreSafetyChecks;
        }
        return obj;
    },
    fromAminoMsg(object) {
        return exports.CreateQuotaPreferenceRequest.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.CreateQuotaPreferenceRequest.decode(message.value);
    },
    toProto(message) {
        return exports.CreateQuotaPreferenceRequest.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.cloudquotas.v1beta.CreateQuotaPreferenceRequest",
            value: exports.CreateQuotaPreferenceRequest.encode(message).finish()
        };
    }
};
function createBaseUpdateQuotaPreferenceRequest() {
    return {
        updateMask: undefined,
        quotaPreference: undefined,
        allowMissing: false,
        validateOnly: false,
        ignoreSafetyChecks: []
    };
}
exports.UpdateQuotaPreferenceRequest = {
    typeUrl: "/google.api.cloudquotas.v1beta.UpdateQuotaPreferenceRequest",
    encode(message, writer = binary_1.BinaryWriter.create()) {
        if (message.updateMask !== undefined) {
            field_mask_1.FieldMask.encode(message.updateMask, writer.uint32(10).fork()).ldelim();
        }
        if (message.quotaPreference !== undefined) {
            resources_1.QuotaPreference.encode(message.quotaPreference, writer.uint32(18).fork()).ldelim();
        }
        if (message.allowMissing === true) {
            writer.uint32(24).bool(message.allowMissing);
        }
        if (message.validateOnly === true) {
            writer.uint32(32).bool(message.validateOnly);
        }
        writer.uint32(42).fork();
        for (const v of message.ignoreSafetyChecks) {
            writer.int32(v);
        }
        writer.ldelim();
        return writer;
    },
    decode(input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseUpdateQuotaPreferenceRequest();
        while (reader.pos < end) {
            const tag = reader.uint32();
            switch (tag >>> 3) {
                case 1:
                    message.updateMask = field_mask_1.FieldMask.decode(reader, reader.uint32());
                    break;
                case 2:
                    message.quotaPreference = resources_1.QuotaPreference.decode(reader, reader.uint32());
                    break;
                case 3:
                    message.allowMissing = reader.bool();
                    break;
                case 4:
                    message.validateOnly = reader.bool();
                    break;
                case 5:
                    if ((tag & 7) === 2) {
                        const end2 = reader.uint32() + reader.pos;
                        while (reader.pos < end2) {
                            message.ignoreSafetyChecks.push(reader.int32());
                        }
                    }
                    else {
                        message.ignoreSafetyChecks.push(reader.int32());
                    }
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial(object) {
        const message = createBaseUpdateQuotaPreferenceRequest();
        message.updateMask = object.updateMask !== undefined && object.updateMask !== null ? field_mask_1.FieldMask.fromPartial(object.updateMask) : undefined;
        message.quotaPreference = object.quotaPreference !== undefined && object.quotaPreference !== null ? resources_1.QuotaPreference.fromPartial(object.quotaPreference) : undefined;
        message.allowMissing = object.allowMissing ?? false;
        message.validateOnly = object.validateOnly ?? false;
        message.ignoreSafetyChecks = object.ignoreSafetyChecks?.map(e => e) || [];
        return message;
    },
    fromAmino(object) {
        const message = createBaseUpdateQuotaPreferenceRequest();
        if (object.update_mask !== undefined && object.update_mask !== null) {
            message.updateMask = field_mask_1.FieldMask.fromAmino(object.update_mask);
        }
        if (object.quota_preference !== undefined && object.quota_preference !== null) {
            message.quotaPreference = resources_1.QuotaPreference.fromAmino(object.quota_preference);
        }
        if (object.allow_missing !== undefined && object.allow_missing !== null) {
            message.allowMissing = object.allow_missing;
        }
        if (object.validate_only !== undefined && object.validate_only !== null) {
            message.validateOnly = object.validate_only;
        }
        message.ignoreSafetyChecks = object.ignore_safety_checks?.map(e => e) || [];
        return message;
    },
    toAmino(message) {
        const obj = {};
        obj.update_mask = message.updateMask ? field_mask_1.FieldMask.toAmino(message.updateMask) : undefined;
        obj.quota_preference = message.quotaPreference ? resources_1.QuotaPreference.toAmino(message.quotaPreference) : undefined;
        obj.allow_missing = message.allowMissing === false ? undefined : message.allowMissing;
        obj.validate_only = message.validateOnly === false ? undefined : message.validateOnly;
        if (message.ignoreSafetyChecks) {
            obj.ignore_safety_checks = message.ignoreSafetyChecks.map(e => e);
        }
        else {
            obj.ignore_safety_checks = message.ignoreSafetyChecks;
        }
        return obj;
    },
    fromAminoMsg(object) {
        return exports.UpdateQuotaPreferenceRequest.fromAmino(object.value);
    },
    fromProtoMsg(message) {
        return exports.UpdateQuotaPreferenceRequest.decode(message.value);
    },
    toProto(message) {
        return exports.UpdateQuotaPreferenceRequest.encode(message).finish();
    },
    toProtoMsg(message) {
        return {
            typeUrl: "/google.api.cloudquotas.v1beta.UpdateQuotaPreferenceRequest",
            value: exports.UpdateQuotaPreferenceRequest.encode(message).finish()
        };
    }
};
