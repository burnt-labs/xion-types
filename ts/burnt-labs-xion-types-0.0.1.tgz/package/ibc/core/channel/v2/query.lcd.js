"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.LCDQueryClient = void 0;
//@ts-nocheck
const helpers_1 = require("../../../../helpers");
class LCDQueryClient {
    constructor({ requestClient }) {
        this.req = requestClient;
        this.nextSequenceSend = this.nextSequenceSend.bind(this);
        this.packetCommitment = this.packetCommitment.bind(this);
        this.packetCommitments = this.packetCommitments.bind(this);
        this.packetAcknowledgement = this.packetAcknowledgement.bind(this);
        this.packetAcknowledgements = this.packetAcknowledgements.bind(this);
        this.packetReceipt = this.packetReceipt.bind(this);
        this.unreceivedPackets = this.unreceivedPackets.bind(this);
        this.unreceivedAcks = this.unreceivedAcks.bind(this);
    }
    /* NextSequenceSend returns the next send sequence for a given channel. */
    async nextSequenceSend(params) {
        const endpoint = `ibc/core/channel/v2/clients/${params.clientId}/next_sequence_send`;
        return await this.req.get(endpoint);
    }
    /* PacketCommitment queries a stored packet commitment hash. */
    async packetCommitment(params) {
        const endpoint = `ibc/core/channel/v2/clients/${params.clientId}/packet_commitments/${params.sequence}`;
        return await this.req.get(endpoint);
    }
    /* PacketCommitments queries a stored packet commitment hash. */
    async packetCommitments(params) {
        const options = {
            params: {}
        };
        if (typeof params?.pagination !== "undefined") {
            (0, helpers_1.setPaginationParams)(options, params.pagination);
        }
        const endpoint = `ibc/core/channel/v2/clients/${params.clientId}/packet_commitments`;
        return await this.req.get(endpoint, options);
    }
    /* PacketAcknowledgement queries a stored acknowledgement commitment hash. */
    async packetAcknowledgement(params) {
        const endpoint = `ibc/core/channel/v2/clients/${params.clientId}/packet_acks/${params.sequence}`;
        return await this.req.get(endpoint);
    }
    /* PacketAcknowledgements returns all packet acknowledgements associated with a channel. */
    async packetAcknowledgements(params) {
        const options = {
            params: {}
        };
        if (typeof params?.pagination !== "undefined") {
            (0, helpers_1.setPaginationParams)(options, params.pagination);
        }
        if (typeof params?.packetCommitmentSequences !== "undefined") {
            options.params.packet_commitment_sequences = params.packetCommitmentSequences;
        }
        const endpoint = `ibc/core/channel/v2/clients/${params.clientId}/packet_acknowledgements`;
        return await this.req.get(endpoint, options);
    }
    /* PacketReceipt queries a stored packet receipt. */
    async packetReceipt(params) {
        const endpoint = `ibc/core/channel/v2/clients/${params.clientId}/packet_receipts/${params.sequence}`;
        return await this.req.get(endpoint);
    }
    /* UnreceivedPackets returns all the unreceived IBC packets associated with a channel and sequences. */
    async unreceivedPackets(params) {
        const endpoint = `ibc/core/channel/v2/clients/${params.clientId}/packet_commitments/${params.sequences}/unreceived_packets`;
        return await this.req.get(endpoint);
    }
    /* UnreceivedAcks returns all the unreceived IBC acknowledgements associated with a channel and sequences. */
    async unreceivedAcks(params) {
        const endpoint = `ibc/core/channel/v2/clients/${params.clientId}/packet_commitments/${params.packetAckSequences}/unreceived_acks`;
        return await this.req.get(endpoint);
    }
}
exports.LCDQueryClient = LCDQueryClient;
