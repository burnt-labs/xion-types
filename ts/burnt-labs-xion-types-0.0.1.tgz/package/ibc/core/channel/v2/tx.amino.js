"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AminoConverter = void 0;
//@ts-nocheck
const tx_1 = require("./tx");
exports.AminoConverter = {
    "/ibc.core.channel.v2.MsgSendPacket": {
        aminoType: "cosmos-sdk/MsgSendPacket",
        toAmino: tx_1.MsgSendPacket.toAmino,
        fromAmino: tx_1.MsgSendPacket.fromAmino
    },
    "/ibc.core.channel.v2.MsgRecvPacket": {
        aminoType: "cosmos-sdk/MsgRecvPacket",
        toAmino: tx_1.MsgRecvPacket.toAmino,
        fromAmino: tx_1.MsgRecvPacket.fromAmino
    },
    "/ibc.core.channel.v2.MsgTimeout": {
        aminoType: "cosmos-sdk/MsgTimeout",
        toAmino: tx_1.MsgTimeout.toAmino,
        fromAmino: tx_1.MsgTimeout.fromAmino
    },
    "/ibc.core.channel.v2.MsgAcknowledgement": {
        aminoType: "cosmos-sdk/MsgAcknowledgement",
        toAmino: tx_1.MsgAcknowledgement.toAmino,
        fromAmino: tx_1.MsgAcknowledgement.fromAmino
    }
};
