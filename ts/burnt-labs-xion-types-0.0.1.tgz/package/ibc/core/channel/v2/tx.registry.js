"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.MessageComposer = exports.load = exports.registry = void 0;
const tx_1 = require("./tx");
exports.registry = [["/ibc.core.channel.v2.MsgSendPacket", tx_1.MsgSendPacket], ["/ibc.core.channel.v2.MsgRecvPacket", tx_1.MsgRecvPacket], ["/ibc.core.channel.v2.MsgTimeout", tx_1.MsgTimeout], ["/ibc.core.channel.v2.MsgAcknowledgement", tx_1.MsgAcknowledgement]];
const load = (protoRegistry) => {
    exports.registry.forEach(([typeUrl, mod]) => {
        protoRegistry.register(typeUrl, mod);
    });
};
exports.load = load;
exports.MessageComposer = {
    encoded: {
        sendPacket(value) {
            return {
                typeUrl: "/ibc.core.channel.v2.MsgSendPacket",
                value: tx_1.MsgSendPacket.encode(value).finish()
            };
        },
        recvPacket(value) {
            return {
                typeUrl: "/ibc.core.channel.v2.MsgRecvPacket",
                value: tx_1.MsgRecvPacket.encode(value).finish()
            };
        },
        timeout(value) {
            return {
                typeUrl: "/ibc.core.channel.v2.MsgTimeout",
                value: tx_1.MsgTimeout.encode(value).finish()
            };
        },
        acknowledgement(value) {
            return {
                typeUrl: "/ibc.core.channel.v2.MsgAcknowledgement",
                value: tx_1.MsgAcknowledgement.encode(value).finish()
            };
        }
    },
    withTypeUrl: {
        sendPacket(value) {
            return {
                typeUrl: "/ibc.core.channel.v2.MsgSendPacket",
                value
            };
        },
        recvPacket(value) {
            return {
                typeUrl: "/ibc.core.channel.v2.MsgRecvPacket",
                value
            };
        },
        timeout(value) {
            return {
                typeUrl: "/ibc.core.channel.v2.MsgTimeout",
                value
            };
        },
        acknowledgement(value) {
            return {
                typeUrl: "/ibc.core.channel.v2.MsgAcknowledgement",
                value
            };
        }
    },
    fromPartial: {
        sendPacket(value) {
            return {
                typeUrl: "/ibc.core.channel.v2.MsgSendPacket",
                value: tx_1.MsgSendPacket.fromPartial(value)
            };
        },
        recvPacket(value) {
            return {
                typeUrl: "/ibc.core.channel.v2.MsgRecvPacket",
                value: tx_1.MsgRecvPacket.fromPartial(value)
            };
        },
        timeout(value) {
            return {
                typeUrl: "/ibc.core.channel.v2.MsgTimeout",
                value: tx_1.MsgTimeout.fromPartial(value)
            };
        },
        acknowledgement(value) {
            return {
                typeUrl: "/ibc.core.channel.v2.MsgAcknowledgement",
                value: tx_1.MsgAcknowledgement.fromPartial(value)
            };
        }
    }
};
