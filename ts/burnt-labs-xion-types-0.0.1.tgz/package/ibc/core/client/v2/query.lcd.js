"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.LCDQueryClient = void 0;
class LCDQueryClient {
    constructor({ requestClient }) {
        this.req = requestClient;
        this.counterpartyInfo = this.counterpartyInfo.bind(this);
        this.config = this.config.bind(this);
    }
    /* CounterpartyInfo queries an IBC light counter party info. */
    async counterpartyInfo(params) {
        const endpoint = `ibc/core/client/v2/counterparty_info/${params.clientId}`;
        return await this.req.get(endpoint);
    }
    /* Config queries the IBC client v2 configuration for a given client. */
    async config(params) {
        const endpoint = `ibc/core/client/v2/config/${params.clientId}`;
        return await this.req.get(endpoint);
    }
}
exports.LCDQueryClient = LCDQueryClient;
