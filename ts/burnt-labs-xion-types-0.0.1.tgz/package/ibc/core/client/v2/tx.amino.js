"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AminoConverter = void 0;
//@ts-nocheck
const tx_1 = require("./tx");
exports.AminoConverter = {
    "/ibc.core.client.v2.MsgRegisterCounterparty": {
        aminoType: "cosmos-sdk/MsgRegisterCounterparty",
        toAmino: tx_1.MsgRegisterCounterparty.toAmino,
        fromAmino: tx_1.MsgRegisterCounterparty.fromAmino
    },
    "/ibc.core.client.v2.MsgUpdateClientConfig": {
        aminoType: "cosmos-sdk/MsgUpdateClientConfig",
        toAmino: tx_1.MsgUpdateClientConfig.toAmino,
        fromAmino: tx_1.MsgUpdateClientConfig.fromAmino
    }
};
