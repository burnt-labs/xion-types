"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.LCDQueryClient = void 0;
//@ts-nocheck
const helpers_1 = require("../../../../helpers");
class LCDQueryClient {
    constructor({ requestClient }) {
        this.req = requestClient;
        this.params = this.params.bind(this);
        this.denoms = this.denoms.bind(this);
        this.denom = this.denom.bind(this);
        this.denomHash = this.denomHash.bind(this);
        this.escrowAddress = this.escrowAddress.bind(this);
        this.totalEscrowForDenom = this.totalEscrowForDenom.bind(this);
    }
    /* Params queries all parameters of the ibc-transfer module. */
    async params(_params = {}) {
        const endpoint = `ibc/apps/transfer/v1/params`;
        return await this.req.get(endpoint);
    }
    /* Denoms queries all denominations */
    async denoms(params = {
        pagination: undefined
    }) {
        const options = {
            params: {}
        };
        if (typeof params?.pagination !== "undefined") {
            (0, helpers_1.setPaginationParams)(options, params.pagination);
        }
        const endpoint = `ibc/apps/transfer/v1/denoms`;
        return await this.req.get(endpoint, options);
    }
    /* Denom queries a denomination */
    async denom(params) {
        const options = {
            params: {}
        };
        if (typeof params?.hash !== "undefined") {
            options.params.hash = params.hash;
        }
        const endpoint = `ibc/apps/transfer/v1/denoms/${params.hash}`;
        return await this.req.get(endpoint, options);
    }
    /* DenomHash queries a denomination hash information. */
    async denomHash(params) {
        const options = {
            params: {}
        };
        if (typeof params?.trace !== "undefined") {
            options.params.trace = params.trace;
        }
        const endpoint = `ibc/apps/transfer/v1/denom_hashes/${params.trace}`;
        return await this.req.get(endpoint, options);
    }
    /* EscrowAddress returns the escrow address for a particular port and channel id. */
    async escrowAddress(params) {
        const endpoint = `ibc/apps/transfer/v1/channels/${params.channelId}/ports/${params.portId}/escrow_address`;
        return await this.req.get(endpoint);
    }
    /* TotalEscrowForDenom returns the total amount of tokens in escrow based on the denom. */
    async totalEscrowForDenom(params) {
        const options = {
            params: {}
        };
        if (typeof params?.denom !== "undefined") {
            options.params.denom = params.denom;
        }
        const endpoint = `ibc/apps/transfer/v1/total_escrow/${params.denom}`;
        return await this.req.get(endpoint, options);
    }
}
exports.LCDQueryClient = LCDQueryClient;
