"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.MessageComposer = exports.load = exports.registry = void 0;
const tx_1 = require("./tx");
exports.registry = [["/ibc.applications.interchain_accounts.controller.v1.MsgRegisterInterchainAccount", tx_1.MsgRegisterInterchainAccount], ["/ibc.applications.interchain_accounts.controller.v1.MsgSendTx", tx_1.MsgSendTx], ["/ibc.applications.interchain_accounts.controller.v1.MsgUpdateParams", tx_1.MsgUpdateParams]];
const load = (protoRegistry) => {
    exports.registry.forEach(([typeUrl, mod]) => {
        protoRegistry.register(typeUrl, mod);
    });
};
exports.load = load;
exports.MessageComposer = {
    encoded: {
        registerInterchainAccount(value) {
            return {
                typeUrl: "/ibc.applications.interchain_accounts.controller.v1.MsgRegisterInterchainAccount",
                value: tx_1.MsgRegisterInterchainAccount.encode(value).finish()
            };
        },
        sendTx(value) {
            return {
                typeUrl: "/ibc.applications.interchain_accounts.controller.v1.MsgSendTx",
                value: tx_1.MsgSendTx.encode(value).finish()
            };
        },
        updateParams(value) {
            return {
                typeUrl: "/ibc.applications.interchain_accounts.controller.v1.MsgUpdateParams",
                value: tx_1.MsgUpdateParams.encode(value).finish()
            };
        }
    },
    withTypeUrl: {
        registerInterchainAccount(value) {
            return {
                typeUrl: "/ibc.applications.interchain_accounts.controller.v1.MsgRegisterInterchainAccount",
                value
            };
        },
        sendTx(value) {
            return {
                typeUrl: "/ibc.applications.interchain_accounts.controller.v1.MsgSendTx",
                value
            };
        },
        updateParams(value) {
            return {
                typeUrl: "/ibc.applications.interchain_accounts.controller.v1.MsgUpdateParams",
                value
            };
        }
    },
    fromPartial: {
        registerInterchainAccount(value) {
            return {
                typeUrl: "/ibc.applications.interchain_accounts.controller.v1.MsgRegisterInterchainAccount",
                value: tx_1.MsgRegisterInterchainAccount.fromPartial(value)
            };
        },
        sendTx(value) {
            return {
                typeUrl: "/ibc.applications.interchain_accounts.controller.v1.MsgSendTx",
                value: tx_1.MsgSendTx.fromPartial(value)
            };
        },
        updateParams(value) {
            return {
                typeUrl: "/ibc.applications.interchain_accounts.controller.v1.MsgUpdateParams",
                value: tx_1.MsgUpdateParams.fromPartial(value)
            };
        }
    }
};
