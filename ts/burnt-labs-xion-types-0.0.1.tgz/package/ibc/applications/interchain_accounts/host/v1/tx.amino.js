"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AminoConverter = void 0;
//@ts-nocheck
const tx_1 = require("./tx");
exports.AminoConverter = {
    "/ibc.applications.interchain_accounts.host.v1.MsgUpdateParams": {
        aminoType: "cosmos-sdk/MsgUpdateParams",
        toAmino: tx_1.MsgUpdateParams.toAmino,
        fromAmino: tx_1.MsgUpdateParams.fromAmino
    },
    "/ibc.applications.interchain_accounts.host.v1.MsgModuleQuerySafe": {
        aminoType: "cosmos-sdk/MsgModuleQuerySafe",
        toAmino: tx_1.MsgModuleQuerySafe.toAmino,
        fromAmino: tx_1.MsgModuleQuerySafe.fromAmino
    }
};
