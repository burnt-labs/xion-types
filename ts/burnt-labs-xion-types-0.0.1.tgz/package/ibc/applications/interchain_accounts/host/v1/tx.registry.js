"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.MessageComposer = exports.load = exports.registry = void 0;
const tx_1 = require("./tx");
exports.registry = [["/ibc.applications.interchain_accounts.host.v1.MsgUpdateParams", tx_1.MsgUpdateParams], ["/ibc.applications.interchain_accounts.host.v1.MsgModuleQuerySafe", tx_1.MsgModuleQuerySafe]];
const load = (protoRegistry) => {
    exports.registry.forEach(([typeUrl, mod]) => {
        protoRegistry.register(typeUrl, mod);
    });
};
exports.load = load;
exports.MessageComposer = {
    encoded: {
        updateParams(value) {
            return {
                typeUrl: "/ibc.applications.interchain_accounts.host.v1.MsgUpdateParams",
                value: tx_1.MsgUpdateParams.encode(value).finish()
            };
        },
        moduleQuerySafe(value) {
            return {
                typeUrl: "/ibc.applications.interchain_accounts.host.v1.MsgModuleQuerySafe",
                value: tx_1.MsgModuleQuerySafe.encode(value).finish()
            };
        }
    },
    withTypeUrl: {
        updateParams(value) {
            return {
                typeUrl: "/ibc.applications.interchain_accounts.host.v1.MsgUpdateParams",
                value
            };
        },
        moduleQuerySafe(value) {
            return {
                typeUrl: "/ibc.applications.interchain_accounts.host.v1.MsgModuleQuerySafe",
                value
            };
        }
    },
    fromPartial: {
        updateParams(value) {
            return {
                typeUrl: "/ibc.applications.interchain_accounts.host.v1.MsgUpdateParams",
                value: tx_1.MsgUpdateParams.fromPartial(value)
            };
        },
        moduleQuerySafe(value) {
            return {
                typeUrl: "/ibc.applications.interchain_accounts.host.v1.MsgModuleQuerySafe",
                value: tx_1.MsgModuleQuerySafe.fromPartial(value)
            };
        }
    }
};
