"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AminoConverter = void 0;
//@ts-nocheck
const tx_1 = require("./tx");
exports.AminoConverter = {
    "/ibc.lightclients.wasm.v1.MsgStoreCode": {
        aminoType: "cosmos-sdk/MsgStoreCode",
        toAmino: tx_1.MsgStoreCode.toAmino,
        fromAmino: tx_1.MsgStoreCode.fromAmino
    },
    "/ibc.lightclients.wasm.v1.MsgRemoveChecksum": {
        aminoType: "cosmos-sdk/MsgRemoveChecksum",
        toAmino: tx_1.MsgRemoveChecksum.toAmino,
        fromAmino: tx_1.MsgRemoveChecksum.fromAmino
    },
    "/ibc.lightclients.wasm.v1.MsgMigrateContract": {
        aminoType: "cosmos-sdk/MsgMigrateContract",
        toAmino: tx_1.MsgMigrateContract.toAmino,
        fromAmino: tx_1.MsgMigrateContract.fromAmino
    }
};
