"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.LCDQueryClient = void 0;
//@ts-nocheck
const helpers_1 = require("../../../../helpers");
class LCDQueryClient {
    constructor({ requestClient }) {
        this.req = requestClient;
        this.checksums = this.checksums.bind(this);
        this.code = this.code.bind(this);
    }
    /* Get all Wasm checksums */
    async checksums(params = {
        pagination: undefined
    }) {
        const options = {
            params: {}
        };
        if (typeof params?.pagination !== "undefined") {
            (0, helpers_1.setPaginationParams)(options, params.pagination);
        }
        const endpoint = `ibc/lightclients/wasm/v1/checksums`;
        return await this.req.get(endpoint, options);
    }
    /* Get Wasm code for given checksum */
    async code(params) {
        const endpoint = `ibc/lightclients/wasm/v1/checksums/${params.checksum}/code`;
        return await this.req.get(endpoint);
    }
}
exports.LCDQueryClient = LCDQueryClient;
