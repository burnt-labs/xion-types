"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createRpcQueryExtension = exports.QueryClientImpl = void 0;
const binary_1 = require("../../../../binary");
const stargate_1 = require("@cosmjs/stargate");
const query_1 = require("./query");
class QueryClientImpl {
    constructor(rpc) {
        this.rpc = rpc;
        this.checksums = this.checksums.bind(this);
        this.code = this.code.bind(this);
    }
    checksums(request = {
        pagination: undefined
    }) {
        const data = query_1.QueryChecksumsRequest.encode(request).finish();
        const promise = this.rpc.request("ibc.lightclients.wasm.v1.Query", "Checksums", data);
        return promise.then(data => query_1.QueryChecksumsResponse.decode(new binary_1.BinaryReader(data)));
    }
    code(request) {
        const data = query_1.QueryCodeRequest.encode(request).finish();
        const promise = this.rpc.request("ibc.lightclients.wasm.v1.Query", "Code", data);
        return promise.then(data => query_1.QueryCodeResponse.decode(new binary_1.BinaryReader(data)));
    }
}
exports.QueryClientImpl = QueryClientImpl;
const createRpcQueryExtension = (base) => {
    const rpc = (0, stargate_1.createProtobufRpcClient)(base);
    const queryService = new QueryClientImpl(rpc);
    return {
        checksums(request) {
            return queryService.checksums(request);
        },
        code(request) {
            return queryService.code(request);
        }
    };
};
exports.createRpcQueryExtension = createRpcQueryExtension;
