"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.ibc = void 0;
//@ts-nocheck
const _206 = __importStar(require("./applications/interchain_accounts/controller/v1/controller"));
const _207 = __importStar(require("./applications/interchain_accounts/controller/v1/query"));
const _208 = __importStar(require("./applications/interchain_accounts/controller/v1/tx"));
const _209 = __importStar(require("./applications/interchain_accounts/genesis/v1/genesis"));
const _210 = __importStar(require("./applications/interchain_accounts/host/v1/host"));
const _211 = __importStar(require("./applications/interchain_accounts/host/v1/query"));
const _212 = __importStar(require("./applications/interchain_accounts/host/v1/tx"));
const _213 = __importStar(require("./applications/interchain_accounts/v1/account"));
const _214 = __importStar(require("./applications/interchain_accounts/v1/metadata"));
const _215 = __importStar(require("./applications/interchain_accounts/v1/packet"));
const _216 = __importStar(require("./applications/transfer/v1/authz"));
const _217 = __importStar(require("./applications/transfer/v1/denomtrace"));
const _218 = __importStar(require("./applications/transfer/v1/genesis"));
const _219 = __importStar(require("./applications/transfer/v1/packet"));
const _220 = __importStar(require("./applications/transfer/v1/query"));
const _221 = __importStar(require("./applications/transfer/v1/token"));
const _222 = __importStar(require("./applications/transfer/v1/transfer"));
const _223 = __importStar(require("./applications/transfer/v1/tx"));
const _224 = __importStar(require("./core/channel/v1/channel"));
const _225 = __importStar(require("./core/channel/v1/genesis"));
const _226 = __importStar(require("./core/channel/v1/query"));
const _227 = __importStar(require("./core/channel/v1/tx"));
const _228 = __importStar(require("./core/channel/v2/genesis"));
const _229 = __importStar(require("./core/channel/v2/packet"));
const _230 = __importStar(require("./core/channel/v2/query"));
const _231 = __importStar(require("./core/channel/v2/tx"));
const _232 = __importStar(require("./core/client/v1/client"));
const _233 = __importStar(require("./core/client/v1/genesis"));
const _234 = __importStar(require("./core/client/v1/query"));
const _235 = __importStar(require("./core/client/v1/tx"));
const _236 = __importStar(require("./core/client/v2/config"));
const _237 = __importStar(require("./core/client/v2/counterparty"));
const _238 = __importStar(require("./core/client/v2/genesis"));
const _239 = __importStar(require("./core/client/v2/query"));
const _240 = __importStar(require("./core/client/v2/tx"));
const _241 = __importStar(require("./core/commitment/v1/commitment"));
const _242 = __importStar(require("./core/commitment/v2/commitment"));
const _243 = __importStar(require("./core/connection/v1/connection"));
const _244 = __importStar(require("./core/connection/v1/genesis"));
const _245 = __importStar(require("./core/connection/v1/query"));
const _246 = __importStar(require("./core/connection/v1/tx"));
const _247 = __importStar(require("./core/types/v1/genesis"));
const _248 = __importStar(require("./lightclients/solomachine/v2/solomachine"));
const _249 = __importStar(require("./lightclients/solomachine/v3/solomachine"));
const _250 = __importStar(require("./lightclients/tendermint/v1/tendermint"));
const _251 = __importStar(require("./lightclients/wasm/v1/genesis"));
const _252 = __importStar(require("./lightclients/wasm/v1/query"));
const _253 = __importStar(require("./lightclients/wasm/v1/tx"));
const _254 = __importStar(require("./lightclients/wasm/v1/wasm"));
const _408 = __importStar(require("./applications/interchain_accounts/controller/v1/tx.amino"));
const _409 = __importStar(require("./applications/interchain_accounts/host/v1/tx.amino"));
const _410 = __importStar(require("./applications/transfer/v1/tx.amino"));
const _411 = __importStar(require("./core/channel/v1/tx.amino"));
const _412 = __importStar(require("./core/channel/v2/tx.amino"));
const _413 = __importStar(require("./core/client/v1/tx.amino"));
const _414 = __importStar(require("./core/client/v2/tx.amino"));
const _415 = __importStar(require("./core/connection/v1/tx.amino"));
const _416 = __importStar(require("./lightclients/wasm/v1/tx.amino"));
const _417 = __importStar(require("./applications/interchain_accounts/controller/v1/tx.registry"));
const _418 = __importStar(require("./applications/interchain_accounts/host/v1/tx.registry"));
const _419 = __importStar(require("./applications/transfer/v1/tx.registry"));
const _420 = __importStar(require("./core/channel/v1/tx.registry"));
const _421 = __importStar(require("./core/channel/v2/tx.registry"));
const _422 = __importStar(require("./core/client/v1/tx.registry"));
const _423 = __importStar(require("./core/client/v2/tx.registry"));
const _424 = __importStar(require("./core/connection/v1/tx.registry"));
const _425 = __importStar(require("./lightclients/wasm/v1/tx.registry"));
const _426 = __importStar(require("./applications/interchain_accounts/controller/v1/query.lcd"));
const _427 = __importStar(require("./applications/interchain_accounts/host/v1/query.lcd"));
const _428 = __importStar(require("./applications/transfer/v1/query.lcd"));
const _429 = __importStar(require("./core/channel/v1/query.lcd"));
const _430 = __importStar(require("./core/channel/v2/query.lcd"));
const _431 = __importStar(require("./core/client/v1/query.lcd"));
const _432 = __importStar(require("./core/client/v2/query.lcd"));
const _433 = __importStar(require("./core/connection/v1/query.lcd"));
const _434 = __importStar(require("./lightclients/wasm/v1/query.lcd"));
const _435 = __importStar(require("./applications/interchain_accounts/controller/v1/query.rpc.Query"));
const _436 = __importStar(require("./applications/interchain_accounts/host/v1/query.rpc.Query"));
const _437 = __importStar(require("./applications/transfer/v1/query.rpc.Query"));
const _438 = __importStar(require("./core/channel/v1/query.rpc.Query"));
const _439 = __importStar(require("./core/channel/v2/query.rpc.Query"));
const _440 = __importStar(require("./core/client/v1/query.rpc.Query"));
const _441 = __importStar(require("./core/client/v2/query.rpc.Query"));
const _442 = __importStar(require("./core/connection/v1/query.rpc.Query"));
const _443 = __importStar(require("./lightclients/wasm/v1/query.rpc.Query"));
const _444 = __importStar(require("./applications/interchain_accounts/controller/v1/tx.rpc.msg"));
const _445 = __importStar(require("./applications/interchain_accounts/host/v1/tx.rpc.msg"));
const _446 = __importStar(require("./applications/transfer/v1/tx.rpc.msg"));
const _447 = __importStar(require("./core/channel/v1/tx.rpc.msg"));
const _448 = __importStar(require("./core/channel/v2/tx.rpc.msg"));
const _449 = __importStar(require("./core/client/v1/tx.rpc.msg"));
const _450 = __importStar(require("./core/client/v2/tx.rpc.msg"));
const _451 = __importStar(require("./core/connection/v1/tx.rpc.msg"));
const _452 = __importStar(require("./lightclients/wasm/v1/tx.rpc.msg"));
const _483 = __importStar(require("./lcd"));
const _484 = __importStar(require("./rpc.query"));
const _485 = __importStar(require("./rpc.tx"));
var ibc;
(function (ibc) {
    let applications;
    (function (applications) {
        let interchain_accounts;
        (function (interchain_accounts) {
            let controller;
            (function (controller) {
                controller.v1 = {
                    ..._206,
                    ..._207,
                    ..._208,
                    ..._408,
                    ..._417,
                    ..._426,
                    ..._435,
                    ..._444
                };
            })(controller = interchain_accounts.controller || (interchain_accounts.controller = {}));
            let genesis;
            (function (genesis) {
                genesis.v1 = {
                    ..._209
                };
            })(genesis = interchain_accounts.genesis || (interchain_accounts.genesis = {}));
            let host;
            (function (host) {
                host.v1 = {
                    ..._210,
                    ..._211,
                    ..._212,
                    ..._409,
                    ..._418,
                    ..._427,
                    ..._436,
                    ..._445
                };
            })(host = interchain_accounts.host || (interchain_accounts.host = {}));
            interchain_accounts.v1 = {
                ..._213,
                ..._214,
                ..._215
            };
        })(interchain_accounts = applications.interchain_accounts || (applications.interchain_accounts = {}));
        let transfer;
        (function (transfer) {
            transfer.v1 = {
                ..._216,
                ..._217,
                ..._218,
                ..._219,
                ..._220,
                ..._221,
                ..._222,
                ..._223,
                ..._410,
                ..._419,
                ..._428,
                ..._437,
                ..._446
            };
        })(transfer = applications.transfer || (applications.transfer = {}));
    })(applications = ibc.applications || (ibc.applications = {}));
    let core;
    (function (core) {
        let channel;
        (function (channel) {
            channel.v1 = {
                ..._224,
                ..._225,
                ..._226,
                ..._227,
                ..._411,
                ..._420,
                ..._429,
                ..._438,
                ..._447
            };
            channel.v2 = {
                ..._228,
                ..._229,
                ..._230,
                ..._231,
                ..._412,
                ..._421,
                ..._430,
                ..._439,
                ..._448
            };
        })(channel = core.channel || (core.channel = {}));
        let client;
        (function (client) {
            client.v1 = {
                ..._232,
                ..._233,
                ..._234,
                ..._235,
                ..._413,
                ..._422,
                ..._431,
                ..._440,
                ..._449
            };
            client.v2 = {
                ..._236,
                ..._237,
                ..._238,
                ..._239,
                ..._240,
                ..._414,
                ..._423,
                ..._432,
                ..._441,
                ..._450
            };
        })(client = core.client || (core.client = {}));
        let commitment;
        (function (commitment) {
            commitment.v1 = {
                ..._241
            };
            commitment.v2 = {
                ..._242
            };
        })(commitment = core.commitment || (core.commitment = {}));
        let connection;
        (function (connection) {
            connection.v1 = {
                ..._243,
                ..._244,
                ..._245,
                ..._246,
                ..._415,
                ..._424,
                ..._433,
                ..._442,
                ..._451
            };
        })(connection = core.connection || (core.connection = {}));
        let types;
        (function (types) {
            types.v1 = {
                ..._247
            };
        })(types = core.types || (core.types = {}));
    })(core = ibc.core || (ibc.core = {}));
    let lightclients;
    (function (lightclients) {
        let solomachine;
        (function (solomachine) {
            solomachine.v2 = {
                ..._248
            };
            solomachine.v3 = {
                ..._249
            };
        })(solomachine = lightclients.solomachine || (lightclients.solomachine = {}));
        let tendermint;
        (function (tendermint) {
            tendermint.v1 = {
                ..._250
            };
        })(tendermint = lightclients.tendermint || (lightclients.tendermint = {}));
        let wasm;
        (function (wasm) {
            wasm.v1 = {
                ..._251,
                ..._252,
                ..._253,
                ..._254,
                ..._416,
                ..._425,
                ..._434,
                ..._443,
                ..._452
            };
        })(wasm = lightclients.wasm || (lightclients.wasm = {}));
    })(lightclients = ibc.lightclients || (ibc.lightclients = {}));
    ibc.ClientFactory = {
        ..._483,
        ..._484,
        ..._485
    };
})(ibc || (exports.ibc = ibc = {}));
