"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.LCDQueryClient = void 0;
//@ts-nocheck
const helpers_1 = require("../../../helpers");
class LCDQueryClient {
    constructor({ requestClient }) {
        this.req = requestClient;
        this.contractInfo = this.contractInfo.bind(this);
        this.contractHistory = this.contractHistory.bind(this);
        this.contractsByCode = this.contractsByCode.bind(this);
        this.allContractState = this.allContractState.bind(this);
        this.rawContractState = this.rawContractState.bind(this);
        this.smartContractState = this.smartContractState.bind(this);
        this.code = this.code.bind(this);
        this.codes = this.codes.bind(this);
        this.codeInfo = this.codeInfo.bind(this);
        this.pinnedCodes = this.pinnedCodes.bind(this);
        this.params = this.params.bind(this);
        this.contractsByCreator = this.contractsByCreator.bind(this);
        this.wasmLimitsConfig = this.wasmLimitsConfig.bind(this);
        this.buildAddress = this.buildAddress.bind(this);
    }
    /* ContractInfo gets the contract meta data */
    async contractInfo(params) {
        const endpoint = `cosmwasm/wasm/v1/contract/${params.address}`;
        return await this.req.get(endpoint);
    }
    /* ContractHistory gets the contract code history */
    async contractHistory(params) {
        const options = {
            params: {}
        };
        if (typeof params?.pagination !== "undefined") {
            (0, helpers_1.setPaginationParams)(options, params.pagination);
        }
        const endpoint = `cosmwasm/wasm/v1/contract/${params.address}/history`;
        return await this.req.get(endpoint, options);
    }
    /* ContractsByCode lists all smart contracts for a code id */
    async contractsByCode(params) {
        const options = {
            params: {}
        };
        if (typeof params?.pagination !== "undefined") {
            (0, helpers_1.setPaginationParams)(options, params.pagination);
        }
        const endpoint = `cosmwasm/wasm/v1/code/${params.codeId}/contracts`;
        return await this.req.get(endpoint, options);
    }
    /* AllContractState gets all raw store data for a single contract */
    async allContractState(params) {
        const options = {
            params: {}
        };
        if (typeof params?.pagination !== "undefined") {
            (0, helpers_1.setPaginationParams)(options, params.pagination);
        }
        const endpoint = `cosmwasm/wasm/v1/contract/${params.address}/state`;
        return await this.req.get(endpoint, options);
    }
    /* RawContractState gets single key from the raw store data of a contract */
    async rawContractState(params) {
        const endpoint = `cosmwasm/wasm/v1/contract/${params.address}/raw/${params.queryData}`;
        return await this.req.get(endpoint);
    }
    /* SmartContractState get smart query result from the contract */
    async smartContractState(params) {
        const endpoint = `cosmwasm/wasm/v1/contract/${params.address}/smart/${params.queryData}`;
        return await this.req.get(endpoint);
    }
    /* Code gets the binary code and metadata for a single wasm code */
    async code(params) {
        const endpoint = `cosmwasm/wasm/v1/code/${params.codeId}`;
        return await this.req.get(endpoint);
    }
    /* Codes gets the metadata for all stored wasm codes */
    async codes(params = {
        pagination: undefined
    }) {
        const options = {
            params: {}
        };
        if (typeof params?.pagination !== "undefined") {
            (0, helpers_1.setPaginationParams)(options, params.pagination);
        }
        const endpoint = `cosmwasm/wasm/v1/code`;
        return await this.req.get(endpoint, options);
    }
    /* CodeInfo gets the metadata for a single wasm code */
    async codeInfo(params) {
        const endpoint = `cosmwasm/wasm/v1/code-info/${params.codeId}`;
        return await this.req.get(endpoint);
    }
    /* PinnedCodes gets the pinned code ids */
    async pinnedCodes(params = {
        pagination: undefined
    }) {
        const options = {
            params: {}
        };
        if (typeof params?.pagination !== "undefined") {
            (0, helpers_1.setPaginationParams)(options, params.pagination);
        }
        const endpoint = `cosmwasm/wasm/v1/codes/pinned`;
        return await this.req.get(endpoint, options);
    }
    /* Params gets the module params */
    async params(_params = {}) {
        const endpoint = `cosmwasm/wasm/v1/codes/params`;
        return await this.req.get(endpoint);
    }
    /* ContractsByCreator gets the contracts by creator */
    async contractsByCreator(params) {
        const options = {
            params: {}
        };
        if (typeof params?.pagination !== "undefined") {
            (0, helpers_1.setPaginationParams)(options, params.pagination);
        }
        const endpoint = `cosmwasm/wasm/v1/contracts/creator/${params.creatorAddress}`;
        return await this.req.get(endpoint, options);
    }
    /* WasmLimitsConfig gets the configured limits for static validation of Wasm
     files, encoded in JSON. */
    async wasmLimitsConfig(_params = {}) {
        const endpoint = `cosmwasm/wasm/v1/wasm-limits-config`;
        return await this.req.get(endpoint);
    }
    /* BuildAddress builds a contract address */
    async buildAddress(params) {
        const options = {
            params: {}
        };
        if (typeof params?.codeHash !== "undefined") {
            options.params.code_hash = params.codeHash;
        }
        if (typeof params?.creatorAddress !== "undefined") {
            options.params.creator_address = params.creatorAddress;
        }
        if (typeof params?.salt !== "undefined") {
            options.params.salt = params.salt;
        }
        if (typeof params?.initArgs !== "undefined") {
            options.params.init_args = params.initArgs;
        }
        const endpoint = `cosmwasm/wasm/v1/contract/build_address`;
        return await this.req.get(endpoint, options);
    }
}
exports.LCDQueryClient = LCDQueryClient;
