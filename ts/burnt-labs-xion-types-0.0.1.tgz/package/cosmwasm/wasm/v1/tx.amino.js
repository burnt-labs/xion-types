"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AminoConverter = void 0;
//@ts-nocheck
const tx_1 = require("./tx");
exports.AminoConverter = {
    "/cosmwasm.wasm.v1.MsgStoreCode": {
        aminoType: "wasm/MsgStoreCode",
        toAmino: tx_1.MsgStoreCode.toAmino,
        fromAmino: tx_1.MsgStoreCode.fromAmino
    },
    "/cosmwasm.wasm.v1.MsgInstantiateContract": {
        aminoType: "wasm/MsgInstantiateContract",
        toAmino: tx_1.MsgInstantiateContract.toAmino,
        fromAmino: tx_1.MsgInstantiateContract.fromAmino
    },
    "/cosmwasm.wasm.v1.MsgInstantiateContract2": {
        aminoType: "wasm/MsgInstantiateContract2",
        toAmino: tx_1.MsgInstantiateContract2.toAmino,
        fromAmino: tx_1.MsgInstantiateContract2.fromAmino
    },
    "/cosmwasm.wasm.v1.MsgExecuteContract": {
        aminoType: "wasm/MsgExecuteContract",
        toAmino: tx_1.MsgExecuteContract.toAmino,
        fromAmino: tx_1.MsgExecuteContract.fromAmino
    },
    "/cosmwasm.wasm.v1.MsgMigrateContract": {
        aminoType: "wasm/MsgMigrateContract",
        toAmino: tx_1.MsgMigrateContract.toAmino,
        fromAmino: tx_1.MsgMigrateContract.fromAmino
    },
    "/cosmwasm.wasm.v1.MsgUpdateAdmin": {
        aminoType: "wasm/MsgUpdateAdmin",
        toAmino: tx_1.MsgUpdateAdmin.toAmino,
        fromAmino: tx_1.MsgUpdateAdmin.fromAmino
    },
    "/cosmwasm.wasm.v1.MsgClearAdmin": {
        aminoType: "wasm/MsgClearAdmin",
        toAmino: tx_1.MsgClearAdmin.toAmino,
        fromAmino: tx_1.MsgClearAdmin.fromAmino
    },
    "/cosmwasm.wasm.v1.MsgUpdateInstantiateConfig": {
        aminoType: "wasm/MsgUpdateInstantiateConfig",
        toAmino: tx_1.MsgUpdateInstantiateConfig.toAmino,
        fromAmino: tx_1.MsgUpdateInstantiateConfig.fromAmino
    },
    "/cosmwasm.wasm.v1.MsgUpdateParams": {
        aminoType: "wasm/MsgUpdateParams",
        toAmino: tx_1.MsgUpdateParams.toAmino,
        fromAmino: tx_1.MsgUpdateParams.fromAmino
    },
    "/cosmwasm.wasm.v1.MsgSudoContract": {
        aminoType: "wasm/MsgSudoContract",
        toAmino: tx_1.MsgSudoContract.toAmino,
        fromAmino: tx_1.MsgSudoContract.fromAmino
    },
    "/cosmwasm.wasm.v1.MsgPinCodes": {
        aminoType: "wasm/MsgPinCodes",
        toAmino: tx_1.MsgPinCodes.toAmino,
        fromAmino: tx_1.MsgPinCodes.fromAmino
    },
    "/cosmwasm.wasm.v1.MsgUnpinCodes": {
        aminoType: "wasm/MsgUnpinCodes",
        toAmino: tx_1.MsgUnpinCodes.toAmino,
        fromAmino: tx_1.MsgUnpinCodes.fromAmino
    },
    "/cosmwasm.wasm.v1.MsgStoreAndInstantiateContract": {
        aminoType: "wasm/MsgStoreAndInstantiateContract",
        toAmino: tx_1.MsgStoreAndInstantiateContract.toAmino,
        fromAmino: tx_1.MsgStoreAndInstantiateContract.fromAmino
    },
    "/cosmwasm.wasm.v1.MsgRemoveCodeUploadParamsAddresses": {
        aminoType: "wasm/MsgRemoveCodeUploadParamsAddresses",
        toAmino: tx_1.MsgRemoveCodeUploadParamsAddresses.toAmino,
        fromAmino: tx_1.MsgRemoveCodeUploadParamsAddresses.fromAmino
    },
    "/cosmwasm.wasm.v1.MsgAddCodeUploadParamsAddresses": {
        aminoType: "wasm/MsgAddCodeUploadParamsAddresses",
        toAmino: tx_1.MsgAddCodeUploadParamsAddresses.toAmino,
        fromAmino: tx_1.MsgAddCodeUploadParamsAddresses.fromAmino
    },
    "/cosmwasm.wasm.v1.MsgStoreAndMigrateContract": {
        aminoType: "wasm/MsgStoreAndMigrateContract",
        toAmino: tx_1.MsgStoreAndMigrateContract.toAmino,
        fromAmino: tx_1.MsgStoreAndMigrateContract.fromAmino
    },
    "/cosmwasm.wasm.v1.MsgUpdateContractLabel": {
        aminoType: "wasm/MsgUpdateContractLabel",
        toAmino: tx_1.MsgUpdateContractLabel.toAmino,
        fromAmino: tx_1.MsgUpdateContractLabel.fromAmino
    }
};
