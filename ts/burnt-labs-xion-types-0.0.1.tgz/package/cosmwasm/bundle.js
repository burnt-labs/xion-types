"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.cosmwasm = void 0;
//@ts-nocheck
const _148 = __importStar(require("./wasm/v1/authz"));
const _149 = __importStar(require("./wasm/v1/genesis"));
const _150 = __importStar(require("./wasm/v1/ibc"));
const _151 = __importStar(require("./wasm/v1/proposal_legacy"));
const _152 = __importStar(require("./wasm/v1/query"));
const _153 = __importStar(require("./wasm/v1/tx"));
const _154 = __importStar(require("./wasm/v1/types"));
const _403 = __importStar(require("./wasm/v1/tx.amino"));
const _404 = __importStar(require("./wasm/v1/tx.registry"));
const _405 = __importStar(require("./wasm/v1/query.lcd"));
const _406 = __importStar(require("./wasm/v1/query.rpc.Query"));
const _407 = __importStar(require("./wasm/v1/tx.rpc.msg"));
const _480 = __importStar(require("./lcd"));
const _481 = __importStar(require("./rpc.query"));
const _482 = __importStar(require("./rpc.tx"));
var cosmwasm;
(function (cosmwasm) {
    let wasm;
    (function (wasm) {
        wasm.v1 = {
            ..._148,
            ..._149,
            ..._150,
            ..._151,
            ..._152,
            ..._153,
            ..._154,
            ..._403,
            ..._404,
            ..._405,
            ..._406,
            ..._407
        };
    })(wasm = cosmwasm.wasm || (cosmwasm.wasm = {}));
    cosmwasm.ClientFactory = {
        ..._480,
        ..._481,
        ..._482
    };
})(cosmwasm || (exports.cosmwasm = cosmwasm = {}));
