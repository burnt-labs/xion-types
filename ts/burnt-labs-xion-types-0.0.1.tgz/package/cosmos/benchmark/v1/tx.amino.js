"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AminoConverter = void 0;
//@ts-nocheck
const tx_1 = require("./tx");
exports.AminoConverter = {
    "/cosmos.benchmark.v1.MsgLoadTest": {
        aminoType: "cosmos-sdk/tools/benchmark/v1/MsgLoadTest",
        toAmino: tx_1.MsgLoadTest.toAmino,
        fromAmino: tx_1.MsgLoadTest.fromAmino
    }
};
