"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.MessageComposer = exports.load = exports.registry = void 0;
const tx_1 = require("./tx");
exports.registry = [["/cosmos.benchmark.v1.MsgLoadTest", tx_1.MsgLoadTest]];
const load = (protoRegistry) => {
    exports.registry.forEach(([typeUrl, mod]) => {
        protoRegistry.register(typeUrl, mod);
    });
};
exports.load = load;
exports.MessageComposer = {
    encoded: {
        loadTest(value) {
            return {
                typeUrl: "/cosmos.benchmark.v1.MsgLoadTest",
                value: tx_1.MsgLoadTest.encode(value).finish()
            };
        }
    },
    withTypeUrl: {
        loadTest(value) {
            return {
                typeUrl: "/cosmos.benchmark.v1.MsgLoadTest",
                value
            };
        }
    },
    fromPartial: {
        loadTest(value) {
            return {
                typeUrl: "/cosmos.benchmark.v1.MsgLoadTest",
                value: tx_1.MsgLoadTest.fromPartial(value)
            };
        }
    }
};
