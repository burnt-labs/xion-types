"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AminoConverter = void 0;
//@ts-nocheck
const tx_1 = require("./tx");
exports.AminoConverter = {
    "/cosmos.counter.v1.MsgIncreaseCounter": {
        aminoType: "cosmos-sdk/increase_counter",
        toAmino: tx_1.MsgIncreaseCounter.toAmino,
        fromAmino: tx_1.MsgIncreaseCounter.fromAmino
    }
};
