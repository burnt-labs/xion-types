"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createRpcQueryExtension = exports.QueryClientImpl = void 0;
const binary_1 = require("../../../binary");
const stargate_1 = require("@cosmjs/stargate");
const query_1 = require("./query");
class QueryClientImpl {
    constructor(rpc) {
        this.rpc = rpc;
        this.getCount = this.getCount.bind(this);
    }
    getCount(request = {}) {
        const data = query_1.QueryGetCountRequest.encode(request).finish();
        const promise = this.rpc.request("cosmos.counter.v1.Query", "GetCount", data);
        return promise.then(data => query_1.QueryGetCountResponse.decode(new binary_1.BinaryReader(data)));
    }
}
exports.QueryClientImpl = QueryClientImpl;
const createRpcQueryExtension = (base) => {
    const rpc = (0, stargate_1.createProtobufRpcClient)(base);
    const queryService = new QueryClientImpl(rpc);
    return {
        getCount(request) {
            return queryService.getCount(request);
        }
    };
};
exports.createRpcQueryExtension = createRpcQueryExtension;
