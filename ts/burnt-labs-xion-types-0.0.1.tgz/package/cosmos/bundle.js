"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.cosmos = void 0;
//@ts-nocheck
const _8 = __importStar(require("./app/runtime/v1alpha1/module"));
const _9 = __importStar(require("./app/v1alpha1/config"));
const _10 = __importStar(require("./app/v1alpha1/module"));
const _11 = __importStar(require("./app/v1alpha1/query"));
const _12 = __importStar(require("./auth/module/v1/module"));
const _13 = __importStar(require("./auth/v1beta1/auth"));
const _14 = __importStar(require("./auth/v1beta1/genesis"));
const _15 = __importStar(require("./auth/v1beta1/query"));
const _16 = __importStar(require("./auth/v1beta1/tx"));
const _17 = __importStar(require("./authz/module/v1/module"));
const _18 = __importStar(require("./authz/v1beta1/authz"));
const _19 = __importStar(require("./authz/v1beta1/event"));
const _20 = __importStar(require("./authz/v1beta1/genesis"));
const _21 = __importStar(require("./authz/v1beta1/query"));
const _22 = __importStar(require("./authz/v1beta1/tx"));
const _23 = __importStar(require("./autocli/v1/options"));
const _24 = __importStar(require("./autocli/v1/query"));
const _25 = __importStar(require("./bank/module/v1/module"));
const _26 = __importStar(require("./bank/v1beta1/authz"));
const _27 = __importStar(require("./bank/v1beta1/bank"));
const _28 = __importStar(require("./bank/v1beta1/genesis"));
const _29 = __importStar(require("./bank/v1beta1/query"));
const _30 = __importStar(require("./bank/v1beta1/tx"));
const _31 = __importStar(require("./base/abci/v1beta1/abci"));
const _32 = __importStar(require("./base/node/v1beta1/query"));
const _33 = __importStar(require("./base/query/v1beta1/pagination"));
const _34 = __importStar(require("./base/reflection/v1beta1/reflection"));
const _35 = __importStar(require("./base/reflection/v2alpha1/reflection"));
const _36 = __importStar(require("./base/tendermint/v1beta1/query"));
const _37 = __importStar(require("./base/tendermint/v1beta1/types"));
const _38 = __importStar(require("./base/v1beta1/coin"));
const _39 = __importStar(require("./benchmark/module/v1/module"));
const _40 = __importStar(require("./benchmark/v1/benchmark"));
const _41 = __importStar(require("./benchmark/v1/tx"));
const _42 = __importStar(require("./circuit/module/v1/module"));
const _43 = __importStar(require("./circuit/v1/query"));
const _44 = __importStar(require("./circuit/v1/tx"));
const _45 = __importStar(require("./circuit/v1/types"));
const _46 = __importStar(require("./consensus/module/v1/module"));
const _47 = __importStar(require("./consensus/v1/query"));
const _48 = __importStar(require("./consensus/v1/tx"));
const _49 = __importStar(require("./counter/module/v1/module"));
const _50 = __importStar(require("./counter/v1/query"));
const _51 = __importStar(require("./counter/v1/tx"));
const _52 = __importStar(require("./crisis/module/v1/module"));
const _53 = __importStar(require("./crisis/v1beta1/genesis"));
const _54 = __importStar(require("./crisis/v1beta1/tx"));
const _55 = __importStar(require("./crypto/ed25519/keys"));
const _56 = __importStar(require("./crypto/hd/v1/hd"));
const _57 = __importStar(require("./crypto/keyring/v1/record"));
const _58 = __importStar(require("./crypto/multisig/keys"));
const _59 = __importStar(require("./crypto/secp256k1/keys"));
const _60 = __importStar(require("./crypto/secp256r1/keys"));
const _61 = __importStar(require("./distribution/module/v1/module"));
const _62 = __importStar(require("./distribution/v1beta1/distribution"));
const _63 = __importStar(require("./distribution/v1beta1/genesis"));
const _64 = __importStar(require("./distribution/v1beta1/query"));
const _65 = __importStar(require("./distribution/v1beta1/tx"));
const _66 = __importStar(require("./epochs/module/v1/module"));
const _67 = __importStar(require("./epochs/v1beta1/events"));
const _68 = __importStar(require("./epochs/v1beta1/genesis"));
const _69 = __importStar(require("./epochs/v1beta1/query"));
const _70 = __importStar(require("./evidence/module/v1/module"));
const _71 = __importStar(require("./evidence/v1beta1/evidence"));
const _72 = __importStar(require("./evidence/v1beta1/genesis"));
const _73 = __importStar(require("./evidence/v1beta1/query"));
const _74 = __importStar(require("./evidence/v1beta1/tx"));
const _75 = __importStar(require("./feegrant/module/v1/module"));
const _76 = __importStar(require("./feegrant/v1beta1/feegrant"));
const _77 = __importStar(require("./feegrant/v1beta1/genesis"));
const _78 = __importStar(require("./feegrant/v1beta1/query"));
const _79 = __importStar(require("./feegrant/v1beta1/tx"));
const _80 = __importStar(require("./genutil/module/v1/module"));
const _81 = __importStar(require("./genutil/v1beta1/genesis"));
const _82 = __importStar(require("./gov/module/v1/module"));
const _83 = __importStar(require("./gov/v1/genesis"));
const _84 = __importStar(require("./gov/v1/gov"));
const _85 = __importStar(require("./gov/v1/query"));
const _86 = __importStar(require("./gov/v1/tx"));
const _87 = __importStar(require("./gov/v1beta1/genesis"));
const _88 = __importStar(require("./gov/v1beta1/gov"));
const _89 = __importStar(require("./gov/v1beta1/query"));
const _90 = __importStar(require("./gov/v1beta1/tx"));
const _91 = __importStar(require("./group/module/v1/module"));
const _92 = __importStar(require("./group/v1/events"));
const _93 = __importStar(require("./group/v1/genesis"));
const _94 = __importStar(require("./group/v1/query"));
const _95 = __importStar(require("./group/v1/tx"));
const _96 = __importStar(require("./group/v1/types"));
const _97 = __importStar(require("./ics23/v1/proofs"));
const _98 = __importStar(require("./mint/module/v1/module"));
const _99 = __importStar(require("./mint/v1beta1/genesis"));
const _100 = __importStar(require("./mint/v1beta1/mint"));
const _101 = __importStar(require("./mint/v1beta1/query"));
const _102 = __importStar(require("./mint/v1beta1/tx"));
const _103 = __importStar(require("./msg/textual/v1/textual"));
const _104 = __importStar(require("./msg/v1/msg"));
const _105 = __importStar(require("./nft/module/v1/module"));
const _106 = __importStar(require("./nft/v1beta1/event"));
const _107 = __importStar(require("./nft/v1beta1/genesis"));
const _108 = __importStar(require("./nft/v1beta1/nft"));
const _109 = __importStar(require("./nft/v1beta1/query"));
const _110 = __importStar(require("./nft/v1beta1/tx"));
const _111 = __importStar(require("./params/module/v1/module"));
const _112 = __importStar(require("./params/v1beta1/params"));
const _113 = __importStar(require("./params/v1beta1/query"));
const _114 = __importStar(require("./protocolpool/module/v1/module"));
const _115 = __importStar(require("./protocolpool/v1/genesis"));
const _116 = __importStar(require("./protocolpool/v1/query"));
const _117 = __importStar(require("./protocolpool/v1/tx"));
const _118 = __importStar(require("./protocolpool/v1/types"));
const _119 = __importStar(require("./query/v1/query"));
const _120 = __importStar(require("./reflection/v1/reflection"));
const _121 = __importStar(require("./slashing/module/v1/module"));
const _122 = __importStar(require("./slashing/v1beta1/genesis"));
const _123 = __importStar(require("./slashing/v1beta1/query"));
const _124 = __importStar(require("./slashing/v1beta1/slashing"));
const _125 = __importStar(require("./slashing/v1beta1/tx"));
const _126 = __importStar(require("./staking/module/v1/module"));
const _127 = __importStar(require("./staking/v1beta1/authz"));
const _128 = __importStar(require("./staking/v1beta1/genesis"));
const _129 = __importStar(require("./staking/v1beta1/query"));
const _130 = __importStar(require("./staking/v1beta1/staking"));
const _131 = __importStar(require("./staking/v1beta1/tx"));
const _132 = __importStar(require("./store/internal/kv/v1beta1/kv"));
const _133 = __importStar(require("./store/snapshots/v1/snapshot"));
const _134 = __importStar(require("./store/streaming/abci/grpc"));
const _135 = __importStar(require("./store/v1beta1/commit_info"));
const _136 = __importStar(require("./store/v1beta1/listening"));
const _137 = __importStar(require("./tx/config/v1/config"));
const _138 = __importStar(require("./tx/signing/v1beta1/signing"));
const _139 = __importStar(require("./tx/v1beta1/service"));
const _140 = __importStar(require("./tx/v1beta1/tx"));
const _141 = __importStar(require("./upgrade/module/v1/module"));
const _142 = __importStar(require("./upgrade/v1beta1/query"));
const _143 = __importStar(require("./upgrade/v1beta1/tx"));
const _144 = __importStar(require("./upgrade/v1beta1/upgrade"));
const _145 = __importStar(require("./vesting/module/v1/module"));
const _146 = __importStar(require("./vesting/v1beta1/tx"));
const _147 = __importStar(require("./vesting/v1beta1/vesting"));
const _293 = __importStar(require("./auth/v1beta1/tx.amino"));
const _294 = __importStar(require("./authz/v1beta1/tx.amino"));
const _295 = __importStar(require("./bank/v1beta1/tx.amino"));
const _296 = __importStar(require("./benchmark/v1/tx.amino"));
const _297 = __importStar(require("./circuit/v1/tx.amino"));
const _298 = __importStar(require("./consensus/v1/tx.amino"));
const _299 = __importStar(require("./counter/v1/tx.amino"));
const _300 = __importStar(require("./crisis/v1beta1/tx.amino"));
const _301 = __importStar(require("./distribution/v1beta1/tx.amino"));
const _302 = __importStar(require("./evidence/v1beta1/tx.amino"));
const _303 = __importStar(require("./feegrant/v1beta1/tx.amino"));
const _304 = __importStar(require("./gov/v1/tx.amino"));
const _305 = __importStar(require("./gov/v1beta1/tx.amino"));
const _306 = __importStar(require("./group/v1/tx.amino"));
const _307 = __importStar(require("./mint/v1beta1/tx.amino"));
const _308 = __importStar(require("./nft/v1beta1/tx.amino"));
const _309 = __importStar(require("./protocolpool/v1/tx.amino"));
const _310 = __importStar(require("./slashing/v1beta1/tx.amino"));
const _311 = __importStar(require("./staking/v1beta1/tx.amino"));
const _312 = __importStar(require("./upgrade/v1beta1/tx.amino"));
const _313 = __importStar(require("./vesting/v1beta1/tx.amino"));
const _314 = __importStar(require("./auth/v1beta1/tx.registry"));
const _315 = __importStar(require("./authz/v1beta1/tx.registry"));
const _316 = __importStar(require("./bank/v1beta1/tx.registry"));
const _317 = __importStar(require("./benchmark/v1/tx.registry"));
const _318 = __importStar(require("./circuit/v1/tx.registry"));
const _319 = __importStar(require("./consensus/v1/tx.registry"));
const _320 = __importStar(require("./counter/v1/tx.registry"));
const _321 = __importStar(require("./crisis/v1beta1/tx.registry"));
const _322 = __importStar(require("./distribution/v1beta1/tx.registry"));
const _323 = __importStar(require("./evidence/v1beta1/tx.registry"));
const _324 = __importStar(require("./feegrant/v1beta1/tx.registry"));
const _325 = __importStar(require("./gov/v1/tx.registry"));
const _326 = __importStar(require("./gov/v1beta1/tx.registry"));
const _327 = __importStar(require("./group/v1/tx.registry"));
const _328 = __importStar(require("./mint/v1beta1/tx.registry"));
const _329 = __importStar(require("./nft/v1beta1/tx.registry"));
const _330 = __importStar(require("./protocolpool/v1/tx.registry"));
const _331 = __importStar(require("./slashing/v1beta1/tx.registry"));
const _332 = __importStar(require("./staking/v1beta1/tx.registry"));
const _333 = __importStar(require("./upgrade/v1beta1/tx.registry"));
const _334 = __importStar(require("./vesting/v1beta1/tx.registry"));
const _335 = __importStar(require("./auth/v1beta1/query.lcd"));
const _336 = __importStar(require("./authz/v1beta1/query.lcd"));
const _337 = __importStar(require("./bank/v1beta1/query.lcd"));
const _338 = __importStar(require("./base/node/v1beta1/query.lcd"));
const _339 = __importStar(require("./base/tendermint/v1beta1/query.lcd"));
const _340 = __importStar(require("./circuit/v1/query.lcd"));
const _341 = __importStar(require("./consensus/v1/query.lcd"));
const _342 = __importStar(require("./distribution/v1beta1/query.lcd"));
const _343 = __importStar(require("./epochs/v1beta1/query.lcd"));
const _344 = __importStar(require("./evidence/v1beta1/query.lcd"));
const _345 = __importStar(require("./feegrant/v1beta1/query.lcd"));
const _346 = __importStar(require("./gov/v1/query.lcd"));
const _347 = __importStar(require("./gov/v1beta1/query.lcd"));
const _348 = __importStar(require("./group/v1/query.lcd"));
const _349 = __importStar(require("./mint/v1beta1/query.lcd"));
const _350 = __importStar(require("./nft/v1beta1/query.lcd"));
const _351 = __importStar(require("./params/v1beta1/query.lcd"));
const _352 = __importStar(require("./protocolpool/v1/query.lcd"));
const _353 = __importStar(require("./slashing/v1beta1/query.lcd"));
const _354 = __importStar(require("./staking/v1beta1/query.lcd"));
const _355 = __importStar(require("./tx/v1beta1/service.lcd"));
const _356 = __importStar(require("./upgrade/v1beta1/query.lcd"));
const _357 = __importStar(require("./app/v1alpha1/query.rpc.Query"));
const _358 = __importStar(require("./auth/v1beta1/query.rpc.Query"));
const _359 = __importStar(require("./authz/v1beta1/query.rpc.Query"));
const _360 = __importStar(require("./autocli/v1/query.rpc.Query"));
const _361 = __importStar(require("./bank/v1beta1/query.rpc.Query"));
const _362 = __importStar(require("./base/node/v1beta1/query.rpc.Service"));
const _363 = __importStar(require("./base/tendermint/v1beta1/query.rpc.Service"));
const _364 = __importStar(require("./circuit/v1/query.rpc.Query"));
const _365 = __importStar(require("./consensus/v1/query.rpc.Query"));
const _366 = __importStar(require("./counter/v1/query.rpc.Query"));
const _367 = __importStar(require("./distribution/v1beta1/query.rpc.Query"));
const _368 = __importStar(require("./epochs/v1beta1/query.rpc.Query"));
const _369 = __importStar(require("./evidence/v1beta1/query.rpc.Query"));
const _370 = __importStar(require("./feegrant/v1beta1/query.rpc.Query"));
const _371 = __importStar(require("./gov/v1/query.rpc.Query"));
const _372 = __importStar(require("./gov/v1beta1/query.rpc.Query"));
const _373 = __importStar(require("./group/v1/query.rpc.Query"));
const _374 = __importStar(require("./mint/v1beta1/query.rpc.Query"));
const _375 = __importStar(require("./nft/v1beta1/query.rpc.Query"));
const _376 = __importStar(require("./params/v1beta1/query.rpc.Query"));
const _377 = __importStar(require("./protocolpool/v1/query.rpc.Query"));
const _378 = __importStar(require("./slashing/v1beta1/query.rpc.Query"));
const _379 = __importStar(require("./staking/v1beta1/query.rpc.Query"));
const _380 = __importStar(require("./tx/v1beta1/service.rpc.Service"));
const _381 = __importStar(require("./upgrade/v1beta1/query.rpc.Query"));
const _382 = __importStar(require("./auth/v1beta1/tx.rpc.msg"));
const _383 = __importStar(require("./authz/v1beta1/tx.rpc.msg"));
const _384 = __importStar(require("./bank/v1beta1/tx.rpc.msg"));
const _385 = __importStar(require("./benchmark/v1/tx.rpc.msg"));
const _386 = __importStar(require("./circuit/v1/tx.rpc.msg"));
const _387 = __importStar(require("./consensus/v1/tx.rpc.msg"));
const _388 = __importStar(require("./counter/v1/tx.rpc.msg"));
const _389 = __importStar(require("./crisis/v1beta1/tx.rpc.msg"));
const _390 = __importStar(require("./distribution/v1beta1/tx.rpc.msg"));
const _391 = __importStar(require("./evidence/v1beta1/tx.rpc.msg"));
const _392 = __importStar(require("./feegrant/v1beta1/tx.rpc.msg"));
const _393 = __importStar(require("./gov/v1/tx.rpc.msg"));
const _394 = __importStar(require("./gov/v1beta1/tx.rpc.msg"));
const _395 = __importStar(require("./group/v1/tx.rpc.msg"));
const _396 = __importStar(require("./mint/v1beta1/tx.rpc.msg"));
const _397 = __importStar(require("./nft/v1beta1/tx.rpc.msg"));
const _398 = __importStar(require("./protocolpool/v1/tx.rpc.msg"));
const _399 = __importStar(require("./slashing/v1beta1/tx.rpc.msg"));
const _400 = __importStar(require("./staking/v1beta1/tx.rpc.msg"));
const _401 = __importStar(require("./upgrade/v1beta1/tx.rpc.msg"));
const _402 = __importStar(require("./vesting/v1beta1/tx.rpc.msg"));
const _477 = __importStar(require("./lcd"));
const _478 = __importStar(require("./rpc.query"));
const _479 = __importStar(require("./rpc.tx"));
var cosmos;
(function (cosmos) {
    let app;
    (function (app) {
        let runtime;
        (function (runtime) {
            runtime.v1alpha1 = {
                ..._8
            };
        })(runtime = app.runtime || (app.runtime = {}));
        app.v1alpha1 = {
            ..._9,
            ..._10,
            ..._11,
            ..._357
        };
    })(app = cosmos.app || (cosmos.app = {}));
    let auth;
    (function (auth) {
        let module;
        (function (module) {
            module.v1 = {
                ..._12
            };
        })(module = auth.module || (auth.module = {}));
        auth.v1beta1 = {
            ..._13,
            ..._14,
            ..._15,
            ..._16,
            ..._293,
            ..._314,
            ..._335,
            ..._358,
            ..._382
        };
    })(auth = cosmos.auth || (cosmos.auth = {}));
    let authz;
    (function (authz) {
        let module;
        (function (module) {
            module.v1 = {
                ..._17
            };
        })(module = authz.module || (authz.module = {}));
        authz.v1beta1 = {
            ..._18,
            ..._19,
            ..._20,
            ..._21,
            ..._22,
            ..._294,
            ..._315,
            ..._336,
            ..._359,
            ..._383
        };
    })(authz = cosmos.authz || (cosmos.authz = {}));
    let autocli;
    (function (autocli) {
        autocli.v1 = {
            ..._23,
            ..._24,
            ..._360
        };
    })(autocli = cosmos.autocli || (cosmos.autocli = {}));
    let bank;
    (function (bank) {
        let module;
        (function (module) {
            module.v1 = {
                ..._25
            };
        })(module = bank.module || (bank.module = {}));
        bank.v1beta1 = {
            ..._26,
            ..._27,
            ..._28,
            ..._29,
            ..._30,
            ..._295,
            ..._316,
            ..._337,
            ..._361,
            ..._384
        };
    })(bank = cosmos.bank || (cosmos.bank = {}));
    let base;
    (function (base) {
        let abci;
        (function (abci) {
            abci.v1beta1 = {
                ..._31
            };
        })(abci = base.abci || (base.abci = {}));
        let node;
        (function (node) {
            node.v1beta1 = {
                ..._32,
                ..._338,
                ..._362
            };
        })(node = base.node || (base.node = {}));
        let query;
        (function (query) {
            query.v1beta1 = {
                ..._33
            };
        })(query = base.query || (base.query = {}));
        let reflection;
        (function (reflection) {
            reflection.v1beta1 = {
                ..._34
            };
            reflection.v2alpha1 = {
                ..._35
            };
        })(reflection = base.reflection || (base.reflection = {}));
        let tendermint;
        (function (tendermint) {
            tendermint.v1beta1 = {
                ..._36,
                ..._37,
                ..._339,
                ..._363
            };
        })(tendermint = base.tendermint || (base.tendermint = {}));
        base.v1beta1 = {
            ..._38
        };
    })(base = cosmos.base || (cosmos.base = {}));
    let benchmark;
    (function (benchmark) {
        let module;
        (function (module) {
            module.v1 = {
                ..._39
            };
        })(module = benchmark.module || (benchmark.module = {}));
        benchmark.v1 = {
            ..._40,
            ..._41,
            ..._296,
            ..._317,
            ..._385
        };
    })(benchmark = cosmos.benchmark || (cosmos.benchmark = {}));
    let circuit;
    (function (circuit) {
        let module;
        (function (module) {
            module.v1 = {
                ..._42
            };
        })(module = circuit.module || (circuit.module = {}));
        circuit.v1 = {
            ..._43,
            ..._44,
            ..._45,
            ..._297,
            ..._318,
            ..._340,
            ..._364,
            ..._386
        };
    })(circuit = cosmos.circuit || (cosmos.circuit = {}));
    let consensus;
    (function (consensus) {
        let module;
        (function (module) {
            module.v1 = {
                ..._46
            };
        })(module = consensus.module || (consensus.module = {}));
        consensus.v1 = {
            ..._47,
            ..._48,
            ..._298,
            ..._319,
            ..._341,
            ..._365,
            ..._387
        };
    })(consensus = cosmos.consensus || (cosmos.consensus = {}));
    let counter;
    (function (counter) {
        let module;
        (function (module) {
            module.v1 = {
                ..._49
            };
        })(module = counter.module || (counter.module = {}));
        counter.v1 = {
            ..._50,
            ..._51,
            ..._299,
            ..._320,
            ..._366,
            ..._388
        };
    })(counter = cosmos.counter || (cosmos.counter = {}));
    let crisis;
    (function (crisis) {
        let module;
        (function (module) {
            module.v1 = {
                ..._52
            };
        })(module = crisis.module || (crisis.module = {}));
        crisis.v1beta1 = {
            ..._53,
            ..._54,
            ..._300,
            ..._321,
            ..._389
        };
    })(crisis = cosmos.crisis || (cosmos.crisis = {}));
    let crypto;
    (function (crypto) {
        crypto.ed25519 = {
            ..._55
        };
        let hd;
        (function (hd) {
            hd.v1 = {
                ..._56
            };
        })(hd = crypto.hd || (crypto.hd = {}));
        let keyring;
        (function (keyring) {
            keyring.v1 = {
                ..._57
            };
        })(keyring = crypto.keyring || (crypto.keyring = {}));
        crypto.multisig = {
            ..._58
        };
        crypto.secp256k1 = {
            ..._59
        };
        crypto.secp256r1 = {
            ..._60
        };
    })(crypto = cosmos.crypto || (cosmos.crypto = {}));
    let distribution;
    (function (distribution) {
        let module;
        (function (module) {
            module.v1 = {
                ..._61
            };
        })(module = distribution.module || (distribution.module = {}));
        distribution.v1beta1 = {
            ..._62,
            ..._63,
            ..._64,
            ..._65,
            ..._301,
            ..._322,
            ..._342,
            ..._367,
            ..._390
        };
    })(distribution = cosmos.distribution || (cosmos.distribution = {}));
    let epochs;
    (function (epochs) {
        let module;
        (function (module) {
            module.v1 = {
                ..._66
            };
        })(module = epochs.module || (epochs.module = {}));
        epochs.v1beta1 = {
            ..._67,
            ..._68,
            ..._69,
            ..._343,
            ..._368
        };
    })(epochs = cosmos.epochs || (cosmos.epochs = {}));
    let evidence;
    (function (evidence) {
        let module;
        (function (module) {
            module.v1 = {
                ..._70
            };
        })(module = evidence.module || (evidence.module = {}));
        evidence.v1beta1 = {
            ..._71,
            ..._72,
            ..._73,
            ..._74,
            ..._302,
            ..._323,
            ..._344,
            ..._369,
            ..._391
        };
    })(evidence = cosmos.evidence || (cosmos.evidence = {}));
    let feegrant;
    (function (feegrant) {
        let module;
        (function (module) {
            module.v1 = {
                ..._75
            };
        })(module = feegrant.module || (feegrant.module = {}));
        feegrant.v1beta1 = {
            ..._76,
            ..._77,
            ..._78,
            ..._79,
            ..._303,
            ..._324,
            ..._345,
            ..._370,
            ..._392
        };
    })(feegrant = cosmos.feegrant || (cosmos.feegrant = {}));
    let genutil;
    (function (genutil) {
        let module;
        (function (module) {
            module.v1 = {
                ..._80
            };
        })(module = genutil.module || (genutil.module = {}));
        genutil.v1beta1 = {
            ..._81
        };
    })(genutil = cosmos.genutil || (cosmos.genutil = {}));
    let gov;
    (function (gov) {
        let module;
        (function (module) {
            module.v1 = {
                ..._82
            };
        })(module = gov.module || (gov.module = {}));
        gov.v1 = {
            ..._83,
            ..._84,
            ..._85,
            ..._86,
            ..._304,
            ..._325,
            ..._346,
            ..._371,
            ..._393
        };
        gov.v1beta1 = {
            ..._87,
            ..._88,
            ..._89,
            ..._90,
            ..._305,
            ..._326,
            ..._347,
            ..._372,
            ..._394
        };
    })(gov = cosmos.gov || (cosmos.gov = {}));
    let group;
    (function (group) {
        let module;
        (function (module) {
            module.v1 = {
                ..._91
            };
        })(module = group.module || (group.module = {}));
        group.v1 = {
            ..._92,
            ..._93,
            ..._94,
            ..._95,
            ..._96,
            ..._306,
            ..._327,
            ..._348,
            ..._373,
            ..._395
        };
    })(group = cosmos.group || (cosmos.group = {}));
    let ics23;
    (function (ics23) {
        ics23.v1 = {
            ..._97
        };
    })(ics23 = cosmos.ics23 || (cosmos.ics23 = {}));
    let mint;
    (function (mint) {
        let module;
        (function (module) {
            module.v1 = {
                ..._98
            };
        })(module = mint.module || (mint.module = {}));
        mint.v1beta1 = {
            ..._99,
            ..._100,
            ..._101,
            ..._102,
            ..._307,
            ..._328,
            ..._349,
            ..._374,
            ..._396
        };
    })(mint = cosmos.mint || (cosmos.mint = {}));
    let msg;
    (function (msg) {
        let textual;
        (function (textual) {
            textual.v1 = {
                ..._103
            };
        })(textual = msg.textual || (msg.textual = {}));
        msg.v1 = {
            ..._104
        };
    })(msg = cosmos.msg || (cosmos.msg = {}));
    let nft;
    (function (nft) {
        let module;
        (function (module) {
            module.v1 = {
                ..._105
            };
        })(module = nft.module || (nft.module = {}));
        nft.v1beta1 = {
            ..._106,
            ..._107,
            ..._108,
            ..._109,
            ..._110,
            ..._308,
            ..._329,
            ..._350,
            ..._375,
            ..._397
        };
    })(nft = cosmos.nft || (cosmos.nft = {}));
    let params;
    (function (params) {
        let module;
        (function (module) {
            module.v1 = {
                ..._111
            };
        })(module = params.module || (params.module = {}));
        params.v1beta1 = {
            ..._112,
            ..._113,
            ..._351,
            ..._376
        };
    })(params = cosmos.params || (cosmos.params = {}));
    let protocolpool;
    (function (protocolpool) {
        let module;
        (function (module) {
            module.v1 = {
                ..._114
            };
        })(module = protocolpool.module || (protocolpool.module = {}));
        protocolpool.v1 = {
            ..._115,
            ..._116,
            ..._117,
            ..._118,
            ..._309,
            ..._330,
            ..._352,
            ..._377,
            ..._398
        };
    })(protocolpool = cosmos.protocolpool || (cosmos.protocolpool = {}));
    let query;
    (function (query) {
        query.v1 = {
            ..._119
        };
    })(query = cosmos.query || (cosmos.query = {}));
    let reflection;
    (function (reflection) {
        reflection.v1 = {
            ..._120
        };
    })(reflection = cosmos.reflection || (cosmos.reflection = {}));
    let slashing;
    (function (slashing) {
        let module;
        (function (module) {
            module.v1 = {
                ..._121
            };
        })(module = slashing.module || (slashing.module = {}));
        slashing.v1beta1 = {
            ..._122,
            ..._123,
            ..._124,
            ..._125,
            ..._310,
            ..._331,
            ..._353,
            ..._378,
            ..._399
        };
    })(slashing = cosmos.slashing || (cosmos.slashing = {}));
    let staking;
    (function (staking) {
        let module;
        (function (module) {
            module.v1 = {
                ..._126
            };
        })(module = staking.module || (staking.module = {}));
        staking.v1beta1 = {
            ..._127,
            ..._128,
            ..._129,
            ..._130,
            ..._131,
            ..._311,
            ..._332,
            ..._354,
            ..._379,
            ..._400
        };
    })(staking = cosmos.staking || (cosmos.staking = {}));
    let store;
    (function (store) {
        let internal;
        (function (internal) {
            let kv;
            (function (kv) {
                kv.v1beta1 = {
                    ..._132
                };
            })(kv = internal.kv || (internal.kv = {}));
        })(internal = store.internal || (store.internal = {}));
        let snapshots;
        (function (snapshots) {
            snapshots.v1 = {
                ..._133
            };
        })(snapshots = store.snapshots || (store.snapshots = {}));
        let streaming;
        (function (streaming) {
            streaming.abci = {
                ..._134
            };
        })(streaming = store.streaming || (store.streaming = {}));
        store.v1beta1 = {
            ..._135,
            ..._136
        };
    })(store = cosmos.store || (cosmos.store = {}));
    let tx;
    (function (tx) {
        let config;
        (function (config) {
            config.v1 = {
                ..._137
            };
        })(config = tx.config || (tx.config = {}));
        let signing;
        (function (signing) {
            signing.v1beta1 = {
                ..._138
            };
        })(signing = tx.signing || (tx.signing = {}));
        tx.v1beta1 = {
            ..._139,
            ..._140,
            ..._355,
            ..._380
        };
    })(tx = cosmos.tx || (cosmos.tx = {}));
    let upgrade;
    (function (upgrade) {
        let module;
        (function (module) {
            module.v1 = {
                ..._141
            };
        })(module = upgrade.module || (upgrade.module = {}));
        upgrade.v1beta1 = {
            ..._142,
            ..._143,
            ..._144,
            ..._312,
            ..._333,
            ..._356,
            ..._381,
            ..._401
        };
    })(upgrade = cosmos.upgrade || (cosmos.upgrade = {}));
    let vesting;
    (function (vesting) {
        let module;
        (function (module) {
            module.v1 = {
                ..._145
            };
        })(module = vesting.module || (vesting.module = {}));
        vesting.v1beta1 = {
            ..._146,
            ..._147,
            ..._313,
            ..._334,
            ..._402
        };
    })(vesting = cosmos.vesting || (cosmos.vesting = {}));
    cosmos.ClientFactory = {
        ..._477,
        ..._478,
        ..._479
    };
})(cosmos || (exports.cosmos = cosmos = {}));
