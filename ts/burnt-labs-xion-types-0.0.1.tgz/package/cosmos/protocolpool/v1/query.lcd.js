"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.LCDQueryClient = void 0;
class LCDQueryClient {
    constructor({ requestClient }) {
        this.req = requestClient;
        this.communityPool = this.communityPool.bind(this);
        this.continuousFund = this.continuousFund.bind(this);
        this.continuousFunds = this.continuousFunds.bind(this);
        this.params = this.params.bind(this);
    }
    /* CommunityPool queries the community pool coins. */
    async communityPool(_params = {}) {
        const endpoint = `cosmos/protocolpool/v1/community_pool`;
        return await this.req.get(endpoint);
    }
    /* ContinuousFund queries a continuous fund by the recipient is is associated with. */
    async continuousFund(params) {
        const endpoint = `cosmos/protocolpool/v1/continuous_funds/${params.recipient}`;
        return await this.req.get(endpoint);
    }
    /* ContinuousFunds queries all continuous funds in the store. */
    async continuousFunds(_params = {}) {
        const endpoint = `cosmos/protocolpool/v1/continuous_funds`;
        return await this.req.get(endpoint);
    }
    /* Params returns the total set of x/protocolpool parameters. */
    async params(_params = {}) {
        const endpoint = `cosmos/protocolpool/v1/params`;
        return await this.req.get(endpoint);
    }
}
exports.LCDQueryClient = LCDQueryClient;
