"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AminoConverter = void 0;
//@ts-nocheck
const tx_1 = require("./tx");
exports.AminoConverter = {
    "/cosmos.protocolpool.v1.MsgFundCommunityPool": {
        aminoType: "cosmos-sdk/MsgFundCommunityPool",
        toAmino: tx_1.MsgFundCommunityPool.toAmino,
        fromAmino: tx_1.MsgFundCommunityPool.fromAmino
    },
    "/cosmos.protocolpool.v1.MsgCommunityPoolSpend": {
        aminoType: "cosmos-sdk/MsgCommunityPoolSpend",
        toAmino: tx_1.MsgCommunityPoolSpend.toAmino,
        fromAmino: tx_1.MsgCommunityPoolSpend.fromAmino
    },
    "/cosmos.protocolpool.v1.MsgCreateContinuousFund": {
        aminoType: "cosmos-sdk/MsgCreateContinuousFund",
        toAmino: tx_1.MsgCreateContinuousFund.toAmino,
        fromAmino: tx_1.MsgCreateContinuousFund.fromAmino
    },
    "/cosmos.protocolpool.v1.MsgCancelContinuousFund": {
        aminoType: "cosmos-sdk/MsgCancelContinuousFund",
        toAmino: tx_1.MsgCancelContinuousFund.toAmino,
        fromAmino: tx_1.MsgCancelContinuousFund.fromAmino
    },
    "/cosmos.protocolpool.v1.MsgUpdateParams": {
        aminoType: "cosmos-sdk/MsgUpdateParams",
        toAmino: tx_1.MsgUpdateParams.toAmino,
        fromAmino: tx_1.MsgUpdateParams.fromAmino
    }
};
