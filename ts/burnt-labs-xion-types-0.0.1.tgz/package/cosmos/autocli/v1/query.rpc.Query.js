"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createRpcQueryExtension = exports.QueryClientImpl = void 0;
const binary_1 = require("../../../binary");
const stargate_1 = require("@cosmjs/stargate");
const query_1 = require("./query");
class QueryClientImpl {
    constructor(rpc) {
        this.rpc = rpc;
        this.appOptions = this.appOptions.bind(this);
    }
    appOptions(request = {}) {
        const data = query_1.AppOptionsRequest.encode(request).finish();
        const promise = this.rpc.request("cosmos.autocli.v1.Query", "AppOptions", data);
        return promise.then(data => query_1.AppOptionsResponse.decode(new binary_1.BinaryReader(data)));
    }
}
exports.QueryClientImpl = QueryClientImpl;
const createRpcQueryExtension = (base) => {
    const rpc = (0, stargate_1.createProtobufRpcClient)(base);
    const queryService = new QueryClientImpl(rpc);
    return {
        appOptions(request) {
            return queryService.appOptions(request);
        }
    };
};
exports.createRpcQueryExtension = createRpcQueryExtension;
