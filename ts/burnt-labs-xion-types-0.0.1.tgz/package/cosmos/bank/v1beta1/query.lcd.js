"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.LCDQueryClient = void 0;
//@ts-nocheck
const helpers_1 = require("../../../helpers");
class LCDQueryClient {
    constructor({ requestClient }) {
        this.req = requestClient;
        this.balance = this.balance.bind(this);
        this.allBalances = this.allBalances.bind(this);
        this.spendableBalances = this.spendableBalances.bind(this);
        this.spendableBalanceByDenom = this.spendableBalanceByDenom.bind(this);
        this.totalSupply = this.totalSupply.bind(this);
        this.supplyOf = this.supplyOf.bind(this);
        this.params = this.params.bind(this);
        this.denomsMetadata = this.denomsMetadata.bind(this);
        this.denomMetadata = this.denomMetadata.bind(this);
        this.denomMetadataByQueryString = this.denomMetadataByQueryString.bind(this);
        this.denomOwners = this.denomOwners.bind(this);
        this.denomOwnersByQuery = this.denomOwnersByQuery.bind(this);
        this.sendEnabled = this.sendEnabled.bind(this);
    }
    /* Balance queries the balance of a single coin for a single account. */
    async balance(params) {
        const options = {
            params: {}
        };
        if (typeof params?.denom !== "undefined") {
            options.params.denom = params.denom;
        }
        const endpoint = `cosmos/bank/v1beta1/balances/${params.address}/by_denom`;
        return await this.req.get(endpoint, options);
    }
    /* AllBalances queries the balance of all coins for a single account.
    
     When called from another module, this query might consume a high amount of
     gas if the pagination field is incorrectly set. */
    async allBalances(params) {
        const options = {
            params: {}
        };
        if (typeof params?.pagination !== "undefined") {
            (0, helpers_1.setPaginationParams)(options, params.pagination);
        }
        if (typeof params?.resolveDenom !== "undefined") {
            options.params.resolve_denom = params.resolveDenom;
        }
        const endpoint = `cosmos/bank/v1beta1/balances/${params.address}`;
        return await this.req.get(endpoint, options);
    }
    /* SpendableBalances queries the spendable balance of all coins for a single
     account.
    
     When called from another module, this query might consume a high amount of
     gas if the pagination field is incorrectly set. */
    async spendableBalances(params) {
        const options = {
            params: {}
        };
        if (typeof params?.pagination !== "undefined") {
            (0, helpers_1.setPaginationParams)(options, params.pagination);
        }
        const endpoint = `cosmos/bank/v1beta1/spendable_balances/${params.address}`;
        return await this.req.get(endpoint, options);
    }
    /* SpendableBalanceByDenom queries the spendable balance of a single denom for
     a single account.
    
     When called from another module, this query might consume a high amount of
     gas if the pagination field is incorrectly set. */
    async spendableBalanceByDenom(params) {
        const options = {
            params: {}
        };
        if (typeof params?.denom !== "undefined") {
            options.params.denom = params.denom;
        }
        const endpoint = `cosmos/bank/v1beta1/spendable_balances/${params.address}/by_denom`;
        return await this.req.get(endpoint, options);
    }
    /* TotalSupply queries the total supply of all coins.
    
     When called from another module, this query might consume a high amount of
     gas if the pagination field is incorrectly set. */
    async totalSupply(params = {
        pagination: undefined
    }) {
        const options = {
            params: {}
        };
        if (typeof params?.pagination !== "undefined") {
            (0, helpers_1.setPaginationParams)(options, params.pagination);
        }
        const endpoint = `cosmos/bank/v1beta1/supply`;
        return await this.req.get(endpoint, options);
    }
    /* SupplyOf queries the supply of a single coin.
    
     When called from another module, this query might consume a high amount of
     gas if the pagination field is incorrectly set. */
    async supplyOf(params) {
        const options = {
            params: {}
        };
        if (typeof params?.denom !== "undefined") {
            options.params.denom = params.denom;
        }
        const endpoint = `cosmos/bank/v1beta1/supply/by_denom`;
        return await this.req.get(endpoint, options);
    }
    /* Params queries the parameters of x/bank module. */
    async params(_params = {}) {
        const endpoint = `cosmos/bank/v1beta1/params`;
        return await this.req.get(endpoint);
    }
    /* DenomsMetadata queries the client metadata for all registered coin
     denominations. */
    async denomsMetadata(params = {
        pagination: undefined
    }) {
        const options = {
            params: {}
        };
        if (typeof params?.pagination !== "undefined") {
            (0, helpers_1.setPaginationParams)(options, params.pagination);
        }
        const endpoint = `cosmos/bank/v1beta1/denoms_metadata`;
        return await this.req.get(endpoint, options);
    }
    /* DenomMetadata queries the client metadata of a given coin denomination. */
    async denomMetadata(params) {
        const options = {
            params: {}
        };
        if (typeof params?.denom !== "undefined") {
            options.params.denom = params.denom;
        }
        const endpoint = `cosmos/bank/v1beta1/denoms_metadata/${params.denom}`;
        return await this.req.get(endpoint, options);
    }
    /* DenomMetadataByQueryString queries the client metadata of a given coin denomination. */
    async denomMetadataByQueryString(params) {
        const options = {
            params: {}
        };
        if (typeof params?.denom !== "undefined") {
            options.params.denom = params.denom;
        }
        const endpoint = `cosmos/bank/v1beta1/denoms_metadata_by_query_string`;
        return await this.req.get(endpoint, options);
    }
    /* DenomOwners queries for all account addresses that own a particular token
     denomination.
    
     When called from another module, this query might consume a high amount of
     gas if the pagination field is incorrectly set. */
    async denomOwners(params) {
        const options = {
            params: {}
        };
        if (typeof params?.denom !== "undefined") {
            options.params.denom = params.denom;
        }
        if (typeof params?.pagination !== "undefined") {
            (0, helpers_1.setPaginationParams)(options, params.pagination);
        }
        const endpoint = `cosmos/bank/v1beta1/denom_owners/${params.denom}`;
        return await this.req.get(endpoint, options);
    }
    /* DenomOwnersByQuery queries for all account addresses that own a particular token
     denomination. */
    async denomOwnersByQuery(params) {
        const options = {
            params: {}
        };
        if (typeof params?.denom !== "undefined") {
            options.params.denom = params.denom;
        }
        if (typeof params?.pagination !== "undefined") {
            (0, helpers_1.setPaginationParams)(options, params.pagination);
        }
        const endpoint = `cosmos/bank/v1beta1/denom_owners_by_query`;
        return await this.req.get(endpoint, options);
    }
    /* SendEnabled queries for SendEnabled entries.
    
     This query only returns denominations that have specific SendEnabled settings.
     Any denomination that does not have a specific setting will use the default
     params.default_send_enabled, and will not be returned by this query. */
    async sendEnabled(params) {
        const options = {
            params: {}
        };
        if (typeof params?.denoms !== "undefined") {
            options.params.denoms = params.denoms;
        }
        if (typeof params?.pagination !== "undefined") {
            (0, helpers_1.setPaginationParams)(options, params.pagination);
        }
        const endpoint = `cosmos/bank/v1beta1/send_enabled`;
        return await this.req.get(endpoint, options);
    }
}
exports.LCDQueryClient = LCDQueryClient;
