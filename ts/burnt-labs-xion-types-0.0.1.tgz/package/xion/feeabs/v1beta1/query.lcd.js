"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.LCDQueryClient = void 0;
class LCDQueryClient {
    constructor({ requestClient }) {
        this.req = requestClient;
        this.osmosisArithmeticTwap = this.osmosisArithmeticTwap.bind(this);
        this.feeabsModuleBalances = this.feeabsModuleBalances.bind(this);
        this.hostChainConfig = this.hostChainConfig.bind(this);
        this.allHostChainConfig = this.allHostChainConfig.bind(this);
    }
    /* OsmosisArithmeticTwap return spot price of pair Osmo/nativeToken */
    async osmosisArithmeticTwap(params) {
        const endpoint = `fee-abstraction/feeabs/v1/osmosis-arithmetic-twap/${params.ibcDenom}`;
        return await this.req.get(endpoint);
    }
    /* FeeabsModuleBalances return total balances of feeabs module */
    async feeabsModuleBalances(_params = {}) {
        const endpoint = `fee-abstraction/feeabs/v1/module-balances`;
        return await this.req.get(endpoint);
    }
    /* HostChainConfig */
    async hostChainConfig(params) {
        const endpoint = `fee-abstraction/feeabs/v1/host-chain-config/${params.ibcDenom}`;
        return await this.req.get(endpoint);
    }
    /* AllHostChainConfig */
    async allHostChainConfig(_params = {}) {
        const endpoint = `fee-abstraction/feeabs/v1/all-host-chain-config`;
        return await this.req.get(endpoint);
    }
}
exports.LCDQueryClient = LCDQueryClient;
