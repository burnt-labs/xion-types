"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AminoConverter = void 0;
//@ts-nocheck
const tx_1 = require("./tx");
exports.AminoConverter = {
    "/xion.feeabs.v1beta1.MsgSendQueryIbcDenomTWAP": {
        aminoType: "/xion.feeabs.v1beta1.MsgSendQueryIbcDenomTWAP",
        toAmino: tx_1.MsgSendQueryIbcDenomTWAP.toAmino,
        fromAmino: tx_1.MsgSendQueryIbcDenomTWAP.fromAmino
    },
    "/xion.feeabs.v1beta1.MsgSwapCrossChain": {
        aminoType: "/xion.feeabs.v1beta1.MsgSwapCrossChain",
        toAmino: tx_1.MsgSwapCrossChain.toAmino,
        fromAmino: tx_1.MsgSwapCrossChain.fromAmino
    },
    "/xion.feeabs.v1beta1.MsgFundFeeAbsModuleAccount": {
        aminoType: "/xion.feeabs.v1beta1.MsgFundFeeAbsModuleAccount",
        toAmino: tx_1.MsgFundFeeAbsModuleAccount.toAmino,
        fromAmino: tx_1.MsgFundFeeAbsModuleAccount.fromAmino
    },
    "/xion.feeabs.v1beta1.MsgUpdateParams": {
        aminoType: "/xion.feeabs.v1beta1.MsgUpdateParams",
        toAmino: tx_1.MsgUpdateParams.toAmino,
        fromAmino: tx_1.MsgUpdateParams.fromAmino
    },
    "/xion.feeabs.v1beta1.MsgAddHostZone": {
        aminoType: "/xion.feeabs.v1beta1.MsgAddHostZone",
        toAmino: tx_1.MsgAddHostZone.toAmino,
        fromAmino: tx_1.MsgAddHostZone.fromAmino
    },
    "/xion.feeabs.v1beta1.MsgUpdateHostZone": {
        aminoType: "/xion.feeabs.v1beta1.MsgUpdateHostZone",
        toAmino: tx_1.MsgUpdateHostZone.toAmino,
        fromAmino: tx_1.MsgUpdateHostZone.fromAmino
    },
    "/xion.feeabs.v1beta1.MsgRemoveHostZone": {
        aminoType: "/xion.feeabs.v1beta1.MsgRemoveHostZone",
        toAmino: tx_1.MsgRemoveHostZone.toAmino,
        fromAmino: tx_1.MsgRemoveHostZone.fromAmino
    }
};
