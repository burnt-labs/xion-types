"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createRpcQueryExtension = exports.QueryClientImpl = void 0;
const binary_1 = require("../../../binary");
const stargate_1 = require("@cosmjs/stargate");
const query_1 = require("./query");
class QueryClientImpl {
    constructor(rpc) {
        this.rpc = rpc;
        this.osmosisArithmeticTwap = this.osmosisArithmeticTwap.bind(this);
        this.feeabsModuleBalances = this.feeabsModuleBalances.bind(this);
        this.hostChainConfig = this.hostChainConfig.bind(this);
        this.allHostChainConfig = this.allHostChainConfig.bind(this);
    }
    osmosisArithmeticTwap(request) {
        const data = query_1.QueryOsmosisArithmeticTwapRequest.encode(request).finish();
        const promise = this.rpc.request("xion.feeabs.v1beta1.Query", "OsmosisArithmeticTwap", data);
        return promise.then(data => query_1.QueryOsmosisArithmeticTwapResponse.decode(new binary_1.BinaryReader(data)));
    }
    feeabsModuleBalances(request = {}) {
        const data = query_1.QueryFeeabsModuleBalacesRequest.encode(request).finish();
        const promise = this.rpc.request("xion.feeabs.v1beta1.Query", "FeeabsModuleBalances", data);
        return promise.then(data => query_1.QueryFeeabsModuleBalacesResponse.decode(new binary_1.BinaryReader(data)));
    }
    hostChainConfig(request) {
        const data = query_1.QueryHostChainConfigRequest.encode(request).finish();
        const promise = this.rpc.request("xion.feeabs.v1beta1.Query", "HostChainConfig", data);
        return promise.then(data => query_1.QueryHostChainConfigResponse.decode(new binary_1.BinaryReader(data)));
    }
    allHostChainConfig(request = {}) {
        const data = query_1.AllQueryHostChainConfigRequest.encode(request).finish();
        const promise = this.rpc.request("xion.feeabs.v1beta1.Query", "AllHostChainConfig", data);
        return promise.then(data => query_1.AllQueryHostChainConfigResponse.decode(new binary_1.BinaryReader(data)));
    }
}
exports.QueryClientImpl = QueryClientImpl;
const createRpcQueryExtension = (base) => {
    const rpc = (0, stargate_1.createProtobufRpcClient)(base);
    const queryService = new QueryClientImpl(rpc);
    return {
        osmosisArithmeticTwap(request) {
            return queryService.osmosisArithmeticTwap(request);
        },
        feeabsModuleBalances(request) {
            return queryService.feeabsModuleBalances(request);
        },
        hostChainConfig(request) {
            return queryService.hostChainConfig(request);
        },
        allHostChainConfig(request) {
            return queryService.allHostChainConfig(request);
        }
    };
};
exports.createRpcQueryExtension = createRpcQueryExtension;
