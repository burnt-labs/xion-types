"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.createRPCQueryClient = void 0;
//@ts-nocheck
const tendermint_rpc_1 = require("@cosmjs/tendermint-rpc");
const stargate_1 = require("@cosmjs/stargate");
const createRPCQueryClient = async ({ rpcEndpoint }) => {
    const tmClient = await tendermint_rpc_1.Tendermint34Client.connect(rpcEndpoint);
    const client = new stargate_1.QueryClient(tmClient);
    return {
        cosmos: {
            app: {
                v1alpha1: (await Promise.resolve().then(() => __importStar(require("../cosmos/app/v1alpha1/query.rpc.Query")))).createRpcQueryExtension(client)
            },
            auth: {
                v1beta1: (await Promise.resolve().then(() => __importStar(require("../cosmos/auth/v1beta1/query.rpc.Query")))).createRpcQueryExtension(client)
            },
            authz: {
                v1beta1: (await Promise.resolve().then(() => __importStar(require("../cosmos/authz/v1beta1/query.rpc.Query")))).createRpcQueryExtension(client)
            },
            autocli: {
                v1: (await Promise.resolve().then(() => __importStar(require("../cosmos/autocli/v1/query.rpc.Query")))).createRpcQueryExtension(client)
            },
            bank: {
                v1beta1: (await Promise.resolve().then(() => __importStar(require("../cosmos/bank/v1beta1/query.rpc.Query")))).createRpcQueryExtension(client)
            },
            base: {
                node: {
                    v1beta1: (await Promise.resolve().then(() => __importStar(require("../cosmos/base/node/v1beta1/query.rpc.Service")))).createRpcQueryExtension(client)
                },
                tendermint: {
                    v1beta1: (await Promise.resolve().then(() => __importStar(require("../cosmos/base/tendermint/v1beta1/query.rpc.Service")))).createRpcQueryExtension(client)
                }
            },
            circuit: {
                v1: (await Promise.resolve().then(() => __importStar(require("../cosmos/circuit/v1/query.rpc.Query")))).createRpcQueryExtension(client)
            },
            consensus: {
                v1: (await Promise.resolve().then(() => __importStar(require("../cosmos/consensus/v1/query.rpc.Query")))).createRpcQueryExtension(client)
            },
            counter: {
                v1: (await Promise.resolve().then(() => __importStar(require("../cosmos/counter/v1/query.rpc.Query")))).createRpcQueryExtension(client)
            },
            distribution: {
                v1beta1: (await Promise.resolve().then(() => __importStar(require("../cosmos/distribution/v1beta1/query.rpc.Query")))).createRpcQueryExtension(client)
            },
            epochs: {
                v1beta1: (await Promise.resolve().then(() => __importStar(require("../cosmos/epochs/v1beta1/query.rpc.Query")))).createRpcQueryExtension(client)
            },
            evidence: {
                v1beta1: (await Promise.resolve().then(() => __importStar(require("../cosmos/evidence/v1beta1/query.rpc.Query")))).createRpcQueryExtension(client)
            },
            feegrant: {
                v1beta1: (await Promise.resolve().then(() => __importStar(require("../cosmos/feegrant/v1beta1/query.rpc.Query")))).createRpcQueryExtension(client)
            },
            gov: {
                v1: (await Promise.resolve().then(() => __importStar(require("../cosmos/gov/v1/query.rpc.Query")))).createRpcQueryExtension(client),
                v1beta1: (await Promise.resolve().then(() => __importStar(require("../cosmos/gov/v1beta1/query.rpc.Query")))).createRpcQueryExtension(client)
            },
            group: {
                v1: (await Promise.resolve().then(() => __importStar(require("../cosmos/group/v1/query.rpc.Query")))).createRpcQueryExtension(client)
            },
            mint: {
                v1beta1: (await Promise.resolve().then(() => __importStar(require("../cosmos/mint/v1beta1/query.rpc.Query")))).createRpcQueryExtension(client)
            },
            nft: {
                v1beta1: (await Promise.resolve().then(() => __importStar(require("../cosmos/nft/v1beta1/query.rpc.Query")))).createRpcQueryExtension(client)
            },
            params: {
                v1beta1: (await Promise.resolve().then(() => __importStar(require("../cosmos/params/v1beta1/query.rpc.Query")))).createRpcQueryExtension(client)
            },
            protocolpool: {
                v1: (await Promise.resolve().then(() => __importStar(require("../cosmos/protocolpool/v1/query.rpc.Query")))).createRpcQueryExtension(client)
            },
            slashing: {
                v1beta1: (await Promise.resolve().then(() => __importStar(require("../cosmos/slashing/v1beta1/query.rpc.Query")))).createRpcQueryExtension(client)
            },
            staking: {
                v1beta1: (await Promise.resolve().then(() => __importStar(require("../cosmos/staking/v1beta1/query.rpc.Query")))).createRpcQueryExtension(client)
            },
            tx: {
                v1beta1: (await Promise.resolve().then(() => __importStar(require("../cosmos/tx/v1beta1/service.rpc.Service")))).createRpcQueryExtension(client)
            },
            upgrade: {
                v1beta1: (await Promise.resolve().then(() => __importStar(require("../cosmos/upgrade/v1beta1/query.rpc.Query")))).createRpcQueryExtension(client)
            }
        },
        xion: {
            feeabs: {
                v1beta1: (await Promise.resolve().then(() => __importStar(require("./feeabs/v1beta1/query.rpc.Query")))).createRpcQueryExtension(client)
            },
            globalfee: {
                v1: (await Promise.resolve().then(() => __importStar(require("./globalfee/v1/query.rpc.Query")))).createRpcQueryExtension(client)
            },
            jwk: {
                v1: (await Promise.resolve().then(() => __importStar(require("./jwk/v1/query.rpc.Query")))).createRpcQueryExtension(client)
            },
            mint: {
                v1: (await Promise.resolve().then(() => __importStar(require("./mint/v1/query.rpc.Query")))).createRpcQueryExtension(client)
            },
            v1: (await Promise.resolve().then(() => __importStar(require("./v1/query.rpc.Query")))).createRpcQueryExtension(client)
        }
    };
};
exports.createRPCQueryClient = createRPCQueryClient;
