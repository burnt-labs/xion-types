"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createRpcQueryExtension = exports.QueryClientImpl = void 0;
const binary_1 = require("../../binary");
const stargate_1 = require("@cosmjs/stargate");
const query_1 = require("./query");
class QueryClientImpl {
    constructor(rpc) {
        this.rpc = rpc;
        this.webAuthNVerifyRegister = this.webAuthNVerifyRegister.bind(this);
        this.webAuthNVerifyAuthenticate = this.webAuthNVerifyAuthenticate.bind(this);
        this.platformPercentage = this.platformPercentage.bind(this);
        this.platformMinimum = this.platformMinimum.bind(this);
    }
    webAuthNVerifyRegister(request) {
        const data = query_1.QueryWebAuthNVerifyRegisterRequest.encode(request).finish();
        const promise = this.rpc.request("xion.v1.Query", "WebAuthNVerifyRegister", data);
        return promise.then(data => query_1.QueryWebAuthNVerifyRegisterResponse.decode(new binary_1.BinaryReader(data)));
    }
    webAuthNVerifyAuthenticate(request) {
        const data = query_1.QueryWebAuthNVerifyAuthenticateRequest.encode(request).finish();
        const promise = this.rpc.request("xion.v1.Query", "WebAuthNVerifyAuthenticate", data);
        return promise.then(data => query_1.QueryWebAuthNVerifyAuthenticateResponse.decode(new binary_1.BinaryReader(data)));
    }
    platformPercentage(request = {}) {
        const data = query_1.QueryPlatformPercentageRequest.encode(request).finish();
        const promise = this.rpc.request("xion.v1.Query", "PlatformPercentage", data);
        return promise.then(data => query_1.QueryPlatformPercentageResponse.decode(new binary_1.BinaryReader(data)));
    }
    platformMinimum(request = {}) {
        const data = query_1.QueryPlatformMinimumRequest.encode(request).finish();
        const promise = this.rpc.request("xion.v1.Query", "PlatformMinimum", data);
        return promise.then(data => query_1.QueryPlatformMinimumResponse.decode(new binary_1.BinaryReader(data)));
    }
}
exports.QueryClientImpl = QueryClientImpl;
const createRpcQueryExtension = (base) => {
    const rpc = (0, stargate_1.createProtobufRpcClient)(base);
    const queryService = new QueryClientImpl(rpc);
    return {
        webAuthNVerifyRegister(request) {
            return queryService.webAuthNVerifyRegister(request);
        },
        webAuthNVerifyAuthenticate(request) {
            return queryService.webAuthNVerifyAuthenticate(request);
        },
        platformPercentage(request) {
            return queryService.platformPercentage(request);
        },
        platformMinimum(request) {
            return queryService.platformMinimum(request);
        }
    };
};
exports.createRpcQueryExtension = createRpcQueryExtension;
