"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AminoConverter = void 0;
//@ts-nocheck
const tx_1 = require("./tx");
exports.AminoConverter = {
    "/xion.v1.MsgSend": {
        aminoType: "xion/MsgSend",
        toAmino: tx_1.MsgSend.toAmino,
        fromAmino: tx_1.MsgSend.fromAmino
    },
    "/xion.v1.MsgMultiSend": {
        aminoType: "xion/MsgMultiSend",
        toAmino: tx_1.MsgMultiSend.toAmino,
        fromAmino: tx_1.MsgMultiSend.fromAmino
    },
    "/xion.v1.MsgSetPlatformPercentage": {
        aminoType: "xion/MsgSetPlatformPercentage",
        toAmino: tx_1.MsgSetPlatformPercentage.toAmino,
        fromAmino: tx_1.MsgSetPlatformPercentage.fromAmino
    },
    "/xion.v1.MsgSetPlatformMinimum": {
        aminoType: "xion/MsgSetPlatformMinimum",
        toAmino: tx_1.MsgSetPlatformMinimum.toAmino,
        fromAmino: tx_1.MsgSetPlatformMinimum.fromAmino
    }
};
