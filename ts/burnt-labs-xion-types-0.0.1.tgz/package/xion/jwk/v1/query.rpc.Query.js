"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createRpcQueryExtension = exports.QueryClientImpl = void 0;
const binary_1 = require("../../../binary");
const stargate_1 = require("@cosmjs/stargate");
const query_1 = require("./query");
class QueryClientImpl {
    constructor(rpc) {
        this.rpc = rpc;
        this.params = this.params.bind(this);
        this.audienceClaim = this.audienceClaim.bind(this);
        this.audience = this.audience.bind(this);
        this.audienceAll = this.audienceAll.bind(this);
        this.validateJWT = this.validateJWT.bind(this);
    }
    params(request = {}) {
        const data = query_1.QueryParamsRequest.encode(request).finish();
        const promise = this.rpc.request("xion.jwk.v1.Query", "Params", data);
        return promise.then(data => query_1.QueryParamsResponse.decode(new binary_1.BinaryReader(data)));
    }
    audienceClaim(request) {
        const data = query_1.QueryGetAudienceClaimRequest.encode(request).finish();
        const promise = this.rpc.request("xion.jwk.v1.Query", "AudienceClaim", data);
        return promise.then(data => query_1.QueryGetAudienceClaimResponse.decode(new binary_1.BinaryReader(data)));
    }
    audience(request) {
        const data = query_1.QueryGetAudienceRequest.encode(request).finish();
        const promise = this.rpc.request("xion.jwk.v1.Query", "Audience", data);
        return promise.then(data => query_1.QueryGetAudienceResponse.decode(new binary_1.BinaryReader(data)));
    }
    audienceAll(request = {
        pagination: undefined
    }) {
        const data = query_1.QueryAllAudienceRequest.encode(request).finish();
        const promise = this.rpc.request("xion.jwk.v1.Query", "AudienceAll", data);
        return promise.then(data => query_1.QueryAllAudienceResponse.decode(new binary_1.BinaryReader(data)));
    }
    validateJWT(request) {
        const data = query_1.QueryValidateJWTRequest.encode(request).finish();
        const promise = this.rpc.request("xion.jwk.v1.Query", "ValidateJWT", data);
        return promise.then(data => query_1.QueryValidateJWTResponse.decode(new binary_1.BinaryReader(data)));
    }
}
exports.QueryClientImpl = QueryClientImpl;
const createRpcQueryExtension = (base) => {
    const rpc = (0, stargate_1.createProtobufRpcClient)(base);
    const queryService = new QueryClientImpl(rpc);
    return {
        params(request) {
            return queryService.params(request);
        },
        audienceClaim(request) {
            return queryService.audienceClaim(request);
        },
        audience(request) {
            return queryService.audience(request);
        },
        audienceAll(request) {
            return queryService.audienceAll(request);
        },
        validateJWT(request) {
            return queryService.validateJWT(request);
        }
    };
};
exports.createRpcQueryExtension = createRpcQueryExtension;
