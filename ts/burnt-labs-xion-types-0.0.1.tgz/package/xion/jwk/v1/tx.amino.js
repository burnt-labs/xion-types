"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AminoConverter = void 0;
//@ts-nocheck
const tx_1 = require("./tx");
exports.AminoConverter = {
    "/xion.jwk.v1.MsgCreateAudienceClaim": {
        aminoType: "/xion.jwk.v1.MsgCreateAudienceClaim",
        toAmino: tx_1.MsgCreateAudienceClaim.toAmino,
        fromAmino: tx_1.MsgCreateAudienceClaim.fromAmino
    },
    "/xion.jwk.v1.MsgDeleteAudienceClaim": {
        aminoType: "/xion.jwk.v1.MsgDeleteAudienceClaim",
        toAmino: tx_1.MsgDeleteAudienceClaim.toAmino,
        fromAmino: tx_1.MsgDeleteAudienceClaim.fromAmino
    },
    "/xion.jwk.v1.MsgCreateAudience": {
        aminoType: "/xion.jwk.v1.MsgCreateAudience",
        toAmino: tx_1.MsgCreateAudience.toAmino,
        fromAmino: tx_1.MsgCreateAudience.fromAmino
    },
    "/xion.jwk.v1.MsgUpdateAudience": {
        aminoType: "/xion.jwk.v1.MsgUpdateAudience",
        toAmino: tx_1.MsgUpdateAudience.toAmino,
        fromAmino: tx_1.MsgUpdateAudience.fromAmino
    },
    "/xion.jwk.v1.MsgDeleteAudience": {
        aminoType: "/xion.jwk.v1.MsgDeleteAudience",
        toAmino: tx_1.MsgDeleteAudience.toAmino,
        fromAmino: tx_1.MsgDeleteAudience.fromAmino
    }
};
