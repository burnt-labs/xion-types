"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.LCDQueryClient = void 0;
//@ts-nocheck
const helpers_1 = require("../../../helpers");
class LCDQueryClient {
    constructor({ requestClient }) {
        this.req = requestClient;
        this.params = this.params.bind(this);
        this.audienceClaim = this.audienceClaim.bind(this);
        this.audience = this.audience.bind(this);
        this.audienceAll = this.audienceAll.bind(this);
        this.validateJWT = this.validateJWT.bind(this);
    }
    /* Parameters queries the parameters of the module. */
    async params(_params = {}) {
        const endpoint = `xion/jwk/params`;
        return await this.req.get(endpoint);
    }
    /* AudienceClaim */
    async audienceClaim(params) {
        const endpoint = `xion/jwk/audience_claim/${params.hash}`;
        return await this.req.get(endpoint);
    }
    /* Queries a list of Audience items. */
    async audience(params) {
        const endpoint = `xion/jwk/audience/${params.aud}`;
        return await this.req.get(endpoint);
    }
    /* AudienceAll */
    async audienceAll(params = {
        pagination: undefined
    }) {
        const options = {
            params: {}
        };
        if (typeof params?.pagination !== "undefined") {
            (0, helpers_1.setPaginationParams)(options, params.pagination);
        }
        const endpoint = `xion/jwk/audience`;
        return await this.req.get(endpoint, options);
    }
    /* Queries a list of ValidateJWT items. */
    async validateJWT(params) {
        const endpoint = `xion/jwk/validate_jwt/${params.aud}/${params.sub}/${params.sigBytes}`;
        return await this.req.get(endpoint);
    }
}
exports.LCDQueryClient = LCDQueryClient;
