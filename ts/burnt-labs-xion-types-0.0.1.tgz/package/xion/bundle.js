"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.xion = void 0;
//@ts-nocheck
const _265 = __importStar(require("./feeabs/v1beta1/epoch"));
const _266 = __importStar(require("./feeabs/v1beta1/genesis"));
const _267 = __importStar(require("./feeabs/v1beta1/osmosisibc"));
const _268 = __importStar(require("./feeabs/v1beta1/params"));
const _269 = __importStar(require("./feeabs/v1beta1/proposal"));
const _270 = __importStar(require("./feeabs/v1beta1/query"));
const _271 = __importStar(require("./feeabs/v1beta1/tx"));
const _272 = __importStar(require("./globalfee/v1/genesis"));
const _273 = __importStar(require("./globalfee/v1/query"));
const _274 = __importStar(require("./jwk/v1/audience"));
const _275 = __importStar(require("./jwk/v1/genesis"));
const _276 = __importStar(require("./jwk/v1/params"));
const _277 = __importStar(require("./jwk/v1/query"));
const _278 = __importStar(require("./jwk/v1/tx"));
const _279 = __importStar(require("./mint/v1/event"));
const _280 = __importStar(require("./mint/v1/genesis"));
const _281 = __importStar(require("./mint/v1/mint"));
const _282 = __importStar(require("./mint/v1/query"));
const _283 = __importStar(require("./mint/v1/tx"));
const _284 = __importStar(require("./v1/feegrant"));
const _285 = __importStar(require("./v1/genesis"));
const _286 = __importStar(require("./v1/query"));
const _287 = __importStar(require("./v1/tx"));
const _453 = __importStar(require("./feeabs/v1beta1/tx.amino"));
const _454 = __importStar(require("./jwk/v1/tx.amino"));
const _455 = __importStar(require("./mint/v1/tx.amino"));
const _456 = __importStar(require("./v1/tx.amino"));
const _457 = __importStar(require("./feeabs/v1beta1/tx.registry"));
const _458 = __importStar(require("./jwk/v1/tx.registry"));
const _459 = __importStar(require("./mint/v1/tx.registry"));
const _460 = __importStar(require("./v1/tx.registry"));
const _461 = __importStar(require("./feeabs/v1beta1/query.lcd"));
const _462 = __importStar(require("./globalfee/v1/query.lcd"));
const _463 = __importStar(require("./jwk/v1/query.lcd"));
const _464 = __importStar(require("./mint/v1/query.lcd"));
const _465 = __importStar(require("./feeabs/v1beta1/query.rpc.Query"));
const _466 = __importStar(require("./globalfee/v1/query.rpc.Query"));
const _467 = __importStar(require("./jwk/v1/query.rpc.Query"));
const _468 = __importStar(require("./mint/v1/query.rpc.Query"));
const _469 = __importStar(require("./v1/query.rpc.Query"));
const _470 = __importStar(require("./feeabs/v1beta1/tx.rpc.msg"));
const _471 = __importStar(require("./jwk/v1/tx.rpc.msg"));
const _472 = __importStar(require("./mint/v1/tx.rpc.msg"));
const _473 = __importStar(require("./v1/tx.rpc.msg"));
const _486 = __importStar(require("./lcd"));
const _487 = __importStar(require("./rpc.query"));
const _488 = __importStar(require("./rpc.tx"));
var xion;
(function (xion) {
    let feeabs;
    (function (feeabs) {
        feeabs.v1beta1 = {
            ..._265,
            ..._266,
            ..._267,
            ..._268,
            ..._269,
            ..._270,
            ..._271,
            ..._453,
            ..._457,
            ..._461,
            ..._465,
            ..._470
        };
    })(feeabs = xion.feeabs || (xion.feeabs = {}));
    let globalfee;
    (function (globalfee) {
        globalfee.v1 = {
            ..._272,
            ..._273,
            ..._462,
            ..._466
        };
    })(globalfee = xion.globalfee || (xion.globalfee = {}));
    let jwk;
    (function (jwk) {
        jwk.v1 = {
            ..._274,
            ..._275,
            ..._276,
            ..._277,
            ..._278,
            ..._454,
            ..._458,
            ..._463,
            ..._467,
            ..._471
        };
    })(jwk = xion.jwk || (xion.jwk = {}));
    let mint;
    (function (mint) {
        mint.v1 = {
            ..._279,
            ..._280,
            ..._281,
            ..._282,
            ..._283,
            ..._455,
            ..._459,
            ..._464,
            ..._468,
            ..._472
        };
    })(mint = xion.mint || (xion.mint = {}));
    xion.v1 = {
        ..._284,
        ..._285,
        ..._286,
        ..._287,
        ..._456,
        ..._460,
        ..._469,
        ..._473
    };
    xion.ClientFactory = {
        ..._486,
        ..._487,
        ..._488
    };
})(xion || (exports.xion = xion = {}));
