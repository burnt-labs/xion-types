"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.tendermint = void 0;
//@ts-nocheck
const _255 = __importStar(require("./abci/types"));
const _256 = __importStar(require("./crypto/keys"));
const _257 = __importStar(require("./crypto/proof"));
const _258 = __importStar(require("./p2p/types"));
const _259 = __importStar(require("./types/block"));
const _260 = __importStar(require("./types/evidence"));
const _261 = __importStar(require("./types/params"));
const _262 = __importStar(require("./types/types"));
const _263 = __importStar(require("./types/validator"));
const _264 = __importStar(require("./version/types"));
var tendermint;
(function (tendermint) {
    tendermint.abci = {
        ..._255
    };
    tendermint.crypto = {
        ..._256,
        ..._257
    };
    tendermint.p2p = {
        ..._258
    };
    tendermint.types = {
        ..._259,
        ..._260,
        ..._261,
        ..._262,
        ..._263
    };
    tendermint.version = {
        ..._264
    };
})(tendermint || (exports.tendermint = tendermint = {}));
