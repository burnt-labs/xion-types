"use strict";
/**
 * CosmWasm Contract Types
 * Auto-generated from contract schemas using @cosmwasm/ts-codegen
 *
 * Types are always available. Client classes and message composers
 * require @interchainjs/* peer dependencies and must be imported
 * directly from their respective files.
 */
Object.defineProperty(exports, "__esModule", { value: true });
