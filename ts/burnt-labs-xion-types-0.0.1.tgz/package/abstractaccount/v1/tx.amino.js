"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AminoConverter = void 0;
//@ts-nocheck
const tx_1 = require("./tx");
exports.AminoConverter = {
    "/abstractaccount.v1.MsgUpdateParams": {
        aminoType: "/abstractaccount.v1.MsgUpdateParams",
        toAmino: tx_1.MsgUpdateParams.toAmino,
        fromAmino: tx_1.MsgUpdateParams.fromAmino
    },
    "/abstractaccount.v1.MsgRegisterAccount": {
        aminoType: "/abstractaccount.v1.MsgRegisterAccount",
        toAmino: tx_1.MsgRegisterAccount.toAmino,
        fromAmino: tx_1.MsgRegisterAccount.fromAmino
    }
};
