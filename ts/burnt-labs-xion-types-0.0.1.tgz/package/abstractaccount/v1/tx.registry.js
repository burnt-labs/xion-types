"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.MessageComposer = exports.load = exports.registry = void 0;
const tx_1 = require("./tx");
exports.registry = [["/abstractaccount.v1.MsgUpdateParams", tx_1.MsgUpdateParams], ["/abstractaccount.v1.MsgRegisterAccount", tx_1.MsgRegisterAccount]];
const load = (protoRegistry) => {
    exports.registry.forEach(([typeUrl, mod]) => {
        protoRegistry.register(typeUrl, mod);
    });
};
exports.load = load;
exports.MessageComposer = {
    encoded: {
        updateParams(value) {
            return {
                typeUrl: "/abstractaccount.v1.MsgUpdateParams",
                value: tx_1.MsgUpdateParams.encode(value).finish()
            };
        },
        registerAccount(value) {
            return {
                typeUrl: "/abstractaccount.v1.MsgRegisterAccount",
                value: tx_1.MsgRegisterAccount.encode(value).finish()
            };
        }
    },
    withTypeUrl: {
        updateParams(value) {
            return {
                typeUrl: "/abstractaccount.v1.MsgUpdateParams",
                value
            };
        },
        registerAccount(value) {
            return {
                typeUrl: "/abstractaccount.v1.MsgRegisterAccount",
                value
            };
        }
    },
    fromPartial: {
        updateParams(value) {
            return {
                typeUrl: "/abstractaccount.v1.MsgUpdateParams",
                value: tx_1.MsgUpdateParams.fromPartial(value)
            };
        },
        registerAccount(value) {
            return {
                typeUrl: "/abstractaccount.v1.MsgRegisterAccount",
                value: tx_1.MsgRegisterAccount.fromPartial(value)
            };
        }
    }
};
