"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.abstractaccount = void 0;
//@ts-nocheck
const _0 = __importStar(require("./v1/account"));
const _1 = __importStar(require("./v1/events"));
const _2 = __importStar(require("./v1/genesis"));
const _3 = __importStar(require("./v1/params"));
const _4 = __importStar(require("./v1/query"));
const _5 = __importStar(require("./v1/tx"));
const _288 = __importStar(require("./v1/tx.amino"));
const _289 = __importStar(require("./v1/tx.registry"));
const _290 = __importStar(require("./v1/query.lcd"));
const _291 = __importStar(require("./v1/query.rpc.Query"));
const _292 = __importStar(require("./v1/tx.rpc.msg"));
const _474 = __importStar(require("./lcd"));
const _475 = __importStar(require("./rpc.query"));
const _476 = __importStar(require("./rpc.tx"));
var abstractaccount;
(function (abstractaccount) {
    abstractaccount.v1 = {
        ..._0,
        ..._1,
        ..._2,
        ..._3,
        ..._4,
        ..._5,
        ..._288,
        ..._289,
        ..._290,
        ..._291,
        ..._292
    };
    abstractaccount.ClientFactory = {
        ..._474,
        ..._475,
        ..._476
    };
})(abstractaccount || (exports.abstractaccount = abstractaccount = {}));
